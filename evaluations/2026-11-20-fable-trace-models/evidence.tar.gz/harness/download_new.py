import pathlib,json,urllib.request,concurrent.futures,threading,hashlib,shutil,os,time,datetime
from gguf_meta import metadata
R=pathlib.Path('/eval');D=pathlib.Path('/models');plan=json.loads((R/'download-plan.json').read_text());reserve=plan['reserve_bytes']
def atomic(p,x):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2));tmp.replace(p)
for m in plan['models']:
 target=D/m['filename'];part=D/(m['filename']+'.newer-eval.part');checkpoint=R/(m['label']+'-ranges.json');begin=time.monotonic();total=m['bytes'];size=(total+3)//4
 progress=json.loads(checkpoint.read_text()) if checkpoint.exists() and part.exists() else [0,0,0,0]
 assert shutil.disk_usage(D).free-(total-sum(progress))>=reserve,'Free-space reserve would be crossed'
 if not target.exists():
  fd=os.open(part,os.O_RDWR|os.O_CREAT,0o644);os.ftruncate(fd,total);lock=threading.RLock();last=[0]
  def publish(force=False):
   with lock:
    if not force and time.monotonic()-last[0]<15:return
    x={'label':m['label'],'phase':'downloading','bytes':sum(progress),'total':total,'percent':round(sum(progress)/total*100,1),'elapsed_seconds':round(time.monotonic()-begin)};atomic(R/'download-status.json',x);atomic(checkpoint,progress);last[0]=time.monotonic();print(json.dumps(x),flush=True)
  def worker(i):
   start=i*size;end=min(total,start+size)-1
   for attempt in range(4):
    first=start+progress[i]
    if first>end:return
    url='https://huggingface.co/'+m['repo']+'/resolve/'+m['revision']+'/'+m['filename']+'?download=true&eval_range='+str(time.time_ns())
    try:
     req=urllib.request.Request(url,headers={'Range':f'bytes={first}-{end}','User-Agent':'Hermes-public-model-evaluation/2.0'})
     with urllib.request.urlopen(req,timeout=90) as response:
      assert response.status==206 and response.headers.get('Content-Range')==f'bytes {first}-{end}/{total}'
      while block:=response.read(4*2**20):
       pos=start+progress[i];assert pos+len(block)<=end+1
       view=memoryview(block)
       while view:
        written=os.pwrite(fd,view,pos);assert written>0;pos+=written;view=view[written:]
       with lock:progress[i]+=len(block)
       publish()
     assert progress[i]==end-start+1;return
    except Exception as e:
     print(json.dumps({'label':m['label'],'segment':i,'attempt':attempt+1,'error_type':type(e).__name__,'http_status':getattr(e,'code',None)}),flush=True)
     if attempt==3:raise
     time.sleep(3)
  publish(True)
  try:
   with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(worker,range(4)))
   os.fsync(fd)
  finally:os.close(fd)
  assert sum(progress)==total;atomic(R/'download-status.json',{'label':m['label'],'phase':'verifying_sha256','total':total})
  with part.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
  assert sha==m['sha256'],'Publisher SHA256 mismatch';part.replace(target);checkpoint.unlink()
 else:
  with target.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
  assert sha==m['sha256']
 assert target.stat().st_size==total
 with target.open('rb') as f:meta=metadata(f)
 rec=m|{'verified_sha256':sha,'gguf_metadata':meta,'seconds':round(time.monotonic()-begin,1),'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes_after':shutil.disk_usage(D).free};atomic(R/(m['label']+'-download.json'),rec);print('VERIFIED',m['label'],flush=True)
atomic(R/'download-status.json',{'phase':'all_downloads_verified','models':len(plan['models'])});print('ALL PUBLIC FILES VERIFIED',flush=True)
