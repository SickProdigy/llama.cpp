import pathlib,json,subprocess,urllib.request,datetime
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
j=json.loads(subprocess.check_output(['docker','inspect','mcp-gitea-hermes']))[0];env=dict(e.split('=',1) for e in j['Config']['Env'] if '=' in e);token=env['GITEA_ACCESS_TOKEN'];base=env['GITEA_HOST'].rstrip('/')
if not base.startswith('http'):base='https://'+base
def req(path,data=None):
 q=urllib.request.Request(base+'/api/v1'+path,data=json.dumps(data).encode() if data is not None else None,headers={'Authorization':'token '+token,'Content-Type':'application/json'},method='PATCH' if data is not None else 'GET');return json.load(urllib.request.urlopen(q))
for p in sorted(R.glob('20261120-fable-cohort-*')):
 if not p.is_dir() or not (p/'state.json').exists() or (p/'issue-cleanup.json').exists():continue
 s=json.loads((p/'state.json').read_text());n=s.get('issue_number')
 if not n:continue
 m=json.loads((p/'manifest.json').read_text());assert m['kind']=='contribution';path='/repos/'+m['upstream_owner']+'/'+m['upstream_repo']+'/issues/'+str(n);i=req(path);assert i['user']['login']=='hermes-agent' and not i.get('pull_request')
 started=json.loads((p/'started.json').read_text())['epoch'];created=datetime.datetime.fromisoformat(i['created_at']).timestamp();assert created>=started-30
 # Preserve body and state before mutating, exclude unrelated user/account metadata.
 (p/'issue-before-cleanup.json').write_text(json.dumps({k:i[k] for k in ['number','title','body','state','html_url','created_at']},indent=2))
 if i['state']=='open':req(path,{'state':'closed'})
 after=req(path);assert after['state']=='closed';(p/'issue-cleanup.json').write_text(json.dumps({'issue_number':n,'url':after['html_url'],'before':i['state'],'after':'closed','comments_added':False,'pull_requests_untouched':True},indent=2));print('Closed newly created test issue',n,flush=True)
