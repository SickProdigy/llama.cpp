import pathlib,json,hashlib,datetime,shutil
R=pathlib.Path('/eval');D=pathlib.Path('/models');plan=json.loads((R/'download-plan.json').read_text());records=[]
for m in plan['models']:
 p=D/m['filename'];proof=json.loads((R/(m['label']+'-download.json')).read_text());assert proof['verified_sha256']==m['sha256'];assert p.stat().st_size==m['bytes']
 rec={k:m[k] for k in ['label','repo','revision','filename','bytes','sha256']}
 if m['label'] in ['qwable9-q5','parable8-q5']:
  with p.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
  assert sha==m['sha256'];p.unlink();rec.update(retained=False,verified_sha256_before_removal=sha,reason='No improvement in this run: selected agent fork on ordinary request, then left MCP for local search; retire this new larger copy, not a universal model-quality judgment.' if m['label']=='qwable9-q5' else 'Stock GGUF/runtime caps loaded context at 40960 rather than the required 98304; retire this new copy without claiming a reasoning failure.')
 else:rec.update(retained=True,reason='Small 4B reading/helper candidate for future spare-GPU testing; 4742 MiB observed on P100, but failed MCP code workflow and selected agent fork. Not an agent-default or measured 2070 result.')
 records.append(rec)
out={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'models':records,'existing_models_untouched':True,'bytes_removed':sum(x['bytes'] for x in records if not x['retained']),'free_bytes_after':shutil.disk_usage(D).free,'reserve_bytes':plan['reserve_bytes'],'local_quantization_or_training':False};assert out['free_bytes_after']>=out['reserve_bytes'];(R/'model-retention.json').write_text(json.dumps(out,indent=2));print(json.dumps({'removed_bytes':out['bytes_removed'],'free_GiB':round(out['free_bytes_after']/2**30,1),'retained_new_models':[x['label'] for x in records if x['retained']]}))
