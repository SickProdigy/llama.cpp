import pathlib,json,subprocess,time,copy,traceback
from driver import Driver,R
for name in ['session.py','guard.py','retry_ledger.py','prepare_profile.py','gitea-focused']:
 subprocess.run(['docker','cp',str(R/name),'hermes-required-store:/eval/'+name],check=True)
source=json.loads((R/'source.json').read_text());original=(R/'original.py').read_text();plan=json.loads((R/'download-plan.json').read_text())
models=[{'label':'fable-control','filename':'Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','alias':'qwen3.6-14b-a3b-fablevibes-q4_k_m'}]+plan['models']
# Same symptom-led prompt and guard as the previous comparison; no patch hints.
ns={};old=pathlib.Path('/tmp/fable-cohort-retained/harness/run_compare.py').read_text();exec(old[old.index("p={'run_id'"):old.index('with Driver() as d:')],{'s':source,'original':original},ns);base=ns['p']
# Exportable cohort manifest, no credentials.
(R/'cohort.json').write_text(json.dumps(models,indent=2))
with Driver() as d:
 for m in models:
  label=m['label']
  if label!='fable-control':
   started=time.monotonic()
   while True:
    proc=subprocess.run(['docker','exec','hermes-required-store','test','-f','/eval/'+label+'-download.json'],capture_output=True)
    if proc.returncode==0:
     subprocess.run(['docker','cp','hermes-required-store:/eval/'+label+'-download.json',str(R/(label+'-download.json'))],check=True);break
    c=json.loads(subprocess.check_output(['docker','inspect','hermes-fable-download']))[0]
    if not c['State']['Running'] or time.monotonic()-started>7200:raise RuntimeError('download missing: '+label)
    time.sleep(10)
  try:d.switch(label,m['filename'],m['alias'])
  except Exception as e:
   (R/(label+'-runtime-failure.json')).write_text(json.dumps({'type':type(e).__name__,'error':str(e)}));print('RUNTIME FAILURE',label,str(e),flush=True);continue
  for task in ['routing','full']:
   p=copy.deepcopy(base);p.update(label=label,phase='fable-trace-cohort',run_id='20261120-fable-cohort-'+label+'-'+task,branch='fable-cohort-'+label+'-20261120',task=task)
   if task=='routing':p.update(kind='read',seconds=180,call_limit=12,prompt='Find my SonicRatings repo and tell me what it does.')
   else:p['prompt']=base['prompt'].replace(base['branch'],p['branch'])
   d.run(p)
print('COHORT COMPLETE',flush=True)
