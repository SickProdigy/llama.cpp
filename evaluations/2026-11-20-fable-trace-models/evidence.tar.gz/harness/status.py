import pathlib,subprocess,json
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
print('\n'.join((R/'cohort.log').read_text().splitlines()[-4:]))
p=subprocess.run(['docker','logs','--tail','1','hermes-fable-download'],capture_output=True,text=True);print((p.stdout+p.stderr).strip())
