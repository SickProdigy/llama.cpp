import ast,json,urllib.request,base64,pathlib
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
def validate(text):
 node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='_bounded_int');ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),'helper','exec'),ns);f=ns['_bounded_int']
 cases=[(float('inf'),20),(float('-inf'),20),(float('nan'),20),(None,20),('bad',20),('12',12),(3,3),(-10,3),(999,200),(42.9,42)]
 rows=[]
 for value,want in cases:
  try:got=f(value,20,3,200);rows.append({'input':repr(value),'expected':want,'actual':got,'pass':got==want})
  except Exception as e:rows.append({'input':repr(value),'expected':want,'exception':type(e).__name__,'pass':False})
 return rows
if __name__=='__main__':
 p=R/'20261120-gemma-real-code-fix';state=json.loads((p/'state.json').read_text());base='https://gitea.rcs1.top/api/v1/repos/';manifest=json.loads((p/'manifest.json').read_text());out={'baseline':validate((R/'original.py').read_text()),'state':state}
 if state.get('commit_present'):
  j=json.load(urllib.request.urlopen(base+'hermes-agent/'+manifest['fork_name']+'/contents/autospamignore/__init__.py?ref='+manifest['branch']));text=base64.b64decode(j['content']).decode();(R/'patched.py').write_text(text);out['patched']=validate(text)
 if state.get('pr_number'):
  n=state['pr_number'];pr=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/pulls/'+str(n)));files=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/pulls/'+str(n)+'/files'));out['pr']={'url':pr['html_url'],'base':pr['base']['ref'],'head':pr['head']['ref'],'head_repo':pr['head']['repo']['full_name'],'body':pr['body'],'files':[f['filename'] for f in files]}
 now=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/branches/main'));before=json.loads((R/'upstream-before.json').read_text());out['upstream_main_unchanged']=now['commit']['id']==before['commit']['id'];(R/'independent-validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
