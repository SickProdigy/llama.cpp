"""Export scored evidence only. Private snapshot/inspect files are never copied."""
import pathlib,json,re,tarfile,io,hashlib,csv,statistics,shutil
r=pathlib.Path('/tmp/hermes-q5-eval'); dest=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-16-q5-repaired');dest.mkdir(exist_ok=True,parents=True)
secrets=set()
sensitive=re.compile(r'key|token|password|secret|credential|authorization|cookie',re.I)
def walk(x,key=''):
 if isinstance(x,dict):
  for k,v in x.items():walk(v,str(k))
 elif isinstance(x,list):
  for v in x:walk(v,key)
 elif isinstance(x,str) and sensitive.search(key) and len(x)>=8 and not x.startswith('${'):secrets.add(x)
for name in ('original-hermes-inspect.json','original-llama-inspect.json'):
 d=json.loads((r/name).read_text());walk(d)
 for obj in d:
  for ev in obj['Config'].get('Env',[]):
   k,_,v=ev.partition('=')
   if sensitive.search(k) and len(v)>=8:secrets.add(v)
with tarfile.open(r/'profile.tgz') as t:
 for name in ('.env','auth.json','config.yaml'):
  data=t.extractfile(name).read().decode()
  if name.endswith('.json'):walk(json.loads(data))
  else:
   for line in data.splitlines():
    m=re.match(r'\s*([\w.-]+)\s*[:=]\s*(.+?)\s*$',line)
    if m and sensitive.search(m[1]):
     v=m[2].strip().strip('\"\'')
     if len(v)>=8 and not v.startswith('${'):secrets.add(v)
# Parsed privately using the shipped Hermes YAML parser; never exported.
walk(json.loads((r/'private-config-parsed.json').read_text()))
secrets=sorted(secrets,key=len,reverse=True)
def clean(data):
 text=data.decode('utf-8')
 for secret in secrets:
  text=text.replace(secret,'[REDACTED]')
  escaped=json.dumps(secret)[1:-1]
  if escaped!=secret:text=text.replace(escaped,'[REDACTED]')
 text=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9_.~+/=-]{12,}',r'\1[REDACTED]',text)
 text=re.sub(r'(https?://)[^/\s:@]+:[^/\s@]+@',r'\1[REDACTED]@',text)
 text=re.sub(r'(?i)([?&](?:access_token|refresh_token|api_key|authorization_code|code|state)=)[^&\s\"<>]+',r'\1[REDACTED]',text)
 return text.encode()
files=[]
for p in (r/'scored').rglob('*'):
 if p.is_file():files.append((p,'runs/'+str(p.relative_to(r/'scored'))))
for name in ('deploy_profile.py','save_rollback.py','verify_deployment.py','deployment.json','deployment-verification.json','post-deployment-mcp.json','post-deployment-plugin.json','rollback-backup.json','routing-reviews.json','test_readable_defaults.py','plugin_preflight.py','launch.py','repair_profile.py','preflight.py','preflight-backend.log','download-verified.json','download.json','run.py','session.py','batch.py','summarize.py','watchdog.py','controller.py','fixtures.py','export.py','history-metrics.py','verify-restored-mcp.py','verify-runtime.py','original-file-hashes.json','restoration.json','restored-mcp.json','fixtures.json','fixture-cog-catalog.json','manual-grades.json','runtime-metadata.json','mcp-version.json','comparison-controls.json','grading-sources.json','render.py','controller.log','watchdog.log','vibeforged-repaired-backend.log','qwen9-q5-repaired-backend.log'):
 if (r/name).exists():files.append((r/name,'harness/'+name))
for folder in ['gitea-readable-defaults','plugin-preflight','diagnostics']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in str(p):files.append((p,folder+'/'+str(p.relative_to(r/folder))))
for p in (r/'preflight').glob('*'):
 if p.is_file():files.append((p,'preflight/'+p.name))
for p in r.glob('*-gpu.json'):files.append((p,'gpu/'+p.name))
for p in r.glob('*-idle-gpu.txt'):files.append((p,'gpu/'+p.name))
manifest=[]
with tarfile.open(dest/'evidence.tar.gz','w:gz') as t:
 for p,name in sorted(files,key=lambda x:x[1]):
  data=clean(p.read_bytes())
  assert not any(s.encode() in data for s in secrets),'Unsanitized evidence'
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data));manifest.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(dest/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2))
rows=json.loads((r/'scored/scores-draft.json').read_text());grades=json.loads((r/'manual-grades.json').read_text())
fields=['run','model_file_reads','model_readable_flags','model_bounded_read_flags','file_reads','readable_file_reads','bounded_file_reads','admin_mutation_attempts','blocked_remote_writes','first_call_seconds','peak_gpu_mib','seconds','model_tool_calls','underlying_dispatches','gitea_repo_successes','github_attempts','connection_calls','tool_errors','prompt_tokens','completion_tokens','cache_read_tokens','last_prompt_tokens','compression_count','spill_count','timed_out','routing_pass','task','count','grounding','note','first_tool','compression_attempts','completed','exit_reasons']
with (dest/'runs.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for x in rows:
  v={k:x.get(k) for k in fields};v.update(grades.get(x['run'],{}));v={k:v.get(k) for k in fields};v['routing_pass']=x['gitea_repo_successes']>0 and x['github_attempts']==0
  model_reads=[c['args'] for c in x['calls'] if c['name']=='mcp__mcp_gitea_hermes__get_file_contents' and isinstance(c.get('args'),dict)]
  v['model_file_reads']=len(model_reads);v['model_readable_flags']=sum(c.get('with_lines') is True for c in model_reads);v['model_bounded_read_flags']=sum(isinstance(c.get('end_line'),int) and c.get('end_line',0)>0 for c in model_reads)
  cp=r/'scored'/x['run']/'calls.json';dispatches=json.loads(cp.read_text()) if cp.exists() else [];reads=[c for c in dispatches if c['name'].endswith('__get_file_contents')];v['file_reads']=len(reads);v['readable_file_reads']=sum(c['args'].get('with_lines') is True for c in reads);v['bounded_file_reads']=sum(c['args'].get('with_lines') is True and isinstance(c['args'].get('end_line'),int) and c['args']['end_line']>=max(1,c['args'].get('start_line') or 1) for c in reads);v['admin_mutation_attempts']=sum(c['name']=='manage_connections' and c['args'].get('action','status') not in ('status','display') for c in dispatches);v['blocked_remote_writes']=sum(c.get('blocked',False) and c['name'].startswith('mcp__') for c in dispatches)
  log=(r/'scored'/x['run']/'agent.log').read_text() if (r/'scored'/x['run']/'agent.log').exists() else ''
  first=re.search(r'API call #1: .*?latency=([0-9.]+)s',log);v['first_call_seconds']=float(first[1]) if first else None
  gpu=r/(x['run']+'-gpu.json');samples=json.loads(gpu.read_text()) if gpu.exists() else [];v['peak_gpu_mib']=max((int(a['gpu'].split(',')[0]) for a in samples if re.match(r'^\d+,',a.get('gpu',''))),default=None)
  for k in ('first_tool','compression_attempts','completed','exit_reasons'):v[k]=json.dumps(v[k],ensure_ascii=False)
  w.writerow(v)
summary=[]
for prefix in sorted({re.sub(r'-L\d-R\d$','',x['run']) for x in rows}):
 group=[x for x in rows if x['run'].startswith(prefix+'-L')]
 if 'history' in prefix:continue
 n=len(group);route=lambda x:x['gitea_repo_successes']>0 and x['github_attempts']==0
 passed=lambda x:grades.get(x['run'],{}).get('task','').startswith('Pass')
 summary.append({'candidate':prefix,'n':n,'gitea':sum(x['gitea_repo_successes']>0 for x in group),'github':sum(x['github_attempts']>0 for x in group),'routing_pass':sum(route(x) for x in group),'content_pass':sum(passed(x) for x in group),'partial':sum(grades.get(x['run'],{}).get('task')=='Partial' for x in group),'combined_pass':sum(route(x) and passed(x) for x in group),'timeouts':sum(x['timed_out'] for x in group),'median_seconds':round(statistics.median(x['seconds'] for x in group),1)})
(dest/'aggregate.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print('Sanitized files:',len(manifest))

if (r/'history-turns.csv').exists():(dest/'history-turns.csv').write_bytes(clean((r/'history-turns.csv').read_bytes()))
