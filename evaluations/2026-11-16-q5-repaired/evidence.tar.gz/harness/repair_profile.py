"""Apply the proposed local-provider profile repair to a disposable Hermes home."""
from pathlib import Path
import re,json,shutil
import hermes_yaml as yaml

def apply(home):
 p=Path(home);cfg=yaml.safe_load((p/'config.yaml').read_text());cfg.setdefault('auxiliary',{}).setdefault('compression',{})['extra_body']={'max_tokens':8192,'chat_template_kwargs':{'enable_thinking':False}}
 cfg.setdefault('plugins',{}).setdefault('enabled',[])
 if 'gitea-readable-defaults' not in cfg['plugins']['enabled']:cfg['plugins']['enabled'].append('gitea-readable-defaults')
 shutil.copytree(Path(__file__).parent/'gitea-readable-defaults',p/'plugins/gitea-readable-defaults',dirs_exist_ok=True)
 cfg['tools']=dict(cfg.get('tools') or {});cfg['tools'].setdefault('tool_search',{})['enabled']='off'
 disabled=cfg['agent'].setdefault('disabled_toolsets',[])
 if 'connections' not in disabled:disabled.append('connections')
 cfg['platform_toolsets']['cli']=[x for x in cfg['platform_toolsets']['cli'] if x!='connections']
 cfg['agent']['environment_hint']='Hermes data and workspace files live under /opt/data. For the owner\'s repositories, including sickprodigy/name and repository-name-only requests, use the configured Gitea MCP service first whether the repository is public or private. Use the actual registered mcp__mcp_gitea_hermes__ tools; never guess a GitHub URL or change connections to find an owner repository. If a repository name is supplied without an owner, search_repos returns its exact full_name, default branch and URL. For a known owner/repo, inspect its root directory directly. For source text, call mcp__mcp_gitea_hermes__get_file_contents with with_lines: true, start_line: 1, end_line: 160; adjust a bounded line range only when the task needs more evidence. Use get_dir_contents for directories, not get_file_contents. Do not copy base64 into code when readable file output is available. Check active branches and repository-specific conventions before claiming a proposed feature is absent. Report repository facts from actual tool results and state missing evidence instead of inventing details. Keep web search for external research. Do not write to repositories unless explicitly asked.'
 changes=[]
 for f in (p/'skills'/'gitea').rglob('*.md'):
  s=f.read_text();new=re.sub(r'(?<![\w])mcp_gitea_([A-Za-z0-9_*]+)',r'mcp__mcp_gitea_hermes__\1',s)
  if new!=s:f.write_text(new);changes.append(str(f.relative_to(p)))
 f=p/'skills/gitea/gitea-workflow/SKILL.md';s=f.read_text().replace("user's private Gitea service","user's configured Gitea service").replace("user's private repositories","user's repositories, whether public or private")
 s=s.replace('## Routing\n','## Routing\n\n- For text files request `with_lines: true` and a finite `start_line`/`end_line` range (start with lines 1-160). This returns readable source; raw API JSON can instead contain base64.\n')
 f.write_text(s)
 f=p/'skills/gitea/gitea-repo-management/SKILL.md'
 f.write_text("""---
name: gitea-repo-management
description: Use the configured Gitea MCP first for the owner's repository searches and reviews, including public repositories. Prefer readable bounded file excerpts.
version: 1.2.0
---

# Gitea Repository Management

Use `mcp__mcp_gitea_hermes__search_repos` for an unknown repository name;
report the exact owner/name/default branch/URL from its result. For an explicit
owner/repo, inspect `mcp__mcp_gitea_hermes__get_dir_contents` at the root.
The owner's source of truth is configured Gitea, whether public or private.

Read source using `mcp__mcp_gitea_hermes__get_file_contents` with
`with_lines: true`, `start_line: 1`, `end_line: 160`, and the required
owner/repo/path/ref. Narrow or advance the range when needed. Directory paths
belong in `get_dir_contents`. Do not paste base64 into generated code to read
text. Raw file downloads are raw bytes; an API JSON object may contain base64.

Consult repository-specific conventions and active development branches before
claiming a feature is absent. Ground descriptions in returned text. For failed
reads, correct the path/ref once using a directory listing; an argument error
is not evidence of broken credentials or a missing repository. Do not change
connections or switch to GitHub to bypass a failed configured-service read.

Do not perform repository mutations during review. Use the actual registered
write tool schema only when the user explicitly requests that operation.
Never infer tool availability or permissions from this skill's examples.
""")
 f=p/'skills/gitea/gitea-repo-management/references/gitea-mcp-tools.md'
 f.write_text("# Configured Gitea MCP tools\n\nThe runtime namespace is `mcp__mcp_gitea_hermes__`. Discover or inspect actual schemas; do not assume a method is allowed because a generic tool advertises it.\n\nRead tools: get_me, search_users, search_repos, get_repository_tree, get_dir_contents, get_file_contents, branch_read, commit_read, issue_read, list_issues, search_issues, label_read, pull_request_read, list_pull_requests, repo_read, wiki_read.\n\nWrite tools: branch_write, create_or_update_file, delete_file, issue_write, label_write, pull_request_write, pull_request_review_write, repo_write, wiki_write. Use only with explicit authorization.\n\nFor source text request with_lines: true and finite start_line/end_line bounds. For directories use get_dir_contents. The configured service rejected repo_read(method=\"get\") in verification; use supported directory/tree/file reads instead. This is a method restriction, not an authentication diagnosis.\n")
 (p/'config.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
 return cfg
if __name__=='__main__':
 import sys;apply(sys.argv[1])
