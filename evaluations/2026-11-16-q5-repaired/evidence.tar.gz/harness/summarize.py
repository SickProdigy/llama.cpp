import json,pathlib,re,collections,sys
root=pathlib.Path(sys.argv[1])
def payload(content):
 if not isinstance(content,str): return content
 try: return json.loads(content)
 except Exception: pass
 for match in re.finditer(r'[\{\[]',content):
  try: return json.JSONDecoder().raw_decode(content[match.start():])[0]
  except Exception: pass
 return {}
def errors(v):
 if isinstance(v,dict):
  if v.get('error') or v.get('success') is False or v.get('status')=='error' or (isinstance(v.get('exit_code'),int) and v['exit_code']!=0):
   err=str(v.get('error') or v.get('output') or v)
   return [err if len(err)<=700 else err[:200]+' ... '+err[-500:]]
  return [x for k,w in v.items() if k not in ('arguments','args') for x in errors(w)]
 if isinstance(v,list): return [x for w in v for x in errors(w)]
 return []
rows=[]
for p in sorted(root.glob('*/summary.json')):
 d=p.parent; s=json.loads(p.read_text()); results=json.loads((d/'result.json').read_text()) if (d/'result.json').exists() else []
 all_calls=[]; failures=[]; answers=[]; seen_calls=set(); seen_results=set(); message_sources=[]
 for request_path in sorted(d.glob('request-*.json')):
  try: message_sources.append(json.loads(request_path.read_text()).get('messages',[]))
  except Exception: pass
 message_sources.extend(r.get('messages',[]) for r in results)
 for messages in message_sources:
  for m in messages:
   if m.get('role')=='assistant':
    for tc in m.get('tool_calls',[]):
     f=tc.get('function',{}); a=f.get('arguments',{})
     ident=tc.get('id') or json.dumps(tc,sort_keys=True)
     if ident in seen_calls: continue
     seen_calls.add(ident)
     if isinstance(a,str):
      try:a=json.loads(a)
      except Exception:pass
     all_calls.append({'name':f.get('name'),'args':a})
   if m.get('role')=='tool':
    ident=m.get('tool_call_id') or json.dumps(m,sort_keys=True)
    if ident in seen_results: continue
    seen_results.add(ident)
    for err in errors(payload(m.get('content',''))): failures.append({'tool':m.get('name'),'error':err})
 for r in results: answers.append(r.get('final_response',''))
 calls=json.loads((d/'calls.json').read_text()) if (d/'calls.json').exists() else []
 github=[c for c in all_calls if not (str(c.get('name') or '').startswith('mcp__mcp_gitea_hermes__') or (c['name']=='tool_call' and isinstance(c['args'],dict) and c['args'].get('calls') and all(str(x.get('name','')).startswith('mcp__mcp_gitea_hermes__') for x in c['args']['calls']))) and re.search(r'githubusercontent\.com|github\.com|\bgithub\b|\bgh\s+(?:repo|issue|api)',json.dumps(c['args']),re.I)]
 gitea=[c for c in calls if 'gitea' in c['name'] and not errors(payload(c.get('result','')))]
 gitea_repo=[c for c in gitea if not c['name'].endswith(('__get_me','__search_users'))]
 admins=[c for c in all_calls if c['name']=='manage_connections']
 # execute_code may embed tool calls; preserve all source arguments alongside dispatch records.
 usage=s.get('usage',{})
 log=(d/'agent.log').read_text() if (d/'agent.log').exists() else ''
 compressions=re.findall(r'Compression #([0-9]+) complete',log)
 attempts=[]
 for match in re.finditer(r'context compression attempt telemetry: (.*)',log):
  try: attempts.append(json.loads(match.group(1)))
  except Exception: pass
 row={'run':d.name,'seconds':round(s['elapsed'],1),'first_tool':all_calls[0] if all_calls else None,'model_tool_calls':len(all_calls),'underlying_dispatches':len(calls),'gitea_successes':len(gitea),'gitea_repo_successes':len(gitea_repo),'github_attempts':len(github),'connection_calls':len(admins),'tool_errors':len(failures),'prompt_tokens':usage.get('session_prompt_tokens'),'completion_tokens':usage.get('session_completion_tokens'),'cache_read_tokens':usage.get('session_cache_read_tokens'),'last_prompt_tokens':usage.get('_last_prompt_size_tokens'),'compression_count':max(map(int,compressions),default=0),'compression_attempts':attempts,'spill_count':len(re.findall('Persisted large tool result:',log)),'timed_out':(d/'timeout.json').exists(),'completed':[r.get('completed') for r in results],'exit_reasons':[r.get('turn_exit_reason') for r in results],'answers':answers,'failures':failures,'calls':all_calls}
 rows.append(row)
 print(row['run'],row['seconds'],'first',row['first_tool'],'tools',row['model_tool_calls'],'gitea',len(gitea),'github_flags',len(github),'errors',len(failures))
reviews_path=root.parent/'routing-reviews.json'
reviews=json.loads(reviews_path.read_text()) if reviews_path.exists() else {}
for row in rows:
 if row['run'] in reviews:
  row['github_lexical_flags']=row['github_attempts']
  row['github_attempts']=reviews[row['run']]['actual_github_attempts']
  row['github_review']=reviews[row['run']]['note']
(root/'scores-draft.json').write_text(json.dumps(rows,indent=2))
