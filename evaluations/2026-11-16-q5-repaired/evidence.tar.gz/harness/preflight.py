import sys,pathlib,tarfile,json,time
sys.path.insert(0,'/opt/hermes');sys.path.insert(0,'/eval')
p=pathlib.Path('/opt/data');p.mkdir(exist_ok=True)
with tarfile.open('/eval/profile.tgz') as t:t.extractall(p,filter='data')
from repair_profile import apply
cfg=apply(p)
import httpx
captured=[];responses=[];send=httpx.Client.send
def capture(self,request,*a,**kw):
 if '/chat/completions' in str(request.url):captured.append(json.loads(request.content))
 result=send(self,request,*a,**kw)
 if '/chat/completions' in str(request.url):
  try:responses.append(result.json())
  except Exception:pass
 return result
httpx.Client.send=capture
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
names=discover_mcp_tools()
def call(name,args):
 raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__'+name,args);d=json.loads(raw);assert 'error' not in d,d
 return d
read=call('get_file_contents',{'owner':'sickprodigy','repo':'SonicRatings','path':'README.md','ref':'main','with_lines':True,'start_line':1,'end_line':24})
from hermes_cli.tools_config import _get_platform_tools
selected=sorted(_get_platform_tools(cfg,'discord'))
assert 'connections' not in selected,selected
from run_agent import AIAgent
a=AIAgent(model=cfg['model']['default'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',max_iterations=30,max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
schemas=a.tools;assert any(t['function']['name']=='mcp__mcp_gitea_hermes__get_file_contents' for t in schemas),[t['function']['name'] for t in schemas]
assert not any(t['function']['name']=='manage_connections' for t in schemas)
from agent.context_compressor import ContextCompressor
c=ContextCompressor(model=cfg['model']['default'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',config_context_length=98304,max_tokens=4096,quiet_mode=True)
prompt='Produce a handoff summary in numbered form. Keep all 60 facts below, each on its own line. Include its exact project identifier and deployment port. Do not add facts.\n'+'\n'.join(f'Project fixture-{i:03d} deploys port {9100+i}; owner approved read-only inspection and requires configuration preservation.' for i in range(60))
t=time.monotonic();summary=c._call_summary_llm(prompt,t)
assert captured and captured[-1].get('max_tokens')==8192,captured[-1].keys()
assert captured[-1].get('chat_template_kwargs',{}).get('enable_thinking') is False
missing=[i for i in range(60) if f'fixture-{i:03d}' not in summary or str(9100+i) not in summary]
out=pathlib.Path('/eval/preflight');out.mkdir(exist_ok=True)
for name,value in [('requests',captured),('responses',responses),('schemas',schemas),('readable-file',read)]: (out/(name+'.json')).write_text(json.dumps(value,indent=2))
(out/'summary.txt').write_text(summary)
result={'summary_seconds':time.monotonic()-t,'missing_fixture_facts':missing,'summary_wire_cap':captured[-1].get('max_tokens'),'summary_disable_thinking':True,'readable_file_succeeded':True,'direct_gitea_schemas':sum('mcp__mcp_gitea_hermes__' in x['function']['name'] for x in schemas),'discord_toolsets':selected,'schema_count':len(schemas),'completion_tokens':responses[-1].get('usage',{}).get('completion_tokens') if responses else None}
(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));assert not missing,missing
a.close()
