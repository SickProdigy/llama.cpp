import pathlib,json,time,subprocess
r=pathlib.Path('/tmp/hermes-q5-eval');expected=json.loads((r/'download.json').read_text());filename=expected['path'];part='/models/'+filename+'.part'
try:
 for _ in range(60):
  p=subprocess.run(['docker','exec','llama-cpp','stat','-c','%s',part],capture_output=True,text=True)
  if p.returncode==0 and int(p.stdout.strip())==expected['size']:break
  time.sleep(15)
 else:raise RuntimeError('Model download did not complete in fifteen minutes')
 got=subprocess.check_output(['docker','exec','llama-cpp','sha256sum',part],text=True).split()[0]
 assert got==expected['lfs']['oid'],'Downloaded model hash mismatch'
 subprocess.run(['docker','exec','llama-cpp','mv',part,'/models/'+filename],check=True)
 (r/'download-verified.json').write_text(json.dumps({'filename':filename,'bytes':expected['size'],'sha256':got,'source':'https://huggingface.co/unsloth/Qwen3.5-9B-GGUF','verified':True},indent=2))
 with open(r/'watchdog.log','w') as f:
  proc=subprocess.Popen(['python3',str(r/'watchdog.py')],stdout=f,stderr=subprocess.STDOUT);(r/'watchdog.pid').write_text(str(proc.pid))
 with open(r/'controller.log','w') as f:subprocess.run(['python3',str(r/'controller.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
except BaseException:
 subprocess.run(['docker','start','llama-cpp'],stdout=subprocess.DEVNULL);subprocess.run(['docker','start','hermes'],stdout=subprocess.DEVNULL);raise
