import pathlib,json,subprocess,hashlib,urllib.request,datetime,tarfile
r=pathlib.Path('/tmp/hermes-q5-eval');result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'containers':{},'changed_source_files':[]}
for name,filename in [('hermes','original-hermes-inspect.json'),('llama-cpp','original-llama-inspect.json')]:
 old=json.loads((r/filename).read_text())[0];now=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
 checks={'same_container':old['Id']==now['Id'],'same_image':old['Image']==now['Image'],'same_environment':old['Config']['Env']==now['Config']['Env'],'same_command':old['Config']['Cmd']==now['Config']['Cmd'],'same_mounts':old['Mounts']==now['Mounts'],'same_ports':old['HostConfig']['PortBindings']==now['HostConfig']['PortBindings'],'running':now['State']['Running']};assert all(checks.values()),name;result['containers'][name]=checks
for fn,expected in json.loads((r/'original-file-hashes.json').read_text()).items():
 actual=hashlib.sha256(pathlib.Path(fn).read_bytes()).hexdigest()
 if actual!=expected:
  assert fn.endswith('/hermes-agent/data/config.yaml') or '/hermes-agent/data/skills/gitea/' in fn,fn
  result['changed_source_files'].append(fn)
with tarfile.open(r/'profile.tgz') as t:
 result['unchanged_identity_files']={}
 for name in ['.env','auth.json','SOUL.md','skills/sick-cogs-conventions/SKILL.md']:
  expected=hashlib.sha256(t.extractfile(name).read()).hexdigest()
  code='from pathlib import Path;import hashlib;print(hashlib.sha256(Path('+repr('/opt/data/'+name)+').read_bytes()).hexdigest())'
  actual=subprocess.check_output(['docker','exec','hermes','python','-c',code],text=True).strip();assert actual==expected,name;result['unchanged_identity_files'][name]=True
for name in ['__init__.py','plugin.yaml']:
 path=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers/hermes-agent/data/plugins/gitea-readable-defaults')/name
 assert path.read_bytes()==(r/'gitea-readable-defaults'/name).read_bytes()
with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=10) as f:p=json.load(f)
assert p['model_alias']=='qwen3.6-14b-a3b-vibeforged-v2-q4_k_m' and p['default_generation_settings']['n_ctx']==98304
result['backend']={'alias':p['model_alias'],'context':98304,'build':p['build_info']}
with urllib.request.urlopen('http://192.168.86.239:11430/health',timeout=10) as f:result['backend_health']=json.load(f)
processes=subprocess.check_output(['docker','top','hermes','-eo','pid,args'],text=True);result['gateway_process_present']=any('gateway' in line and 'hermes' in line for line in processes.splitlines());assert result['gateway_process_present']
result['plugin_native_check']=json.loads((r/'post-deployment-plugin.json').read_text());result['authenticated_gitea_check']=json.loads((r/'post-deployment-mcp.json').read_text());assert result['authenticated_gitea_check']['login']=='hermes-agent'
(r/'deployment-verification.json').write_text(json.dumps(result,indent=2));print('Deployed profile verified: same containers/images/env/ports/model/context; intended source changes only; credentials/SOUL/Sick-Cogs skill preserved; native hook and authenticated Gitea fixture reads passed')
