import subprocess,time,json,pathlib,sys
root=pathlib.Path('/tmp/hermes-q5-eval'); label=sys.argv[1]; context=int(sys.argv[2]); model=sys.argv[3]; variant=sys.argv[4] if len(sys.argv)>4 else 'repaired'; sequence=variant.endswith('sequence')
image=json.load(open(root/'original-hermes-inspect.json'))[0]['Image']
for level in ((1,) if sequence else (1,2,3)):
 for rep in ((1,) if sequence else (1,2,3)):
  print('START',label,level,rep,flush=True)
  with open(root/f'{label}-L{level}-R{rep}.log','w') as f:
   cmd=['docker','run','--rm','--name','hermes-routing-session','--network','homelab','--mount','type=volume,source=hermes-routing-evidence,target=/eval','-e','HERMES_HOME=/opt/data','-e','PYTHONUNBUFFERED=1','--entrypoint','python',image,'/eval/session.py',label,str(level),str(rep),model,str(context),variant]
   proc=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT); start=time.monotonic();samples=[]
   while proc.poll() is None:
    active=subprocess.run(['docker','inspect','-f','{{.State.Running}}','llama-routing-eval'],capture_output=True,text=True).stdout.strip()=='true'
    backend='llama-routing-eval' if active else 'llama-cpp'
    gpu=subprocess.run(['docker','exec',backend,'nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True)
    samples.append({'elapsed':time.monotonic()-start,'gpu':gpu.stdout.strip()});(root/f'{label}-L{level}-R{rep}-gpu.json').write_text(json.dumps(samples))
    if time.monotonic()-start>1800:
     subprocess.run(['docker','stop','-t','5','hermes-routing-session']);break
    time.sleep(5)
   proc.wait()
  print('END',label,level,rep,proc.returncode,round(time.monotonic()-start,1),flush=True)
  if proc.returncode:
   timed_out=subprocess.run(['docker','exec','hermes-routing-store','test','-f',f'/eval/results/{label}-L{level}-R{rep}/timeout.json']).returncode==0
   if not timed_out: raise RuntimeError(f'Run failed before a scored result: {label} L{level} R{rep}; inspect console log')
