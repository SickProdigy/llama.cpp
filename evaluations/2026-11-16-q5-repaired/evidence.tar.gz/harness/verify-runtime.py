import pathlib,json,subprocess,urllib.request,hashlib,datetime,tarfile
r=pathlib.Path('/tmp/hermes-q5-eval');result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'containers':{},'files':{}}
for name,source in [('hermes','original-hermes-inspect.json'),('llama-cpp','original-llama-inspect.json')]:
 original=json.loads((r/source).read_text())[0];current=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
 d={'same_container':current['Id']==original['Id'],'same_image':current['Image']==original['Image'],'image_id':current['Image'],'same_command':current['Config']['Cmd']==original['Config']['Cmd'],'same_environment':current['Config']['Env']==original['Config']['Env'],'same_mounts':current['Mounts']==original['Mounts'],'same_port_bindings':current['HostConfig'].get('PortBindings')==original['HostConfig'].get('PortBindings'),'same_network_mode':current['HostConfig'].get('NetworkMode')==original['HostConfig'].get('NetworkMode'),'running':current['State']['Running'],'health':current['State'].get('Health',{}).get('Status')}
 assert all(v for k,v in d.items() if k.startswith('same_')) and d['running'],name+' was not restored'
 assert d['health'] in (None,'healthy'),name+' is not healthy yet'
 result['containers'][name]=d
for filename,expected in json.loads((r/'original-file-hashes.json').read_text()).items():
 match=hashlib.sha256(pathlib.Path(filename).read_bytes()).hexdigest()==expected;result['files'][filename]=match;assert match,'Original source file changed: '+filename
with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=10) as f:p=json.load(f)
assert p['model_alias']=='qwen3.6-14b-a3b-vibeforged-v2-q4_k_m' and p['default_generation_settings']['n_ctx']==98304
result['backend']={'alias':p['model_alias'],'context':p['default_generation_settings']['n_ctx'],'slots':p['total_slots'],'caps':p['chat_template_caps'],'build':p['build_info']}
with urllib.request.urlopen('http://192.168.86.239:11430/health',timeout=10) as f:result['backend_health']=json.load(f)
processes=subprocess.check_output(['docker','top','hermes','-eo','pid,args'],text=True)
result['gateway_process_present']=any('gateway' in line and 'hermes' in line for line in processes.splitlines())
assert result['gateway_process_present'],'Native Hermes gateway process absent'
result['gpu']=subprocess.check_output(['docker','exec','llama-cpp','nvidia-smi','--query-gpu=name,memory.used,memory.total,utilization.gpu','--format=csv'],text=True).strip()
expected_mcp=json.loads((r/'mcp-version.json').read_text())['image_id']
current_mcp=json.loads(subprocess.check_output(['docker','inspect','mcp-gitea-hermes'],text=True))[0]['Image']
result['mcp_image_unchanged']=expected_mcp==current_mcp
assert result['mcp_image_unchanged']
result['live_profile_hashes_unchanged']={}
with tarfile.open(r/'profile.tgz') as t:
 for name in ['config.yaml','.env','auth.json','SOUL.md','AGENTS.md']:
  try:expected=hashlib.sha256(t.extractfile(name).read()).hexdigest()
  except KeyError:continue
  code='import pathlib,hashlib;print(hashlib.sha256(pathlib.Path('+repr('/opt/data/'+name)+').read_bytes()).hexdigest())'
  actual=subprocess.check_output(['docker','exec','hermes','python','-c',code],text=True).strip()
  result['live_profile_hashes_unchanged'][name]=expected==actual
  assert expected==actual,name+' changed'
(r/'restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
