import sys,pathlib,tarfile,runpy,json,urllib.request
sys.path.insert(0,'/opt/hermes')
import hermes_yaml as yaml
label,level,rep,model,ctx,variant=sys.argv[1:7]
p=pathlib.Path('/opt/data');p.mkdir(exist_ok=True)
with tarfile.open('/eval/profile.tgz') as t:t.extractall(p,filter='data')
(p/'workspace').mkdir(exist_ok=True)
c=yaml.safe_load((p/'config.yaml').read_text());c['model']['default']=model;c['model']['context_length']=int(ctx)
(p/'config.yaml').write_text(yaml.safe_dump(c,sort_keys=False))
if variant.startswith('repaired'):
 from repair_profile import apply
 apply(p)
with urllib.request.urlopen('http://llama:11430/props',timeout=10) as f:props=json.load(f)
assert props['model_alias']==model and props['default_generation_settings']['n_ctx']==int(ctx)
ref=json.loads(pathlib.Path('/eval/reference-props.json').read_text())
for k in ('temperature','dynatemp_range','top_k','top_p','min_p','repeat_penalty','presence_penalty','frequency_penalty','seed','samplers'):
 assert props['default_generation_settings']['params'].get(k)==ref['default_generation_settings']['params'].get(k),(k,props['default_generation_settings']['params'].get(k),ref['default_generation_settings']['params'].get(k))
out=pathlib.Path('/eval/results')/f'{label}-L{level}-R{rep}';out.mkdir(parents=True,exist_ok=True);(out/'props.json').write_text(json.dumps(props,indent=2))
sys.argv=['/eval/run.py',label,level,rep]+(['sequence'] if variant.endswith('sequence') else [])
runpy.run_path('/eval/run.py',run_name='__main__')
