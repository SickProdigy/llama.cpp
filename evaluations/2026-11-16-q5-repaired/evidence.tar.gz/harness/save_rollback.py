import pathlib,tarfile,os,json
p=pathlib.Path('/opt/data');uid=(p/'config.yaml').stat().st_uid;gid=(p/'config.yaml').stat().st_gid
backup=p/'backups/2026-11-16-profile-repair';backup.mkdir(parents=True,exist_ok=False)
with tarfile.open('/eval/profile.tgz') as t:
 for member in t.getmembers():
  if not member.isfile() or not (member.name=='config.yaml' or member.name.startswith('skills/gitea/')):continue
  dest=backup/member.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(t.extractfile(member).read());dest.chmod(0o600);os.chown(dest,uid,gid)
(backup/'ROLLBACK.txt').write_text('Stop only hermes. Restore config.yaml and skills/gitea from this backup into its data home. Remove only plugins/gitea-readable-defaults (new in this repair), then start hermes and verify backend model/context and authenticated Gitea reads. Do not replace credentials, endpoints, session databases or unrelated data. The original backend model remains VibeForged Q4 at98304.\n')
for item in [backup,*backup.rglob('*')]:
 os.chown(item,uid,gid)
 if item.is_dir():item.chmod(0o700)
 else:item.chmod(0o600)
print(json.dumps({'private_rollback_backup':'/opt/data/backups/2026-11-16-profile-repair','original_config_and_gitea_skills_saved':True,'directory_mode':'0700','file_mode':'0600','owner_matches_existing_config':True}))
