"""Apply only the tested local profile repair; retain all other configuration."""
import sys,pathlib,json,copy,hashlib,os
sys.path.insert(0,'/opt/hermes');sys.path.insert(0,'/eval')
import hermes_yaml as yaml
from repair_profile import apply
p=pathlib.Path('/opt/data');before=yaml.safe_load((p/'config.yaml').read_text())
assert before['model']['default']=='qwen3.6-14b-a3b-vibeforged-v2-q4_k_m' and before['model']['context_length']==98304
hashes={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['.env','auth.json','SOUL.md'] if (p/n).exists()}
after=apply(p)
stat=(p/'config.yaml').stat();plugin=p/'plugins/gitea-readable-defaults'
for item in [plugin,*plugin.rglob('*')]:os.chown(item,stat.st_uid,stat.st_gid)
paths=[('auxiliary','compression','extra_body'),('tools','tool_search','enabled'),('plugins','enabled'),('agent','disabled_toolsets'),('platform_toolsets','cli'),('agent','environment_hint')]
def stripped(value):
 result=copy.deepcopy(value)
 for path in paths:
  d=result
  for key in path[:-1]:d=d[key]
  d.pop(path[-1],None)
 return result
assert stripped(before)==stripped(after),'Unexpected configuration mutation'
assert after['model']==before['model']
assert after['agent']['disabled_toolsets']==before['agent']['disabled_toolsets']+([] if 'connections' in before['agent']['disabled_toolsets'] else ['connections'])
assert after['platform_toolsets']['cli']==[x for x in before['platform_toolsets']['cli'] if x!='connections']
for n,h in hashes.items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n+' changed'
result={'applied':True,'preserved_other_configuration':True,'preserved_model_configuration':True,'preserved_credential_identity_files':list(hashes),'changed_configuration_paths':['.'.join(x) for x in paths],'plugin':'gitea-readable-defaults 0.1.0','source':'tested frozen profile repair','model_alias':after['model']['default'],'context':after['model']['context_length'],'main_output_cap':after['model']['max_tokens']}
pathlib.Path('/eval/deployment.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
