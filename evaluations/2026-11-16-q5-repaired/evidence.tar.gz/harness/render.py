import pathlib,json,csv,statistics
r=pathlib.Path('/tmp/hermes-q5-eval');d=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-16-q5-repaired');a=json.loads((d/'aggregate.json').read_text());g=json.loads((r/'manual-grades.json').read_text());rows=list(csv.DictReader((d/'runs.csv').open()))
labels={'vibeforged-repaired':'VibeForged v2 Q4_K_M','qwen9-q5-repaired':'Qwen3.5-9B Q5_K_M'}
table='| Model / repaired Discord agent profile | Routing | Content | Both | GitHub attempted | Timeouts | Median turn |\n|---|---:|---:|---:|---:|---:|---:|\n'
for tag,name in labels.items():
 x=next(x for x in a if x['candidate']==tag);assert x['n']==9
 table+=f"| {name} | {x['routing_pass']}/9 | {x['content_pass']}/9 | {x['combined_pass']}/9 | {x['github']}/9 | {x['timeouts']} | {x['median_seconds']}s |\n"
text='''# Repaired Hermes profile and Qwen9B Q5 comparison — November 16, 2026

## Protocol and results

The user requested an approximately 8-GB model file, leaving room for a large
context on the 16-GiB P100. The new Qwen3.5-9B Q5_K_M weights are 6,577,841,376
bytes; the file SHA-256 was checked against its publisher's Hugging Face LFS OID.
Both models run at 98,304 context on the same pinned llama.cpp b12407-e574a17b0
image and original Hermes image. The backend had already updated before this
task; this evaluation did not upgrade it.

'''+table+'''
Each model receives three fresh repetitions of each unchanged user prompt:

1. `Find my SonicRatings repo and tell me what it does.`
2. `Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.`
3. `Review sickprodigy/sick-cogs and suggest five useful new cogs that aren’t already there. Explain why each would fit.`

A separate sequence sends the same three prompts with normal accumulated
conversation history. Read-only forge guards block known write methods and
connection mutations; local scratch/code/terminal and external web tools remain
available. No corrective user hints are added during scored turns. Complete
model-facing requests, tool calls/results, answers and manual grade notes are
retained in the sanitized archive. Passing requires both a successful configured
Gitea repository operation with no GitHub attempt, and a complete grounded
answer meeting the requested count and novelty. Useful but materially defective
answers are Partial. Completion flags alone are insufficient.

These use the full shipped AIAgent loop with **Discord platform selection**,
normal SOUL/skills/plugins, and its platform-specific prompt posture, inside
disposable exact-image containers. No Discord messages are sent. Native gateway
transport/delivery and an existing live session are not tested. Previous CLI
scores used automatic coding guidance; do not pool them with this experiment or
attribute any difference to a single repair. This comparison changes the profile
and platform as a bundle; targeted preflights validate individual mechanisms.

## Interpretation and decision

Keep VibeForged Q4 as the live model for now. Both models pass routing and
content together in 3/9 fresh turns. Qwen has one more content-only pass (4/9
versus 3/9), but more outright content failures (four versus two); VibeForged has
four Partial answers versus Qwen's one. Neither is established as reliable for
open-ended repository novelty reviews. VibeForged's median turn is 63.2s versus
Qwen's 100.7s. These workflows differ, so this is not a pure decode benchmark.

Qwen Q5 meets the memory objective: its 6.58-GB model file loaded 98,304 context
at 7,348 MiB and peaked at 7,472 MiB in five-second samples, versus VibeForged's
9,028 MiB loaded / 9,082 MiB sampled peak. Keep the verified download available
for lower-memory trials; there is no demonstrated workflow-quality reason to
replace the current model. No larger context is claimed or configured.

Both models now finish all three history turns without a context-too-long
failure, but neither history sequence is fully source-correct. No natural
history compression was triggered, so this is not proof that all long-session
summary quality is solved. The separate real compressor preflight demonstrates
that the local output-budget override works beyond 512 tokens.

This is not a controlled before/after fine-tuning experiment: the models have
different architectures, weights, quantization and native templates. The result
does not establish that community fine-tuning is better or worse than vendor
post-training. Earlier CLI scores also differ in platform, backend and profile.
The strongest mechanism result is concrete: models emitted with_lines themselves
on only 5/25 (VibeForged) and 3/23 (Qwen) file calls, while all 48 effective dispatches
had readable, finite line arguments after the native hook. These counts include
failed path/cooldown calls; they do not mean 48 successful file reads. Wrong paths,
wrong forge choices, repeated retries, and incorrect novelty/fit claims remain.

Further work should target verified branch/catalog reasoning and a wider held-out
set of actual user tasks before downloading or training many more checkpoints.
The fixed three-prompt benchmark is intentionally small and should not become
training data for claims of generalization on these same prompts.

## Deployed profile repairs

- The compression task alone supplies `extra_body.max_tokens: 8192` and
  `chat_template_kwargs.enable_thinking: false` through the existing auxiliary
  configuration path. Ordinary agent requests retain max_tokens 4,096; the
  backend default remains 512. This targets this local Qwen-compatible backend,
  not arbitrary external-provider semantics.
- Gitea schemas are direct (`tools.tool_search.enabled: off`). Connection
  administration is disabled in the normal agent. Public and private owner
  repositories default to the configured Gitea source; external research still
  has web access.
- Environment/skill examples use the actual registered
  `mcp__mcp_gitea_hermes__` namespace. The repository-management skill no longer
  teaches speculative multi-encoding/gzip decoding, and its fabricated tool
  inventory is replaced with the verified current surface.
- The local `gitea-readable-defaults` plugin uses the supported `pre_tool_call`
  modify hook to default omitted text-read arguments to `with_lines: true` and
  a 160-line excerpt. Explicit raw reads/ranges and binary paths are preserved.
  Model-emitted and effective dispatch arguments are retained separately; the
  model still has to choose valid paths and refs.

## Preliminary diagnostics and protocol correction

Before final scoring, three fresh VibeForged lookup turns used the repaired
configuration with readable-file guidance only. One failed without an explanation,
two produced partially correct explanations. The third omitted the readable flag
and returned to base64 decoding. The host batch scheduler was paused while that
turn finished; no diagnostic turn was interrupted. The remaining preliminary
batch was canceled with restoration verified. All three turns, requests and
logs are retained under `diagnostics/` in the archive and are excluded from the
paired scores. This prompted the native default-argument plugin and its tests;
no diagnostic outcome was silently replaced or counted as a final repetition.

## Targeted preflight

A real `ContextCompressor._call_summary_llm` call received 60 synthetic numbered
project/port facts. The captured request used the compression-only 8,192 cap
and disabled thinking. It finished in 56.9 seconds, retained all 60 project IDs
and ports, and the backend recorded **1,731 generated tokens**, exceeding the old
512-token default. This proves the override reaches the actual summary path;
it does not guarantee arbitrary long-history summary quality.

Four plugin behavior tests cover omitted flags, preserved raw/binary/other tools,
explicit ranges and invalid start lines. The native plugin loader and hook
dispatch were then exercised: a call omitting flags became UTF-8 lines 1–160,
while an explicit raw call was unchanged. A real configured Gitea file read
also returned readable lines 1–24. The actual
Discord AIAgent surface contained 25 direct Gitea schemas and no
manage_connections tool. The matching repository fixtures and authenticated
service principal were reverified before scoring. Preflight request/schema/
source-output evidence and backend timings are in the archive.

## Resource and history measurements

'''
for tag,name in labels.items():
 rs=[x for x in rows if x['run'].startswith(tag+'-L')];peak=max(int(x['peak_gpu_mib']) for x in rs if x['peak_gpu_mib']);first=statistics.median(float(x['first_call_seconds']) for x in rs if x['first_call_seconds'])
 text+=f'- {name}: sampled peak {peak:,} MiB; median first API-call latency {first:.1f}s.\n'
for tag,name in labels.items():
 x=g[tag+'-history-L1-R1'];text+=f"\n**{name} history:** {x['task']}. {x['note']}\n"
text+='''

Five-second GPU samples can miss transients. First API-call latency includes
generation and may use prompt cache; it is not first-token latency or a pure
throughput comparison. Native checkpoint chat templates are preserved, and
model identity remains visible. Both use matched temperature 1, top-k 20,
top-p 0.95, min-p 0.05, repeat penalty 1, q4 K/V, one slot, 30 iterations and a
600-second external limit per turn. Fresh profiles have no session databases or
conversation history and an empty memory directory. Background review is off.

## Evidence and operational outcome

- [Fresh run metrics and manual grades](runs.csv)
- [Separate history turns](history-turns.csv)
- [Aggregate metrics](aggregate.json)
- [Sanitized evidence archive](evidence.tar.gz) and [member checksums](evidence-manifest.json)

Private Docker inspections, raw profile snapshots, auth stores and credential
values are excluded or redacted. Harness scripts are an operational record
requiring this workspace's Docker resources and a fresh private profile.
Original containers/images/configuration were restored and verified before the
live repair. The tested profile changes and native plugin were then applied to
`hermes-agent`, retaining its VibeForged alias, 98,304 context, 4,096 main cap,
credentials, endpoints, SOUL and Sick-Cogs skill. Post-restart native-hook and
authenticated Gitea checks passed as `hermes-agent`, with unchanged fixture refs.
Container identities/images/environment/ports/mounts remain unchanged.

A private original-config/Gitea-skill rollback backup is retained at
`hermes-agent/data/backups/2026-11-16-profile-repair/` (directories 0700,
files 0600, owner matches the existing configuration). It is not exported.
Temporary test containers/volume and host private snapshots are removed after
sanitized export verification. No change was made to hermes-codex. The plugin's
[maintainable source and installation notes](../../hermes-profile/README.md) and
[final verification](verification.json) accompany this report. Live gateway
process presence is checked; actual Discord delivery remains untested.

The earlier comparison has a [grading erratum](../2026-11-13-fablevibes/grading-corrections.md)
correcting one GameRoom capability note without changing aggregate scores.
'''
(d/'investigation.md').write_text(text)
p=d.parent.parent/'README.md';s=p.read_text();heading='## November 16, 2026 repaired profile and Qwen9B Q5 comparison'
if heading in s:
 start=s.index(heading);end=s.index('## November 13, 2026 FableVibes comparison',start);s=s[:start]+s[end:]
section=heading+'\n\nBoth models were tested at 98,304 context on llama.cpp b12407 with the same\nrepaired profile and full AIAgent Discord platform selection in disposable\ncontainers. No Discord messages or forge writes were sent. Each row has nine\nfresh runs; history sequences are separate. This is a new protocol, not pooled\nwith the earlier CLI measurements.\n\n'+table+'\nSee the [full repair/Q5 comparison](evaluations/2026-11-16-q5-repaired/investigation.md)\nand [per-run evidence](evaluations/2026-11-16-q5-repaired/runs.csv).\n\n'
s=s.replace('## November 13, 2026 FableVibes comparison',section+'## November 13, 2026 FableVibes comparison',1);# Refresh the main matrix without pooling historical CLI results with this pair.
s=s.replace('Each row below uses nine fresh full-agent CLI sessions (three repetitions of\nthree fixed prompts). “Both” means routing and content passed in the same run.\nThese are the latest baseline observations for each model/context, not a pooled\nranking: the November 13 comparison used backend b12316, while November 12 used\nb12282. The dated sections above retain all configurations and earlier scores.',
"Each row uses nine fresh full-agent sessions. November 16 uses the repaired\nDiscord agent profile on b12407; older rows use CLI selection on b12316 (Nov 13)\nor b12282 (Nov 12). Compare the two November 16 rows as the matched pair; do not\npool or rank across profiles. Both means routing and content passed in one turn.\nThe dated sections retain all configurations and earlier scores.")
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| VibeForged v2 Q4_K_M | [Nov 13]'):
  lines[i]='| VibeForged v2 Q4_K_M | [Nov 16 · Discord](evaluations/2026-11-16-q5-repaired/investigation.md) | 98,304 | 6/9 | 3/9 | 3/9 | 9,082 MiB | 3.3s | 63.2s | Not retested |'
  lines.insert(i+1,'| Qwen3.5-9B Q5_K_M | [Nov 16 · Discord](evaluations/2026-11-16-q5-repaired/investigation.md) | 98,304 | 6/9 | 4/9 | 3/9 | 7,472 MiB | 5.2s | 100.7s | Not tested |')
  break
s='\n'.join(lines)+'\n'
matrix_start=s.index('### Latest Ordinary Repository Results')
old='No candidate established reliable ordinary repository work. Keep the deployed'
new='No candidate established reliable ordinary repository reviews. Keep VibeForged Q4:'
start=s.index(old if old in s[matrix_start:] else new,matrix_start)
end=s.index('### Historical Guided Workflow Results',start)
s=s[:start]+"""No candidate established reliable ordinary repository reviews. Keep VibeForged Q4:
Qwen Q5 uses less VRAM but ties its 3/9 combined score and has a slower median turn.
Both finish the November 16 history sequence, with content defects remaining.
The tested local summary budget/read-default/routing profile fixes are deployed;
the existing model/credentials/endpoints remain. See the dated report and
[plugin source/config notes](hermes-profile/README.md). These tests do not prove
native Discord delivery, issue-write reliability or a million-token context.
First API-call latency includes generation/cache; sampled VRAM may miss peaks.

"""+s[end:]
p.write_text(s)
print(table)
