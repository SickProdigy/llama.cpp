import sys,tarfile,pathlib,json
sys.path.insert(0,'/opt/hermes');sys.path.insert(0,'/eval')
p=pathlib.Path('/opt/data');p.mkdir(exist_ok=True)
with tarfile.open('/eval/profile.tgz') as t:t.extractall(p,filter='data')
from repair_profile import apply
apply(p)
from hermes_cli.plugins import _dispatch_pre_tool_call_hooks,discover_plugins
plugins=discover_plugins()
name='mcp__mcp_gitea_hermes__get_file_contents'
args={'owner':'sickprodigy','repo':'SonicRatings','path':'README.md','ref':'main'}
blocked,modified=_dispatch_pre_tool_call_hooks(name,args)
assert not blocked and modified and modified['with_lines'] is True and modified['start_line']==1 and modified['end_line']==160,(blocked,modified)
assert 'with_lines' not in args
blocked,raw=_dispatch_pre_tool_call_hooks(name,{**args,'with_lines':False})
assert not blocked and raw is None,(blocked,raw)
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
discover_mcp_tools()
result=json.loads(model_tools.handle_function_call(name,modified));assert 'error' not in result,result
out=pathlib.Path('/eval/plugin-preflight');out.mkdir(exist_ok=True)
(out/'result.json').write_text(json.dumps({'plugin_hook_loaded':True,'model_omitted_arguments':args,'effective_arguments':modified,'explicit_raw_preserved':True,'real_mcp_result':result},indent=2))
print('Native plugin loader/argument hook and real readable MCP dispatch passed')
