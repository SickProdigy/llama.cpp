import sys,os,time,json,pathlib,tarfile,threading,shutil,hashlib
sys.path[:0]=['/eval','/opt/hermes']
p=json.loads(pathlib.Path('/eval/parameters.json').read_text());r=pathlib.Path('/eval/runs')/p['run_id'];r.mkdir(parents=True,exist_ok=True)
(r/'guard-sha256.txt').write_text(hashlib.sha256(pathlib.Path('/eval/guard.py').read_bytes()).hexdigest())
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
pathlib.Path('/opt/data/workspace').mkdir(exist_ok=True)
import hermes_yaml as yaml
cp=pathlib.Path('/opt/data/config.yaml');cfg=yaml.safe_load(cp.read_text());cfg['model']['default']=p['alias'];cfg['model']['context_length']=98304;cp.write_text(yaml.safe_dump(cfg,sort_keys=False))
import httpx
send=httpx.Client.send;requests=[];lock=threading.RLock()
def captured(self,request,*args,**kwargs):
 if '/chat/completions' in str(request.url):
  try:
   body=json.loads(request.content)
   with lock:requests.append(body);(r/f'request-{len(requests):03d}.json').write_text(json.dumps(body,indent=2))
  except Exception:pass
 return send(self,request,*args,**kwargs)
httpx.Client.send=captured
import model_tools
from tools.registry import registry
from tools.mcp_tool_discovery import discover_mcp_tools
from hermes_cli.config import load_config
from hermes_cli.tools_config import _get_platform_tools
from run_agent import AIAgent
from guard import Guard,Reject
discover_mcp_tools();cfg=load_config();selected=sorted(_get_platform_tools(cfg,'discord'))
a=AIAgent(model=p['alias'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',max_iterations=p['call_limit'],max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
(r/'schemas.json').write_text(json.dumps(a.tools,indent=2));(r/'prompt.txt').write_text(p['prompt']);g=Guard(p);orig=registry.dispatch;calls=[];state={'early_stop':None,'validation_rejections':0,'validation_rejections_by_tool':{}};start=time.monotonic()
def stop(reason):
 if state['early_stop'] is None:state['early_stop']=reason;a.hard_interrupt(tool_reason='Bounded workflow: '+reason)
 return json.dumps({'error':'Evaluation stopped: '+reason})
def unpack(raw):
 try:
  d=json.loads(raw) if isinstance(raw,str) else raw
  if isinstance(d,dict) and 'result' in d:d=d['result'];d=json.loads(d) if isinstance(d,str) else d
  return d
 except Exception:return {'unparsed':str(raw)}
def save():
 state.update({'elapsed':round(time.monotonic()-start,3),'tool_calls':len(calls),'issue_number':g.issue,'branch_created':g.branch,'commit_created':g.commit,'pr_number':g.pr,'dispatched_stages':sorted(g.sent),'effective_fork_name':g.p['fork_name']})
 (r/'state.json').write_text(json.dumps(state,indent=2));(r/'calls.json').write_text(json.dumps(calls,indent=2,default=str))
def dispatch(name,args,**kwargs):
 with lock:
  c={'number':len(calls)+1,'name':name,'args':args,'dispatched':False};calls.append(c)
  try:
   if state['early_stop']:value=json.dumps({'error':'Evaluation already stopped'})
   elif len(calls)>p['call_limit']:value=stop('tool-call limit')
   elif time.monotonic()-start>=p['seconds']:value=stop('time limit')
   else:
    fp=name+':'+json.dumps(args,sort_keys=True)
    if fp in g.rejected:raise Reject('repeated identical rejected call')
    stage=g.check(name,args);g.before(stage);c['stage']=stage;c['dispatched']=True
    value=orig(name,args,**kwargs);parsed=unpack(value);g.after(stage,parsed)
    if isinstance(parsed,dict) and 'error' in parsed:g.rejected.add(fp)
  except ValueError as e:
   state['validation_rejections']+=1;state['validation_rejections_by_tool'][name]=state['validation_rejections_by_tool'].get(name,0)+1;g.rejected.add(name+':'+json.dumps(args,sort_keys=True))
   value=stop('repeated invalid arguments: '+str(e)) if state['validation_rejections_by_tool'][name]>1 else json.dumps({'error':'Invalid arguments: '+str(e)})
  except Reject as e:value=stop(str(e))
  except BaseException as e:c['exception']=str(e);save();raise
  c['result']=value;c['elapsed']=round(time.monotonic()-start,3);save();return value
registry.dispatch=dispatch
(r/'started.json').write_text(json.dumps({'epoch':time.time(),'cap_seconds':p['seconds']}));timer=threading.Timer(p['seconds'],lambda:stop('time limit'));timer.daemon=True;timer.start()
try:(r/'result.json').write_text(json.dumps(a.run_conversation(p['prompt']),indent=2,default=str))
except BaseException as e:(r/'exception.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e)}))
finally:
 timer.cancel();save()
 try:shutil.copy('/opt/data/logs/agent.log',r/'agent.log')
 except Exception:pass
 print(json.dumps(state),flush=True);a.close()
