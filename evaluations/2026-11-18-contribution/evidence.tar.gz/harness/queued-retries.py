import pathlib,json,time,subprocess
r=pathlib.Path('/tmp/hermes-contribution-eval')
for _ in range(600):
 p=r/'restoration.json'
 if p.exists():
  assert json.loads(p.read_text())['complete'],'Initial controller did not complete; investigate before retrying'
  with open(r/'retry-controller.log','w') as f:subprocess.run(['python3',str(r/'retry-controller.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
  break
 time.sleep(2)
else:raise RuntimeError('Initial controller did not finish within twenty minutes')
