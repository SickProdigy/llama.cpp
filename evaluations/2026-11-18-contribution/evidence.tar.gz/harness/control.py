"""Same-credential non-model control, only if no model completes the PR chain."""
import sys,json,pathlib,tarfile
sys.path[:0]=['/eval','/opt/hermes']
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
from guard import Guard,PREFIX
discover_mcp_tools();p=json.loads(pathlib.Path('/eval/manifests.json').read_text())[0]
p.update({'branch':'mcp-control-20261118','pr_title':'Docs: repository wording (MCP capability control)','pr_body':'Refs #<issue-number>\n\nSame-credential MCP capability control, executed directly by the operator, not by a model. Change only the requested README wording; leave open for review.'})
g=Guard(p);calls=[];out={'kind':'direct MCP control, not a model pass','calls':calls,'manifest':p}
def call(n,a):
 stage=g.check(PREFIX+n,a);g.before(stage);entry={'name':n,'args':a,'stage':stage};calls.append(entry)
 raw=model_tools.handle_function_call(PREFIX+n,a);entry['raw_result']=raw;d=json.loads(raw);d=d.get('result',d);d=json.loads(d) if isinstance(d,str) else d;g.after(stage,d)
 pathlib.Path('/eval/control.json').write_text(json.dumps(out,indent=2))
 if isinstance(d,dict) and 'error' in d:raise RuntimeError(str(d))
 return d
assert call('get_me',{})['login']=='hermes-agent'
ii=call('issue_read',{'method':'get','owner':'sickprodigy','repo':'nicotineplus-plugins','issue_number':4})
assert ii['title']==p['issue_title'] and ii['body']==p['issue_body'];g.issue=4;g.sent.add('issue')
call('branch_write',{'method':'create','owner':'hermes-agent','repo':p['fork_name'],'branch':p['branch'],'old_branch':'main'})
call('create_or_update_file',{'owner':'hermes-agent','repo':p['fork_name'],'branch_name':p['branch'],'path':'README.md','sha':p['file_sha'],'message':'docs: refer to the repository rather than directory','edits':[{'old_string':p['old_text'],'new_string':p['new_text']}]})
pr=call('pull_request_write',{'method':'create','owner':'sickprodigy','repo':'nicotineplus-plugins','base':'main','head':'hermes-agent:'+p['branch'],'title':p['pr_title'],'body':p['pr_body'].replace('<issue-number>','4')})
call('get_file_contents',{'owner':'hermes-agent','repo':p['fork_name'],'path':'README.md','ref':p['branch']})
call('pull_request_read',{'method':'get','owner':'sickprodigy','repo':'nicotineplus-plugins','pull_number':pr['number']})
out['pr_number']=pr['number'];out['completed']=True;pathlib.Path('/eval/control.json').write_text(json.dumps(out,indent=2));print(json.dumps({'control_completed':True,'issue_number':4,'pr_number':pr['number']}))
