import subprocess,pathlib,json,time,urllib.request,base64,datetime,threading
r=pathlib.Path('/tmp/hermes-contribution-eval')
def sh(a,**kw):return subprocess.run(a,check=True,**kw)
def inspect(n):return json.loads(subprocess.check_output(['docker','inspect',n]))[0]
hi=json.loads((r/'hermes-inspect.json').read_text())[0];li=json.loads((r/'llama-cpp-inspect.json').read_text())[0]
def ready(alias):
 for _ in range(150):
  try:
   d=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=3))
   if d.get('model_alias')==alias and d.get('default_generation_settings',{}).get('n_ctx')==98304:return d
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('backend readiness timeout: '+alias)
def rm(n):subprocess.run(['docker','rm','-f',n],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
original=(r/'readme.txt').read_text();source=json.loads((r/'source-before.json').read_text());file_sha=source['upstream']['contents/README.md']['sha']
models=[('qwen9-q5-pr-only', 'Qwen3.5-9B-Q5_K_M.gguf', 'qwen3.5-9b-q5_k_m', 'Contributions are welcome! Feel free to:', 'Contributions are welcome! You can:')]
(r/'pr-models.json').write_text(json.dumps(models,indent=2));manifests=json.loads((r/'manifests.json').read_text());done=False
for f in ['guard.py','pr_session.py']:sh(['docker','cp',str(r/f),'hermes-contribution-store:/eval/'+f])
sh(['docker','stop','-t','30','hermes'],stdout=subprocess.DEVNULL)
try:
 sh(['docker','stop','-t','20','llama-cpp'],stdout=subprocess.DEVNULL)
 for label,file,alias,old,new in models:
  rm('llama-contribution-eval')
  args=['docker','run','-d','--name','llama-contribution-eval','--network','homelab','--network-alias','llama','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','25g','--memory-swap','25g',li['Image'],'-m','/models/'+file,'--alias',alias,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size','98304','--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--n-predict','512','-ngl','999','--temp','1','--top-k','20','--top-p','0.95','--min-p','0.05','--repeat-penalty','1','--presence-penalty','0','--frequency-penalty','0']
  sh(args,stdout=subprocess.DEVNULL);props=ready(alias);(r/(label+'-props.json')).write_text(json.dumps(props,indent=2));print('BACKEND READY',label,flush=True)
  for kind,prompt in [('contribution',None)]:
   runid='20261118-'+label+'-'+kind;branch='mcp-test-'+runid
   p={'run_id':runid,'kind':kind,'alias':alias,'seconds':300 if kind=='contribution' else 180,'call_limit':20 if kind=='contribution' else 16,'fork_name':'hermes-mcp-test-20261117-vf-144838','branch':branch,'file_sha':file_sha,'original_content':original,'expected_content':original.replace(old,new,1),'old_text':old,'new_text':new,'issue_title':'MCP contribution test '+runid,'issue_body':f'Documentation correction: in README.md, replace `{old}` with `{new}`. This is a bounded Hermes model evaluation; no implementation beyond that correction is requested.','pr_title':'Docs: '+label+' contribution test '+runid,'pr_body':'Refs #<issue-number>\n\nMake only the requested README.md correction. Hermes model evaluation; leave open for review.'}
   seeded=next(x for x in manifests if x['run_id']=='20261118-qwen9-q5-matched-contribution');identity=p['run_id'];p.update(seeded);p.update({'run_id':identity,'seconds':180,'call_limit':8,'seed_issue_number':10,'seeded_stages':['issue','branch','commit'],'variant':'PR-only follow-up, existing committed branch'})
   assert original.count(old)==1
   if prompt is None:
    prompt=f'Using only the configured Gitea MCP, open one pull request in sickprodigy/nicotineplus-plugins from hermes-agent/hermes-mcp-test-20261117-vf-144838 branch {p["branch"]} to upstream main. The requested README correction for upstream issue #10 is already committed on that fork branch. Use this exact PR title: {p["pr_title"]}\nUse this exact PR body:\n{p["pr_body"].replace("<issue-number>","10")}\nRead the PR back and return its URL. Leave it open for review. Do not create another issue, fork or branch, change files or settings, merge or close anything, or use alternatives to Gitea MCP. If a step fails, report the error and stop.' 
   p['prompt']=prompt;manifests.append(p);(r/'manifests.json').write_text(json.dumps(manifests,indent=2));(r/'parameters.json').write_text(json.dumps(p,indent=2));sh(['docker','cp',str(r/'parameters.json'),'hermes-contribution-store:/eval/parameters.json'])
   print('RUN START',runid,flush=True)
   with open(r/(runid+'-console.log'),'w') as f:
    proc=subprocess.Popen(['docker','run','--rm','--name','hermes-contribution-session','--network','homelab','--mount','type=volume,source=hermes-contribution-evidence,target=/eval','-e','HERMES_HOME=/opt/data','-e','PYTHONUNBUFFERED=1','--entrypoint','python',hi['Image'],'/eval/pr_session.py'],stdout=f,stderr=subprocess.STDOUT)
    launched=time.monotonic();gpu=[]
    while proc.poll() is None:
     # Independent wall-clock cap includes session startup grace.
     if time.monotonic()-launched>p['seconds']+50:
      rm('hermes-contribution-session');(r/(runid+'-external-timeout.json')).write_text(json.dumps({'limit':p['seconds']+50}));break
     sample=subprocess.run(['docker','exec','llama-contribution-eval','nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True)
     if sample.returncode==0:gpu.append({'seconds':round(time.monotonic()-launched,2),'gpu':sample.stdout.strip()})
     time.sleep(3)
    proc.wait();(r/(runid+'-gpu.json')).write_text(json.dumps(gpu,indent=2))
   subprocess.run(['docker','cp','hermes-contribution-store:/eval/runs/'+runid,str(r/runid)],check=True)
   state=json.loads((r/runid/'state.json').read_text()) if (r/runid/'state.json').exists() else {'missing_state':True}
   print('RUN DONE',runid,json.dumps(state),flush=True)
  (r/(label+'-backend.log')).write_bytes(subprocess.check_output(['docker','logs','llama-contribution-eval'],stderr=subprocess.STDOUT))
 done=True
finally:
 rm('hermes-contribution-session');rm('llama-contribution-eval');sh(['docker','start','llama-cpp'],stdout=subprocess.DEVNULL);ready('qwen3.6-14b-a3b-vibeforged-v2-q4_k_m');sh(['docker','start','hermes'],stdout=subprocess.DEVNULL)
 (r/'pr-restoration.json').write_text(json.dumps({'complete':done,'hermes_image_unchanged':inspect('hermes')['Image']==hi['Image'],'llama_image_unchanged':inspect('llama-cpp')['Image']==li['Image'],'hermes_running':inspect('hermes')['State']['Running'],'llama_running':inspect('llama-cpp')['State']['Running']},indent=2));print('RESTORED ORIGINALS',flush=True)
