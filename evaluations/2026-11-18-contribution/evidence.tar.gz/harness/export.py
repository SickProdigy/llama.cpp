import pathlib,json,re,hashlib,tarfile,io
r=pathlib.Path('/tmp/hermes-contribution-eval');out=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-18-contribution');out.mkdir(exist_ok=True)
secrets=json.loads((r/'secrets.json').read_text());allowed={'sickprodigy/nicotineplus-plugins','sickprodigy/SonicRatings','sickprodigy/sick-cogs','hermes-agent/hermes-mcp-test-20261117-vf-144838','hermes-agent/nicotineplus-plugins'};unrelated=set()
def scan(x):
 if isinstance(x,dict):
  if x.get('full_name') and '/' in x['full_name'] and x['full_name'] not in allowed:
   for key in ('full_name','description','clone_url','html_url','ssh_url'):
    v=x.get(key)
    if isinstance(v,str) and len(v)>3:unrelated.add(v)
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
 elif isinstance(x,str):
  try:scan(json.loads(x))
  except Exception:pass
for f in r.glob('20261118-*/calls.json'):scan(json.loads(f.read_text()))
scan(json.loads((r/'preflight.json').read_text()))
replacements=[(v,'[REDACTED_SECRET]') for v in secrets]+[(v,'[UNRELATED_REPOSITORY]') for v in sorted(unrelated,key=len,reverse=True)]
def structured(value):
 if isinstance(value,dict):
  if value.get('full_name') and '/' in value['full_name'] and value['full_name'] not in allowed:
   return {'redacted':True,'reason':'unrelated repository metadata'},True
  changed=False;result={}
  for key,item in value.items():
   result[key],c=structured(item);changed=changed or c
  return result,changed
 if isinstance(value,list):
  result=[];changed=False
  for item in value:
   v,c=structured(item);result.append(v);changed=changed or c
  return result,changed
 if isinstance(value,str):
  try:
   parsed=json.loads(value)
   if isinstance(parsed,(dict,list)):
    result,c=structured(parsed)
    if c:return json.dumps(result,ensure_ascii=False),True
  except Exception:pass
  match=re.fullmatch(r'(.*?\n\n)(.*)(\n</untrusted_tool_result>)',value,re.S)
  if match:
   body,c=structured(match[2])
   if c:return match[1]+body+match[3],True
 return value,False
def scrub(text):
 try:
  parsed=json.loads(text);changed,c=structured(parsed)
  if c:text=json.dumps(changed,indent=2,ensure_ascii=False)
 except Exception:pass
 for old,new in replacements:
  for representation in {old,json.dumps(old,ensure_ascii=False)[1:-1],json.dumps(json.dumps(old,ensure_ascii=False)[1:-1],ensure_ascii=False)[1:-1]}:
   text=text.replace(representation,new)
 text=re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '[USER_EMAIL]',text)
 return text
files=[]
for d in sorted(r.glob('20261118-*')):
 if d.is_dir():
  for f in sorted(d.iterdir()):
   if f.is_file():files.append((str(f.relative_to(r)),f))
for pattern in ['*.py','*-props.json','*-gpu.json','*-console.log','*-backend.log']:
 for f in sorted(r.glob(pattern)):
  if f.name not in ('setup.py','collect_secrets.py','retry.py'):files.append(('harness/'+f.name,f))
for name in ['controller.log','retry-controller.log','test-guard.log','models.json','retry-models.json','manifests.json','source-before.json','grading-fixtures.json','preflight.json','schemas.json','verification.json','restoration.json','retry-restoration.json','final-restoration.json','profile-hashes.json','comparison-controls.json','diagnostics.json','control.json','control-initial.json','control-independent.json','metrics.json','manual-grades.json','matched-controller.log','focused-controller.log','matched-models.json','focused-models.json','matched-restoration.json','focused-restoration.json','sick-cogs-ReadMe-md','sick-cogs-info-json','sick-cogs-develop-tree.json']:
 f=r/name
 if f.exists():files.append(('harness/'+name,f))
manifest=[];seen=set()
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for name,f in files:
  if name in seen:continue
  seen.add(name);data=scrub(f.read_text(errors='replace')).encode()
  for secret in secrets:
   if secret.encode() in data:raise RuntimeError('Secret redaction failed')
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'evidence-manifest.json').write_text(json.dumps({'redaction':'Credential values, email addresses and unrelated repository identifiers/descriptions removed. Private profile, environment and Docker inspection snapshots excluded.','members':manifest},indent=2)+'\n')
sha=hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest();(out/'evidence.tar.gz.sha256').write_text(sha+'  evidence.tar.gz\n')
for name in ['verification.json','final-restoration.json','comparison-controls.json','diagnostics.json']:
 if (r/name).exists():(out/name).write_text(scrub((r/name).read_text())+'\n')
# Verify every archive member against the manifest after writing.
with tarfile.open(out/'evidence.tar.gz') as t:
 for m in manifest:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
print('Sanitized evidence exported and verified:',len(manifest),'members')
