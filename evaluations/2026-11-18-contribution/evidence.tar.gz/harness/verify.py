import json,pathlib,urllib.request,urllib.error,base64,datetime
r=pathlib.Path('/tmp/hermes-contribution-eval');base='https://gitea.rcs1.top/api/v1/repos/'
def get(path):
 try:return json.load(urllib.request.urlopen(base+path,timeout=15))
 except urllib.error.HTTPError as e:return {'error':e.code}
up='sickprodigy/nicotineplus-plugins';fork='hermes-agent/hermes-mcp-test-20261117-vf-144838'
issues=get(up+'/issues?state=all&limit=100');pulls=get(up+'/pulls?state=all&limit=100');meta=get(fork)
out={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstream_main':get(up+'/branches/main'),'fork_parent':meta.get('parent',{}).get('full_name'),'runs':[]}
for p in json.loads((r/'manifests.json').read_text()):
 if p['kind']!='contribution':continue
 run=r/p['run_id'];state=json.loads((run/'state.json').read_text()) if (run/'state.json').exists() else {};fork='hermes-agent/'+state.get('effective_fork_name',p['fork_name']);calls=json.loads((run/'calls.json').read_text()) if (run/'calls.json').exists() else []
 branch=get(fork+'/branches/'+p['branch']);file=get(fork+'/contents/README.md?ref='+p['branch']);content=base64.b64decode(file['content']).decode() if 'content' in file else None
 ii=[x for x in issues if x.get('title')==p['issue_title'] and not x.get('pull_request')];pp=[x for x in pulls if x.get('title')==p['pr_title']]
 pr=get(up+'/pulls/'+str(pp[0]['number'])) if len(pp)==1 else {};diff=get(up+'/pulls/'+str(pp[0]['number'])+'/files') if len(pp)==1 else []
 issue_ok=len(ii)==1 and ii[0]['body']==p['issue_body'] and ii[0].get('user',{}).get('login')=='hermes-agent';pr_ok=len(pp)==1 and pr.get('base',{}).get('repo',{}).get('full_name')==up and pr.get('base',{}).get('ref')=='main' and pr.get('head',{}).get('repo',{}).get('full_name')==fork and pr.get('head',{}).get('ref')==p['branch'] and pr.get('state')=='open' and not pr.get('merged') and issue_ok and pr.get('body')==p['pr_body'].replace('<issue-number>',str(ii[0]['number']))
 def successful(c):
  try:
   x=c.get('result');x=json.loads(x) if isinstance(x,str) else x
   if isinstance(x,dict) and ('error' in x or x.get('isError')):return False
   if isinstance(x,dict) and 'result' in x:
    x=x['result'];x=json.loads(x) if isinstance(x,str) else x
   return not (isinstance(x,dict) and ('error' in x or x.get('isError')))
  except Exception:return False
 reads=[c for c in calls if c.get('dispatched') and c.get('stage')=='read' and successful(c)]
 # Read-back must happen after the corresponding write, with exact resource identifiers.
 def after_read(suffix,field,value,stage):
  writes=[c['number'] for c in calls if c.get('dispatched') and c.get('stage')==stage]
  return (bool(writes) or (suffix=='issue_read' and p.get('seed_issue_number'))) and any(c['name'].endswith('__'+suffix) and c['number']>max(writes or [0]) and c['args'].get(field)==value and c['args'].get('method')=='get' and (c['args'].get('owner'),c['args'].get('repo'))==('sickprodigy','nicotineplus-plugins') for c in reads)
 readback={'issue':bool(ii) and after_read('issue_read','issue_number',ii[0]['number'],'issue'),'file':any(c['name'].endswith('__get_file_contents') and c['args'].get('ref')==p['branch'] and str(c['args'].get('filepath',c['args'].get('path',''))).lstrip('/')=='README.md' and (c['args'].get('owner'),c['args'].get('repo'))==('hermes-agent',state.get('effective_fork_name',p['fork_name'])) and c['number']>max([x['number'] for x in calls if x.get('stage')=='commit'] or [999]) for c in reads),'pr':bool(pp) and after_read('pull_request_read','pull_number',pp[0]['number'],'pr')}
 state=json.loads((run/'state.json').read_text()) if (run/'state.json').exists() else {}
 mutations=[c for c in calls if c.get('dispatched') and c.get('stage')!='read'];order_ok=bool(mutations) and mutations[0].get('stage')=='issue'
 result={'requested_issue_first':order_ok,'fork_parent':get(fork).get('parent',{}).get('full_name'),'run_id':p['run_id'],'issue_matches':issue_ok,'issue_created':issue_ok and not p.get('seed_issue_number'),'issue_number':ii[0]['number'] if ii else None,'issue_url':ii[0].get('html_url') if ii else None,'branch_created':'name' in branch,'file_exact':content==p['expected_content'],'pr_correct':pr_ok,'pr_number':pp[0]['number'] if pp else None,'pr_url':pp[0].get('html_url') if pp else None,'only_requested_pr_file':isinstance(diff,list) and len(diff)==1 and diff[0].get('filename')=='README.md','readback':readback,'state':state,'branch':branch,'file':file,'pr':pr,'pr_files':diff}
 final=json.loads((run/'result.json').read_text()).get('final_response') if (run/'result.json').exists() else '';final=final or '';urls={'issue':bool(ii) and '/'+up+'/issues/'+str(ii[0]['number']) in final,'pr':bool(pp) and '/'+up+'/pulls/'+str(pp[0]['number']) in final,'file_or_branch':'/'+fork+'/src/branch/'+p['branch'] in final};result['returned_resource_urls']=urls
 result['implementation_workflow_pass']=all([result['fork_parent']==up,issue_ok,result['branch_created'],result['file_exact'],pr_ok,result['only_requested_pr_file'],all(readback.values()),not state.get('early_stop'),state.get('commit_created'),state.get('pr_number'),all(urls.values())])
 result['whole_workflow_pass']=result['implementation_workflow_pass'] and not p.get('seed_issue_number')
 result['issue_created_in_this_run']=issue_ok and not p.get('seed_issue_number')
 result['variant']=p.get('variant','full Discord profile')
 result['harness_invalidated']='-matched-' not in p['run_id'] and not p.get('variant')
 if result['harness_invalidated']:result['whole_workflow_pass']=False
 out['runs'].append(result)
before=json.loads((r/'source-before.json').read_text());out['upstream_main_unchanged']=out['upstream_main'].get('commit',{}).get('id')==before['upstream']['branches/main']['commit']['id']
(r/'verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({'upstream_main_unchanged':out['upstream_main_unchanged'],'runs':[{k:x[k] for k in ['run_id','issue_created','branch_created','file_exact','pr_correct','readback','whole_workflow_pass']} for x in out['runs']]},indent=2))
