import subprocess,pathlib,json,time,urllib.request,base64,datetime,threading
r=pathlib.Path('/tmp/hermes-contribution-eval')
def sh(a,**kw):return subprocess.run(a,check=True,**kw)
def inspect(n):return json.loads(subprocess.check_output(['docker','inspect',n]))[0]
hi=json.loads((r/'hermes-inspect.json').read_text())[0];li=json.loads((r/'llama-cpp-inspect.json').read_text())[0]
def ready(alias):
 for _ in range(150):
  try:
   d=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=3))
   if d.get('model_alias')==alias and d.get('default_generation_settings',{}).get('n_ctx')==98304:return d
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('backend readiness timeout: '+alias)
def rm(n):subprocess.run(['docker','rm','-f',n],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
original=(r/'readme.txt').read_text();source=json.loads((r/'source-before.json').read_text());file_sha=source['upstream']['contents/README.md']['sha']
models=[('vibeforged-retry', 'Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf', 'qwen3.6-14b-a3b-vibeforged-v2-q4_k_m', '3. Restart Nicotine+ to load the plugins', '3. Restart Nicotine+ after installing the plugin folders'), ('qwen9-q5-retry', 'Qwen3.5-9B-Q5_K_M.gguf', 'qwen3.5-9b-q5_k_m', '4. Enable plugins in Preferences → Plugins', '4. Enable the installed plugins in Preferences → Plugins'), ('fablevibes-retry', 'Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf', 'qwen3.6-14b-a3b-fablevibes-q4_k_m', '2. Place them in your Nicotine+ plugins directory', '2. Place each plugin folder in your Nicotine+ plugins directory')]
(r/'retry-models.json').write_text(json.dumps(models,indent=2));manifests=json.loads((r/'manifests.json').read_text());done=False
for f in ['guard.py','session.py']:sh(['docker','cp',str(r/f),'hermes-contribution-store:/eval/'+f])
sh(['docker','stop','-t','30','hermes'],stdout=subprocess.DEVNULL)
try:
 sh(['docker','stop','-t','20','llama-cpp'],stdout=subprocess.DEVNULL)
 for label,file,alias,old,new in models:
  rm('llama-contribution-eval')
  args=['docker','run','-d','--name','llama-contribution-eval','--network','homelab','--network-alias','llama','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','25g','--memory-swap','25g',li['Image'],'-m','/models/'+file,'--alias',alias,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size','98304','--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--n-predict','512','-ngl','999','--temp','1','--top-k','20','--top-p','0.95','--min-p','0.05','--repeat-penalty','1','--presence-penalty','0','--frequency-penalty','0']
  sh(args,stdout=subprocess.DEVNULL);props=ready(alias);(r/(label+'-props.json')).write_text(json.dumps(props,indent=2));print('BACKEND READY',label,flush=True)
  for kind,prompt in [('contribution',None)]:
   runid='20261118-'+label+'-'+kind;branch='mcp-test-'+runid
   p={'run_id':runid,'kind':kind,'alias':alias,'seconds':300 if kind=='contribution' else 180,'call_limit':20 if kind=='contribution' else 16,'fork_name':'hermes-mcp-test-20261117-vf-144838','branch':branch,'file_sha':file_sha,'original_content':original,'expected_content':original.replace(old,new,1),'old_text':old,'new_text':new,'issue_title':'MCP contribution test '+runid,'issue_body':f'Documentation correction: in README.md, replace `{old}` with `{new}`. This is a bounded Hermes model evaluation; no implementation beyond that correction is requested.','pr_title':'Docs: '+label+' contribution test '+runid,'pr_body':'Refs #<issue-number>\n\nMake only the requested README.md correction. Hermes model evaluation; leave open for review.'}
   assert original.count(old)==1
   if prompt is None:
    prompt=f'Using only the configured Gitea MCP, contribute this documentation fix to sickprodigy/nicotineplus-plugins: in README.md, replace the exact text "{old}" with "{new}". First open exactly one issue in that upstream repository titled "{p["issue_title"]}" with this exact body:\n{p["issue_body"]}\n\nFork into your hermes-agent personal account, or verify and reuse your existing fork hermes-agent/hermes-mcp-test-20261117-vf-144838. Create branch {branch} in your fork and commit only that correction there. Open exactly one PR from that branch to the upstream default branch, titled "{p["pr_title"]}" with this exact body (replace <issue-number> with the upstream issue you created):\n{p["pr_body"]}\n\nRead back the upstream issue, changed file and PR, and return their URLs. Leave the PR open for review. Do not commit directly to upstream, merge or close anything, change repository settings or connections, or use GitHub/browser/terminal alternatives. If a step fails, report the exact error and resources already created, then stop.'
   p['prompt']=prompt;manifests.append(p);(r/'manifests.json').write_text(json.dumps(manifests,indent=2));(r/'parameters.json').write_text(json.dumps(p,indent=2));sh(['docker','cp',str(r/'parameters.json'),'hermes-contribution-store:/eval/parameters.json'])
   print('RUN START',runid,flush=True)
   with open(r/(runid+'-console.log'),'w') as f:
    proc=subprocess.Popen(['docker','run','--rm','--name','hermes-contribution-session','--network','homelab','--mount','type=volume,source=hermes-contribution-evidence,target=/eval','-e','HERMES_HOME=/opt/data','-e','PYTHONUNBUFFERED=1','--entrypoint','python',hi['Image'],'/eval/session.py'],stdout=f,stderr=subprocess.STDOUT)
    launched=time.monotonic();gpu=[]
    while proc.poll() is None:
     # Independent wall-clock cap includes session startup grace.
     if time.monotonic()-launched>p['seconds']+50:
      rm('hermes-contribution-session');(r/(runid+'-external-timeout.json')).write_text(json.dumps({'limit':p['seconds']+50}));break
     sample=subprocess.run(['docker','exec','llama-contribution-eval','nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True)
     if sample.returncode==0:gpu.append({'seconds':round(time.monotonic()-launched,2),'gpu':sample.stdout.strip()})
     time.sleep(3)
    proc.wait();(r/(runid+'-gpu.json')).write_text(json.dumps(gpu,indent=2))
   subprocess.run(['docker','cp','hermes-contribution-store:/eval/runs/'+runid,str(r/runid)],check=True)
   state=json.loads((r/runid/'state.json').read_text()) if (r/runid/'state.json').exists() else {'missing_state':True}
   print('RUN DONE',runid,json.dumps(state),flush=True)
  (r/(label+'-backend.log')).write_bytes(subprocess.check_output(['docker','logs','llama-contribution-eval'],stderr=subprocess.STDOUT))
 done=True
finally:
 rm('hermes-contribution-session');rm('llama-contribution-eval');sh(['docker','start','llama-cpp'],stdout=subprocess.DEVNULL);ready('qwen3.6-14b-a3b-vibeforged-v2-q4_k_m');sh(['docker','start','hermes'],stdout=subprocess.DEVNULL)
 (r/'retry-restoration.json').write_text(json.dumps({'complete':done,'hermes_image_unchanged':inspect('hermes')['Image']==hi['Image'],'llama_image_unchanged':inspect('llama-cpp')['Image']==li['Image'],'hermes_running':inspect('hermes')['State']['Running'],'llama_running':inspect('llama-cpp')['State']['Running']},indent=2));print('RESTORED ORIGINALS',flush=True)
