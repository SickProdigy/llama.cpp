import re
from guard import Guard as Base,Reject,PREFIX
class Guard(Base):
 def check(self,name,a):
  if name==PREFIX+'pull_request_write' and a.get('method')=='create':
   title=a.get('title');body=a.get('body')
   if not isinstance(title,str) or not title.strip():raise ValueError('PR title required')
   if not isinstance(body,str) or not (re.search(r'#'+str(self.issue)+r'\b',body) or '/issues/'+str(self.issue) in body):raise ValueError('PR must reference upstream issue '+str(self.issue))
   self.p['pr_title']=title;self.p['pr_body']=body
  return super().check(name,a)
