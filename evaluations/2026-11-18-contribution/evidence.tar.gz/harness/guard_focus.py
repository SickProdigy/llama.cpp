import re
from guard import Guard as Base,Reject,PREFIX
class Guard(Base):
 def check(self,name,a):
  if name==PREFIX+'create_or_update_file':
   files=a.get('files')
   if files is None:
    if not a.get('path'):raise ValueError('file path is required')
    if 'content' not in a and 'edits' not in a:raise ValueError('file content or edits are required')
   elif len(files)==1 and 'content' not in files[0] and 'edits' not in files[0] and 'edits' not in a and 'content' not in a:raise ValueError('file content or edits are required')
  if name==PREFIX+'pull_request_write'  and a.get('method')=='create':
   title=a.get('title');body=a.get('body')
   if not isinstance(title,str) or not title.strip():raise ValueError('PR title required')
   if not isinstance(body,str) or not (re.search(r'#'+str(self.issue)+r'\b',body) or '/issues/'+str(self.issue) in body):raise ValueError('PR must reference upstream issue '+str(self.issue))
   self.p['pr_title']=title;self.p['pr_body']=body
  return super().check(name,a)
