import pathlib,json,time,subprocess,urllib.request
r=pathlib.Path('/tmp/hermes-contribution-eval')
for _ in range(600):
 if (r/'matched-restoration.json').exists():
  assert json.loads((r/'matched-restoration.json').read_text())['complete']
  pulls=json.load(urllib.request.urlopen('https://gitea.rcs1.top/api/v1/repos/sickprodigy/nicotineplus-plugins/pulls?state=all&limit=100'))
  assert not any(x.get('head',{}).get('ref')=='mcp-test-20261118-qwen9-q5-matched-contribution' for x in pulls),'PR already exists; do not duplicate'
  with open(r/'pr-controller.log','w') as f:subprocess.run(['python3',str(r/'pr-controller.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
  break
 time.sleep(2)
else:raise RuntimeError('Matched controller timeout')
