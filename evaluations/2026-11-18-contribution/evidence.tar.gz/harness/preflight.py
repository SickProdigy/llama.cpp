import sys,json,pathlib,tarfile,base64
sys.path.insert(0,'/opt/hermes')
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
pathlib.Path('/opt/data/workspace').mkdir(exist_ok=True)
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
from tools.registry import registry
names=discover_mcp_tools()
def call(n,a):
 raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__'+n,a);d=json.loads(raw)
 if 'error' in d:raise RuntimeError(str(d))
 d=d.get('result',d);return json.loads(d) if isinstance(d,str) else d
me=call('get_me',{});assert me['login']=='hermes-agent'
repos=call('search_repos',{'query':'nicotineplus-plugins'})
source=next(x for x in repos if x['full_name']=='sickprodigy/nicotineplus-plugins')
forks=call('repo_read',{'method':'list_my_repos','per_page':100})
issues=call('list_issues',{'owner':'sickprodigy','repo':'nicotineplus-plugins','state':'all','per_page':100})
pulls=call('list_pull_requests',{'owner':'sickprodigy','repo':'nicotineplus-plugins','state':'all','per_page':100})
from hermes_cli.config import load_config
from hermes_cli.tools_config import _get_platform_tools
from run_agent import AIAgent
cfg=load_config();selected=sorted(_get_platform_tools(cfg,'discord'))
a=AIAgent(model=cfg['model']['default'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',max_iterations=20,max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
pathlib.Path('/eval/schemas.json').write_text(json.dumps(a.tools,indent=2))
out={'principal':me['login'],'source':source,'forks':[x for x in forks if x.get('fork')],'issues':issues,'pulls':pulls,'selected':selected,'model':cfg['model']['default'],'context':cfg['model']['context_length']}
pathlib.Path('/eval/preflight.json').write_text(json.dumps(out,indent=2)); print(json.dumps({'principal':me['login'],'source_permissions':source.get('permissions'),'forks':[(x['full_name'],x.get('permissions')) for x in forks if x.get('fork')],'tools':len(a.tools),'context':cfg['model']['context_length']}));a.close()
