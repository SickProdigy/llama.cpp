import pathlib,json,csv,statistics
r=pathlib.Path('/tmp/hermes-fable-eval');d=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-13-fablevibes');a=json.load(open(d/'aggregate.json'));g=json.load(open(r/'manual-grades.json'));rows=list(csv.DictReader(open(d/'runs.csv')))
labels={'vibeforged-control':'VibeForged v2 Q4_K_M control','fablevibes':'FableVibes Q4_K_M'}
table='| Model · 98,304 context | Gitea used | GitHub attempted | Routing pass | Content pass | Both | Timeout | Median turn |\n|---|---:|---:|---:|---:|---:|---:|---:|\n'
for label,name in labels.items():
 x=next(x for x in a if x['candidate']==label);assert x['n']==9
 table+='| '+name+' | '+' | '.join(str(x[k])+'/9' for k in ['gitea','github','routing_pass','content_pass','combined_pass'])+f" | {x['timeouts']} | {x['median_seconds']}s |\n"
text='''# FableVibes versus refreshed VibeForged control — November 13, 2026

Dates in the title use America/New_York; raw logs use UTC. Both use the downloaded
Q4_K_M weights at 98,304 context on the 16 GiB Tesla P100. No training, issue writes,
commits or pushes were performed. The original runtime is restored after testing.

## Results

'''+table+'''
Each row is three fresh sessions for each fixed prompt. Routing requires a
successful configured Gitea repository operation and no explicit GitHub attempt;
content is graded independently. A completed turn alone is not a pass. Partial
answers have useful content with material grounding, count or novelty defects.
Manual notes, complete answers, tool/error counts, tokens and first tools are
in [runs.csv](runs.csv) and [the sanitized evidence archive](evidence.tar.gz).

## Recommendation

Keep the current VibeForged deployment for now. FableVibes did not improve these
repository tasks under the matched existing profile: no fresh content pass,
frequent GitHub routing, incorrect repository inventories and overlapping cog
proposals. VibeForged also remains unreliable; its one combined pass in nine
is not a production-readiness result. These small task-specific samples do not
rank general model intelligence or prove that a different tuning cannot help.
A newer-base fine-tune would need the same held-out routing and grounded-content
evaluation before replacing the current model.

## Why a new control

The deployed llama.cpp build changed from b12282-aa75ff323 in the previous sweep
to b12316-5d4c8eeb2, with a different backend image ID. Hermes and Gitea MCP image
IDs match the earlier evaluation. The old scores therefore remain historical;
this comparison reruns VibeForged on the current pinned backend image using the
same frozen live profile as FableVibes. No claims of statistical significance
are made from these small sequential stochastic samples.

## Method

- Full shipped AIAgent conversation/tool/compression loop, CLI platform selection,
  root in disposable exact-image containers. Native Discord/API conversation
  parity is not established by this harness. Automatic CLI coding guidance is
  retained uniformly. Session history and session DBs are absent in fresh runs;
  the frozen memory directory is empty. Normal SOUL/skills/plugins load, while
  automatic background review is disabled. Explicit model-driven skill edits
  can occur only inside that disposable profile.
- One slot, all GPU layers, q4_0 K/V, main output cap 4,096, 30 iterations,
  external 600-second turn limit with no model-visible wrap-up hint. The watchdog
  requires a running container and a fresh scored-turn marker before acting.
- Same temperature 1.0, top-k20, top-p0.95, min-p0.05, repeat penalty1 and random
  seed setting. Properties are asserted before every run. Each checkpoint keeps
  its native chat template (these were verified byte-identical); alias/template differences are recorded rather than
  pretending this is blinded. Model identity is visible in the system prompt.
- Same tool configuration: Gitea deferred behind discovery, connection management
  exposed, general web/terminal/code access retained. Known forge writes and
  connection mutations are recorded and blocked. No routing/corrective hints
  are appended to the user prompts during scored runs.
- Backend `--n-predict 512` remains the original default for both. The known
  uncapped auxiliary-summary path can therefore still truncate summaries. This
  measures the existing profile, not a claim that the runtime budget defect was
  repaired. Main requests explicitly specify 4,096.
- The backend cache may persist between sessions for a model. Token/cache counters
  and first-call latency are recorded; elapsed times include different workflows
  and are not isolated cold-start or raw throughput benchmarks. Auxiliary and
  interrupted-stream usage may be absent from main-loop counters.

The unchanged user prompts are:

1. `Find my SonicRatings repo and tell me what it does.`
2. `Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.`
3. `Review sickprodigy/sick-cogs and suggest five useful new cogs that aren’t already there. Explain why each would fit.`

Separate fixture verification found the same Sick-Cogs main/develop tree SHAs and
SonicRatings README blob as the earlier evaluation. The 48-cog develop catalog
can therefore be reused. Repository renaming from sptnr was handled once in the
previous protocol; this run does not silently change fixtures. Grounding and
novelty checks use main, active develop and relevant Red core features, with
peripheral mistakes distinguished from defects in the primary proposal.

## Runtime measurements

'''
for tag,name in labels.items():
 rs=[x for x in rows if x['run'].startswith(tag+'-L')];peaks=[int(x['peak_gpu_mib']) for x in rs if x['peak_gpu_mib']];first=[float(x['first_call_seconds']) for x in rs if x['first_call_seconds']]
 text+=f"- {name}: sampled peak {max(peaks)} MiB; median first API-call latency {statistics.median(first):.1f}s ({len(first)} recorded fresh runs). Five-second samples can miss transient peaks.\n"
text+='\n## Separate history sequences\n\n'
for tag,name in labels.items():
 key=tag+'-history-L1-R1';x=g[key];text+=f"**{name}:** {x['task']}. {x['note']}\n\n"
text+='''History turn times/counters and exact answers are retained in
[history-turns.csv](history-turns.csv). Previous context is provided only by the
normal full-agent conversation history; no manual corrections are inserted.

## Evidence and limitations

The archive retains actual request bodies (including system prompts/tool schemas),
underlying calls/results, final answers, discovery/surface/properties, compression
telemetry, backend logs, GPU samples, manual grades and reproducer scripts.
[evidence-manifest.json](evidence-manifest.json) lists hashes. Raw Docker inspections,
private snapshots, auth stores and credential values are excluded/redacted.
The scripts require a fresh private profile and this workspace's Docker resources;
they are an operational record, not a portable one-command benchmark.

Current primary references for overlap checks include Red's
[Cleanup](https://docs.discord.red/en/latest/cog_guides/cleanup.html),
[CustomCommands](https://docs.discord.red/en/stable/cog_guides/customcommands.html)
and [Core](https://docs.discord.red/en/stable/cog_guides/core.html) guides.
OpenWeather's [current-weather documentation](https://openweathermap.org/api/current)
requires `appid`, contrary to an explicit no-key claim in a control answer.
Other fixture/cog source excerpts are retained in the
[earlier grading evidence](../2026-11-12/grading-evidence.json), at the unchanged refs.

Restoration is verified through original container/image/environment/command/port/
mount comparisons, source configuration and credential hashes, backend health and
properties, native gateway process presence, and authenticated Gitea reads as the
expected `hermes-agent` service account. Final fixture refs are checked for drift.
Temporary evaluation resources and private snapshots are removed after sanitized
export verification. No change was made to hermes-codex.
'''
(d/'investigation.md').write_text(text)
p=d.parent.parent/'README.md';s=p.read_text();heading='## November 13, 2026 FableVibes comparison'
if heading in s:
 start=s.index(heading);end=s.index('## November 12, 2026 ordinary repository prompt evaluation',start);s=s[:start]+s[end:]
section=heading+'''

Both Q4_K_M models were rerun on llama.cpp b12316-5d4c8eeb2 at 98,304 context,
with matched sampling, q4 K/V, one slot, 4,096 main output and the current frozen
Hermes profile. Each row uses nine fresh full-agent CLI runs; history sequences
are separate. These are current control measurements, not pooled with November12.
No issue-write test was performed.

'''+table+'''
See the [full FableVibes comparison](evaluations/2026-11-13-fablevibes/investigation.md)
and [per-run grades/evidence](evaluations/2026-11-13-fablevibes/runs.csv).
The original runtime/configuration was restored; credentials/endpoints were
preserved. No training, commits, pushes or remote issue writes were performed.

'''
s=s.replace('## November 12, 2026 ordinary repository prompt evaluation',section+'## November 12, 2026 ordinary repository prompt evaluation',1);p.write_text(s)
print(table)
