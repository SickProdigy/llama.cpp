import sys,pathlib,tarfile,json
sys.path.insert(0,'/opt/hermes')
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
from tools.registry import registry
discover_mcp_tools()
def call(name,args):
 raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__'+name,args)
 x=json.loads(raw);assert 'error' not in x,(name,x)
 x=x.get('result',x)
 return json.loads(x) if isinstance(x,str) else x
out={'principal':call('get_me',{}).get('login')}
for ref in ['main','develop']:
 out[ref]=call('get_repository_tree',{'owner':'sickprodigy','repo':'sick-cogs','tree_sha':ref,'per_page':100})
for repo,path in [('SonicRatings','README.md'),('Sick-Cogs','ReadMe.md')]:
 out[repo+' README']=call('get_file_contents',{'owner':'sickprodigy','repo':repo,'path':path})
out['SonicRatings search']=call('search_repos',{'query':'SonicRatings'})
pathlib.Path('/eval/fixtures.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'principal':out['principal'],'main':out['main']['sha'],'develop':out['develop']['sha'],'sonic_readme':out['SonicRatings README']['sha']}))
