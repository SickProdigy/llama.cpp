import subprocess,pathlib,json,time,urllib.request,tarfile,os
r=pathlib.Path('/tmp/hermes-fable-eval')
def sh(args,**kw):return subprocess.run(args,check=True,text=True,**kw)
def ready(alias=None):
 for _ in range(180):
  try:
   with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=3) as f:p=json.load(f)
   if p.get('model_path') and (alias is None or p['model_alias']==alias):return p
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('Backend readiness timeout')
def remove_backend():
 d=subprocess.run(['docker','inspect','llama-routing-eval'],capture_output=True,text=True)
 if d.returncode==0:
  if json.loads(d.stdout)[0]['State']['Running']:sh(['docker','stop','-t','15','llama-routing-eval'],stdout=subprocess.DEVNULL)
  sh(['docker','rm','llama-routing-eval'],stdout=subprocess.DEVNULL)
def switch(file,alias,label):
 sh(['docker','stop','-t','20','llama-cpp'],stdout=subprocess.DEVNULL);remove_backend()
 im=json.load(open(r/'original-llama-inspect.json'))[0]['Image']
 args=['docker','run','-d','--name','llama-routing-eval','--network','homelab','--network-alias','llama','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','25g','--memory-swap','25g','--health-cmd','curl -f http://localhost:11430/health',im,'-m','/models/'+file,'--alias',alias,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size','98304','--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--n-predict','512','-ngl','999','--temp','1','--top-k','20','--top-p','0.95','--min-p','0.05','--repeat-penalty','1','--presence-penalty','0','--frequency-penalty','0']
 sh(args,stdout=subprocess.DEVNULL);p=ready(alias);(r/(label+'-props.json')).write_text(json.dumps(p,indent=2))
 gpu=sh(['docker','exec','llama-routing-eval','nvidia-smi','--query-gpu=name,memory.used,memory.total,utilization.gpu','--format=csv'],capture_output=True).stdout;(r/(label+'-idle-gpu.txt')).write_text(gpu)
 with open(r/(label+'-backend.log'),'w') as f:subprocess.Popen(['docker','logs','-f','llama-routing-eval'],stdout=f,stderr=subprocess.STDOUT)
 print('BACKEND',label,p['model_alias'],p['default_generation_settings']['n_ctx'],gpu.strip(),flush=True)
def batch(label,alias,seq=False):sh(['python3',str(r/'batch.py'),label,'98304',alias,'baseline-sequence' if seq else 'baseline'])
hermes=json.load(open(r/'original-hermes-inspect.json'))[0]
sh(['docker','stop','-t','30','hermes'],stdout=subprocess.DEVNULL)
try:
 sh(['docker','volume','create','hermes-routing-evidence'],stdout=subprocess.DEVNULL)
 sh(['docker','run','-d','--name','hermes-routing-store','--network','homelab','--volumes-from','hermes:ro','--mount','type=volume,source=hermes-routing-evidence,target=/eval','--entrypoint','sleep',hermes['Image'],'infinity'],stdout=subprocess.DEVNULL)
 snapshot="""import tarfile,pathlib
p=pathlib.Path('/opt/data'); names=['config.yaml','.env','SOUL.md','AGENTS.md','skills','memories','plugins','auth.json']; names += ['cache/'+x for x in ['tool_discovery_cache.json','plugin_toolset_keys.json','mcp_schema_cache.json','reasoning_caps.json','discord_capabilities.json','local_endpoint_probes.json']]
with tarfile.open('/eval/profile.tgz','w:gz') as t:
 for n in names:
  if (p/n).exists(): t.add(p/n,arcname=n)
"""
 sh(['docker','exec','hermes-routing-store','python','-c',snapshot])
 sh(['docker','cp','hermes-routing-store:/eval/profile.tgz',str(r/'profile.tgz')]);(r/'profile.tgz').chmod(0o600)
 for name in ['run.py','session.py','fixtures.py','reference-props.json']:
  sh(['docker','cp',str(r/name),'hermes-routing-store:/eval/'+name])
 sh(['docker','run','--rm','--network','homelab','--mount','type=volume,source=hermes-routing-evidence,target=/eval','-e','HERMES_HOME=/opt/data','--entrypoint','python',hermes['Image'],'/eval/fixtures.py'])
 sh(['docker','cp','hermes-routing-store:/eval/fixtures.json',str(r/'fixtures.json')])
 # Each model receives its own nine fresh runs and history, on this exact backend image.
 for label,file,alias in [('vibeforged-control','Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m'),('fablevibes','Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','qwen3.6-14b-a3b-fablevibes-q4_k_m')]:
  switch(file,alias,label);batch(label,alias);batch(label+'-history',alias,True)
finally:
 remove_backend();sh(['docker','start','llama-cpp'],stdout=subprocess.DEVNULL);ready(json.load(open(r/'reference-props.json'))['model_alias']);sh(['docker','start','hermes'],stdout=subprocess.DEVNULL);print('RESTORED originals',flush=True)
