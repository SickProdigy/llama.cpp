import pathlib,json,re,csv
root=pathlib.Path('/tmp/hermes-fable-eval/scored')
prompts=['Find my SonicRatings repo and tell me what it does.','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.','Review sickprodigy/sick-cogs and suggest five useful new cogs that aren’t already there. Explain why each would fit.']
def payload(content):
 if not isinstance(content,str):return content
 for m in re.finditer(r'[\{\[]',content):
  try:return json.JSONDecoder().raw_decode(content[m.start():])[0]
  except Exception:pass
 return {}
def bad(v):
 if isinstance(v,dict):return bool(v.get('error') or v.get('success') is False or v.get('status')=='error' or (isinstance(v.get('exit_code'),int) and v['exit_code']!=0)) or any(bad(w) for k,w in v.items() if k not in ('arguments','args'))
 if isinstance(v,list):return any(bad(w) for w in v)
 return False
rows=[]
for p in sorted(root.glob('*history*/result.json')):
 results=json.loads(p.read_text());turns=[{'calls':{},'tools':{}} for _ in prompts];sources=[]
 for req in sorted(p.parent.glob('request-*.json')):sources.append(json.loads(req.read_text()).get('messages',[]))
 sources.extend(r.get('messages',[]) for r in results)
 for messages in sources:
  current=None
  for m in messages:
   if m.get('role')=='user' and m.get('content') in prompts:current=prompts.index(m['content'])
   if current is None:continue
   if m.get('role')=='assistant':
    for call in m.get('tool_calls',[]):turns[current]['calls'][call.get('id',json.dumps(call))]=call
   if m.get('role')=='tool':turns[current]['tools'][m.get('tool_call_id',json.dumps(m))]=m
 prev={k:0 for k in ('prompt_tokens','completion_tokens','cache_read_tokens')}
 for i,r in enumerate(results):
  calls=[c['function'] for c in turns[i]['calls'].values()];tools=list(turns[i]['tools'].values());github=[];admins=[]
  for c in calls:
   try:a=json.loads(c.get('arguments','{}'))
   except Exception:a=c.get('arguments')
   gitea=c['name'].startswith('mcp__mcp_gitea_hermes__') or (c['name']=='tool_call' and isinstance(a,dict) and a.get('calls') and all(str(x.get('name','')).startswith('mcp__mcp_gitea_hermes__') for x in a['calls']))
   if not gitea and re.search(r'githubusercontent\.com|github\.com|\bgithub\b|\bgh\s+(?:repo|issue|api)',json.dumps(a),re.I):github.append(c)
   if c['name']=='manage_connections':admins.append(c)
  x={'sequence':p.parent.name,'turn':i+1,'seconds':round(r.get('eval_elapsed',0),1),'first_tool':json.dumps(calls[0] if calls else None),'model_tool_calls':len(calls),'gitea_repo_results':sum(str(m.get('name','')).startswith('mcp__mcp_gitea_hermes__') and not str(m.get('name','')).endswith(('__get_me','__search_users')) and not bad(payload(m.get('content',''))) for m in tools),'github_attempts':len(github),'connection_calls':len(admins),'tool_errors':sum(bad(payload(m.get('content',''))) for m in tools),'completed':r.get('completed'),'exit_reason':r.get('turn_exit_reason'),'last_prompt_tokens':r.get('last_prompt_tokens'),'answer':r.get('final_response','')}
  for k in prev:x[k+'_delta']=r.get(k,0)-prev[k];prev[k]=r.get(k,0)
  rows.append(x)
dest=pathlib.Path('/tmp/hermes-fable-eval/history-turns.csv')
if rows:
 with dest.open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print([(r['sequence'],r['turn'],r['seconds'],r['gitea_repo_results'],r['github_attempts'],r['completed']) for r in rows])
