"""Regression tests for Room Announcer room-name parsing and targeting."""

from __future__ import annotations

import sys
import types
from unittest import mock

import pytest


def _load_plugin_module():
    """Import announcer without a running Nicotine+ instance."""
    if "announcer" in sys.modules:
        return sys.modules["announcer"]

    events_module = types.ModuleType("pynicotine.events")

    class _Events:
        def schedule(self, *_args, **_kwargs):
            return None

    events_module.events = _Events()

    pluginsystem_module = types.ModuleType("pynicotine.pluginsystem")

    class BasePlugin:
        def __init__(self, *args, **kwargs):
            self.settings = {}
            self.commands = {}

        def log(self, *args, **kwargs):
            pass

        def output(self, *args, **kwargs):
            pass

        def echo_message(self, *args, **kwargs):
            pass

        def echo_public(self, *args, **kwargs):
            pass

        def echo_private(self, *args, **kwargs):
            pass

    pluginsystem_module.BasePlugin = BasePlugin

    package_module = types.ModuleType("pynicotine")
    for name, module in {
        "pynicotine": package_module,
        "pynicotine.events": events_module,
        "pynicotine.pluginsystem": pluginsystem_module,
    }.items():
        sys.modules[name] = module

    sys.path.insert(0, str(__file__).rsplit("/", 1)[0] + "/..")
    try:
        import announcer
    finally:
        sys.path.pop(0)
    return announcer


announcer = _load_plugin_module()


def _plugin_with_rooms(default_rooms: str, room_groups_json: str, joined_rooms):
    plugin = announcer.Plugin()
    plugin.settings = dict(announcer.Plugin.settings)
    plugin.settings.update(
        {
            "default_rooms": default_rooms,
            "room_groups_json": room_groups_json,
            "sending_enabled": False,
        }
    )
    core = types.SimpleNamespace()
    core.chatrooms = types.SimpleNamespace(joined_rooms=list(joined_rooms))
    plugin.core = core
    return plugin


def test_group_json_room_with_comma_stays_one_room():
    rooms = announcer._parse_groups('{"news": ["Chat, News", "Plain Room"]}')
    assert rooms == {"news": ["Chat, News", "Plain Room"]}


def test_group_json_rooms_still_trim_and_dedupe():
    rooms = announcer._parse_groups('{"a": ["  One ", "one", "Two"]}')
    assert rooms == {"a": ["One", "Two"]}


def test_group_json_non_list_and_non_string_entries_rejected():
    with pytest.raises(announcer.AnnouncementError):
        announcer._parse_groups('{"a": "not a list"}')
    with pytest.raises(announcer.AnnouncementError):
        announcer._parse_groups('{"a": ["ok", 42]}')


def test_announcegroup_targets_room_with_comma():
    plugin = _plugin_with_rooms(
        "",
        '{"news": ["Chat, News", "Other"]}',
        joined_rooms=["Chat, News", "Other"],
    )
    captured = []
    plugin._local_reply = lambda room, user: lambda message: captured.append(message)
    assert plugin.announce_group_command("news hello", room="Room", user="User")
    assert captured == ["PREVIEW to Chat, News, Other: [Open Source] hello"]


def test_announcegroup_does_not_create_fake_rooms_from_comma_split():
    plugin = _plugin_with_rooms(
        "",
        '{"news": ["Chat, News"]}',
        joined_rooms=["Chat, News"],
    )
    captured = []
    plugin._local_reply = lambda room, user: lambda message: captured.append(message)
    assert plugin.announce_group_command("news hello", room="Room", user="User")
    assert captured == ["PREVIEW to Chat, News: [Open Source] hello"]


def test_announce_all_includes_group_room_with_comma():
    plugin = _plugin_with_rooms(
        "Plain Room",
        '{"news": ["Chat, News"]}',
        joined_rooms=["Plain Room", "Chat, News"],
    )
    captured = []
    plugin._local_reply = lambda room, user: lambda message: captured.append(message)
    assert plugin.announce_all_command("hello", room="Room", user="User")
    assert captured == ["PREVIEW to Plain Room, Chat, News: [Open Source] hello"]


def test_default_rooms_csv_behavior_unchanged():
    assert announcer._csv_rooms("  One , One ,two ,") == ["One", "two"]


def test_announce_default_rooms_uses_csv_setting():
    plugin = _plugin_with_rooms("Alpha, Beta", "{}", joined_rooms=["Alpha", "Beta"])
    captured = []
    plugin._local_reply = lambda room, user: lambda message: captured.append(message)
    assert plugin.announce_command("hello", room="Room", user="User")
    assert captured == ["PREVIEW to Alpha, Beta: [Open Source] hello"]


def test_preview_only_mode_never_schedules_sends():
    plugin = _plugin_with_rooms(
        "",
        '{"news": ["Chat, News"]}',
        joined_rooms=["Chat, News"],
    )
    captured = []
    plugin._local_reply = lambda room, user: lambda message: captured.append(message)
    with mock.patch.object(announcer.events, "schedule", side_effect=AssertionError("must not schedule")):
        assert plugin.announce_group_command("news hello", room="Room", user="User")
    assert plugin._scheduled == {}
    assert captured == ["PREVIEW to Chat, News: [Open Source] hello"]


def test_unjoined_filtered_rooms_are_not_targets():
    plugin = _plugin_with_rooms(
        "",
        '{"news": ["Chat, News", "Never Joined"]}',
        joined_rooms=["Chat, News"],
    )
    captured = []
    plugin._local_reply = lambda room, user: lambda message: captured.append(message)
    assert plugin.announce_group_command("news hello", room="Room", user="User")
    assert captured == ["PREVIEW to Chat, News: [Open Source] hello"]
