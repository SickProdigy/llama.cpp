# Room Announcer

Room Announcer previews or sends one message to a controlled set of Nicotine+
rooms. Soulseek calls these chats **rooms**; this plugin's named **groups** are
local aliases that collect rooms you choose.

Sending is disabled by default. In preview mode, commands show the final message
and targets only in your local client. The plugin never auto-joins rooms and only
targets explicitly configured rooms that you are currently in.

## Configuration

Set **Default rooms** to a comma-separated list used by `/announce`, for example:

```text
Linux, Open Source
```

Set **Named groups JSON** to a JSON object whose values are room lists:

```json
{"opensource": ["Linux", "Open Source"], "media": ["Music", "Books"]}
```

### Room names containing commas

The two settings parse room names differently:

- **Default rooms** is a comma-separated string. A room name that contains a
  comma cannot be represented and will be split into multiple (wrong) rooms.
  Use a group instead for such rooms.
- **Named groups JSON** keeps each room name intact because JSON strings are
  parsed directly, not split on commas. A room named `Chat, News` is configured
  as:

```json
{"news": ["Chat, News", "Open Source"]}
```

`/announcegroup news hello` targets exactly `Chat, News` and `Open Source`.
`/announceall hello` targets the union of default rooms and every group's
rooms, also keeping `Chat, News` as a single room.

Both formats still trim whitespace and remove case-insensitive duplicates,
and only rooms you are currently joined to are targeted.

Review previews before enabling **Actually send announcements**. Messages are
queued with a configurable delay between rooms, and an identical message to the
same targets is blocked during the duplicate cooldown. The prefix and final
message-length limit are also configurable.

## Commands

- `/announce <message>` — default rooms
- `/announcegroup <group> <message>` — one named group
- `/announceall <message>` — union of all explicitly configured rooms
- `/announcecancel` — cancel all queued sends
- `/announcestatus` — show mode, configured targets, and queue size
- `/announcestatus <group>` — show one group's configured rooms and which are
  currently joined (read-only: no sending, joining, scheduling, or cooldown
  changes)

Commands are owner-side slash commands, not remote chat triggers. Preview and
status output are local echoes and are not posted to the room. Keep intervals
conservative and use this for occasional, relevant announcements where room
rules permit them; the plugin intentionally has no recurring schedule.

## Requirements

Nicotine+ 3.3.11 or newer and Python 3.9 or newer. No additional packages or
credentials are required.
