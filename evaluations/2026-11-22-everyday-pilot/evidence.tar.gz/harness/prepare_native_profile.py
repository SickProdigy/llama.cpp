"""Run only in trusted operator, on /state. Never copy production auth/env."""
from pathlib import Path
from ruamel.yaml import YAML
import tarfile,shutil,sys,os,json,hashlib
D=Path('/state');arm=sys.argv[1];endpoint=sys.argv[2];repo='hermes-pilot-'+arm+'-20261122';alias=sys.argv[3] if len(sys.argv)>3 else 'qwen3.8-27b-hermes-adapted-iq3xxs'
profile=D/'arms'/arm/'profile';profile.mkdir(parents=True,exist_ok=True)
with tarfile.open(D/'normal-profile-private.tgz') as t:t.extractall(profile,filter='data')
yaml=YAML(typ='safe');c=yaml.load((profile/'config.yaml').read_text());orig=json.loads(json.dumps(c))
sampler={'temperature':.8,'top_p':1.,'presence_penalty':0.,'top_k':0,'min_p':0.,'repeat_penalty':1.,'chat_template_kwargs':{'enable_thinking':False}}
c['model']={'default':alias,'provider':'custom:pilot','base_url':endpoint,'api_key':'local-pilot-only','context_length':98304,'max_tokens':8192}
c['custom_providers']=[{'name':'pilot','base_url':endpoint,'api_key':'local-pilot-only','model':alias,'extra_body':dict(sampler,max_tokens=8192)}]
c['fallback_providers']=[];c['platforms']={};c['dashboard']['enabled']=False;c['telemetry']={'enabled':False}
c['mcp_servers']={'mcp-gitea-hermes':{'url':'http://gitea-pilot:8080/mcp','transport':'streamable-http','timeout':600}}
# Profile policies remain enabled, including explicit approval for memory and skill writes.
a=c['agent'];a['disabled_toolsets']=[x for x in a.get('disabled_toolsets',[]) if x!='memory'];a['disabled_toolsets']=list(dict.fromkeys(a['disabled_toolsets']+['mcp-gitea-hermes','discord','discord_admin']))
a['max_turns']=60;a['run_budget_seconds']=1800;a['gateway_timeout']=2200
hint=a.get('environment_hint','').replace('Hermes data and workspace files live under /opt/data.','Hermes data lives under /opt/data; the selected repository checkout is /workspace.').replace('mcp__mcp_gitea_hermes__get_file_contents','gitea_read_file').replace('mcp__mcp_gitea_hermes__','gitea_').replace('search_repos','gitea_search_repositories').replace('get_dir_contents','gitea_list_directory').replace('get_file_contents','gitea_read_file').replace('with with_lines: true, start_line: 1, end_line: 160','with start_line: 1, end_line: 160')
a['environment_hint']=hint+' Infer upstream ownership from the selected Git repository and the configured Gitea repository metadata; personal fork ownership comes from the authenticated Gitea identity. Use local repository tools for code and tests, and the configured Gitea MCP for forge operations.'
c['terminal'].update(backend='local',cwd='/workspace',timeout=90)
c['compression'].update(threshold=.85,threshold_tokens=None)
c.setdefault('auxiliary',{}).setdefault('compression',{}).update(extra_body={'max_tokens':8192,'chat_template_kwargs':{'enable_thinking':False}})
plugins=c['plugins'];plugins['enabled']=[x for x in plugins.get('enabled',[]) if x!='discord-platform']
for name in ['gitea-focused','gitea-workspace','selected-project']:
 shutil.copytree(D/'plugins'/name,profile/'plugins'/name,dirs_exist_ok=True)
 plugins['enabled']=list(dict.fromkeys(plugins['enabled']+[name]))
entries=plugins.setdefault('entries',{})
entries['gitea-focused']={'settings':{'allowed_upstream_repositories':['chatgpt-codex/'+repo],'public_url':'https://gitea.rcs1.top'}}
entries['gitea-workspace']={'settings':{'workspace_root':'/workspace','baseline_ref':('1d8f965035e97403ebe13a57607d2d9c5d36d6e9' if arm=='review' else '01e776cc518d02cacb9fec12143edeef6a95d2ad'),'allowed_upstream_repositories':['chatgpt-codex/'+repo],'allowed_paths':['README.md'],'allowed_path_prefixes':['beetsbridge/','announcer/','arrrequests/','tests/'],'public_url':'https://gitea.rcs1.top'}}
entries['selected-project']={'settings':{'workspace_root':'/workspace'}}
c.setdefault('platform_toolsets',{})['cli']=list(dict.fromkeys(c.get('platform_toolsets',{}).get('cli',[])+['memory','gitea-focused','gitea-workspace']))
YAML().dump(c,(profile/'config.yaml').open('w'))
# No production keys, platform credentials or external auth stores are copied.
for p in [profile,*profile.rglob('*')]:
 if not p.is_symlink():os.chown(p,1000,1000)
notes={'arm':arm,'cloned_profile_components':['config.yaml','SOUL.md','skills','memories','plugins','hooks'],'not_copied':['.env','auth.json','mcp-tokens','state.db','sessions'],'modified_top_level_keys':[k for k in c if orig.get(k)!=c[k]],'memory_write_approval':c['memory'].get('write_approval'),'skills_write_approval':c['skills'].get('write_approval'),'memory_tool_enabled':True,'native_background_review':'normal default retained; separate from prepublication review','sampler_native_custom_provider_extra_body':sampler,'max_tokens':8192,'compression_threshold':.85,'read_only_rootfs':True,'workspace':'/workspace','write_safe_root':'/workspace:/opt/data/cache/scratch','profile_config_sha256':hashlib.sha256((profile/'config.yaml').read_bytes()).hexdigest()}
(D/'arms'/arm/'profile-manifest.json').write_text(json.dumps(notes,indent=2))
print(json.dumps(notes))
