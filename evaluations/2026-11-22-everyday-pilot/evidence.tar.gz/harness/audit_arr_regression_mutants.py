"""API-preserving discrimination of Arr model regression tests, posthoc only."""
from pathlib import Path
import ast,shutil,json,time
import controller as c
from audit_arr_model_test_quality import check
D=c.D;out=D/'provisional-review-audits/arr-additional-regression-mutants';out.mkdir(exist_ok=True);records={}
for name,source,target in [('plain-feature',D/'runs/plain-arrrequests/turn2/workspace','tests/test_arrrequests.py::RedirectCredentialTests::test_allow_redirects_false_refuses_same_origin_redirect'),('review-cross',D/'runs/review-arrrequests/turn1/workspace','tests/test_arrrequests.py::RedirectBoundaryTests::test_cross_origin_redirect_is_blocked_and_key_not_leaked')]:
 stage=out/(name+'-mutant');assert not stage.exists();shutil.copytree(source,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
 try:
  actual=check(stage,target,out/(name+'-actual.log'));p=stage/'arrrequests/__init__.py';s=p.read_text()
  if name=='plain-feature':
   assert s.count('    if allow_redirects:')==1;s=s.replace('    if allow_redirects:','    if True:')
  else:
   tree=ast.parse(s);n=next(x for x in ast.walk(tree) if isinstance(x,ast.FunctionDef) and x.name=='_check_redirect_origin');lines=s.splitlines(keepends=True);lines[n.lineno:n.end_lineno]=['        return None\n'];s=''.join(lines)
   assert 'returned an unexpected lookup response.' in s;s=s.replace('returned an unexpected lookup response.','returned an unexpected origin lookup response.')
  compile(s,str(p),'exec');p.write_text(s);mutant=check(stage,target,out/(name+'-mutant.log'));records[name]={'actual':actual,'mutant':mutant}
  assert actual['exit_code']==0 and mutant['exit_code']!=0,name
 finally:shutil.rmtree(stage)
result={'epoch':time.time(),'posthoc_not_primary':True,'not_fed_to_models':True,'no_actual_source_edits':True,'mutations':{'plain-feature':'Ignore allow_redirects flag but retain accepted public keyword and all other implementation.','review-cross':'Disable only origin predicate while preserving APIs; put origin in generic unexpected-payload message so assertion reaches leaked-header checks instead of incidental wording.'},'results':records,'manual_failure_location_review_required':True};(out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(records))
