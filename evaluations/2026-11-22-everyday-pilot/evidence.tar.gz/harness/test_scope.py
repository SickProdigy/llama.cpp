import unittest
from scope_proxy import Scope,Denied
class Isolation(unittest.TestCase):
 def setUp(self):
  self.s=Scope({'owner':'up','repo':'project','fork_repo':'project','base_sha':'a'*40,'branch_prefix':'eval-own-','allowed_paths':['README.md']});self.s.branch='eval-own-fix'
 def read(self,ref,owner='hermes-agent'):
  return self.s.check('get_repository_tree',{'owner':owner,'repo':'project','tree_sha':ref})
 def test_unknown_sha_denied(self):
  with self.assertRaises(Denied):self.read('b'*40)
 def test_verified_own_flat_sha_allowed(self):
  self.s.filter('branch_read',[{'name':self.s.branch,'commit_sha':'b'*40}],{'owner':'hermes-agent','repo':'project'})
  self.assertEqual(self.read('b'*40),'read')
 def test_verified_own_nested_sha_allowed(self):
  self.s.filter('branch_read',[{'name':self.s.branch,'commit':{'id':'b'*40}}],{'owner':'hermes-agent','repo':'project'})
  self.assertEqual(self.read('b'*40),'read')
 def test_foreign_branch_filtered_and_sha_denied(self):
  out=self.s.filter('branch_read',[{'name':'eval-other-fix','commit_sha':'b'*40}],{'owner':'hermes-agent','repo':'project'});self.assertEqual(out,[])
  with self.assertRaises(Denied):self.read('b'*40)
 def test_upstream_metadata_does_not_authorize_fork_sha(self):
  self.s.filter('branch_read',[{'name':self.s.branch,'commit_sha':'b'*40}],{'owner':'up','repo':'project'})
  with self.assertRaises(Denied):self.read('b'*40)
 def test_verified_fork_sha_not_allowed_on_upstream(self):
  self.s.filter('branch_read',[{'name':self.s.branch,'commit_sha':'b'*40}],{'owner':'hermes-agent','repo':'project'})
  with self.assertRaises(Denied):self.read('b'*40,owner='up')
 def test_original_base_and_own_branch_remain_readable(self):
  self.assertEqual(self.read('a'*40),'read');self.assertEqual(self.read(self.s.branch),'read')
 def test_default_branch_and_foreign_repo_write_remain_denied(self):
  for owner,branch in [('up','eval-own-fix'),('hermes-agent','main')]:
   with self.assertRaises(Denied):self.s.check('create_or_update_file',{'owner':owner,'repo':'project','branch_name':branch,'path':'README.md','content':'x'})
if __name__=='__main__':unittest.main()
