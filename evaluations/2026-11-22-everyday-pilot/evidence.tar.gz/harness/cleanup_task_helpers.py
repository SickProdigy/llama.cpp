"""Run from the host after final audits. Exact task IDs only; preserve bind data."""
from pathlib import Path
import json,subprocess,time
import controller as c
D=c.D
NAMES=['hermes-pilot-supervisor-first','hermes-pilot-supervisor-continuation1','hermes-pilot-supervisor','hermes-pilot-supervisor-continuation3','hermes-pilot-audit-watch','hermes-pilot-store','hermes-pilot-llm-proxy']
def get(name):
 p=subprocess.run(['docker','inspect',name],capture_output=True,text=True)
 return json.loads(p.stdout)[0] if p.returncode==0 else None

def inventory():
 assert not (D/'cleanup-owned-helper-manifest.json').exists()
 items=[]
 for name in NAMES:
  item=get(name);assert item,name
  own=[m for m in item['Mounts'] if m['Type']=='bind' and (m['Source']==c.ENGINE or m['Source'].startswith(c.ENGINE+'/'))];assert own,name
  items.append({'name':name,'id':item['Id'],'image':item['Image'],'task_bind_verified':True})
 net=json.loads(subprocess.check_output(['docker','network','inspect','hermes-pilot-coding']))[0];assert net['Internal']
 c.write(D/'cleanup-owned-helper-manifest.json',{'epoch':time.time(),'containers':items,'network':{'name':net['Name'],'id':net['Id'],'internal':True},'scope':'Only task helpers; no production containers, retained preexisting MCP services, model files, bind data or shared homelab network.'});print(json.dumps({'helpers_recorded':len(items),'network':net['Name']}))
def main():
 assert (D/'all-model-workflows-finished.json').exists()
 assert json.loads((D/'final-preservation.json').read_text())['passed']
 assert json.loads((D/'final-forge-audit.json').read_text())['passed']
 assert json.loads((D/'final-manual-review.json').read_text())['all_18_turns_independently_reviewed']
 manifest=json.loads((D/'cleanup-owned-helper-manifest.json').read_text());initial={x['name']:get(x['name']) for x in manifest['containers']}
 for expected in manifest['containers']:
  live=initial[expected['name']]
  if live:assert live['Id']==expected['id'] and live['Image']==expected['image'],'Changed helper identity; preserve and inspect'
 # These scoring containers must already be gone through controller finally restoration.
 for name in ['hermes-pilot-agent','hermes-pilot-proxy','llama-pilot-eval']:assert get(name) is None,'Scoring container remains: '+name
 removed=[]
 for expected in manifest['containers']:
  live=initial[expected['name']]
  if not live:continue
  output=subprocess.run(['docker','logs',expected['id']],capture_output=True);(D/('cleanup-'+expected['name']+'.log')).write_bytes(output.stdout+output.stderr)
  if live['State']['Running']:subprocess.run(['docker','stop','-t','5',expected['id']],check=True,stdout=subprocess.DEVNULL)
  subprocess.run(['docker','rm','-v',expected['id']],check=True,stdout=subprocess.DEVNULL);removed.append(expected['name'])
 net=manifest['network'];p=subprocess.run(['docker','network','inspect',net['id']],capture_output=True,text=True)
 if p.returncode==0:
  current=json.loads(p.stdout)[0];assert current['Id']==net['id'] and current['Name']==net['name'] and not current.get('Containers'),'Unexpected endpoint; preserve network'
  subprocess.run(['docker','network','rm',net['id']],check=True,stdout=subprocess.DEVNULL)
 result={'epoch':time.time(),'passed':all(get(x['name']) is None for x in manifest['containers']),'removed_task_containers':removed,'task_network_removed':True,'bind_data_and_models_preserved':True,'preexisting_mcp_services_untouched':True,'production_running':{n:get(n)['State']['Running'] for n in ['hermes','llama-cpp','hermes-codex']}}
 result['passed']=result['passed'] and all(result['production_running'].values());c.write(D/'task-helper-cleanup.json',result);print(json.dumps(result));assert result['passed']
if __name__=='__main__':
 import sys
 if '--inventory-only' in sys.argv:inventory()
 else:main()
