"""Run only the remaining fresh review-Arr case; preserve verified native SID rotation."""
from pathlib import Path
import hashlib
import inspect
import json
import os
import sqlite3
import subprocess
import time
import traceback
import controller as c
import resume_supervisor as prior
from native_session_lineage import compression_lineage

D = c.D
NAME = 'hermes-pilot-supervisor-continuation3'


def first_session_for(profile, query):
    db = sqlite3.connect('file:' + str(profile / 'state.db') + '?mode=ro', uri=True)
    try:
        row = db.execute("select session_id from messages where role='user' and content=? order by id limit 1", (query,)).fetchone()
        return row[0] if row else None
    finally:
        db.close()


def install_case():
    source = inspect.getsource(c.run_case)
    old = 'records.mkdir();scope='
    assert source.count(old) == 1
    source = source.replace(old, 'records.mkdir();os.chown(records,1000,1000);scope=')
    source = source.replace('  sid=None\n', '  sid=None;root_sid=None\n')
    old = '  for i,query in enumerate(prompts):'
    assert source.count(old) == 1
    source = source.replace(old, old + '\n   if sid:\n    with (run/("native-discard-before-turn"+str(i)+".log")).open("w") as recovery:\n     sh(["docker","exec",agent,"/opt/hermes/bin/hermes","sessions","discard",sid,"--yes"],stdout=recovery,stderr=subprocess.STDOUT)')
    old = "'session_id':sid,'state_db':'/profile/state.db'"
    assert source.count(old) == 1
    # The frozen Gate already resolves exact current-query receipts when SID is None.
    source = source.replace(old, "'session_id':None,'native_resume_session_id':sid,'state_db':'/profile/state.db'")
    old = "   if sid and found!=sid:raise RuntimeError('Dependent followup did not retain native session')"
    assert source.count(old) == 1
    source = source.replace(old, "   incoming_sid=sid\n   if not found:raise RuntimeError('Native CLI did not persist the frozen current query')\n   root_sid=root_sid or first_session_for(profile,prompts[0])\n   lineage=compression_lineage(profile/'state.db',root_sid,found)\n   if incoming_sid and found!=incoming_sid:compression_lineage(profile/'state.db',incoming_sid,found)\n   write(out/'native-session-lineage.json',{'logical_session_root':root_sid,'incoming_session_id':incoming_sid,'effective_session_id':found,'lineage':lineage,'task_replayed':False})")
    old = "'session_id':sid,'exit_code':code"
    assert source.count(old) == 1
    source = source.replace(old, "'session_id':sid,'logical_session_root':root_sid,'incoming_session_id':incoming_sid,'admission_session_id':incoming_sid or root_sid,'native_session_lineage':lineage,'native_session_rotation':len(lineage)>1,'exit_code':code")
    old = "{'session_id':sid,'turns_present':"
    assert source.count(old) == 1
    source = source.replace(old, "{'session_id':sid,'logical_session_root':root_sid,'native_session_lineage':lineage,'turns_present':")
    compile(source, str(D / 'continuation3-run-case.py'), 'exec')
    (D / 'continuation3-run-case.py').write_text(source)
    c.__dict__.update(first_session_for=first_session_for, compression_lineage=compression_lineage)
    exec(compile(source, str(D / 'continuation3-run-case.py'), 'exec'), c.__dict__)
    return hashlib.sha256(source.encode()).hexdigest()


def transport_ready():
    code = "import urllib.request,time\nend=time.monotonic()+30\nwhile time.monotonic()<end:\n try:\n  assert urllib.request.urlopen('http://llm-pilot:8080/v1/models',timeout=3).status==200\n  break\n except Exception:time.sleep(.3)\nelse:raise RuntimeError('Model recorder listener did not become ready')\n"
    c.quiet(['docker', 'exec', 'hermes-pilot-store', 'python', '-c', code])


def main():
    frozen = json.loads((D / 'frozen-protocol.json').read_text())
    for name, digest in frozen['files_sha256'].items():
        assert hashlib.sha256((D / name).read_bytes()).hexdigest() == digest, name
    assert len(list((D / 'runs').glob('*/turn*/run.json'))) == 15
    assert not (D / 'runs/review-arrrequests').exists()
    assert json.loads((D / 'runs/plain-arrrequests/case-finished.json').read_text())['turns_present'] == 3
    source_hash = install_case()
    initial = {name: c.inspect(name) for name in ['hermes', 'llama-cpp', 'hermes-codex']}
    original = json.loads((D / 'original-props.json').read_text())
    candidate = json.loads((D / 'candidate-manifest.json').read_text())
    for name, state in initial.items():
        before = json.loads((D / (name + '-pre-gpu-inspect.json')).read_text())[0]
        assert state['State']['Running'] and c.signature(state) == c.signature(before), name
        c.write(D / (name + '-continuation3-pre-gpu-inspect.json'), [state])
    c.ready(original['model_alias'])
    for name in ['hermes-pilot-agent', 'hermes-pilot-proxy', 'hermes-pilot-llm-proxy', 'llama-pilot-eval']:
        assert subprocess.run(['docker', 'inspect', name], capture_output=True).returncode != 0, name
    c.write(D / 'continuation3-started.json', {'epoch': time.time(), 'supervisor_name': NAME, 'remaining_case': ['arrrequests', 'review'], 'generated_run_case_sha256': source_hash, 'native_tasks_replayed': False, 'private_grader_or_corrective_hints_added': False, 'frozen_tasks_graders_reference_and_settings_unchanged': True, 'changes': 'Permit only verified native oneshot compression ancestry; use frozen Gate exact-query receipt lookup for every turn; retain native discard and owned record-directory fixes.'})
    try:
        c.quiet(['docker', 'stop', '-t', '30', 'hermes'])
        c.quiet(['docker', 'stop', '-t', '20', 'llama-cpp'])
        c.quiet(['docker', 'run', '-d', '--name', 'llama-pilot-eval', '--network', 'homelab', '--network-alias', 'llama-pilot', '--gpus', 'all', '--volumes-from', 'llama-cpp:ro', '-p', '11430:11430', '--memory', '40g', '--memory-swap', '40g', initial['llama-cpp']['Image'], *candidate['actual_test_backend_launch']['args']])
        c.write(D / 'candidate-props-continuation3.json', c.ready(c.ALIAS))
        records = D / 'llm-records-continuation3'
        records.mkdir()
        os.chown(records, 1000, 1000)
        c.quiet(['docker', 'create', '--name', 'hermes-pilot-llm-proxy', '--user', '1000:1000', '--network', 'homelab', '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--memory', '1g', *c.mount('public-harness', '/harness', True), *c.mount('llm-records-continuation3', '/records'), '--entrypoint', 'python', c.IMAGE, '/harness/llm_proxy.py'])
        c.quiet(['docker', 'network', 'connect', '--alias', 'llm-pilot', 'hermes-pilot-coding', 'hermes-pilot-llm-proxy'])
        c.quiet(['docker', 'start', 'hermes-pilot-llm-proxy'])
        c.quiet(['docker', 'exec', 'hermes-pilot-llm-proxy', 'python', '-c', 'from pathlib import Path;p=Path("/records/.write-preflight");p.write_text("ok");p.unlink()'])
        transport_ready()
        c.run_case('arrrequests', 'review', json.loads((D / 'task-prompts.json').read_text())['arrrequests'])
        assert len(list((D / 'runs').glob('*/turn*/run.json'))) == 18
        c.write(D / 'all-model-workflows-finished.json', {'epoch': time.time(), 'supervisor_name': NAME, 'prior_fifteen_turns_retained': True, 'native_compaction_rotation_recovery_without_replay': True})
    except BaseException as error:
        c.write(D / 'continuation3-error.json', {'error': str(error), 'traceback': traceback.format_exc()})
        raise
    finally:
        prior.restore(initial, original)


if __name__ == '__main__':
    main()
