"""Read pinned runtime redirect defaults; no network requests or model feedback."""
import json,sys,inspect,hashlib
from pathlib import Path
from urllib.request import HTTPRedirectHandler
import hidden_checks as h
m=h.load('arrrequests');handler=m.CredentialBoundaryRedirectHandler;source=Path(inspect.getfile(HTTPRedirectHandler));print(json.dumps({'python_version':sys.version.split()[0],'stdlib_source':str(source),'stdlib_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'stdlib_max_redirections':HTTPRedirectHandler.max_redirections,'stdlib_max_repeats':HTTPRedirectHandler.max_repeats,'candidate_max_redirections':handler.max_redirections,'candidate_max_repeats':handler.max_repeats,'candidate_defines_own_limits':any(n in handler.__dict__ for n in ['max_redirections','max_repeats'])}))
