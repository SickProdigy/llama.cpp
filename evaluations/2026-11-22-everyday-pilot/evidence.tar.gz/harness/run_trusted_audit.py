"""Host launcher for pinned native-Python operator audits; never invokes a model."""
from pathlib import Path
import subprocess,sys,json,time
import controller as c
D=c.D
assert len(sys.argv)>1
name=sys.argv[1];assert name.endswith('.py') and Path(name).name==name and (D/name).is_file()
start=time.time();args=['docker','run','--rm','--network','homelab','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--security-opt','no-new-privileges','--cpus','1','--memory','1g','--tmpfs','/tmp:rw,size=256m','--mount','type=bind,source='+c.ENGINE+',target=/state','--mount','type=bind,source=/var/run/docker.sock,target=/var/run/docker.sock','--mount','type=bind,source=/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-goal-recovery-20261121/rebuilt/docker,target=/usr/local/bin/docker,readonly','--entrypoint','python',c.IMAGE,'/state/'+name,*sys.argv[2:]]
log=D/('trusted-audit-'+name.removesuffix('.py')+'.log')
with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
print(json.dumps({'script':name,'native_image':c.IMAGE,'exit_code':r.returncode,'seconds':round(time.time()-start,3),'private_log':log.name,'no_model_request':True}));sys.exit(r.returncode)
