"""Read-only durable exit/GPU evidence; no agent input or process restart."""
from pathlib import Path
import json,time,subprocess,threading,http.client,socket
import controller as c
D=c.D;cfg=json.loads((D/'native-compaction-exec-observer-config.json').read_text());done=threading.Event()
def events():
 proc=subprocess.Popen(['docker','events','--since',str(int(cfg['epoch'])-5),'--filter','container='+cfg['actor_container_id'],'--filter','event=exec_die','--format','{{json .}}'],stdout=subprocess.PIPE,text=True)
 try:
  for line in proc.stdout:
   try:event=json.loads(line)
   except ValueError:continue
   attrs=event.get('Actor',{}).get('Attributes',{})
   if attrs.get('execID')!=cfg['native_exec_id']:continue
   result={'observed_epoch':time.time(),'event_epoch':event.get('timeNano',0)/1e9,'native_exec_id':cfg['native_exec_id'],'exit_code':int(attrs['exitCode']),'source':'Docker exec_die event for exact captured CLI exec','not_restarted_or_resubmitted':True};c.write(D/'native-compaction-exec-terminal.json',result);done.set();return
 finally:proc.terminate()
threading.Thread(target=events,daemon=True).start()
with (D/'native-compaction-observed-gpu.jsonl').open('a',buffering=1) as stream:
 while time.time()<cfg['original_turn_start_epoch']+2300 and not done.is_set():
  now=time.time();stream.write(json.dumps({'epoch':now,'seconds_from_original_start':round(now-cfg['original_turn_start_epoch'],3),'gpu':c.gpu(),'coverage':'Late observer only; original controller earlier samples may be lost if literal-ID assertion aborts.'})+'\n');done.wait(3)
