"""Operator-only readback. Never sends findings to a model or changes frozen inputs."""
from pathlib import Path
from review_gate import SYSTEM as REVIEW_SYSTEM
import json,hashlib,sqlite3,datetime
D=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
frozen=load(D/'frozen-protocol.json')
hashes={name:hashlib.sha256((D/name).read_bytes()).hexdigest()==sha for name,sha in frozen['files_sha256'].items()}
assert all(hashes.values()),'Frozen input changed'
requests=[]
for path in sorted(p for folder in D.glob('llm-records*') if folder.is_dir() for p in folder.glob('*.metrics.json')):
 metric=load(path);request=load(path.with_name(path.name.replace('.metrics.json','.request.json')))
 tools=[t.get('function',{}).get('name') for t in request.get('tools',[])]
 requests.append({'record_namespace':path.parent.name,'id':metric['id'],'purpose':metric['purpose'],'received_epoch':metric['received_epoch'],'backend_start_epoch':metric.get('backend_start_epoch'),'end_epoch':metric['end_epoch'],'wall_seconds':round(metric['end_epoch']-metric['received_epoch'],3),'queue_seconds':round(metric.get('backend_start_epoch',metric['received_epoch'])-metric['received_epoch'],3),'usage':metric.get('usage'),'finish_reasons':metric.get('finish_reasons'),'transport_error':metric.get('transport_error'),'outer_response_parse_failed':bool(metric.get('response_parse_failed')),'final_metrics_present':True,'model':request['model'],'messages':len(request['messages']),'message_json_chars':len(json.dumps(request['messages'],ensure_ascii=False)),'has_terminal_and_gitea_tools':'terminal' in tools and 'gitea_commit_workspace' in tools,'tool_schema_count':len(tools),'max_tokens':request.get('max_tokens'),'native_context_checkpoint_request':any(m.get('role')=='system' and isinstance(m.get('content'),str) and m['content'].startswith('You are a summarization agent creating a context checkpoint.') for m in request['messages']),'request_sha256':metric['request_sha256']})
# Include requests whose final metrics were lost on cancellation/recorder shutdown.
# Their persisted request-file timestamp bounds attribution; never count missing usage as zero.
for folder in D.glob('llm-records*'):
 if not folder.is_dir():continue
 for path in folder.glob('*.request.json'):
  metric_path=path.with_name(path.name.replace('.request.json','.metrics.json'))
  if metric_path.exists():continue
  request=load(path);tools=[t.get('function',{}).get('name') for t in request.get('tools',[])]
  inferred='prepublication-review-incomplete' if any(m.get('role')=='system' and m.get('content')==REVIEW_SYSTEM for m in request.get('messages',[])) else 'unknown-incomplete-transport'
  requests.append({'record_namespace':folder.name,'id':int(path.name.split('.')[0]),'purpose':inferred,'purpose_inferred_from_exact_frozen_reviewer_system_prompt':inferred.startswith('prepublication-review'),'received_epoch':path.stat().st_mtime,'received_epoch_source':'persisted request file mtime; exact start metric unavailable','backend_start_epoch':None,'end_epoch':None,'wall_seconds':None,'queue_seconds':None,'usage':None,'finish_reasons':[],'transport_error':'Final metrics absent; request may be active or interrupted','model':request['model'],'messages':len(request['messages']),'message_json_chars':len(json.dumps(request['messages'],ensure_ascii=False)),'has_terminal_and_gitea_tools':'terminal' in tools and 'gitea_commit_workspace' in tools,'tool_schema_count':len(tools),'max_tokens':request.get('max_tokens'),'native_context_checkpoint_request':any(m.get('role')=='system' and isinstance(m.get('content'),str) and m['content'].startswith('You are a summarization agent creating a context checkpoint.') for m in request['messages']),'request_sha256':None,'incomplete_transport':True,'final_metrics_present':False,'outer_response_parse_failed':None})
requests.sort(key=lambda r:r['received_epoch'])
phases=[]
for run in sorted((D/'runs').glob('*/turn*/run.json')):
 p=run.parent;data=load(run);db=sqlite3.connect('file:'+str(p/'state.db')+'?mode=ro&immutable=1',uri=True)
 try:
  rows=db.execute('select role,content,tool_name,message_uid,active,compacted from messages where session_id=? order by id',(data['session_id'],)).fetchall()
 finally:db.close()
 tools=[r for r in rows if r[0]=='tool']
 users=[r for r in rows if r[0]=='user']
 if data.get('original_turn_start_epoch') is not None:
  before=data['original_turn_start_epoch']
 elif data.get('native_exec_adopted_without_restart'):
  before=load(D/'live-adoption.json')['original_turn_start_epoch']
 else:
  before=(data['gpu'][0]['epoch']-data['gpu'][0]['seconds']) if data.get('gpu') else None
 after=before+data['elapsed_seconds'] if before is not None else None
 calls=[r for r in requests if before is not None and before<=r['received_epoch']<=after]
 usage={'prompt_tokens':0,'completion_tokens':0,'cached_prompt_tokens':0,'requests_with_usage':0,'requests_without_usage':0}
 for r in calls:
  u=r.get('usage') or {}
  if u:
   usage['requests_with_usage']+=1;usage['prompt_tokens']+=u.get('prompt_tokens',0);usage['completion_tokens']+=u.get('completion_tokens',0);usage['cached_prompt_tokens']+=(u.get('prompt_tokens_details') or {}).get('cached_tokens',0)
 usage['requests_without_usage']=len(calls)-usage['requests_with_usage']
 usage['token_totals_are_lower_bounds']=usage['requests_without_usage']>0
 samples=[int(s['gpu'].split(',')[0]) for s in data.get('gpu',[]) if s.get('gpu')]
 # A caller can finish after the native turn snapshot. Reconcile immutable
 # later snapshots by global review filename, retaining the original phase ID.
 review_inventory={}
 for snapshot in sorted(p.parent.glob('turn*')):
  if not (snapshot/'run.json').exists() or not (snapshot/'forge-snapshot.json').exists():continue
  for record in sorted((snapshot/'forge-and-review-records/reviews').glob('*-review.json')):review_inventory[record.name]=record
 reviews=[load(r) for r in review_inventory.values() if load(r).get('phase')==run.parent.parent.name+'-turn'+str(data['phase'])]
 phases.append({'run':run.parent.parent.name,'phase':data['phase'],'session_id':data['session_id'],'logical_session_root':data.get('logical_session_root',data['session_id']),'native_compression_rotations':max(0,len(data.get('native_session_lineage',[]))-1),'native_checkpoint_requests':sum(bool(r.get('native_context_checkpoint_request')) for r in calls),'native_checkpoint_backend_seconds_observed':round(sum(r['end_epoch']-r['backend_start_epoch'] for r in calls if r.get('native_context_checkpoint_request') and r.get('end_epoch') is not None and r.get('backend_start_epoch') is not None),3),'native_checkpoint_records_without_final_timing':sum(bool(r.get('native_context_checkpoint_request')) and (r.get('end_epoch') is None or r.get('backend_start_epoch') is None) for r in calls),'elapsed_seconds':data['elapsed_seconds'],'exit_code':data['exit_code'],'external_timeout':data['external_timeout'],'grade':load(p/'grade.json'),'user_rows':len(users),'all_user_rows_have_native_uids':all(r[3] for r in users),'tool_receipt_count':len(tools),'memory_calls':sum(r[2]=='memory' for r in tools),'skill_calls':sum(r[2] in ('skill_view','skill_manage','skills_list') for r in tools),'active_message_rows':sum(bool(r[4]) for r in rows),'compacted_message_rows':sum(bool(r[5]) for r in rows),'max_input_tokens':max([(r.get('usage') or {}).get('prompt_tokens',0) for r in calls],default=0),'usage':usage,'observed_peak_vram_mib':max(samples,default=None),'gpu_coverage':data.get('gpu_coverage','sampled from turn start'),'measurement_start_epoch':before,'measurement_end_epoch':after,'reviews_this_turn':len(reviews),'review_seconds':round(sum(r['elapsed_seconds'] for r in reviews),3),'approved_reviews':sum(r.get('approved') is True for r in reviews),'revision_requests':sum((r.get('review') or {}).get('decision')=='revise' for r in reviews),'review_errors':sum(bool(r.get('error')) and (r.get('review') or {}).get('decision')!='revise' for r in reviews)})
runtime_harness={p.name:{'runtime_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'matches_frozen_original':p.exists() and (D/p.name).exists() and p.read_bytes()==(D/p.name).read_bytes()} for p in sorted((D/'public-harness').glob('*.py'))}
out={'runtime_harness':runtime_harness,'runtime_recovery_declaration':'proxy-restart-recovery.json' if (D/'proxy-restart-recovery.json').exists() else None,'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_files_unchanged':all(hashes.values()),'completed_turns':len(phases),'expected_turns':18,'completed_request_records':sum(not r.get('incomplete_transport') for r in requests),'request_records_with_final_metrics':sum(bool(r.get('final_metrics_present')) for r in requests),'request_records_missing_api_usage':sum(not r.get('usage') for r in requests),'response_parse_failure_records':sum(r.get('outer_response_parse_failed') is True for r in requests),'inventory_definitions':{'completed_request_records':'Legacy field: a final metrics file exists; does not mean full response capture or usage is available.','incomplete_request_records':'Request file exists without final metrics; may be active or interrupted.','token_totals':'Only recorded API usage; missing values stay unknown and sums are lower bounds.'},'total_request_records':len(requests),'incomplete_request_records':sum(bool(r.get('incomplete_transport')) for r in requests),'phases':phases,'requests':requests,'scope':'Evidence inventory and measurements only; semantic code, documentation, regression relevance and execution-claim review remain separate.'}
(D/'progress-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ('requests','phases')},indent=2))
