"""Continue remaining frozen cases after a pre-inference output-directory fault."""
from pathlib import Path
import json,os,time,subprocess,hashlib,inspect as pyinspect,traceback
import controller as c
import resume_supervisor as prior
D=c.D
def install_owned_records_case():
 source=pyinspect.getsource(c.run_case)
 old="records=run/'proxy-records';records.mkdir();scope="
 new="records=run/'proxy-records';records.mkdir();os.chown(records,1000,1000);scope="
 assert source.count(old)==1
 source=source.replace(old,new)
 (D/'supervisor-owned-records-run-case.py').write_text(source)
 exec(compile(source,str(D/'supervisor-owned-records-run-case.py'),'exec'),c.__dict__)
 return hashlib.sha256(source.encode()).hexdigest()
def ready_transport():
 code="""import urllib.request,time
deadline=time.monotonic()+30
while time.monotonic()<deadline:
 try:
  r=urllib.request.urlopen('http://llm-pilot:8080/v1/models',timeout=3)
  assert r.status==200
  print('model transport ready')
  break
 except Exception:time.sleep(.3)
else:raise RuntimeError('model transport listener not ready')
"""
 c.quiet(['docker','exec','hermes-pilot-store','python','-c',code])
def quality_diagnostic():
 source=pyinspect.getsource(c.quality_preflight)
 assert "'critic-preflight'" in source
 source=source.replace("'critic-preflight'","'critic-preflight-continuation1'")
 exec(compile(source,str(D/'diagnostic-quality-replay.py'),'exec'),c.__dict__)
 (D/'diagnostic-quality-replay.py').write_text(source)
 c.quality_preflight()
def main():
 frozen=json.loads((D/'frozen-protocol.json').read_text())
 for path,sha in frozen['files_sha256'].items():assert hashlib.sha256((D/path).read_bytes()).hexdigest()==sha,path
 assert json.loads((D/'runs/plain-beetsbridge/case-finished.json').read_text())['turns_present']==3
 for case,arm in frozen['order'][1:]:
  assert not (D/'runs'/(arm+'-'+case)).exists()
  assert not (D/'worktrees'/(arm+'-'+case)).exists()
 assert not (D/'arms/review/profile/state.db').exists()
 source_sha=install_owned_records_case()
 initial={name:c.inspect(name) for name in ['hermes','llama-cpp','hermes-codex']}
 assert all(v['State']['Running'] for v in initial.values())
 original=json.loads((D/'original-props.json').read_text());candidate=json.loads((D/'candidate-manifest.json').read_text())
 c.write(D/'continuation1-started.json',{'epoch':time.time(),'remaining_cases':frozen['order'][1:],'generated_run_case_sha256':source_sha,'only_run_case_change':'os.chown(proxy records,1000,1000) before proxy startup','frozen_tasks_graders_reference_and_settings_unchanged':True,'recorder_directory':'llm-records-continuation1','first_three_turns_retained':True})
 for name,value in initial.items():c.write(D/(name+'-continuation1-pre-gpu-inspect.json'),[value])
 try:
  c.quiet(['docker','stop','-t','30','hermes']);c.quiet(['docker','stop','-t','20','llama-cpp'])
  launch=candidate['actual_test_backend_launch']['args']
  c.quiet(['docker','run','-d','--name','llama-pilot-eval','--network','homelab','--network-alias','llama-pilot','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','40g','--memory-swap','40g',initial['llama-cpp']['Image'],*launch])
  c.write(D/'candidate-props-continuation1.json',c.ready(c.ALIAS))
  folder=D/'llm-records-continuation1';folder.mkdir();os.chown(folder,1000,1000)
  c.quiet(['docker','create','--name','hermes-pilot-llm-proxy','--user','1000:1000','--network','homelab','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g',*c.mount('public-harness','/harness',True),*c.mount('llm-records-continuation1','/records'),'--entrypoint','python',c.IMAGE,'/harness/llm_proxy.py'])
  c.quiet(['docker','network','connect','--alias','llm-pilot','hermes-pilot-coding','hermes-pilot-llm-proxy']);c.quiet(['docker','start','hermes-pilot-llm-proxy'])
  c.quiet(['docker','exec','hermes-pilot-llm-proxy','python','-c','from pathlib import Path;p=Path("/records/.write-preflight");p.write_text("ok");p.unlink()'])
  ready_transport();quality_diagnostic()
  prompts=json.loads((D/'task-prompts.json').read_text())
  for case,arm in frozen['order'][1:]:c.run_case(case,arm,prompts[case])
  c.write(D/'all-model-workflows-finished.json',{'epoch':time.time(),'completed_first_case_retained':True,'provisioning_fix_before_review_inference':True})
 except BaseException as error:
  c.write(D/'continuation1-error.json',{'error':str(error),'traceback':traceback.format_exc()});raise
 finally:prior.restore(initial,original)
if __name__=='__main__':main()
