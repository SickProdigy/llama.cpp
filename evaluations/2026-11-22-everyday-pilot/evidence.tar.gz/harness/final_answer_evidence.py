"""Private final-answer curation/provenance; no automatic privacy or semantic approval."""
from pathlib import Path
import json,sqlite3,hashlib,sys
D=Path(__file__).resolve().parent

def extract(turn):
 run=json.loads((turn/'run.json').read_text());query=json.loads((D/'task-prompts.json').read_text())[run['case']][run['phase']];db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
 try:
  starts=db.execute("select id from messages where session_id=? and role='user' and content=? order by id",(run['session_id'],query)).fetchall();assert len(starts)==1
  rows=db.execute("select id,content,message_uid,finish_reason from messages where session_id=? and id>? and role='assistant' and finish_reason='stop' and (tool_calls is null or tool_calls='' or tool_calls='[]') order by id",(run['session_id'],starts[0][0])).fetchall();ad=db.execute('select status,outcome from session_admissions where target_session_id=? order by seq desc limit 1',(run.get('admission_session_id',run['session_id']),)).fetchone()
 finally:db.close()
 return {'run':turn.parent.name,'phase':run['phase'],'session_id':run['session_id'],'native_exit_code':run['exit_code'],'external_guard':run['external_timeout'],'native_admission_at_capture':list(ad) if ad else None,'candidate_final_rows':[{'message_id':r[0],'text':r[1],'message_uid':r[2],'finish_reason':r[3],'source_content_sha256':hashlib.sha256((r[1] or '').encode()).hexdigest()} for r in rows]}
def main():
 validate='--validate' in sys.argv;progress='--progress' in sys.argv;checked=[]
 for file in sorted((D/'runs').glob('*/turn*/run.json')):
  turn=file.parent
  if not (turn/'forge-snapshot.json').exists():continue
  record=extract(turn)
  if not validate:
   p=D/'final-answer-curation-private';p.mkdir(exist_ok=True);(p/(turn.parent.name+'-'+turn.name+'.json')).write_text(json.dumps(record,indent=2));checked.append({'run':record['run'],'phase':record['phase'],'candidate_finals':len(record['candidate_final_rows'])})
  else:
   path=turn/'final-answer.json';approved=json.loads(path.read_text());assert approved['approved_for_public_export'] is True
   for key in ['run','phase','session_id','native_exit_code','external_guard','native_admission_at_capture']:assert approved[key]==record[key],key
   if approved['final_answer'] is None:assert not record['candidate_final_rows']
   else:assert approved['final_answer'] in record['candidate_final_rows']
   checked.append({'run':record['run'],'phase':record['phase'],'has_final_answer':approved['final_answer'] is not None,'artifact_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 if validate:
  assert progress or len(checked)==18,'All18 approved final/absence artifacts required'
  result={'progress_only':progress,'all_selected_finals_match_native_snapshots':True,'turns':len(checked),'checked':checked};(D/('final-answer-validation'+('-progress' if progress else '')+'.json')).write_text(json.dumps(result,indent=2))
 print(json.dumps(checked))
if __name__=='__main__':main()
