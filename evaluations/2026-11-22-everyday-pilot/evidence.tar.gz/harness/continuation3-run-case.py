def run_case(case,arm,prompts):
 name=arm+'-'+case;run=D/'runs'/name;run.mkdir(parents=True);work=D/'worktrees'/name;cl=clone(name,arm);write(run/'clone.json',cl);prefix='pilot-'+hashlib.sha256(name.encode()).hexdigest()[:8]+'-';repo='hermes-pilot-'+arm+'-20261122'
 config=run/'proxy-config';config.mkdir();records=run/'proxy-records';records.mkdir();os.chown(records,1000,1000);scope={'owner':'chatgpt-codex','repo':repo,'fork_repo':repo,'base_sha':BASE[arm],'branch_prefix':prefix,'allowed_paths':['README.md'],'allowed_path_prefixes':[case+'/'],'automatic_review':arm=='review','phase_lease':True,'alias':ALIAS};write(config/'publication-parameters.json',scope);write(config/'current-phase.json',{'id':name+'-not-started','active':False,'tasks_so_far':[]});agent='hermes-pilot-agent';proxy='hermes-pilot-proxy';profile=D/'arms'/arm/'profile'
 hint='\nContribution branches in this disposable evaluation must start with '+prefix+'; this prevents collisions with other test work.\n'
 quiet(['docker','exec','hermes-pilot-store','python','-c','from pathlib import Path; p=Path("/state/worktrees/'+name+'/AGENTS.md");p.write_text(p.read_text()+'+repr(hint)+')'])
 try:
  quiet(['docker','create','--name',proxy,'--user','1000:1000','--network','homelab','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g',*mount('public-harness','/harness',True),*mount(str(config.relative_to(D)),'/eval',True),*mount(str(records.relative_to(D)),'/proxy-records'),*mount(str(work.relative_to(D)),'/workspace',True),*mount('arms/'+arm+'/profile','/profile',True),'--entrypoint','python',IMAGE,'/harness/scope_proxy.py'])
  quiet(['docker','network','connect','--alias','gitea-pilot','hermes-pilot-coding',proxy]);quiet(['docker','start',proxy]);quiet(['docker','exec',proxy,'python','-c','from pathlib import Path;p=Path("/proxy-records/.write-preflight");p.write_text("ok");p.unlink()']);time.sleep(1)
  quiet(['docker','run','-d','--name',agent,'--network','hermes-pilot-coding','--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','4g','--memory-swap','4g','--cpus','2','--tmpfs','/tmp:rw,size=1g,mode=1777',*mount('arms/'+arm+'/profile','/opt/data'),*mount(str(work.relative_to(D)),'/workspace'),'-e','HOME=/opt/data','-e','HERMES_HOME=/opt/data','-e','HERMES_WRITE_SAFE_ROOT=/workspace:/opt/data/cache/scratch','--entrypoint','sleep',IMAGE,'infinity'])
  sid=None;root_sid=None
  for i,query in enumerate(prompts):
   if sid:
    with (run/("native-discard-before-turn"+str(i)+".log")).open("w") as recovery:
     sh(["docker","exec",agent,"/opt/hermes/bin/hermes","sessions","discard",sid,"--yes"],stdout=recovery,stderr=subprocess.STDOUT)
   out=run/('turn'+str(i));out.mkdir();phase={'id':name+'-turn'+str(i),'active':True,'tasks_so_far':prompts[:i+1],'session_id':None,'native_resume_session_id':sid,'state_db':'/profile/state.db'};write(config/'current-phase.json',phase);print('TURN START',name,i,time.time(),flush=True)
   command=['docker','exec','-i','-w','/workspace',agent,'/opt/hermes/bin/hermes','chat','--cli','--oneshot','-Q','--query-file','-','--in','/workspace','--accept-hooks']
   if sid:command+=['--resume',sid]
   else:command+=['--max-turns','60','--run-budget','1800']
   samples=[];start=time.monotonic();external_timeout=False
   with (out/'console.log').open('w') as log:
    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT);proc.stdin.write(query.encode());proc.stdin.close()
    while proc.poll() is None:
     elapsed=time.monotonic()-start
     if elapsed>2100:
      external_timeout=True;phase['active']=False;write(config/'current-phase.json',phase);quiet(['docker','stop','-t','15',agent]);break
     samples.append({'epoch':time.time(),'seconds':round(elapsed,3),'gpu':gpu()});time.sleep(3)
    code=proc.wait()
   elapsed=time.monotonic()-start;phase['active']=False;write(config/'current-phase.json',phase);found=session_for(profile,query)
   incoming_sid=sid
   if not found:raise RuntimeError('Native CLI did not persist the frozen current query')
   root_sid=root_sid or first_session_for(profile,prompts[0])
   lineage=compression_lineage(profile/'state.db',root_sid,found)
   if incoming_sid and found!=incoming_sid:compression_lineage(profile/'state.db',incoming_sid,found)
   write(out/'native-session-lineage.json',{'logical_session_root':root_sid,'incoming_session_id':incoming_sid,'effective_session_id':found,'lineage':lineage,'task_replayed':False})
   sid=found
   if not sid:raise RuntimeError('Native CLI did not persist a user session; see console')
   phase['session_id']=sid;write(config/'current-phase.json',phase);write(out/'run.json',{'case':case,'arm':arm,'phase':i,'session_id':sid,'logical_session_root':root_sid,'incoming_session_id':incoming_sid,'admission_session_id':incoming_sid or root_sid,'native_session_lineage':lineage,'native_session_rotation':len(lineage)>1,'exit_code':code,'elapsed_seconds':round(elapsed,3),'external_timeout':external_timeout,'gpu':samples,'query_sha256':hashlib.sha256(query.encode()).hexdigest()});capture_db(profile,out);shutil.copytree(work,out/'workspace',symlinks=True);grade(out/'workspace',case,i,out);shutil.copytree(records,out/'forge-and-review-records',dirs_exist_ok=True);audit_remote(run,out,case,arm,i);print('TURN END',name,i,code,round(elapsed,1),flush=True)
   if external_timeout:quiet(['docker','start',agent])
  write(run/'case-finished.json',{'session_id':sid,'logical_session_root':root_sid,'native_session_lineage':lineage,'turns_present':len(list(run.glob('turn*/run.json'))),'epoch':time.time()})
 finally:
  for n in [agent,proxy]:
   if subprocess.run(['docker','inspect',n],capture_output=True).returncode==0:
    x=subprocess.run(['docker','logs',n],capture_output=True);(run/(n+'.log')).write_bytes(x.stdout+x.stderr)
  rm(agent);rm(proxy)
  state_path=records/'state.json'
  if state_path.exists():
   state=json.loads(state_path.read_text())
   if state.get('issue'):
    result=api('PATCH','repos/chatgpt-codex/'+repo+'/issues/'+str(state['issue']),{'state':'closed'})
    write(run/'issue-cleanup.json',{'number':state['issue'],'state':result['body'].get('state'),'preserved_for_audit':True})
