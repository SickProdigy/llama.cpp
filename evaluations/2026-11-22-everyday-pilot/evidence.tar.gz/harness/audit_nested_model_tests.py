"""Supplement omitted nested model tests; independent paired runs, no actor feedback."""
from pathlib import Path
import json,hashlib,shutil,subprocess,time
from controller import D,IMAGE,mount

def run(turn):
 out=turn/'nested-model-tests-audit.json'
 if out.exists():return
 r=json.loads((turn/'run.json').read_text());remote=D/'worktrees/audit'/(r['arm']+'-'+r['case']+'-turn'+str(r['phase']));work=remote if remote.exists() else turn/'workspace'
 files=sorted(str(p.relative_to(work)) for p in work.rglob('test_*.py') if p.relative_to(work).parts[0]!='tests' and '.git' not in p.relative_to(work).parts and '__pycache__' not in p.relative_to(work).parts)
 result={'epoch':time.time(),'source':'published personal branch' if remote.exists() else 'local only','nested_test_files':files,'not_fed_to_models':True,'scope':'Supplement top-level-tests-only audit; paired pytest outcomes require manual behavioral failure review.','paired_results':[]}
 if files:
  stage=D/'nested-test-audit-work'/hashlib.sha256(str(turn).encode()).hexdigest()[:16];assert not stage.exists();stage.parent.mkdir(exist_ok=True)
  shutil.copytree(work,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
  try:
   saved={str(p.relative_to(stage)):p.read_bytes() for f in files for p in (stage/f).parent.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
   for variant in ['candidate','original']:
    if variant=='original':
     target=stage/r['case'];shutil.rmtree(target);shutil.copytree(D/'baseline'/r['case'],target)
     for rel,content in saved.items():dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
    for n,file in enumerate(files):
     logname='nested-model-tests-'+variant+'-'+str(n)+'.log';args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*mount(str(stage.relative_to(D)),'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',IMAGE,'-s','KILL','90','python','-m','pytest','-q','-p','no:cacheprovider',file]
     with (turn/logname).open('w') as log:proc=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
     result['paired_results'].append({'variant':variant,'file':file,'exit_code':proc.returncode,'log':logname})
  finally:shutil.rmtree(stage)
 out.write_text(json.dumps(result,indent=2))
 prior=turn/'regression-relevance.json'
 if prior.exists() and files:
  obj=json.loads(prior.read_text());obj['coverage_limitation']='Original helper covers only top-level tests/. Nested tests separately paired and must be included in manual assessment; empty modified_or_added_tests is not absence of model regressions.';obj['nested_test_audit']='nested-model-tests-audit.json';prior.write_text(json.dumps(obj,indent=2))
 print(turn.parent.name,turn.name,len(files),flush=True)
if __name__=='__main__':
 for t in sorted((D/'runs').glob('*/turn*')):
  if (t/'forge-snapshot.json').exists():run(t)
