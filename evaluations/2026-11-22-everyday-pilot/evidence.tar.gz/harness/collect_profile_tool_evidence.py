"""Safe per-turn evidence of real skill/memory tool use; omit private contents."""
from pathlib import Path
import sqlite3,json,hashlib,time
D=Path(__file__).resolve().parent

def collect(turn):
 run=json.loads((turn/'run.json').read_text());query=json.loads((D/'task-prompts.json').read_text())[run['case']][run['phase']];db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
 try:
  starts=db.execute("select id from messages where session_id=? and role='user' and content=? order by id",(run['session_id'],query)).fetchall();assert len(starts)==1
  rows=db.execute("select id,tool_name,content from messages where session_id=? and role='tool' order by id",(run['session_id'],)).fetchall();compacted=db.execute('select count(*) from messages where session_id=? and compacted!=0',(run['session_id'],)).fetchone()[0]
 finally:db.close()
 evidence=[]
 for ident,name,raw in rows:
  lower=(name or '').lower()
  if 'skill' not in lower and 'memory' not in lower:continue
  try:value=json.loads(raw)
  except (ValueError,TypeError):value={}
  if not isinstance(value,dict):value={}
  content=value.get('content');evidence.append({'message_id':ident,'tool_name':name,'current_turn':ident>starts[0][0],'success':value.get('success') if isinstance(value.get('success'),bool) else None,'returned_skill_content':isinstance(content,str) and bool(content),'content_chars':len(content) if isinstance(content,str) else None,'private_receipt_sha256':hashlib.sha256((raw or '').encode()).hexdigest(),'private_skill_content_sha256':hashlib.sha256(content.encode()).hexdigest() if isinstance(content,str) else None})
 result={'epoch':time.time(),'run':turn.parent.name,'phase':run['phase'],'accepted_user_message_id':starts[0][0],'session_id':run['session_id'],'receipts':evidence,'current_turn_successful_skill_content_reads':sum(x['current_turn'] and x['success'] is True and x['returned_skill_content'] for x in evidence),'current_turn_memory_tool_receipts':sum(x['current_turn'] and 'memory' in x['tool_name'].lower() for x in evidence),'session_compacted_rows_observed':compacted,'private_skill_names_paths_text_and_environment_requirements_omitted':True,'scope':'Actual native tool receipt metadata, not a claim memory writes or compaction were exercised. No private profile contents or corrective model feedback.'};(turn/'profile-tool-evidence.json').write_text(json.dumps(result,indent=2));return {'run':result['run'],'phase':result['phase'],'skill_content_reads_this_turn':result['current_turn_successful_skill_content_reads'],'memory_receipts_this_turn':result['current_turn_memory_tool_receipts']}
if __name__=='__main__':print(json.dumps([collect(t) for t in sorted((D/'runs').glob('*/turn*')) if (t/'forge-snapshot.json').exists()]))
