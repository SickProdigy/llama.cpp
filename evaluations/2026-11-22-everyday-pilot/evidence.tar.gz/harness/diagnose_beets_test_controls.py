"""Posthoc sensitivity checks of model-added controls; not a primary grader or model hint."""
from controller import D,IMAGE,mount
import pathlib,shutil,subprocess,json
turn=D/'runs/plain-beetsbridge/turn0';work=D/'worktrees/audit/plain-beetsbridge-turn0';results=[]
cases=[
 ('serialization-lock-removed','test_serial_imports_still_run_when_not_disabled',lambda s:s.replace('with self._import_lock:','if True:  # diagnostic mutant removes serialization lock')),
 ('stop-timers-noop','test_timer_elapsed_after_disable_starts_nothing',lambda s:s[:s.index('    def _stop_timers(self) -> None:')]+'    def _stop_timers(self) -> None:\n        pass  # diagnostic mutant leaves timers and stopping flag unchanged\n'),
]
for label,test,mutate in cases:
 stage=D/'posthoc-control-mutants'/label
 if stage.exists():raise RuntimeError('Diagnostic stage already exists')
 stage.parent.mkdir(exist_ok=True);shutil.copytree(work,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
 p=stage/'beetsbridge/__init__.py';before=p.read_text();after=mutate(before);assert before!=after;p.write_text(after)
 args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','512m','--cpus','1','--tmpfs','/tmp:rw,size=128m',*mount(str(stage.relative_to(D)),'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','timeout',IMAGE,'-s','KILL','30','python','-m','unittest','tests.test_beetsbridge.BeetsBridgeTests.'+test,'-v']
 try:
  log=turn/('posthoc-'+label+'.log')
  with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
  results.append({'mutant':label,'model_added_test':test,'exit_code':r.returncode,'log':log.name,'interpretation':'Passed despite the named behavior being deliberately removed; weak sensitivity in this control.' if r.returncode==0 else 'Inspect failure reason; a nonzero exit alone does not prove useful sensitivity.'})
 finally:shutil.rmtree(stage)
(turn/'posthoc-control-sensitivity.json').write_text(json.dumps({'posthoc':True,'not_fed_to_agent':True,'not_part_of_frozen_primary_grade':True,'results':results},indent=2));print(json.dumps(results,indent=2))
