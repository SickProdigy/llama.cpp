"""Run immutable original tests against actual published code, outside the agent."""
from pathlib import Path
import json,shutil,subprocess,hashlib
from controller import D,IMAGE,mount
def run(turn):
 data=json.loads((turn/'run.json').read_text());out=turn/'original-tests-audit.json'
 if out.exists():return
 work=D/'worktrees/audit'/(data['arm']+'-'+data['case']+'-turn'+str(data['phase']))
 published=work.exists()
 if not published:work=turn/'workspace'
 stage=D/'original-tests-work'/hashlib.sha256(str(turn).encode()).hexdigest()[:16]
 if stage.exists():raise RuntimeError('Inspect interrupted audit staging before resuming')
 stage.parent.mkdir(exist_ok=True);shutil.copytree(work,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
 tests=stage/'tests'
 if tests.exists():shutil.rmtree(tests)
 shutil.copytree(D/'baseline/tests',tests)
 args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*mount(str(stage.relative_to(D)),'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',IMAGE,'-s','KILL','90','python','-m','pytest','-q','-p','no:cacheprovider','tests']
 try:
  with (turn/'immutable-original-tests.log').open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
  out.write_text(json.dumps({'actual_published_code':published,'original_tests_restored_without_model_edits':True,'exit_code':r.returncode,'baseline_source_tree':'60e59671ae0973188ae90ac46f7cfec1c06bfd8f','not_fed_to_agent':True,'scope':'Existing tests only; private behavior, test relevance, prose and execution claims are separate.'},indent=2));print(turn.parent.name,data['phase'],'immutable original tests exit',r.returncode,flush=True)
 finally:shutil.rmtree(stage)
if __name__=='__main__':
 for turn in sorted((D/'runs').glob('*/turn*')):
  if (turn/'forge-snapshot.json').exists():run(turn)
