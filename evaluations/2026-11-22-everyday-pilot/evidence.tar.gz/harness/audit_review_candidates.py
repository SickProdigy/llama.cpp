"""Grade exact prepublication candidates after a turn, never feed results to models."""
from pathlib import Path,PurePosixPath
import json,subprocess,shutil,tarfile,io,os,sys,hashlib
from controller import D,BASE
def load(path):return json.loads(path.read_text())
def commit_success(entry):
 if entry.get('stage')!='commit' or entry.get('denied_or_error'):return False
 result=entry.get('result') or {}
 if result.get('isError'):return False
 for part in result.get('content',[]):
  if part.get('type')!='text':continue
  try:value=json.loads(part['text'])
  except (ValueError,KeyError):continue
  if isinstance(value,dict) and value.get('error'):return False
 return True
def paths_for_commit(publication):
 return publication.get('files') or [{k:publication[k] for k in ('path','content','edits','delete') if k in publication}]
def safe(root,path):
 p=PurePosixPath(path)
 if p.is_absolute() or '..' in p.parts or '.git' in p.parts:raise ValueError('Unsafe candidate path')
 return root/path
def materialize(stage,base_clone,base_sha,packet):
 if base_clone:
  command=['git','-c','safe.directory='+str(base_clone),'-C',str(base_clone),'archive',base_sha]
  blob=subprocess.check_output(command)
  with tarfile.open(fileobj=io.BytesIO(blob)) as archive:archive.extractall(stage,filter='data')
 else:shutil.copytree(D/'baseline',stage,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 candidate=packet['candidate']
 if candidate['operation']=='create_or_update_file':
  for item in paths_for_commit(candidate['publication']):
   name=item['path'];target=safe(stage,name)
   if item.get('delete'):
    if target.exists():target.unlink()
   else:
    # Independently reconstruct the actual forge payload, never trust the gate's
    # resolved proposed context as the authoritative mutation.
    if 'content' in item:
     content=item['content']
     if not isinstance(content,str):raise ValueError('Non-text proposed file content')
    elif item.get('edits'):
     if not target.is_file():raise ValueError('Edit target absent from actual base')
     content=target.read_text()
     for edit in item['edits']:
      old=edit['old_string'];new=edit['new_string']
      if not old or content.count(old)!=1:raise ValueError('Ambiguous raw edit against actual base')
      content=content.replace(old,new,1)
    else:raise ValueError('Raw payload has neither content nor edits')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_text(content)
 mismatch=[]
 for name,context in candidate.get('source_context',{}).items():
  target=safe(stage,name);actual=target.read_text() if target.is_file() else None
  if actual!=context.get('proposed'):mismatch.append(name)
 return mismatch
def run(turn):
 params=load(turn/'run.json');name=turn.parent.name;case=params['case'];arm=params['arm'];phase=params['phase']
 # Recover gate completions captured only in a later immutable turn snapshot.
 snapshots=[s for s in sorted(turn.parent.glob('turn*')) if (s/'run.json').exists() and (s/'forge-snapshot.json').exists()]
 records=snapshots[-1]/'forge-and-review-records';calls=load(records/'calls.json') if (records/'calls.json').exists() else []
 inventory={}
 for snapshot in snapshots:
  for f in sorted((snapshot/'forge-and-review-records/reviews').glob('*-review.json')):inventory[f.name]=f
 review_files=[f for f in inventory.values() if load(f).get('phase')==name+'-turn'+str(phase)]
 if not review_files:return
 remote=D/'worktrees/audit'/(name+'-turn'+str(phase))
 commits=[]
 if remote.exists():
  commits=subprocess.check_output(['git','-c','safe.directory='+str(remote),'-C',str(remote),'rev-list','--reverse',BASE[arm]+'..HEAD'],text=True).splitlines()
 for file in review_files:
  review=load(file);out=turn/'candidate-reviews'/file.stem
  if (out/'grade.json').exists():
   prior=load(out/'grade.json')
   if prior.get('materializer_version')==2:continue
   (out/'grade.prior-context-audit.json').write_text(json.dumps(prior,indent=2))
   if (out/'independent-candidate.log').exists():shutil.copy2(out/'independent-candidate.log',out/'independent-candidate.prior-context.log')
  out.mkdir(parents=True,exist_ok=True);packet=review['input'];candidate=packet['candidate'];operation=candidate['operation'];publication=candidate['publication']
  matches=[entry for entry in calls if entry.get('name')==operation and entry.get('args')==publication and entry.get('epoch',float('inf'))<=review['start_epoch'] and entry.get('end_epoch',float('-inf'))>=review['start_epoch']]
  if len(matches)!=1:raise ValueError('Cannot uniquely match reviewed MCP mutation: '+str(file))
  entry=matches[0];prior_count=sum(commit_success(e) and e.get('end_epoch',float('inf'))<entry['epoch'] for e in calls)
  if prior_count>len(commits):raise ValueError('Remote commit history does not account for earlier successful writes')
  base_sha=commits[prior_count-1] if prior_count else BASE[arm];base_clone=remote if prior_count else None
  stage=D/'review-candidate-work'/(name+'-turn'+str(phase)+'-'+file.stem)
  if stage.exists():raise RuntimeError('Inspect partial candidate audit stage before resuming')
  stage.mkdir(parents=True)
  try:
   mismatches=materialize(stage,base_clone,base_sha,packet)
   cls={'beetsbridge':'Beets','announcer':'Announcer','arrrequests':'Arr'}[case];env=dict(os.environ,CHECKOUT=str(stage),PHASE=str(phase),PYTHONDONTWRITEBYTECODE='1')
   with (out/'independent-candidate.log').open('w') as stream:
    try:code=subprocess.run([sys.executable,str(D/'hidden_checks.py'),cls],stdout=stream,stderr=subprocess.STDOUT,env=env,timeout=60).returncode
    except subprocess.TimeoutExpired:code=124
   result={'materializer_version':2,'raw_payload_reconstructed_independently_of_review_context':True,'record':str(file.relative_to(D)),'phase':review['phase'],'review_key':review['key'],'operation':operation,'prior_successful_commits':prior_count,'actual_base_sha':base_sha,'exact_mutation_payload_applied':operation=='create_or_update_file','adjacent_local_context_not_silently_published':True,'review_context_differs_from_actual_candidate_paths':mismatches,'frozen_behavior_exit_code':code,'review_decision':(review.get('review') or {}).get('decision'),'review_error':review.get('error'),'review_seconds':review.get('elapsed_seconds'),'approved':review.get('approved',False),'not_fed_to_agent':True,'interpretation':'Code behavior only. Manually assess which reviewer findings are real, documentation and execution claims, and whether later revisions resolve them; rejection alone is not successful defect detection.'}
   (out/'grade.json').write_text(json.dumps(result,indent=2));print(name,phase,file.name,'candidate behavior exit',code,flush=True)
  finally:shutil.rmtree(stage)
if __name__=='__main__':
 for turn in sorted((D/'runs').glob('*/turn*')):
  if (turn/'run.json').exists() and (turn/'forge-snapshot.json').exists():run(turn)
