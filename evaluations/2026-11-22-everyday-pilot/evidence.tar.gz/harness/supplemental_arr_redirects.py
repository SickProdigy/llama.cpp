"""Supplemental black-box HTTP coverage, frozen before either Arr model workflow.
Not part of the primary16 checks. Never supplied to actor or critic.
"""
import unittest,threading,json
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from hidden_checks import load
CODES=(301,302,303,307,308)
class RedirectCoverage(unittest.TestCase):
 def setUp(self):
  self.module=load('arrrequests');self.seen=[];seen=self.seen;foreign=[None]
  class Handler(BaseHTTPRequestHandler):
   def do_GET(self):
    seen.append({'port':self.server.server_port,'path':self.path,'key':self.headers.get('X-Api-Key'),'method':self.command})
    parts=self.path.split('?',1)[0].strip('/').split('/');kind=parts[0]
    if kind in {'same','cross','relative','chain'}:
     code=int(parts[1]);target={'same':'/ok','cross':f'http://127.0.0.1:{foreign[0]}/ok','relative':f'//127.0.0.1:{foreign[0]}/ok','chain':'/cross/'+str(code)}[kind]
     self.send_response(code);self.send_header('Location',target);self.end_headers();return
    self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"appName":"Sonarr","version":"supplemental"}')
   def log_message(self,*args):pass
  self.servers=[ThreadingHTTPServer(('127.0.0.1',0),Handler) for _ in range(2)];foreign[0]=self.servers[1].server_port;self.foreign=foreign[0]
  self.threads=[threading.Thread(target=s.serve_forever,kwargs={'poll_interval':.01},daemon=True) for s in self.servers]
  for t in self.threads:t.start()
  self.client=self.module.ArrClient('tv',f'http://127.0.0.1:{self.servers[0].server_port}','FAKE-supplemental-key')
 def tearDown(self):
  for s in self.servers:s.shutdown();s.server_close()
  for t in self.threads:t.join(1)
 def protected(self,kind,code):
  self.seen.clear()
  try:self.client._get_json('/'+kind+'/'+str(code),{},2)
  except self.module.ArrError as error:self.assertNotIn('FAKE-supplemental-key',str(error))
  self.assertTrue(self.seen,'No authenticated request was attempted')
  self.assertEqual(self.seen[0]['key'],'FAKE-supplemental-key')
  self.assertFalse(any(r['port']==self.foreign and r['key'] for r in self.seen),'API key crossed the origin boundary')
  self.assertTrue(all(r['method']=='GET' for r in self.seen))
 def test_cross_origin_all_standard_statuses(self):
  for code in CODES:
   with self.subTest(code=code):self.protected('cross',code)
 def test_protocol_relative_cross_origin_all_statuses(self):
  for code in CODES:
   with self.subTest(code=code):self.protected('relative',code)
 def test_chain_origin_boundary_all_statuses(self):
  for code in CODES:
   with self.subTest(code=code):
    self.protected('chain',code);self.assertGreaterEqual(len(self.seen),2)
 def test_same_origin_preserves_get_and_auth_all_statuses(self):
  for code in CODES:
   with self.subTest(code=code):
    self.seen.clear();self.assertEqual(self.client._get_json('/same/'+str(code),{},2)['appName'],'Sonarr');self.assertEqual(len(self.seen),2);self.assertTrue(all(r['method']=='GET' and r['key']=='FAKE-supplemental-key' for r in self.seen))
if __name__=='__main__':unittest.main(verbosity=2)
