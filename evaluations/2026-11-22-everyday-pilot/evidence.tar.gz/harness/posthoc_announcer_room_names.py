"""Supplemental room-name preservation inputs; not frozen primary checks."""
import json
import hidden_checks as h
m,p=h.Announcer().make();name='Room  Two';p.core.chatrooms.joined_rooms={name:object()};p.settings.update(default_rooms=name,room_groups_json=json.dumps({'two':[name]}));result={'csv_result':m._csv_rooms(name),'group_result':m._parse_groups(json.dumps({'two':[name]}))}
for label,call in [('default',lambda:p.announce_command('Hello',user='owner')),('group',lambda:p.announce_group_command('two Hello',user='owner'))]:
 p.out.clear();result[label]={'returned':call(),'local_messages':list(p.out)}
try:result['legacy_numeric_group']=m._parse_groups('{"number":[42]}')
except Exception as e:result['legacy_numeric_group']={'exception':type(e).__name__,'message':str(e)}
print(json.dumps(result,indent=2))
