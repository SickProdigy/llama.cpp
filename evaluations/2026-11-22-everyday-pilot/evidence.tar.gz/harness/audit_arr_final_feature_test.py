"""Posthoc API-preserving opt-out regression discrimination for final review draft."""
from pathlib import Path
import shutil,json,time
import controller as c
from audit_arr_model_test_quality import check
D=c.D;out=D/'provisional-review-audits/review-arrrequests-final-feature-regression';out.mkdir(exist_ok=True);stage=out/'mutant';assert not stage.exists();shutil.copytree(D/'runs/review-arrrequests/turn2/workspace',stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
target='tests/test_arrrequests.py::AllowRedirectsTests::test_redirects_disabled_rejects_same_origin_redirect';records={}
try:
 records['actual']=check(stage,target,out/'actual.log');p=stage/'arrrequests/__init__.py';s=p.read_text();old='_SameOriginRedirectHandler(allow_redirects=allow_redirects)';assert s.count(old)==1;s=s.replace(old,'_SameOriginRedirectHandler(allow_redirects=True)');p.write_text(s)
 records['ignore_flag']=check(stage,target,out/'ignore-flag.log')
 old='raise ArrError(f"{self.application} returned HTTP {error.code}.")';assert old in s;s=s.replace(old,'raise ArrError(f"{self.application} returned redirect disabled HTTP {error.code}.")');p.write_text(s)
 records['ignore_flag_error_wording_preserved']=check(stage,target,out/'ignore-flag-wording.log')
 assert records['actual']['exit_code']==0 and records['ignore_flag']['exit_code']!=0 and records['ignore_flag_error_wording_preserved']['exit_code']==0
 result={'epoch':time.time(),'not_fed_to_models':True,'posthoc_not_primary':True,'API_preserved':True,'actual_source_unchanged':True,'mutations':['Force only opener handler flagTrue, leaving accepted client/plugin APIs unchanged.','Then put redirect/disabled words in generic HTTP error without restoring opt-out behavior.'],'results':records,'interpretation':'The model fixture redirects every path back to itself. Its disabled assertion distinguishes generic loop error text in the simple mutant, but passes the unsafe flag-ignoring mutant once error words match. It does not assert that only one request is made. This is weaker than independent flag propagation/request-count checks; original-target constructor errors alone are not relevant regression proof.'};(out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(records))
finally:shutil.rmtree(stage)
