"""Private reference corrections, never mounted in model containers."""
from pathlib import Path
import shutil
D=Path(__file__).parent
R=D/'reference'
shutil.copytree(D/'baseline',R,dirs_exist_ok=True)
def edit(name,old,new):
 p=R/name;s=p.read_text();assert old in s,(name,old[:60]);p.write_text(s.replace(old,new))
edit('announcer/__init__.py','def _csv_rooms(value: object) -> list[str]:\n','def _csv_rooms(value: object) -> list[str]:\n    return _literal_rooms(str(value or "").split(","))\n\n\ndef _literal_rooms(values) -> list[str]:\n')
edit('announcer/__init__.py','for item in str(value or "").split(","):\n        room = item.strip()','for item in values:\n        room = str(item).strip()')
edit('announcer/__init__.py','_csv_rooms(",".join(str(room) for room in rooms))','_literal_rooms(rooms)')
edit('announcer/__init__.py','rooms = _csv_rooms(",".join(rooms))','rooms = _literal_rooms(rooms)')
edit('announcer/__init__.py','def announce_status_command(self, _args: str, **_context: object) -> bool:\n','''def announce_status_command(self, _args: str, **_context: object) -> bool:
        if _args.strip():
            try:
                groups = _parse_groups(self.settings.get("room_groups_json", "{}"))
            except AnnouncementError as error:
                self.echo_message(str(error))
                return False
            name = _args.strip().casefold()
            if name not in groups:
                self.echo_message(f"Unknown announcement group: {name}")
                return False
            configured = groups[name]
            joined = self._joined_rooms(configured)
            joined_keys = {room.casefold() for room in joined}
            skipped = [room for room in configured if room.casefold() not in joined_keys]
            self.echo_message(f"Group {name}; configured: {configured!r}; joined: {joined!r}; skipped: {skipped!r}")
            return True
''')
edit('beetsbridge/__init__.py','self._generation = 0','self._generation = 0\n        self._cancel_epoch = 0\n        self._waiting_imports = set()')
edit('beetsbridge/__init__.py','"beetsstatus": {','"beetscancel": {"callback": self.beets_cancel_command, "description": "Cancel imports not yet started", "disable": ["cli"]},\n            "beetsstatus": {')
edit('beetsbridge/__init__.py','    def beets_status_command(','''    def beets_cancel_command(self, _args: str, **_context: object) -> bool:
        count = self._cancel_queued()
        self.echo_message(f"Cancelled {count} queued imports.")
        return True

    def _cancel_queued(self):
        with self._lock:
            self._cancel_epoch += 1
            count = len(self._pending) + len(self._waiting_imports)
            for _generation, timer in self._pending.values():
                timer.cancel()
            self._pending.clear()
            self._waiting_imports.clear()
        return count

    def beets_status_command(''')
edit('beetsbridge/__init__.py','''            del self._pending[folder]
        threading.Thread(''','''            del self._pending[folder]
            epoch = self._cancel_epoch
            ticket = object()
            self._waiting_imports.add(ticket)
        threading.Thread(''')
edit('beetsbridge/__init__.py','args=(folder,),\n            name="nicotine-beets-import"','args=(folder, epoch, ticket),\n            name="nicotine-beets-import"')
edit('beetsbridge/__init__.py','def _import_worker(self, folder: Path) -> None:','def _import_worker(self, folder: Path, epoch=None, ticket=None) -> None:')
edit('beetsbridge/__init__.py','''            with self._import_lock:
                result = runner.import_folder(folder)''','''            with self._import_lock:
                with self._lock:
                    self._waiting_imports.discard(ticket)
                    if self._stopping or (epoch is not None and epoch != self._cancel_epoch):
                        return
                result = runner.import_folder(folder)''')
edit('beetsbridge/__init__.py','''        with self._lock:
            for _generation, timer in self._pending.values():
                timer.cancel()
            self._pending.clear()
''','''        self._cancel_queued()
''')
edit('arrrequests/__init__.py','from urllib.request import Request, urlopen','''from urllib.request import Request, HTTPRedirectHandler, build_opener


def _origin(url):
    parsed = urlparse(url)
    return parsed.scheme.lower(), parsed.hostname, parsed.port or (443 if parsed.scheme.lower() == "https" else 80)


class _SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not getattr(req, "allow_redirects", True):
            raise ArrError("Redirects are disabled.")
        if _origin(req.full_url) != _origin(newurl):
            raise ArrError("Cross-origin redirect refused.")
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if redirected is not None:
            redirected.allow_redirects = getattr(req, "allow_redirects", True)
        return redirected


def urlopen(request, timeout):
    return build_opener(_SafeRedirect()).open(request, timeout=timeout)
''')
edit('arrrequests/__init__.py','def __init__(self, media_type: str, base_url: str, api_key: str):','def __init__(self, media_type: str, base_url: str, api_key: str, allow_redirects: bool = True):\n        self.allow_redirects = bool(allow_redirects)')
edit('arrrequests/__init__.py','''        try:
            with urlopen(request, timeout=timeout)''','''        request.allow_redirects = self.allow_redirects
        try:
            with urlopen(request, timeout=timeout)''')
edit('arrrequests/__init__.py','"allow_remote_requests": False,','"allow_remote_requests": False,\n        "allow_redirects": True,')
edit('arrrequests/__init__.py','"allow_remote_requests": {"description":','"allow_redirects": {"description": "Allow safe same-origin redirects", "type": "bool"},\n        "allow_remote_requests": {"description":')
edit('arrrequests/__init__.py','''            str(self.settings.get(f"{application}_api_key", "")),''','''            str(self.settings.get(f"{application}_api_key", "")),
            allow_redirects=bool(self.settings.get("allow_redirects", True)),''')
print('Private reference copied and corrected.')
