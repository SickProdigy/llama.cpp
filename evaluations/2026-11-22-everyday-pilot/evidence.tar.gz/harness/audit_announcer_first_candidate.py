"""Posthoc diagnostics of a frozen pending patch; no feedback to either model."""
from pathlib import Path
import json,subprocess,shutil,time,hashlib
import controller as c,audit_review_candidates as a
D=c.D

def child(root,log,command):
 args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*c.mount(str(root.relative_to(D)),'/workspace',True),*c.mount('supplemental-private-grader','/grader',True),'-e','CHECKOUT=/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/grader','-w','/workspace','--entrypoint','timeout',c.IMAGE,'-s','KILL','45','python',*command]
 with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
 return {'exit_code':r.returncode,'log':str(log.relative_to(D)),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
def main():
 out=D/'provisional-review-audits/review-announcer-turn0-001';review=json.loads((D/'runs/review-announcer/proxy-records/reviews/001-review.json').read_text());stage=out/'posthoc-candidate';assert not stage.exists();stage.mkdir();a.materialize(stage,None,c.BASE['review'],review['input']);results={}
 try:
  code="""from pathlib import Path
import hidden_checks as h,json
h.ROOT=Path('/workspace');m,p=h.Announcer().make();p.settings['default_rooms']=None
try:r=p.announce_command('Hello',room='Linux');result={'returned':r,'local_messages':p.out,'exception':None}
except Exception as e:result={'exception':type(e).__name__,'message':str(e)}
print(json.dumps(result))
"""
  for name,root in [('original',D/'baseline'),('reference',D/'reference'),('proposed',stage)]:
   p=out/('posthoc-null-default-'+name+'.log');results[name]=child(root,p,['-c',code]);results[name]['observed']=json.loads(p.read_text())
  target=['-m','pytest','-q','-p','no:cacheprovider','tests/test_announcer.py::test_group_room_with_comma_preview_is_a_single_target']
  actual=child(stage,out/'critic-test-relevance-actual.log',target)
  (stage/'announcer/__init__.py').write_bytes((D/'baseline/announcer/__init__.py').read_bytes())
  original=child(stage,out/'critic-test-relevance-original-target.log',target)
  result={'epoch':time.time(),'posthoc_not_primary_score':True,'case_not_complete':True,'none_default_compatibility':results,'criticized_test_original_target_control':{'actual':actual,'original_target':original},'interpretation':'None is a previously tolerated non-string configuration value, not the normal GUI string type. Treat any new exception as supplemental legacy-input robustness regression, not failure of the four frozen initial checks. Verify the test failure is behavior, not missing API.','not_fed_to_models':True};c.write(out/'posthoc-audit.json',result);print(json.dumps(result));assert actual['exit_code']==0 and original['exit_code']!=0
 finally:shutil.rmtree(stage)
if __name__=='__main__':main()
