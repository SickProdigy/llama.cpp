"""Private curation candidates only. No automatic export approval; no model feedback."""
from pathlib import Path
import sqlite3,json,re,hashlib
D=Path(__file__).resolve().parent
MATCH=re.compile(r'\b(?:pytest|unittest|py_compile|compileall)\b|\bgit\s+(?:commit|push)\b|\bpython[0-9.]*\s+-c\b')
PRIVATE=re.compile(r'AGENTS\.md|SOUL\.md|memories|skills/|config\.ya?ml|auth\.json|(?:^|/)\.env\b|/opt/data/(?!cache/scratch)|os\.environ|printenv',re.I)
def collect(turn):
 params=json.loads((turn/'run.json').read_text());query=json.loads((D/'task-prompts.json').read_text())[params['case']][params['phase']];db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
 try:
  starts=db.execute("select id from messages where session_id=? and role='user' and content=? order by id",(params['session_id'],query)).fetchall();assert len(starts)==1,'Ambiguous accepted query'
  rows=db.execute('select id,role,content,tool_call_id,tool_calls,tool_name,timestamp from messages where session_id=? and id>? order by id',(params['session_id'],starts[0][0])).fetchall()
 finally:db.close()
 calls={};candidates=[]
 for ident,role,content,tool_id,serialized,name,stamp in rows:
  if serialized:
   for call in json.loads(serialized):
    fn=call.get('function',{});args=fn.get('arguments',{})
    if isinstance(args,str):
     try:args=json.loads(args)
     except ValueError:args={}
    if fn.get('name')=='terminal':calls[call.get('id') or call.get('call_id')]=args.get('command','')
  if role!='tool' or name!='terminal':continue
  command=calls.get(tool_id)
  if not command or not MATCH.search(command):continue
  try:receipt=json.loads(content)
  except (ValueError,TypeError):continue
  text=json.dumps({'command':command,'receipt':receipt},ensure_ascii=False);candidates.append({'source_message_id':ident,'source_tool_call_id':tool_id,'timestamp':stamp,'command':command,'receipt':receipt,'private_marker_flag':bool(PRIVATE.search(text)),'source_content_sha256':hashlib.sha256(content.encode()).hexdigest()})
 return {'run':turn.parent.name,'phase':params['phase'],'session_id':params['session_id'],'accepted_user_message_id':starts[0][0],'scope':'Current accepted user turn only; earlier tests are not silently attributed to this followup.','approved_for_public_export':False,'manual_review_required':'Check commands and full outputs, credentials/private text, relevance and claims before copying selected receipts to the turn export allowlist.','candidates':candidates}
def main():
 summaries=[]
 for turn in sorted((D/'runs').glob('*/turn*')):
  if not (turn/'run.json').exists() or not (turn/'forge-snapshot.json').exists():continue
  record=collect(turn);dest=D/'receipt-curation-private'/(turn.parent.name+'-'+turn.name);dest.mkdir(parents=True,exist_ok=True);(dest/'candidates.json').write_text(json.dumps(record,indent=2));summaries.append({'run':record['run'],'phase':record['phase'],'candidates':len(record['candidates']),'private_marker_flags':sum(x['private_marker_flag'] for x in record['candidates'])})
 (D/'receipt-curation-private/index.json').write_text(json.dumps(summaries,indent=2));print(json.dumps(summaries))
if __name__=='__main__':main()
