"""Immutable user-task protocol audit; disclose source-verified native controls."""
from pathlib import Path
import json,sqlite3,hashlib,sys,time
from native_session_lineage import compression_lineage
D=Path(__file__).resolve().parent

def digest(text):return hashlib.sha256((text or '').encode()).hexdigest()
def main():
 progress='--progress' in sys.argv;prompts=json.loads((D/'task-prompts.json').read_text());frozen=json.loads((D/'frozen-protocol.json').read_text());origin=json.loads((D/'native-length-continuation-provenance.json').read_text());assert origin['source_verified_native_output_limit_control'] and digest(origin['exact_message'])==origin['message_sha256'];native=origin['exact_message'];runs=[];sessions=[];turns=0;unique_controls=set();rotations=set()
 for case,arm in frozen['order']:
  root=D/'runs'/(arm+'-'+case)
  if not root.exists():continue
  phases=[];sids=[];logical_root=None
  for phase in range(3):
   turn=root/('turn'+str(phase))
   if not (turn/'forge-snapshot.json').exists() or not (turn/'run.json').exists():continue
   r=json.loads((turn/'run.json').read_text());assert (r['case'],r['arm'],r['phase'])==(case,arm,phase);expected=prompts[case][:phase+1];sid=r['session_id'];sids.append(sid);logical_root=logical_root or r.get('logical_session_root',sid);assert r.get('logical_session_root',logical_root)==logical_root;lineage=compression_lineage(turn/'state.db',logical_root,sid);rotations.update((x['parent_session_id'],x['id']) for x in lineage[1:]);db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
   admission_sid=r.get('admission_session_id',sid);assert admission_sid in {x['id'] for x in lineage},'Admission session outside verified native ancestry'
   try:
    rows=db.execute('select id,role,content,finish_reason,compacted from messages where session_id=? order by id',(sid,)).fetchall()
    admission_rows=db.execute('select id,role,content,finish_reason,compacted from messages where session_id=? order by id',(admission_sid,)).fetchall()
   finally:db.close()
   users=[];tasks=[];controls=[];prior=None
   for ident,role,text,finish,compacted in rows:
    if role=='user':
     item={'id':ident,'content_sha256':digest(text),'compacted':compacted};users.append(item)
     if text==native and prior and prior[1]=='assistant' and prior[3]=='length':
      controls.append({**item,'kind':'native_output_limit_continuation','prior_assistant_message_id':prior[0],'prior_assistant_finish_reason':prior[3],'exact_source_verified_constant':True});unique_controls.add((sid,ident))
     else:tasks.append((item,text))
    prior=(ident,role,text,finish)
   actual=[x[1] for x in tasks];exact=actual==expected
   # Native archive compression legitimately replaces older messages. Verify
   # admissions in the exact source session separately from child retention.
   admitted=[];admission_prior=None
   for ident,role,text,finish,compacted in admission_rows:
    if role=='user':
     if not (text==native and admission_prior and admission_prior[1]=='assistant' and admission_prior[3]=='length'):admitted.append((ident,text))
    admission_prior=(ident,role,text,finish)
   admission_exact=[text for _,text in admitted]==expected
   positions=[expected.index(text) if text in expected else -1 for text in actual]
   subset=all(n>=0 for n in positions) and positions==sorted(set(positions))
   current_query_retained=bool(actual and actual[-1]==prompts[case][phase])
   missing=[{'frozen_task_index':n,'content_sha256':digest(text)} for n,text in enumerate(expected) if text not in actual]
   phases.append({'phase':phase,'session_id':sid,'logical_session_root':logical_root,'verified_native_lineage':lineage,'all_persisted_user_rows':users,'task_user_rows':[x[0] for x in tasks],'native_control_rows':controls,'expected_frozen_tasks_in_order':phase+1,'admission_session_id':admission_sid,'admission_task_rows':[{'id':i,'content_sha256':digest(text)} for i,text in admitted],'admission_history_exact_frozen_prefix':admission_exact,'current_user_tasks_are_ordered_frozen_subset':subset,'current_query_retained_verbatim':current_query_retained,'frozen_tasks_missing_verbatim_from_current_session':missing,'task_history_exact_frozen_prefix':exact,'raw_user_history_only_frozen_tasks':not controls and exact,'run_query_sha256_matches':r['query_sha256']==digest(prompts[case][phase])});turns+=1
  if not phases:continue
  same=len(set(sids))==1;sessions.append(logical_root);runs.append({'run':root.name,'literal_native_sid_unchanged':same,'same_logical_session_verified':True,'logical_session_root':logical_root,'turns':phases})
 unique=len(set(sessions))==len(sessions);assert unique,'Session reused across workflows';raw_retention=all(p['task_history_exact_frozen_prefix'] for r in runs for p in r['turns']);admissions_match=all(p['admission_history_exact_frozen_prefix'] and p['run_query_sha256_matches'] for r in runs for p in r['turns']);subset_clean=all(p['current_user_tasks_are_ordered_frozen_subset'] and p['current_query_retained_verbatim'] for r in runs for p in r['turns']);passed=unique and admissions_match and subset_clean;assert progress or (turns==18 and len(runs)==6),'Full18turn/6workflow native histories required'
 result={'epoch':time.time(),'progress_only':progress,'completed_turns':turns,'workflows_with_snapshots':len(runs),'fresh_distinct_sessions_across_workflows':unique,'all_frozen_task_histories_match':raw_retention,'all_frozen_task_admissions_match':admissions_match,'all_current_user_rows_are_frozen_ordered_subset_with_current_query':subset_clean,'protocol_fidelity_passed':passed,'raw_retention_does_not_prove_summary_fidelity':True,'raw_user_histories_contain_native_controls':bool(unique_controls),'unique_source_verified_native_control_rows':len(unique_controls),'native_compression_rotations_unique':len(rotations),'native_control_provenance':'native-length-continuation-provenance.json','runs':runs,'scope':'Exact admissions in their native source session, task order/hash and fresh logical roots are separate from current child raw-message retention. Missing earlier messages after verified compression are explicitly reported, never called full verbatim retention. Physical SID changes require verified oneshot parent ancestry with parent end_reason compression; unrelated drift fails. Generic output-limit continuation rows are separately disclosed only when exact pinned-runtime constant and preceding assistant finish_reason length match. Other unmatched rows fail task-prefix validation. This does not certify every system/tool context byte, compression quality or memory effectiveness. Same-arm profile persistence is intentional.','not_fed_to_models':True};(D/('session-protocol-validation'+('-progress' if progress else '')+'.json')).write_text(json.dumps(result,indent=2));print(json.dumps({'passed':passed,'all_raw_task_histories_retained':raw_retention,'turns':turns,'workflows':len(runs),'native_controls_unique':len(unique_controls),'progress_only':progress}));assert passed,'Unexpected persisted task history; inspect before claiming protocol fidelity'
if __name__=='__main__':main()
