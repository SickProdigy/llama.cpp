"""Operator-only posthoc cancellation-window check; not a frozen primary grader."""
from pathlib import Path
import json,subprocess
import hidden_checks as h
from unittest.mock import patch
D=Path(__file__).resolve().parent
def check(root):
 h.ROOT=root;m=h.load('beetsbridge');p=m.Plugin();p.settings=dict(p.settings,auto_import=True);p.echoes=[];p.echo_message=p.echoes.append;p.output=p.echoes.append;calls=[]
 p._make_runner=lambda:type('Runner',(),{'import_folder':lambda self,folder:calls.append(str(folder)) or subprocess.CompletedProcess([],0,'','')})()
 waiting=[]
 class DeferredThread:
  def __init__(self,target,args=(),kwargs=None,**other):self.target=target;self.args=args;self.kwargs=kwargs or {}
  def start(self):waiting.append(self)
 with patch.object(m.threading,'Timer',h.Timer),patch.object(m.threading,'Thread',DeferredThread):
  folder=Path('/fake/deferred');p._schedule(folder,delay=0);timer=p._pending[folder][1];timer.fire()
  assert len(waiting)==1 and not p._pending
  p.commands['beetscancel']['callback']('')
  waiting[0].target(*waiting[0].args,**waiting[0].kwargs)
 return {'imports_started_after_cancellation':calls,'local_reply':p.echoes,'pass':calls==[]}
if __name__=='__main__':
 result={'posthoc':True,'not_part_of_frozen_primary_score':True,'not_fed_to_agent':True,'scenario':'Timer has removed its pending entry and spawned a worker, but worker code has not registered itself; cancel before allowing worker to run.','reference':check(D/'reference'),'local_unpublished_model_draft':check(D/'runs/plain-beetsbridge/turn2/workspace')}
 assert result['reference']['pass'] and not result['local_unpublished_model_draft']['pass']
 (D/'runs/plain-beetsbridge/turn2/posthoc-cancel-registration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
