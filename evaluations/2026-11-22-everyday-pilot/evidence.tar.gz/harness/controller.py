"""Trusted operator. Agent mounts never include this controller or private checks."""
from pathlib import Path
import subprocess,json,time,os,sys,hashlib,shutil,re,sqlite3,urllib.request,traceback
D=Path(__file__).resolve().parent
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-everyday-pilot-20261122'
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
ALIAS='qwen3.8-27b-hermes-adapted-iq3xxs'
BASE={'plain':'01e776cc518d02cacb9fec12143edeef6a95d2ad','review':'1d8f965035e97403ebe13a57607d2d9c5d36d6e9'}
def sh(args,**kw):return subprocess.run(args,check=True,**kw)
def quiet(args,**kw):return sh(args,stdout=subprocess.DEVNULL,**kw)
def rm(name):subprocess.run(['docker','rm','-f',name],capture_output=True)
def mount(relative,target,ro=False):return ['--mount','type=bind,source='+ENGINE+'/'+relative+',target='+target+(',readonly' if ro else '')]
def write(path,obj):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)
def inspect(name):return json.loads(subprocess.check_output(['docker','inspect',name]))[0]
def signature(c):return hashlib.sha256(json.dumps({'Image':c['Image'],'Config':c['Config'],'HostConfig':c['HostConfig'],'Mounts':c['Mounts']},sort_keys=True).encode()).hexdigest()
def ready(alias,seconds=300):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   data=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=5))
   if data.get('model_alias')==alias:return data
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('Backend readiness timeout for '+alias)
def operator(script,p):return subprocess.check_output(['docker','exec','-i','hermes-pilot-store','python','/state/'+script],input=json.dumps(p).encode())
def api(method,path,body=None):
 c=inspect('mcp-gitea-codex');e=dict(x.split('=',1) for x in c['Config']['Env']);return json.loads(operator('api_operator.py',{'method':method,'url':e['GITEA_HOST'].rstrip('/')+'/api/v1/'+path,'body':body or {},'token':e['GITEA_ACCESS_TOKEN']}))
def clone(name,arm):
 c=inspect('mcp-gitea-codex');e=dict(x.split('=',1) for x in c['Config']['Env']);repo='hermes-pilot-'+arm+'-20261122';r=json.loads(operator('clone_operator.py',{'name':name,'url':e['GITEA_HOST'].rstrip('/')+'/chatgpt-codex/'+repo+'.git','public_url':'https://gitea.rcs1.top/chatgpt-codex/'+repo+'.git','token':e['GITEA_ACCESS_TOKEN']}));assert r['head']==BASE[arm] and r['tree']=='60e59671ae0973188ae90ac46f7cfec1c06bfd8f';return r
def gpu():
 p=subprocess.run(['docker','exec','llama-pilot-eval','nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True);return p.stdout.strip() if p.returncode==0 else None
def grade(work,case,phase,out):
 out.mkdir(parents=True,exist_ok=True)
 classes={'beetsbridge':'Beets','announcer':'Announcer','arrrequests':'Arr'}
 rel=str(work.relative_to(D));base=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*mount(rel,'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',IMAGE,'-s','KILL','90','python']
 with (out/'existing-tests.log').open('w') as f:r=subprocess.run(base+['-m','pytest','-q','-p','no:cacheprovider','tests'],stdout=f,stderr=subprocess.STDOUT)
 with (out/'independent-tests.log').open('w') as f:
  env=dict(os.environ,CHECKOUT=str(work),PHASE=str(phase),PYTHONDONTWRITEBYTECODE='1');h=subprocess.run([sys.executable,str(D/'hidden_checks.py'),classes[case]],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=60)
 write(out/'grade.json',{'existing_suite_exit_code':r.returncode,'independent_case_exit_code':h.returncode,'phase':phase,'case':case,'not_fed_to_agent':True})

def audit_remote(run,out,case,arm,phase):
 state_path=run/'proxy-records/state.json'
 state=json.loads(state_path.read_text()) if state_path.exists() else {}
 repo='hermes-pilot-'+arm+'-20261122';result={'proxy_state':state}
 if state.get('issue'):result['upstream_issue']=api('GET','repos/chatgpt-codex/'+repo+'/issues/'+str(state['issue']))['body']
 if state.get('pr'):result['upstream_pr']=api('GET','repos/chatgpt-codex/'+repo+'/pulls/'+str(state['pr']))['body']
 if state.get('branch') and state.get('commits'):
  c=inspect('mcp-gitea-required-eval');e=dict(x.split('=',1) for x in c['Config']['Env']);name='audit/'+arm+'-'+case+'-turn'+str(phase)
  result['remote_clone']=json.loads(operator('clone_operator.py',{'name':name,'branch':state['branch'],'user':'hermes-agent','url':e['GITEA_HOST'].rstrip('/')+'/hermes-agent/'+repo+'.git','public_url':'https://gitea.rcs1.top/hermes-agent/'+repo+'.git','token':e['GITEA_ACCESS_TOKEN']}))
  destination=D/'worktrees'/name;grade(destination,case,phase,out/'remote-grade')
 write(out/'forge-snapshot.json',result)

def session_for(profile,query):
 db=sqlite3.connect(profile/'state.db');r=db.execute("select session_id from messages where role='user' and content=? order by id desc limit 1",(query,)).fetchone();db.close();return r[0] if r else None
def capture_db(profile,out):
 source=sqlite3.connect(profile/'state.db',timeout=10);target=sqlite3.connect(out/'state.db');source.backup(target);target.close();source.close()
def run_case(case,arm,prompts):
 name=arm+'-'+case;run=D/'runs'/name;run.mkdir(parents=True);work=D/'worktrees'/name;cl=clone(name,arm);write(run/'clone.json',cl);prefix='pilot-'+hashlib.sha256(name.encode()).hexdigest()[:8]+'-';repo='hermes-pilot-'+arm+'-20261122'
 config=run/'proxy-config';config.mkdir();records=run/'proxy-records';records.mkdir();scope={'owner':'chatgpt-codex','repo':repo,'fork_repo':repo,'base_sha':BASE[arm],'branch_prefix':prefix,'allowed_paths':['README.md'],'allowed_path_prefixes':[case+'/'],'automatic_review':arm=='review','phase_lease':True,'alias':ALIAS};write(config/'publication-parameters.json',scope);write(config/'current-phase.json',{'id':name+'-not-started','active':False,'tasks_so_far':[]});agent='hermes-pilot-agent';proxy='hermes-pilot-proxy';profile=D/'arms'/arm/'profile'
 hint='\nContribution branches in this disposable evaluation must start with '+prefix+'; this prevents collisions with other test work.\n'
 quiet(['docker','exec','hermes-pilot-store','python','-c','from pathlib import Path; p=Path("/state/worktrees/'+name+'/AGENTS.md");p.write_text(p.read_text()+'+repr(hint)+')'])
 try:
  quiet(['docker','create','--name',proxy,'--user','1000:1000','--network','homelab','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g',*mount('public-harness','/harness',True),*mount(str(config.relative_to(D)),'/eval',True),*mount(str(records.relative_to(D)),'/proxy-records'),*mount(str(work.relative_to(D)),'/workspace',True),*mount('arms/'+arm+'/profile','/profile',True),'--entrypoint','python',IMAGE,'/harness/scope_proxy.py'])
  quiet(['docker','network','connect','--alias','gitea-pilot','hermes-pilot-coding',proxy]);quiet(['docker','start',proxy]);quiet(['docker','exec',proxy,'python','-c','from pathlib import Path;p=Path("/proxy-records/.write-preflight");p.write_text("ok");p.unlink()']);time.sleep(1)
  quiet(['docker','run','-d','--name',agent,'--network','hermes-pilot-coding','--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','4g','--memory-swap','4g','--cpus','2','--tmpfs','/tmp:rw,size=1g,mode=1777',*mount('arms/'+arm+'/profile','/opt/data'),*mount(str(work.relative_to(D)),'/workspace'),'-e','HOME=/opt/data','-e','HERMES_HOME=/opt/data','-e','HERMES_WRITE_SAFE_ROOT=/workspace:/opt/data/cache/scratch','--entrypoint','sleep',IMAGE,'infinity'])
  sid=None
  for i,query in enumerate(prompts):
   out=run/('turn'+str(i));out.mkdir();phase={'id':name+'-turn'+str(i),'active':True,'tasks_so_far':prompts[:i+1],'session_id':sid,'state_db':'/profile/state.db'};write(config/'current-phase.json',phase);print('TURN START',name,i,time.time(),flush=True)
   command=['docker','exec','-i','-w','/workspace',agent,'/opt/hermes/bin/hermes','chat','--cli','--oneshot','-Q','--query-file','-','--in','/workspace','--accept-hooks']
   if sid:command+=['--resume',sid]
   else:command+=['--max-turns','60','--run-budget','1800']
   samples=[];start=time.monotonic();external_timeout=False
   with (out/'console.log').open('w') as log:
    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT);proc.stdin.write(query.encode());proc.stdin.close()
    while proc.poll() is None:
     elapsed=time.monotonic()-start
     if elapsed>2100:
      external_timeout=True;phase['active']=False;write(config/'current-phase.json',phase);quiet(['docker','stop','-t','15',agent]);break
     samples.append({'epoch':time.time(),'seconds':round(elapsed,3),'gpu':gpu()});time.sleep(3)
    code=proc.wait()
   elapsed=time.monotonic()-start;phase['active']=False;write(config/'current-phase.json',phase);found=session_for(profile,query)
   if sid and found!=sid:raise RuntimeError('Dependent followup did not retain native session')
   sid=found
   if not sid:raise RuntimeError('Native CLI did not persist a user session; see console')
   phase['session_id']=sid;write(config/'current-phase.json',phase);write(out/'run.json',{'case':case,'arm':arm,'phase':i,'session_id':sid,'exit_code':code,'elapsed_seconds':round(elapsed,3),'external_timeout':external_timeout,'gpu':samples,'query_sha256':hashlib.sha256(query.encode()).hexdigest()});capture_db(profile,out);shutil.copytree(work,out/'workspace',symlinks=True);grade(out/'workspace',case,i,out);shutil.copytree(records,out/'forge-and-review-records',dirs_exist_ok=True);audit_remote(run,out,case,arm,i);print('TURN END',name,i,code,round(elapsed,1),flush=True)
   if external_timeout:quiet(['docker','start',agent])
  write(run/'case-finished.json',{'session_id':sid,'turns_present':len(list(run.glob('turn*/run.json'))),'epoch':time.time()})
 finally:
  for n in [agent,proxy]:
   if subprocess.run(['docker','inspect',n],capture_output=True).returncode==0:
    x=subprocess.run(['docker','logs',n],capture_output=True);(run/(n+'.log')).write_bytes(x.stdout+x.stderr)
  rm(agent);rm(proxy)
  state_path=records/'state.json'
  if state_path.exists():
   state=json.loads(state_path.read_text())
   if state.get('issue'):
    result=api('PATCH','repos/chatgpt-codex/'+repo+'/issues/'+str(state['issue']),{'state':'closed'})
    write(run/'issue-cleanup.json',{'number':state['issue'],'state':result['body'].get('state'),'preserved_for_audit':True})
def quality_preflight():
 packets=[('code-error',{'code.py':{'baseline':'def add(a,b): return a+b','proposed':'def add(a,b): return a-b'}},'revise'),('doc-error',{'code.py':{'baseline':'def add(a,b): return a+b','proposed':'def add(a,b): return a+b'},'README.md':{'baseline':'Adds two numbers.','proposed':'Subtracts the second number from the first.'}},'revise'),('correct-control',{'code.py':{'baseline':'def add(a,b): return a+b','proposed':'def add(a,b): return a+b'},'README.md':{'baseline':'Adds two numbers.','proposed':'Returns the sum of the two numbers.'}},'approve')]
 for name,context,expected in packets:
  packet={'task_history':['Keep add returning the sum of its two numbers and document that behavior.'],'candidate':{'operation':'create_or_update_file','source_context':context,'publication':{'message':'Update add and docs'}},'execution_evidence':{'available':False,'note':'No test execution was claimed.'}}
  code="import json,sys,time;sys.path.insert(0,'/state');from review_gate import http_reviewer;p=json.load(sys.stdin);s=time.monotonic();\ntry:r=http_reviewer('http://llm-pilot:8080/v1/chat/completions',"+repr(ALIAS)+")(p);print(json.dumps({'result':r,'elapsed':time.monotonic()-s}))\nexcept Exception as e:print(json.dumps({'error':str(e),'elapsed':time.monotonic()-s}))"
  raw=subprocess.check_output(['docker','exec','-i','hermes-pilot-store','python','-c',code],input=json.dumps(packet).encode());write(D/'critic-preflight'/(name+'.json'),{'expected':expected,'mock_fixture_not_scored_family':True,**json.loads(raw)});print('CRITIC PREFLIGHT',name,raw.decode()[:600],flush=True)
def main():
 frozen=json.loads((D/'frozen-protocol.json').read_text())
 for path,sha in frozen['files_sha256'].items():assert hashlib.sha256((D/path).read_bytes()).hexdigest()==sha,path
 # Reject stale/partial cohorts before touching any production runtime.
 for case,arm in frozen['order']:
  assert not (D/'runs'/(arm+'-'+case)).exists(),'A previous run requires explicit archival/resume, never silent replacement'
  assert not (D/'worktrees'/(arm+'-'+case)).exists(),'A prior checkout is still present'
 for arm in ('plain','review'):
  assert not (D/'arms'/arm/'profile/state.db').exists(),'A clean initial arm profile is required'
 write(D/'controller-started.json',{'epoch':time.time(),'pid':os.getpid()});initial={n:inspect(n) for n in ['hermes','llama-cpp','hermes-codex']}
 for n,c in initial.items():write(D/(n+'-pre-gpu-inspect.json'),[c])
 original=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=10));write(D/'original-props.json',original);candidate=json.loads((D.parents[1]/'evaluations/2026-11-21-goal-investigation/supervised-candidate.json').read_text())
 try:
  quiet(['docker','stop','-t','30','hermes']);quiet(['docker','stop','-t','20','llama-cpp'])
  launch=candidate['actual_test_backend_launch']['args'];quiet(['docker','run','-d','--name','llama-pilot-eval','--network','homelab','--network-alias','llama-pilot','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','40g','--memory-swap','40g',initial['llama-cpp']['Image'],*launch]);write(D/'candidate-props.json',ready(ALIAS))
  (D/'llm-records').mkdir(exist_ok=True)
  quiet(['docker','create','--name','hermes-pilot-llm-proxy','--user','1000:1000','--network','homelab','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g',*mount('public-harness','/harness',True),*mount('llm-records','/records'),'--entrypoint','python',IMAGE,'/harness/llm_proxy.py']);quiet(['docker','network','connect','--alias','llm-pilot','hermes-pilot-coding','hermes-pilot-llm-proxy']);quiet(['docker','start','hermes-pilot-llm-proxy']);quiet(['docker','exec','hermes-pilot-llm-proxy','python','-c','from pathlib import Path;p=Path("/records/.write-preflight");p.write_text("ok");p.unlink()'])
  if 'hermes-pilot-coding' not in inspect('hermes-pilot-store')['NetworkSettings']['Networks']:quiet(['docker','network','connect','hermes-pilot-coding','hermes-pilot-store'])
  quality_preflight();prompts=json.loads((D/'task-prompts.json').read_text())
  for case,arm in frozen['order']:run_case(case,arm,prompts[case])
  write(D/'all-model-workflows-finished.json',{'epoch':time.time()})
 except BaseException as e:
  write(D/'controller-error.json',{'error':str(e),'traceback':traceback.format_exc()});raise
 finally:
  for n in ['hermes-pilot-agent','hermes-pilot-proxy','hermes-pilot-llm-proxy']:rm(n)
  if subprocess.run(['docker','inspect','llama-pilot-eval'],capture_output=True).returncode==0:
   x=subprocess.run(['docker','logs','llama-pilot-eval'],capture_output=True);(D/'candidate-backend.log').write_bytes(x.stdout+x.stderr)
  rm('llama-pilot-eval');quiet(['docker','start','llama-cpp']);restored=ready(original['model_alias']);quiet(['docker','start','hermes']);after={n:inspect(n) for n in initial};write(D/'runtime-restoration.json',{'epoch':time.time(),'running':{n:c['State']['Running'] for n,c in after.items()},'configuration_unchanged':{n:signature(initial[n])==signature(after[n]) for n in initial},'restored_alias':restored['model_alias'],'restored_context':restored['default_generation_settings']['n_ctx']});print('ORIGINAL RUNTIME RESTORED',flush=True)
if __name__=='__main__':main()
