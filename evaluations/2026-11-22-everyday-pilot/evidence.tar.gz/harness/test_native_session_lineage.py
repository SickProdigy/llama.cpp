import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from native_session_lineage import compression_lineage
from review_gate import Gate


class NativeLineage(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'state.db'
        self.db = sqlite3.connect(self.path)
        self.addCleanup(self.db.close)
        self.db.execute('create table sessions(id,parent_session_id,source,started_at,ended_at,end_reason)')
        self.db.execute('create table messages(id integer primary key,session_id,role,content,tool_name,tool_calls)')
        self.db.executemany('insert into sessions values(?,?,?,?,?,?)', [
            ('root', None, 'oneshot', 1, 3, 'compression'),
            ('child', 'root', 'oneshot', 2.99, None, None),
            ('other', None, 'oneshot', 1, None, None),
        ])
        self.db.commit()

    def test_verified_rotation_and_same_id(self):
        self.assertEqual([x['id'] for x in compression_lineage(self.path, 'root', 'child')], ['root', 'child'])
        self.assertEqual(len(compression_lineage(self.path, 'root', 'root')), 1)

    def test_unrelated_and_reverse_ids_rejected(self):
        for root, leaf in [('other', 'child'), ('child', 'root')]:
            with self.assertRaises(ValueError):
                compression_lineage(self.path, root, leaf)

    def test_noncompression_parent_rejected(self):
        self.db.execute("update sessions set end_reason='cli_close' where id='root'")
        self.db.commit()
        with self.assertRaises(ValueError):
            compression_lineage(self.path, 'root', 'child')

    def test_foreign_source_and_cycle_rejected(self):
        self.db.execute("update sessions set source='foreign' where id='child'")
        self.db.commit()
        with self.assertRaises(ValueError):
            compression_lineage(self.path, 'root', 'child')
        self.db.execute("update sessions set source='oneshot',end_reason='compression' where id='child'")
        self.db.execute("update sessions set parent_session_id='child' where id='root'")
        self.db.commit()
        with self.assertRaises(ValueError):
            compression_lineage(self.path, 'other', 'child')

    def test_frozen_gate_query_lookup_is_identical_then_tracks_native_child(self):
        self.db.executemany('insert into messages values(?,?,?,?,?,?)', [
            (1, 'root', 'user', 'frozen task', None, None),
            (2, 'root', 'tool', '{"output":"old test receipt"}', 'terminal', None),
        ])
        self.db.commit()
        gate = Gate.__new__(Gate)
        known = {'state_db': str(self.path), 'session_id': 'root', 'tasks_so_far': ['frozen task']}
        lookup = dict(known, session_id=None)
        self.assertEqual(gate.execution_evidence(known), gate.execution_evidence(lookup))
        self.db.executemany('insert into messages values(?,?,?,?,?,?)', [
            (3, 'child', 'user', 'frozen task', None, None),
            (4, 'child', 'tool', '{"output":"current child test receipt"}', 'terminal', None),
        ])
        self.db.commit()
        evidence = gate.execution_evidence(lookup)
        self.assertTrue(evidence['available'])
        self.assertIn('current child test receipt', evidence['tail'])
        self.assertNotIn('old test receipt', evidence['tail'])
        self.assertIn('old test receipt', gate.execution_evidence(known)['tail'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
