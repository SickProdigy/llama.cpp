"""HTTP integration: direct native MCP mutations cannot bypass automatic review."""
import unittest,json,tempfile,pathlib,threading,subprocess,sys,os,socket,time,urllib.request
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
class Integration(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name);(self.root/'records').mkdir();(self.root/'work').mkdir();(self.root/'work/code.py').write_text('x=1\n');self.forwarded=[];self.decision='revise';self.delay=0;outer=self
  class H(BaseHTTPRequestHandler):
   def do_POST(self):
    d=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
    if self.path=='/review':
     time.sleep(outer.delay);result={'choices':[{'message':{'content':json.dumps({'decision':outer.decision,'findings':[] if outer.decision=='approve' else [{'file':'code.py','issue':'mock concrete defect'}]})},'finish_reason':'stop'}],'usage':{'total_tokens':1}}
    else:
     if d['method']=='tools/list':value={'tools':[{'name':x,'inputSchema':{'type':'object'}} for x in ['get_me','branch_write','create_or_update_file','issue_write','pull_request_write']]}
     else:
      n=d['params']['name'];outer.forwarded.append(n);v={'number':1} if n=='issue_write' else {'ok':True};value={'content':[{'type':'text','text':json.dumps(v)}]}
     result={'jsonrpc':'2.0','id':d['id'],'result':value}
    b=json.dumps(result).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
   def log_message(self,*a):pass
  self.server=ThreadingHTTPServer(('127.0.0.1',0),H);threading.Thread(target=self.server.serve_forever,daemon=True).start();self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  self.url=f'http://127.0.0.1:{port}/mcp';up=f'http://127.0.0.1:{self.server.server_port}';phase={'id':'case-turn0','active':True,'tasks_so_far':['Fix a bug.']};self.phase=self.root/'phase.json';self.phase.write_text(json.dumps(phase));scope={'owner':'up','repo':'arena','fork_repo':'arena','base_sha':'HEAD','branch_prefix':'lease-','allowed_paths':['code.py'],'automatic_review':True,'phase_lease':True,'alias':'mock'};(self.root/'scope.json').write_text(json.dumps(scope))
  env=dict(os.environ,PILOT_SCOPE_CONFIG=str(self.root/'scope.json'),PILOT_PHASE_FILE=str(self.phase),PILOT_WORKSPACE=str(self.root/'work'),PILOT_RECORDS=str(self.root/'records'),PILOT_REVIEW_URL=up+'/review',PILOT_BIND_HOST='127.0.0.1',PILOT_BIND_PORT=str(port),UPSTREAM_MCP=up+'/mcp',PYTHONDONTWRITEBYTECODE='1');self.proc=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).with_name('scope_proxy.py'))],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  self.addCleanup(self.stop)
  deadline=time.monotonic()+5
  while time.monotonic()<deadline:
   try:self.rpc('tools/list',{});break
   except OSError:time.sleep(.03)
  else:self.fail('proxy failed startup: '+self.proc.stderr.read().decode())
  self.call('branch_write',{'method':'create','owner':'hermes-agent','repo':'arena','branch':'lease-fix','old_branch':'main'})
 def stop(self):
  self.proc.terminate();self.proc.wait(timeout=5);self.proc.stderr.close()
 def rpc(self,method,params):
  req=urllib.request.Request(self.url,data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json'});return json.load(urllib.request.urlopen(req,timeout=5))['result']
 def call(self,name,args):return self.rpc('tools/call',{'name':name,'arguments':args})
 def mutation(self):return {'owner':'hermes-agent','repo':'arena','branch_name':'lease-fix','message':'fix','files':[{'path':'code.py','content':'x=2\n'}]}
 def test_direct_commit_is_blocked_then_reviewed_before_forwarding(self):
  r=self.call('create_or_update_file',self.mutation());self.assertTrue(r['isError']);self.assertNotIn('create_or_update_file',self.forwarded)
  self.decision='approve';r=self.call('create_or_update_file',self.mutation());self.assertFalse(r['isError']);self.assertEqual(self.forwarded.count('create_or_update_file'),1)
 def test_other_transports_repos_and_rename_escape_denied(self):
  self.decision='approve';r=self.call('delete_file',self.mutation());self.assertTrue(r['isError']);a=self.mutation();a['repo']='foreign';self.assertTrue(self.call('create_or_update_file',a)['isError']);a=self.mutation();a['files'][0]['new_path']='unrelated/config';self.assertTrue(self.call('create_or_update_file',a)['isError']);self.assertNotIn('create_or_update_file',self.forwarded)
 def test_ended_lease_blocks_even_an_approved_payload(self):
  self.decision='approve';d=json.loads(self.phase.read_text());d['active']=False;self.phase.write_text(json.dumps(d));r=self.call('create_or_update_file',self.mutation());self.assertTrue(r['isError']);self.assertNotIn('create_or_update_file',self.forwarded)
if __name__=='__main__':unittest.main(verbosity=2)
