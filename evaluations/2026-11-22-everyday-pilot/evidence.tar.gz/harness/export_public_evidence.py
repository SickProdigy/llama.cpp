"""Trusted allowlist exporter. Run only after all model work and independent review."""
from pathlib import Path
import json,hashlib,tarfile,base64,urllib.parse,sqlite3,re
import controller as c
D=c.D
DEST=D.parents[1]/'evaluations/2026-11-22-everyday-pilot'

def main():
 assert (D/'all-model-workflows-finished.json').exists()
 assert json.loads((D/'final-preservation.json').read_text())['passed']
 assert json.loads((D/'final-forge-audit.json').read_text())['passed']
 assert json.loads((D/'task-helper-cleanup.json').read_text())['passed']
 assert json.loads((D/'final-manual-review.json').read_text())['all_18_turns_independently_reviewed']
 settings=json.loads((D/'request-settings-validation.json').read_text());assert settings['all_observed_requests_match_configured_settings'] and settings['completed_turns']==18 and not settings['progress_only']
 sessions=json.loads((D/'session-protocol-validation.json').read_text());assert sessions['all_frozen_task_admissions_match'] and sessions['all_current_user_rows_are_frozen_ordered_subset_with_current_query'] and sessions['fresh_distinct_sessions_across_workflows'] and sessions['completed_turns']==18 and sessions['workflows_with_snapshots']==6 and not sessions['progress_only']
 finals=json.loads((D/'final-answer-validation.json').read_text());assert finals['all_selected_finals_match_native_snapshots'] and finals['turns']==18 and not finals['progress_only']
 receipts=json.loads((D/'execution-receipts-validation.json').read_text());assert receipts['all_selected_excerpts_match_native_snapshot'] and receipts['turns']==18 and not receipts['progress_only']
 for turn in (D/'runs').glob('*/turn*'):
  if (turn/'run.json').exists():
   assert (turn/'nested-model-tests-audit.json').exists(),'Nested-test audit missing: '+str(turn)
   assert (turn/'profile-tool-evidence.json').exists(),'Profile tool evidence missing: '+str(turn)
   assert (turn/'root-test-discovery.json').exists(),'Root-test discovery audit missing: '+str(turn)
 progress=json.loads((D/'progress-audit.json').read_text());assert progress['completed_turns']==18 and progress['frozen_files_unchanged']
 # Gather known credential values without printing or persisting their contents.
 secrets=set(json.loads((D.parent/'hermes-goal-recovery-20261121/remote-required-evidence/private-secrets.json').read_text()))
 for name in ['hermes','mcp-gitea-codex','mcp-gitea-required-eval']:
  for item in c.inspect(name)['Config'].get('Env',[]):
   key,sep,value=item.partition('=')
   if sep and re.search(r'(?:KEY|TOKEN|PASSWORD|SECRET|AUTH)',key,re.I) and len(value)>=8:secrets.add(value)
 patterns=set()
 for secret in secrets:
  if not isinstance(secret,str) or len(secret)<8:continue
  for variant in [secret,urllib.parse.quote(secret,safe=''),base64.b64encode(secret.encode()).decode()]:
   for _ in range(4):patterns.add(variant);variant=json.dumps(variant)[1:-1]
 stage=D/'export-stage-final';assert not stage.exists();stage.mkdir()
 manifest={};transformed=[]
 def scrub(text):
  for value in sorted(patterns,key=len,reverse=True):text=text.replace(value,'<REDACTED_CREDENTIAL>')
  return text
 def save_text(text,rel,raw_hash=None):
  safe=scrub(text);path=stage/rel;assert not path.exists(),rel
  assert '..' not in Path(rel).parts and not Path(rel).is_absolute()
  if safe!=text:transformed.append(str(rel))
  path.parent.mkdir(parents=True,exist_ok=True);path.write_text(safe)
  manifest[str(rel)]={'sha256':hashlib.sha256(safe.encode()).hexdigest(),'bytes':len(safe.encode()),'private_original_sha256':raw_hash or hashlib.sha256(text.encode()).hexdigest()}
 def save(path,rel):
  assert path.is_file() and not path.is_symlink()
  save_text(path.read_text(),rel,hashlib.sha256(path.read_bytes()).hexdigest())
 def obj(value,rel):save_text(json.dumps(value,indent=2),rel)
 def source_tree(root,rel):
  # Only tracked baseline source names plus case-local source/tests/README files.
  for p in sorted(root.rglob('*')):
   relative=p.relative_to(root)
   if p.is_symlink() or not p.is_file() or any(x in {'.git','__pycache__','.pytest_cache'} for x in relative.parts):continue
   if p.name=='AGENTS.md':continue
   if p.suffix in {'.py','.md','.yaml'} or p.name in {'PLUGININFO','.gitignore','.gitattributes','NOTICE','LICENSE'}:save(p,Path(rel)/relative)
 for name in ['task-prompts.json','frozen-protocol.json','candidate-manifest.json','controller.py','scope_proxy.py','review_gate.py','llm_proxy.py','scope_proxy_recovered.py','repair_proxy_restart.py','resume_supervisor.py','resume_remaining_suite.py','resume_suite_continuation2.py','continuation2-run-case.py','resume_suite_continuation3.py','continuation3-run-case.py','native_session_lineage.py','test_native_session_lineage.py','observe_compacted_exec.py','hidden_checks.py','supplemental_arr_redirects.py','audit_supplemental_arr.py','build_references.py','reproduce.py','clone_operator.py','api_operator.py','prepare_native_profile.py','test_scope.py','test_review_gate.py','test_proxy_gate.py','audit_progress.py','audit_original_tests.py','audit_root_test_discovery.py','audit_regression_relevance.py','audit_nested_model_tests.py','posthoc_announcer_room_names.py','posthoc_announcer_empty_status.py','audit_review_candidates.py','posthoc_cancel_registration.py','diagnose_beets_test_controls.py','audit_announcer_first_candidate.py','audit_arr_model_test_quality.py','posthoc_arr_https.py','audit_arr_https.py','validate_https_replay.py','audit_arr_regression_mutants.py','audit_arr_final_feature_test.py','posthoc_arr_redirect_defaults.py','cleanup_task_helpers.py','collect_execution_receipts.py','validate_execution_receipts.py','final_answer_evidence.py','collect_profile_tool_evidence.py','record_current_fresh_session.py','render_measurements.py','watch_independent_audits.py','verify_final_preservation.py','verify_postcleanup_preservation.py','verify_session_protocol.py','verify_request_settings.py','verify_final_forge.py','run_trusted_audit.py','validate_actual_archive.py','export_public_evidence.py']:
  save(D/name,Path('harness')/name)
 for p in sorted((D/'public-harness').glob('*.py')):save(p,Path('harness/runtime-proxies')/p.name)
 save(DEST/'SOURCE-NOTICE.md',Path('SOURCE-NOTICE.md'))
 save(DEST/'REPLAY.md',Path('REPLAY.md'))
 for name in ['validation.json','fixed-tests.log','frozen-original-tests.log']:save(D/'next-run-recorder'/name,Path('next-run-recorder')/name)
 for arm in ['plain','review']:save(D/'arms'/arm/'profile-manifest.json',Path('profile-manifests')/(arm+'.json'))
 source_tree(D/'next-run-recorder','next-run-recorder');source_tree(D/'plugins','harness/plugins');source_tree(D/'baseline','source-baseline');source_tree(D/'reference','reference-controls')
 for name in ['first-call-measurements.json','postcleanup-preservation.json','session-protocol-raw-retention-initial-final.json','session-retention-interpretation.json','task-data-ownership-normalization-final.json','review-ledger-notes.json','review-findings-ledger.json','review-findings.md','public-replay-https-reference.log','public-replay-https-review-readme.log','late-arr-review-analysis.json','late-review-snapshot-reconciliation.json','active-supervisor.json','continuation3-started.json','native-lineage-recovery-preflight.json','native-compaction-turn-recovery.json','native-compaction-exec-terminal.json','native-compaction-recovery-grading-runtime.json','task-data-ownership-normalization.json','cleanup-owned-helper-manifest-before-continuation3.json','native-compression-live-observation.json','native-compression-audit.json','production-profile-late-progress.json','native-context-trigger-observation.json','request-settings-validation.json','session-protocol-validation.json','session-protocol-initial-strict-progress.json','native-length-continuation-provenance.json','root-test-audit-addition.json','root-test-discovery-controls.json','root-test-control-baseline.log','root-test-control-reference.log','separate-codex-progress.json','plain-arrrequests-fresh-session-preflight.json','review-arrrequests-fresh-session-preflight.json','pilot-profile-config-progress.json','nested-test-audit-correction.json','plain-announcer-fresh-session-preflight.json','public-replay-validation.json','public-replay-reference-primary.log','public-replay-reference-redirects.log','public-replay-original-repository.log','public-replay-offline-recorder.log','late-announcer-feature-review-analysis.json','final-answer-validation.json','guarded-session-final-state-audit.json','announcer-doc-review-partial-capture.json','announcer-doc-critic-partial-response.txt','announcer-doc-critic-backend-trace.log','late-announcer-readme-scope-review-analysis.json','task-helper-cleanup.json','cleanup-owned-helper-manifest.json','execution-receipts-validation.json','materializer-v2-preflight.json','original-profile-continuation2-progress.json','measurements.csv','measurements.md','native-runtime-plugin-provenance.json','independent-audit-watch-state.json','independent-audit-watch.log','progress-audit.json','final-preservation.json','final-forge-audit.json','final-manual-review.json','completion-audit-final.json','supplemental-arr-controls.json','supplemental-arr-baseline.log','supplemental-arr-reference.log','supplemental-arr-isolated-controls.json','supplemental-arr-isolated-baseline.log','supplemental-arr-isolated-reference.log','baseline-reproductions.json','baseline-checks-native-runtime.log','reference-checks-native-runtime.log','full-existing-baseline.log','full-existing-reference.log','durable-native-preflight.json','critic-diagnostic-summary.json','first-real-review-timeout-analysis.json','late-first-review-response-analysis.json','late-readme-review-response-analysis.json','late-readme-repeat-review-response-analysis.json','late-readme-single-file-review-analysis.json','late-beets-feature-review-analysis.json','beets-posthoc-cancellation-comparison.json','review-beets-feature-regression-relevance.json','review-beets-feature-regression-actual.log','review-beets-feature-regression-ignore_cancel_generation_mutant.log','announcer-review-fresh-session-preflight.json','late-announcer-first-review-analysis.json','late-announcer-repeat-review-analysis.json','late-announcer-third-review-analysis.json','announcer-readme-followup-session-proof.json','readme-repeat-review-observation.json','feature-native-admission-progress.json','feature-native-lease-recovery-observation.json','model-preservation-continuation2-progress.json','reviewer-live-sqlite-preflight.json','review-candidate-materialization-preflight.json','candidate-backend-first-case.log','candidate-backend-continuation1.log','candidate-backend.log','long-response-observation.json','feature-output-cap-observation.json','isolated-profile-known-credential-scan.json','profile-credential-key-audit.json','profile-credential-scan-interpretation.json','proxy-recovery-live-verification.json','proxy-recovery-regression-tests.json','proxy-recovery-regression-tests.log','proxy-restart-recovery.json','proxy-recovery-branch-readback.json','continuation1-started.json','continuation1-error.json','continuation2-started.json','runtime-restoration-after-first-case.json','runtime-restoration.json','owner-source-during-continuation2.json','proxy-gate-tests.log','review-gate-tests.log','scope-tests.log']:
  save(D/name,Path('controls')/name)
 for file in sorted((D/'provisional-review-audits').rglob('*')):
  if file.is_file() and file.suffix in {'.json','.log'}:save(file,Path('provisional-review-audits')/file.relative_to(D/'provisional-review-audits'))
 for folder in sorted(D.glob('llm-records*')):
  for p in sorted(folder.glob('*.metrics.json')):save(p,Path('request-metrics')/folder.name/p.name)
 # The explicitly manually reviewed 8192-byte partial critic response prefix is
 # allowlisted above; it is incomplete and has no recovered API usage.
 # Do not publish raw HTTP requests, system prompts, SQLite databases, native
 # console dumps, private AGENTS/SOUL/skills/memories, profile archives or inspections.
 for run in sorted((D/'runs').iterdir()):
  if not run.is_dir():continue
  for p in sorted(run.glob('*.json')):save(p,Path('runs')/run.name/p.name)
  for turn in sorted(run.glob('turn*')):
   rel=Path('runs')/run.name/turn.name
   for p in sorted(turn.glob('*')):
    if p.is_file() and p.name!='state.db' and p.name!='console.log' and p.suffix in {'.json','.log'}:save(p,rel/p.name)
   source_tree(turn/'workspace',rel/'local-source')
   # Scope logs contain only explicitly permitted forge calls, not private profile reads.
   records=turn/'forge-and-review-records'
   for p in sorted(records.glob('*.json')):save(p,rel/'forge'/p.name)
   for p in sorted((records/'reviews').glob('*-review.json')):
    review=json.loads(p.read_text());evidence=review.get('input',{}).get('execution_evidence')
    if evidence is not None:
     raw=json.dumps(evidence,ensure_ascii=False)
     review['input']['execution_evidence']={'private_record_sha256':hashlib.sha256(raw.encode()).hexdigest(),'available':evidence.get('available'),'truncated':evidence.get('truncated'),'omitted_from_export':'May contain private owner instructions; execution claims are independently audited against private native receipts.'}
    obj(review,rel/'forge/reviews'/p.name)
   for candidate in sorted((turn/'candidate-reviews').glob('*')):
    for p in sorted(candidate.glob('*')):
     if p.is_file() and p.suffix in {'.json','.log'}:save(p,rel/'candidate-reviews'/candidate.name/p.name)
   data=json.loads((turn/'run.json').read_text());db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
   try:rows=db.execute('select id,role,tool_name,content,tool_calls,timestamp,compacted from messages where session_id=? order by id',(data['session_id'],)).fetchall()
   finally:db.close()
   obj([{'id':r[0],'role':r[1],'tool_name':r[2],'content_sha256':hashlib.sha256((r[3] or '').encode()).hexdigest(),'tool_calls_sha256':hashlib.sha256((r[4] or '').encode()).hexdigest(),'timestamp':r[5],'compacted':r[6]} for r in rows],rel/'native-message-provenance.json')
 # Export authenticated published snapshots separately; local-only drafts are not submissions.
 for root in sorted((D/'worktrees/audit').glob('*')):source_tree(root,Path('published-source')/root.name)
 obj({'files':manifest,'credential_redactions':transformed,'credential_values_checked':len(secrets),'excluded':['private profiles','production environment/auth','full model system prompts and HTTP transcripts','SQLite contents','native console dumps','owner AGENTS instructions'],'limitation':'Code and tests are replayable. Full byte-identical everyday-profile inference is private; message and raw-source hashes preserve provenance without asserting public exact replay.'},'export-manifest.json')
 for path in stage.rglob('*'):
  if path.is_file():assert not any(value.encode() in path.read_bytes() for value in patterns),str(path)
 archive=DEST/'evidence.tar.gz';assert not archive.exists()
 with tarfile.open(archive,'w:gz') as tar:
  for path in sorted(stage.rglob('*')):
   if path.is_file():tar.add(path,arcname=str(path.relative_to(stage)),recursive=False)
 with tarfile.open(archive,'r:gz') as tar:
  for member in tar.getmembers():
   assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
   assert not any(value.encode() in tar.extractfile(member).read() for value in patterns),member.name
 (DEST/'evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  evidence.tar.gz\n')
 print(json.dumps({'files':len(manifest),'archive_bytes':archive.stat().st_size,'redacted_files':len(transformed)}))
if __name__=='__main__':main()
