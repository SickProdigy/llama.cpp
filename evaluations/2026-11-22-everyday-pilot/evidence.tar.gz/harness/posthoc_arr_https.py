"""Posthoc loopback-only HTTPS preservation; never model-visible or primary-scored."""
import ssl,tempfile,subprocess,threading,json
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from unittest.mock import patch
from hidden_checks import load
m=load('arrrequests');seen=[];ports=[]
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  seen.append({'port':self.server.server_port,'path':self.path,'key':self.headers.get('X-Api-Key')})
  targets={'/relative':'/ok','/absolute':f'https://127.0.0.1:{ports[0]}/ok','/cross':f'https://127.0.0.1:{ports[1]}/ok'}
  if self.path in targets:
   self.send_response(302);self.send_header('Location',targets[self.path]);self.end_headers();return
  self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"appName":"Sonarr","version":"TLS-fixture"}')
 def log_message(self,*a):pass
with tempfile.TemporaryDirectory() as temp:
 key=Path(temp)/'fixture.key';cert=Path(temp)/'fixture.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=localhost','-keyout',str(key),'-out',str(cert)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(cert,key)
 servers=[ThreadingHTTPServer(('127.0.0.1',0),Handler) for _ in range(2)]
 for s in servers:s.socket=ctx.wrap_socket(s.socket,server_side=True);ports.append(s.server_port)
 threads=[threading.Thread(target=s.serve_forever,kwargs={'poll_interval':.01},daemon=True) for s in servers]
 for t in threads:t.start()
 result={}
 try:
  # Only this network-isolated fake TLS fixture trusts its ephemeral certificate.
  # The candidate source and production TLS policy are never edited.
  with patch.object(ssl,'_create_default_https_context',ssl._create_unverified_context):
   client=m.ArrClient('tv',f'https://127.0.0.1:{ports[0]}','FAKE-TLS-only-key')
   for path in ['/ok','/absolute','/relative','/cross']:
    seen.clear();value=None;error=None
    try:value=client._get_json(path,{},2)
    except Exception as e:error={'type':type(e).__name__,'message':str(e),'safe_ArrError':isinstance(e,m.ArrError)}
    result[path]={'response':value,'error':error,'request_count':len(seen),'foreign_key_received':any(x['port']==ports[1] and x['key'] for x in seen),'all_observed_requests_authenticate':all(x['key']=='FAKE-TLS-only-key' for x in seen)}
 finally:
  for s in servers:s.shutdown();s.server_close()
  for t in threads:t.join(1)
print(json.dumps({'posthoc_not_primary':True,'not_fed_to_models':True,'ephemeral_loopback_TLS_fixture':True,'results':result},indent=2))
