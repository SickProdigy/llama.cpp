"""Trusted operator only. Credentials arrive on stdin, never in argv or records."""
import sys,json,urllib.request
p=json.load(sys.stdin)
req=urllib.request.Request(p['url'],data=json.dumps(p.get('body',{})).encode() if p['method']!='GET' else None,method=p['method'],headers={'Authorization':'token '+p['token'],'Content-Type':'application/json'})
with urllib.request.urlopen(req,timeout=60) as r:
 b=r.read();print(json.dumps({'status':r.status,'body':json.loads(b) if b else None}))
