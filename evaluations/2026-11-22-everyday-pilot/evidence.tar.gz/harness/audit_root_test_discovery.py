"""Independent repository-root pytest integration audit. No model feedback."""
from pathlib import Path
import json,subprocess,hashlib,time
import controller as c
D=c.D

def fingerprint(root):
 files={}
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or p.is_symlink() or p.name=='AGENTS.md' or any(x in {'.git','__pycache__','.pytest_cache'} for x in rel.parts):continue
  files[str(rel)]=hashlib.sha256(p.read_bytes()).hexdigest()
 return hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()
def check(root,log):
 args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g','--cpus','1','--pids-limit','128','--tmpfs','/tmp:rw,size=128m',*c.mount(str(root.relative_to(D)),'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',c.IMAGE,'-s','KILL','90','python','-m','pytest','-q','-p','no:cacheprovider']
 with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=110)
 return {'exit_code':r.returncode,'log':str(log.relative_to(D)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
def main():
 control=D/'root-test-discovery-controls.json'
 if not control.exists():
  records={name:check(D/name,D/('root-test-control-'+name+'.log')) for name in ['baseline','reference']};assert all(x['exit_code']==0 for x in records.values());control.write_text(json.dumps({'epoch':time.time(),'controls':records,'scope':'Default root pytest, separate from immutable-original tests/ command.','not_fed_to_models':True},indent=2))
 for t in sorted((D/'runs').glob('*/turn*')):
  if not (t/'forge-snapshot.json').exists() or not (t/'run.json').exists() or (t/'root-test-discovery.json').exists():continue
  snap=json.loads((t/'forge-snapshot.json').read_text());local=t/'workspace';local_hash=fingerprint(local);result={'epoch':time.time(),'command':'python -m pytest -q -p no:cacheprovider','local_source_fingerprint':local_hash,'local':check(local,t/'root-test-discovery-local.log'),'actual_published':None,'published_head':None,'not_fed_to_models':True,'scope':'Integration/discovery with model test edits included, not immutable baseline tests. Nonzero results require manual failure/privacy review.'}
  if snap.get('remote_clone'):
   remote=D/'worktrees'/snap['remote_clone']['name'];remote_hash=fingerprint(remote);result['published_head']=snap['remote_clone']['head'];result['published_source_fingerprint']=remote_hash
   if remote_hash==local_hash:result['actual_published']={**result['local'],'reused_identical_source_result':True}
   else:result['actual_published']=check(remote,t/'root-test-discovery-published.log')
  else:result['publication_note']='No new commit published; local result is not submission evidence.'
  (t/'root-test-discovery.json').write_text(json.dumps(result,indent=2));print(t.parent.name,t.name,result['local']['exit_code'],result['actual_published']['exit_code'] if result['actual_published'] else None,flush=True)
if __name__=='__main__':main()
