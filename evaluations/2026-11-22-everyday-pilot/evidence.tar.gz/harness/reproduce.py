"""Operator-only baseline reproductions; no live services or credentials."""
import sys,types,importlib.util,pathlib,json,threading,subprocess
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=pathlib.Path(__file__).parent/'baseline'
events=types.SimpleNamespace(invoke_main_thread=lambda f,*a:f(*a))
sys.modules['pynicotine']=types.ModuleType('pynicotine')
sys.modules['pynicotine.events']=types.SimpleNamespace(events=events)
sys.modules['pynicotine.pluginsystem']=types.SimpleNamespace(BasePlugin=type('BasePlugin',(),{'log':lambda *a:None}))
def load(name):
 s=importlib.util.spec_from_file_location(name,ROOT/name/'__init__.py');m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
results={}
m=load('announcer')
parsed=m._parse_groups(json.dumps({'music':[' Jazz, Blues ','jazz, blues','Rock']}))
p=m.Plugin();p.settings=dict(m.Plugin.settings,room_groups_json=json.dumps({'music':['Jazz, Blues']}),default_rooms='Linux,Books');captured=[]
p._announce=lambda rooms,*args:captured.append(rooms) or True
p.announce_all_command('hello')
results['announcer']={'json_rooms':parsed['music'],'all_rooms':captured[0],'default_csv_control':m._csv_rooms('Linux, Books,linux'),'bug_reproduced':parsed['music']!=['Jazz, Blues','Rock']}
m=load('beetsbridge');p=m.Plugin();p.settings=dict(m.Plugin.settings);waiting=threading.Event();real_lock=threading.Lock()
class ObservedLock:
 def __enter__(self):waiting.set();real_lock.acquire()
 def __exit__(self,*a):real_lock.release()
p._import_lock=ObservedLock();calls=[];p._make_runner=lambda:types.SimpleNamespace(import_folder=lambda folder:calls.append(str(folder)) or subprocess.CompletedProcess([],0,'',''))
real_lock.acquire();worker=threading.Thread(target=p._import_worker,args=(pathlib.Path('/fake/album'),),daemon=True);worker.start();assert waiting.wait(2),'Worker did not reach lock'
p.disable();real_lock.release();worker.join(2);assert not worker.is_alive(),'Worker stuck'
results['beetsbridge']={'imports_started_after_disable':calls,'bug_reproduced':bool(calls)}
m=load('arrrequests');seen=[];target=[None]
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  seen.append({'port':self.server.server_port,'path':self.path,'key':self.headers.get('X-Api-Key')})
  if self.path.startswith('/same'):
   self.send_response(302);self.send_header('Location','/ok');self.end_headers()
  elif self.server.server_port==target[0] or self.path=='/ok':
   self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"appName":"Sonarr","version":"test"}')
  else:
   self.send_response(302);self.send_header('Location',f'http://127.0.0.1:{target[0]}/ok');self.end_headers()
 def log_message(self,*a):pass
servers=[ThreadingHTTPServer(('127.0.0.1',0),Handler) for _ in range(2)];target[0]=servers[1].server_port
threads=[threading.Thread(target=s.serve_forever,daemon=True) for s in servers]
for t in threads:t.start()
try:
 client=m.ArrClient('tv',f'http://127.0.0.1:{servers[0].server_port}','fake-pilot-key');client.status(2)
 cross=[x for x in seen if x['port']==target[0]];seen.clear();client._get_json('/same',{},2)
 results['arrrequests']={'cross_origin_key_forwarded':any(x['key']=='fake-pilot-key' for x in cross),'same_origin_control_key_preserved':seen[-1]['key']=='fake-pilot-key','bug_reproduced':any(x['key']=='fake-pilot-key' for x in cross)}
finally:
 for s in servers:s.shutdown();s.server_close()
print(json.dumps(results,indent=2))
assert all(x['bug_reproduced'] for x in results.values())
