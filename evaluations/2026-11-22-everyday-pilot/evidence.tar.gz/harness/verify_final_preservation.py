"""Read-only final verification; never repairs or overwrites owner configuration."""
from pathlib import Path
import json,hashlib,subprocess,time
import controller as c
D=c.D

def main():
 assert (D/'all-model-workflows-finished.json').exists(), 'Model workflows not finished'
 active=json.loads((D/'active-supervisor.json').read_text()) if (D/'active-supervisor.json').exists() else {'name':'hermes-pilot-supervisor'}
 supervisor=c.inspect(active['name'])
 assert not supervisor['State']['Running'], 'Wait for active supervisor finally restoration before final verification'
 if active.get('id'):assert supervisor['Id']==active['id'],'Active supervisor identity changed'
 initial={n:json.loads((D/(n+'-pre-gpu-inspect.json')).read_text())[0] for n in ['hermes','llama-cpp','hermes-codex']}
 after={n:c.inspect(n) for n in initial}
 runtime={n:{'running':after[n]['State']['Running'],'configuration_signature_unchanged':c.signature(after[n])==c.signature(initial[n]),'container_id_unchanged':after[n]['Id']==initial[n]['Id'],'docker_health':after[n]['State'].get('Health',{}).get('Status')} for n in initial}
 codex_untouched=after['hermes-codex']['State']['StartedAt']==initial['hermes-codex']['State']['StartedAt'] and after['hermes-codex']['RestartCount']==initial['hermes-codex']['RestartCount']
 original_props=json.loads((D/'original-props.json').read_text());props=c.ready(original_props['model_alias'])
 context_restored=props['default_generation_settings']['n_ctx']==original_props['default_generation_settings']['n_ctx']
 # Trusted read-only helper sees the exact original container binds. No secret values leave it.
 code='''from pathlib import Path
import json,hashlib,os
root=Path('/opt/data')
print(json.dumps({'files':{n:{'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest(),'bytes':(root/n).stat().st_size} for n in ['config.yaml','.env','auth.json','SOUL.md']}}))
'''
 profile=json.loads(subprocess.check_output(['docker','run','--rm','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--volumes-from','hermes:ro','--entrypoint','python',c.IMAGE,'-c',code]))
 before=json.loads((D/'original-files-during-pilot.json').read_text())
 profile['unchanged_vs_recorded_hashes']={n:v==before['files'][n] for n,v in profile['files'].items()}
 code='''from pathlib import Path
import json,os
roots=[p for p in [Path('/models'),Path('/opt/models')] if p.exists()]
assert len(roots)==1, roots
p=roots[0];stat=os.statvfs(p)
print(json.dumps({'gguf_files':[{'name':str(f.relative_to(p)),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns} for f in sorted(p.rglob('*.gguf'))],'free_bytes':stat.f_bavail*stat.f_frsize}))
'''
 models=json.loads(subprocess.check_output(['docker','run','--rm','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--volumes-from','llama-cpp:ro','--entrypoint','python',c.IMAGE,'-c',code]))
 before=json.loads((D/'model-inventory-during-pilot.json').read_text());old={x['name']:x for x in before['gguf_files']};new={x['name']:x for x in models['gguf_files']}
 models.update(missing_retained_models=sorted(set(old)-set(new)),changed_retained_models=[n for n in old if n in new and old[n]!=new[n]],reserve_bytes=100*1024**3)
 source_before=json.loads((D/'owner-source-provenance.json').read_text())
 # Use the local server path through the trusted store. The production checkout is not mounted in the actor.
 source_root='/srv/samba/media/Documents/prodigy/Coding-Programming/Repos/nicotineplus-plugins'
 code='''from pathlib import Path
import json,hashlib,subprocess
p=Path('/source');names=json.loads(__import__('sys').argv[1]);print(json.dumps({'head':subprocess.check_output(['git','-c','safe.directory=/source','-C','/source','rev-parse','HEAD'],text=True).strip(),'files':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in names}}))
'''
 owner=json.loads(subprocess.check_output(['docker','run','--rm','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--mount','type=bind,source='+source_root+',target=/source,readonly','--entrypoint','python',c.IMAGE,'-c',code,json.dumps(list(source_before['owner_modified_files']))]))
 owner['head_unchanged']=owner['head']==source_before['head'];owner['pending_files_unchanged']=owner['files']==source_before['owner_modified_files']
 pilot_profiles={}
 for arm in ['plain','review']:
  manifest=json.loads((D/'arms'/arm/'profile-manifest.json').read_text());actual=hashlib.sha256((D/'arms'/arm/'profile/config.yaml').read_bytes()).hexdigest();pilot_profiles[arm]={'expected_config_sha256':manifest['profile_config_sha256'],'actual_config_sha256':actual,'unchanged':actual==manifest['profile_config_sha256']}
 health=json.load(__import__('urllib.request',fromlist=['urlopen']).urlopen('http://192.168.86.239:11430/health',timeout=10))
 result={'epoch':time.time(),'runtime':runtime,'original_profile':profile,'models':models,'owner_source':owner,'pilot_profiles':pilot_profiles,'separate_hermes_codex_not_restarted':codex_untouched,'endpoint':{'health':health,'alias':props['model_alias'],'context':props['default_generation_settings']['n_ctx'],'expected_original_context':original_props['default_generation_settings']['n_ctx'],'context_restored':context_restored},'read_only':True}
 result['passed']=all(v['running'] and v['configuration_signature_unchanged'] and v['container_id_unchanged'] for v in runtime.values()) and codex_untouched and all(profile['unchanged_vs_recorded_hashes'].values()) and not models['missing_retained_models'] and not models['changed_retained_models'] and models['free_bytes']>=models['reserve_bytes'] and owner['head_unchanged'] and owner['pending_files_unchanged'] and all(x['unchanged'] for x in pilot_profiles.values()) and context_restored and health.get('status')=='ok' and runtime['llama-cpp']['docker_health']=='healthy'
 c.write(D/'final-preservation.json',result)
 print(json.dumps({'passed':result['passed'],'free_gib':round(models['free_bytes']/1024**3,2),'runtime':runtime}))
 assert result['passed'], 'Preservation verification failed; inspect evidence without overwriting owner changes'
if __name__=='__main__':main()
