import unittest,tempfile,pathlib,json,subprocess
from review_gate import Gate,ReviewDenied
class GateTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name)/'repo';self.root.mkdir();self.records=pathlib.Path(self.temp.name)/'records';self.phase=pathlib.Path(self.temp.name)/'phase.json';self.phase.write_text(json.dumps({'id':'turn0','tasks_so_far':['Fix a boundary bug.']}));(self.root/'code.py').write_text('def add(a,b):return a+b\n');subprocess.run(['git','init','-q',self.root],check=True);subprocess.run(['git','-C',self.root,'add','.'],check=True);subprocess.run(['git','-C',self.root,'-c','user.name=Test','-c','user.email=test@example.invalid','commit','-qm','baseline'],check=True)
  self.calls=[]
 def args(self,content='def add(a,b):return a-b\n'):return {'owner':'hermes-agent','repo':'arena','branch_name':'lease-fix','message':'Fix','files':[{'path':'code.py','content':content}]}
 def reviewer(self,packet):self.calls.append(packet);return {'decision':'approve','findings':[]}
 def gate(self,reviewer=None,**kw):return Gate(self.root,self.records,self.phase,'HEAD',reviewer or self.reviewer,**kw)
 def test_approved_exact_payload_cache_and_changed_payload_reviewed(self):
  g=self.gate();a=self.args();g.check('create_or_update_file',a);g.check('create_or_update_file',a);self.assertEqual(len(self.calls),1);g.check('create_or_update_file',self.args('def add(a,b):return a+b\n'));self.assertEqual(len(self.calls),2);self.assertEqual(len(list(self.records.glob('*-review.json'))),2)
 def test_findings_block_publication(self):
  g=self.gate(lambda _:dict(decision='revise',findings=[{'file':'code.py','issue':'wrong operator'}]));self.assertRaisesRegex(ReviewDenied,'wrong operator',g.check,'create_or_update_file',self.args())
 def test_invalid_and_timeout_fail_closed(self):
  for reviewer in (lambda _:{'decision':'approve'},lambda _:(_ for _ in ()).throw(TimeoutError('review timeout'))):
   with self.subTest(reviewer=reviewer):self.assertRaises(ReviewDenied,self.gate(reviewer).check,'create_or_update_file',self.args())
 def test_stale_workspace_approval_rejected(self):
  def change(packet):(self.root/'code.py').write_text('changed');return self.reviewer(packet)
  self.assertRaisesRegex(ReviewDenied,'changed',self.gate(change).check,'create_or_update_file',self.args())
 def test_review_uses_proposed_payload_not_different_local_content(self):
  (self.root/'code.py').write_text('local good content');g=self.gate();g.check('create_or_update_file',self.args('remote bad content'));self.assertEqual(self.calls[0]['candidate']['source_context']['code.py']['proposed'],'remote bad content');self.assertNotIn('local good content',json.dumps(self.calls[0]))
 def test_native_edit_payload_reconstructed_from_baseline(self):
  g=self.gate();a=self.args();a['files']=[{'path':'code.py','edits':[{'old_string':'a+b','new_string':'a-b'}]}];g.check('create_or_update_file',a);self.assertIn('a-b',self.calls[0]['candidate']['source_context']['code.py']['proposed'])
 def test_pr_prose_and_published_code_reviewed_together(self):
  g=self.gate();a=self.args();g.check('create_or_update_file',a);g.after('create_or_update_file',a);g.check('pull_request_write',{'method':'create','body':'Ran tests'});self.assertEqual(self.calls[-1]['candidate']['publication']['body'],'Ran tests');self.assertIn('code.py',self.calls[-1]['candidate']['source_context'])
 def test_budget_cannot_be_bypassed_with_changed_text(self):
  g=self.gate(max_attempts=1);g.check('create_or_update_file',self.args());self.assertRaisesRegex(ReviewDenied,'allowance',g.check,'create_or_update_file',self.args('new content'))
 def test_new_turn_review_is_not_reused(self):
  g=self.gate();g.check('create_or_update_file',self.args());d=json.loads(self.phase.read_text());d['id']='turn1';d['tasks_so_far'].append('Document it');self.phase.write_text(json.dumps(d));g.check('create_or_update_file',self.args());self.assertEqual(len(self.calls),2)
 def test_read_and_issue_calls_do_not_invoke_reviewer(self):
  g=self.gate();g.check('issue_write',{});g.check('get_me',{});self.assertFalse(self.calls)
if __name__=='__main__':unittest.main(verbosity=2)
