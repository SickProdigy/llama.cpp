"""Operator-only authenticated clone; token supplied via stdin, never persisted."""
import json,os,subprocess,sys,pathlib
p=json.load(sys.stdin);root=pathlib.Path('/state/worktrees')/p['name'];root.parent.mkdir(exist_ok=True)
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GIT_ASKPASS='/state/git-askpass.py',PILOT_GIT_USER=p.get('user','chatgpt-codex'),PILOT_GIT_TOKEN=p['token'])
subprocess.run(['git','clone','--single-branch','--branch',p.get('branch','main'),p['url'],str(root)],env=env,check=True,capture_output=True)
subprocess.run(['git','-C',str(root),'remote','set-url','origin',p['public_url']],check=True)
subprocess.run(['git','-C',str(root),'config','user.name','Hermes Agent'],check=True);subprocess.run(['git','-C',str(root),'config','user.email','hermes-agent@noreply.local'],check=True)
(root/'AGENTS.md').write_text(pathlib.Path('/state/project-AGENTS.md').read_text())
with (root/'.git/info/exclude').open('a') as f:f.write('\nAGENTS.md\n')
for f in [root,*root.rglob('*')]:
 if not f.is_symlink():os.chown(f,1000,1000)
print(json.dumps({'name':p['name'],'head':subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'rev-parse','HEAD']).decode().strip(),'tree':subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'rev-parse','HEAD^{tree}']).decode().strip()}))
