"""Trusted posthoc controls for HTTPS redirect preservation."""
from pathlib import Path
import json,subprocess,time,hashlib
import controller as c
D=c.D
out=D/'provisional-review-audits/arr-https-preservation';out.mkdir(exist_ok=True)
roots={'original':D/'baseline','reference':D/'reference','plain-final':D/'runs/plain-arrrequests/turn2/workspace','review-initial':D/'runs/review-arrrequests/turn0/workspace','review-readme':D/'runs/review-arrrequests/turn1/workspace'}
if (D/'runs/review-arrrequests/turn2/run.json').exists():roots['review-final']=D/'runs/review-arrrequests/turn2/workspace'
rows={}
for name,root in roots.items():
 log=out/(name+'.log')
 if not log.exists():
  args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*c.mount(str(root.relative_to(D)),'/workspace',True),*c.mount('hidden_checks.py','/audit/hidden_checks.py',True),*c.mount('posthoc_arr_https.py','/audit/probe.py',True),'-e','CHECKOUT=/workspace','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',c.IMAGE,'/audit/probe.py']
  with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
  assert r.returncode==0,name
 value=json.loads(log.read_text());rows[name]={'source_sha256':hashlib.sha256((root/'arrrequests/__init__.py').read_bytes()).hexdigest(),'log':str(log.relative_to(D)),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'results':value['results']}
result={'epoch':time.time(),'posthoc_not_primary':True,'not_fed_to_models':True,'no_candidate_or_production_edits':True,'native_image':c.IMAGE,'results':rows}
(out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:{p:(v['error']['type'] if v['error'] else 'OK') for p,v in x['results'].items()} for k,x in rows.items()}))
