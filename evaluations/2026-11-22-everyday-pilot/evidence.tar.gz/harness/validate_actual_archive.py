"""Host-side launcher: validate delivered archive bytes in an isolated pinned runtime."""
from pathlib import Path
import tarfile,subprocess,json,hashlib,time
import controller as c
D=c.D;public=D.parents[1]/'evaluations/2026-11-22-everyday-pilot';archive=public/'evidence.tar.gz';assert archive.is_file();stage=D/'actual-archive-replay';assert not stage.exists();stage.mkdir()
with tarfile.open(archive,'r:gz') as t:
 for m in t.getmembers():assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 t.extractall(stage,filter='data')
manifest=json.loads((stage/'export-manifest.json').read_text());assert all(hashlib.sha256((stage/n).read_bytes()).hexdigest()==v['sha256'] for n,v in manifest['files'].items())
cases=[('reference-primary',['harness/hidden_checks.py'],{'CHECKOUT':'/replay/reference-controls','PHASE':'2'},'Ran 16 tests'),('reference-redirects',['harness/supplemental_arr_redirects.py'],{'CHECKOUT':'/replay/reference-controls'},'OK'),('original-tests',['-m','pytest','-q','-p','no:cacheprovider','source-baseline/tests'],{},'83 passed'),('offline-recorder',['-m','unittest','discover','-s','next-run-recorder','-p','test_recorder.py','-v'],{},'Ran 4 tests'),('captured-announcer',['harness/hidden_checks.py','Announcer'],{'CHECKOUT':'/replay/runs/review-announcer/turn2/local-source','PHASE':'2'},'Ran 6 tests'),('https-reference',['harness/posthoc_arr_https.py'],{'CHECKOUT':'/replay/reference-controls'},None),('https-review',['harness/posthoc_arr_https.py'],{'CHECKOUT':'/replay/runs/review-arrrequests/turn1/local-source'},None)]
out=public/'replay';out.mkdir(exist_ok=True);rows=[]
for name,command,env,marker in cases:
 args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*c.mount('actual-archive-replay','/replay',True),'-w','/replay','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python']
 for k,v in env.items():args.extend(['-e',k+'='+v])
 # Docker options must precede the image.
 args.extend([c.IMAGE,*command]);log=out/(name+'.log');begin=time.time()
 with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
 text=log.read_text();assert r.returncode==0,(name,r.returncode)
 if marker:assert marker in text,(name,marker)
 if name=='https-reference':
  x=json.loads(text)['results'];assert all(x[p]['error'] is None for p in ['/ok','/absolute','/relative']) and x['/cross']['error']['safe_ArrError'] and not x['/cross']['foreign_key_received']
 if name=='https-review':
  x=json.loads(text)['results'];assert x['/ok']['error'] is None and all(x[p]['error']['type']=='AttributeError' for p in ['/absolute','/relative','/cross'])
 rows.append({'name':name,'python_argv':command,'environment':env,'exit_code':r.returncode,'seconds':round(time.time()-begin,3),'log':'replay/'+log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'expected_recorded_behavior_reproduced':True})
result={'epoch':time.time(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_manifest_entries_verified':len(manifest['files']),'native_image':c.IMAGE,'network':'none, loopback-only fixtures','readonly_archive_extract':True,'passed':len(rows)==7,'checks':rows,'scope':'Actual public archive behavior replay only; no inference, credentials, profile, system prompts or Gitea access. Observation-only HTTPS probe is checked for its expected positive reference and negative captured behavior.'};(public/'replay-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'checks':len(rows),'archive_entries':len(manifest['files'])}))
