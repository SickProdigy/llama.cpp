"""Trusted observer: audit completed immutable turn snapshots; never contact a model."""
from pathlib import Path
import json,time,subprocess,os,traceback
D=Path('/state');scripts=['audit_original_tests.py','audit_regression_relevance.py','audit_review_candidates.py','audit_supplemental_arr.py','audit_progress.py']
completed=set();log=D/'independent-audit-watch.log'
def emit(value):
 with log.open('a') as stream:stream.write(json.dumps(dict(epoch=time.time(),**value))+'\n')
def state():
 active=json.loads((D/'active-supervisor.json').read_text()) if (D/'active-supervisor.json').exists() else {'name':'hermes-pilot-supervisor'}
 p=subprocess.run(['docker','inspect',active['name'],'--format','{{.State.Running}}'],capture_output=True,text=True)
 return p.returncode==0 and p.stdout.strip()=='true'
def main():
 completed=set()
 emit({'event':'start','scope':'Read completed snapshots only; no private findings sent to actor or critic. No final semantic approval or goal completion.'})
 while True:
  turns={str(p.parent.relative_to(D)) for p in (D/'runs').glob('*/turn*/forge-snapshot.json') if (p.parent/'run.json').exists()}
  new=turns-completed
  if new:
   for script in scripts:
    begin=time.time()
    with (D/(script.removesuffix('.py')+'-watch.log')).open('a') as stream:r=subprocess.run(['python','/state/'+script],cwd='/state',stdout=stream,stderr=subprocess.STDOUT)
    emit({'event':'audit','script':script,'exit_code':r.returncode,'seconds':round(time.time()-begin,3),'new_turns':sorted(new)})
    if r.returncode:raise RuntimeError('Independent audit failed: '+script)
   completed=turns
   (D/'independent-audit-watch-state.json').write_text(json.dumps({'epoch':time.time(),'completed_turns':sorted(completed),'semantic_manual_review_still_required':True},indent=2))
  if len(turns)==18:emit({'event':'all_18_snapshots_audited'});return
  if not state():emit({'event':'supervisor_terminal','snapshots_audited':len(completed)});return
  time.sleep(20)
if __name__=='__main__':
 try:main()
 except BaseException as error:emit({'event':'error','error':str(error),'traceback':traceback.format_exc()});raise
