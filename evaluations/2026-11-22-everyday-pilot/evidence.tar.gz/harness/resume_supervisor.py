"""Adopt the existing native Docker exec; preserve prompts, session and elapsed budget."""
from pathlib import Path
import json,subprocess,time,sqlite3,shutil,hashlib,http.client,socket,inspect as pyinspect,traceback,os
import controller as c
D=c.D
EXEC_ID='ea56789b63a24b099063e4602a50541018a7a7ca72aa7c7c42913371948668fd'
class UnixConnection(http.client.HTTPConnection):
 def __init__(self):super().__init__('localhost')
 def connect(self):self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.connect('/var/run/docker.sock')
def exec_state():
 conn=UnixConnection()
 try:
  conn.request('GET','/exec/'+EXEC_ID+'/json');res=conn.getresponse();data=json.load(res)
  if res.status!=200:raise RuntimeError('Adopted Docker exec inspection failed: '+str(res.status))
  return data
 finally:conn.close()
def preserve_first_turn(prompts):
 run=D/'runs/plain-beetsbridge';out=run/'turn0';profile=D/'arms/plain/profile';work=D/'worktrees/plain-beetsbridge';config=run/'proxy-config/current-phase.json';phase=json.loads(config.read_text())
 assert phase['id']=='plain-beetsbridge-turn0' and phase['tasks_so_far']==prompts[:1]
 start_epoch=1795313876.8877976
 sid=c.session_for(profile,prompts[0]);assert sid
 state=exec_state();assert state['ProcessConfig']['arguments'][:2]==['chat','--cli'];assert state['ProcessConfig']['entrypoint']=='/opt/hermes/bin/hermes'
 c.write(D/'live-adoption.json',{'epoch':time.time(),'adopted_exec_id':EXEC_ID,'running_at_adoption':state['Running'],'actual_native_pid':state['Pid'],'session_id':sid,'original_turn_start_epoch':start_epoch,'prompts_and_model_work_unchanged':True,'lost_host_supervisor_pid':215421,'cause':'Chat tool interruption ended host process; Docker exec and native gateway continued','gpu_sampling_gap':'Original host controller buffered its samples in memory, now unavailable. Sparse earlier observations and durable samples after adoption remain; do not claim full-turn peak coverage.'})
 samples=[];external_timeout=False
 with (out/'adopted-gpu.jsonl').open('a',buffering=1) as stream:
  while state['Running']:
   now=time.time()
   if now-start_epoch>2100:
    external_timeout=True;phase['active']=False;c.write(config,phase);c.quiet(['docker','stop','-t','15','hermes-pilot-agent']);state=exec_state();break
   sample={'epoch':now,'seconds':round(now-start_epoch,3),'gpu':c.gpu()};samples.append(sample);stream.write(json.dumps(sample)+'\n');time.sleep(3);state=exec_state()
 elapsed=time.time()-start_epoch
 phase.update(active=False,session_id=sid);c.write(config,phase)
 c.write(out/'run.json',{'case':'beetsbridge','arm':'plain','phase':0,'session_id':sid,'exit_code':state.get('ExitCode'),'elapsed_seconds':round(elapsed,3),'elapsed_start_reconstructed_from_original_controller_log':True,'external_timeout':external_timeout,'gpu':samples,'gpu_coverage':'after adoption only; earlier buffered samples lost','query_sha256':hashlib.sha256(prompts[0].encode()).hexdigest(),'native_exec_adopted_without_restart':True})
 c.capture_db(profile,out);shutil.copytree(work,out/'workspace',symlinks=True);c.grade(out/'workspace','beetsbridge',0,out);shutil.copytree(run/'proxy-records',out/'forge-and-review-records',dirs_exist_ok=True);c.audit_remote(run,out,'beetsbridge','plain',0)
 print('ADOPTED TURN END plain-beetsbridge 0',state.get('ExitCode'),round(elapsed,1),flush=True)
 if external_timeout:c.quiet(['docker','start','hermes-pilot-agent'])
 return sid
def build_resume():
 # Keep the frozen run_case's remaining turn loop, native invocation and cleanup exactly.
 source=pyinspect.getsource(c.run_case)
 start=source.index('  sid=None\n')
 body=source[start:].replace('  sid=None\n','  sid=existing_sid\n',1).replace('  for i,query in enumerate(prompts):','  for i in (1,2):\n   query=prompts[i]',1)
 prefix="""def resume_remaining(case,arm,prompts,existing_sid):
 name=arm+'-'+case;run=D/'runs'/name;work=D/'worktrees'/name;repo='hermes-pilot-'+arm+'-20261122'
 config=run/'proxy-config';records=run/'proxy-records';agent='hermes-pilot-agent';proxy='hermes-pilot-proxy';profile=D/'arms'/arm/'profile'
 try:
"""
 text=prefix+body
 (D/'supervisor-generated-remaining-case.py').write_text(text)
 exec(compile(text,str(D/'supervisor-generated-remaining-case.py'),'exec'),c.__dict__)
 return c.__dict__['resume_remaining']
def restore(initial,original):
 for name in ['hermes-pilot-agent','hermes-pilot-proxy','hermes-pilot-llm-proxy']:
  if subprocess.run(['docker','inspect',name],capture_output=True).returncode==0:
   log=subprocess.run(['docker','logs',name],capture_output=True);(D/(name+'-supervisor-final.log')).write_bytes(log.stdout+log.stderr)
  c.rm(name)
 if subprocess.run(['docker','inspect','llama-pilot-eval'],capture_output=True).returncode==0:
  log=subprocess.run(['docker','logs','llama-pilot-eval'],capture_output=True);(D/'candidate-backend.log').write_bytes(log.stdout+log.stderr)
 c.rm('llama-pilot-eval');c.quiet(['docker','start','llama-cpp']);restored=c.ready(original['model_alias']);c.quiet(['docker','start','hermes']);after={name:c.inspect(name) for name in initial}
 c.write(D/'runtime-restoration.json',{'epoch':time.time(),'running':{n:v['State']['Running'] for n,v in after.items()},'configuration_unchanged':{n:c.signature(initial[n])==c.signature(after[n]) for n in initial},'restored_alias':restored['model_alias'],'restored_context':restored['default_generation_settings']['n_ctx'],'restored_by':'detached adoption supervisor'})
 print('ORIGINAL RUNTIME RESTORED',flush=True)
def main():
 frozen=json.loads((D/'frozen-protocol.json').read_text())
 for path,sha in frozen['files_sha256'].items():assert hashlib.sha256((D/path).read_bytes()).hexdigest()==sha,path
 initial={name:json.loads((D/(name+'-pre-gpu-inspect.json')).read_text())[0] for name in ['hermes','llama-cpp','hermes-codex']};original=json.loads((D/'original-props.json').read_text());prompts=json.loads((D/'task-prompts.json').read_text())
 c.write(D/'supervisor-started.json',{'epoch':time.time(),'pid_in_container':os.getpid(),'model_hints_added':False})
 try:
  sid=preserve_first_turn(prompts['beetsbridge']);resume=build_resume();resume('beetsbridge','plain',prompts['beetsbridge'],sid)
  for case,arm in frozen['order'][1:]:c.run_case(case,arm,prompts[case])
  c.write(D/'all-model-workflows-finished.json',{'epoch':time.time(),'first_turn_adopted':True})
 except BaseException as error:
  c.write(D/'supervisor-error.json',{'error':str(error),'traceback':traceback.format_exc()});raise
 finally:restore(initial,original)
if __name__=='__main__':main()
