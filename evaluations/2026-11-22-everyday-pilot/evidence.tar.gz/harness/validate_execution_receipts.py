"""Check curated excerpts against immutable native snapshots; not semantic approval."""
from pathlib import Path
import json,hashlib,sys
from collect_execution_receipts import collect
D=Path(__file__).resolve().parent

def main():
 progress='--progress' in sys.argv;artifacts=sorted((D/'runs').glob('*/turn*/execution-receipts.json'));assert progress or len(artifacts)==18,'All18 curated turn artifacts required'
 checked=[]
 for file in artifacts:
  approved=json.loads(file.read_text());assert approved['approved_for_public_export'] is True
  source=collect(file.parent);assert approved['run']==source['run'] and approved['phase']==source['phase'];by_id={x['source_message_id']:x for x in source['candidates']};seen=set()
  for row in approved['receipts']:
   assert row['id'] not in seen;seen.add(row['id']);actual=by_id[row['id']];receipt=actual['receipt'];output=str(receipt.get('output',''))
   assert row['command']==actual['command']
   assert row['source_content_sha256']==actual['source_content_sha256']
   assert row['terminal_exit_code']==receipt.get('exit_code') and row['error']==receipt.get('error')
   assert row['output_excerpt']==output[-1300:]
   assert row['complete_output_sha256']==hashlib.sha256(output.encode()).hexdigest() and row['complete_output_chars']==len(output)
   assert row['excerpt_is_tail']==(len(output)>1300)
  checked.append({'run':source['run'],'phase':source['phase'],'selected_receipts':len(seen),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
 result={'all_selected_excerpts_match_native_snapshot':True,'progress_only':progress,'turns':len(artifacts),'checked':checked,'scope':'Provenance only; manual private-content/relevance review and interpretation of unittest output remain necessary.'};(D/('execution-receipts-validation'+('-progress' if progress else '')+'.json')).write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='checked'}))
if __name__=='__main__':main()
