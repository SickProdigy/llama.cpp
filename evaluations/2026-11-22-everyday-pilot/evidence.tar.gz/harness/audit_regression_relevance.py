"""Private post-run test discrimination checks; never feeds results back to models."""
from pathlib import Path
import json,shutil,subprocess,hashlib,os,sys
from controller import D,IMAGE,mount
def run(turn):
 state=json.loads((turn/'run.json').read_text());case=state['case'];arm=state['arm'];phase=state['phase'];remote=D/'worktrees/audit'/(arm+'-'+case+'-turn'+str(phase));work=remote if remote.exists() else turn/'workspace';source='published personal branch' if remote.exists() else 'local workspace only'
 out=turn/'regression-relevance.json'
 if out.exists():return
 changed=[];deleted=[]
 baseline=D/'baseline'
 for f in (work/'tests').rglob('*.py'):
  original=baseline/f.relative_to(work)
  if not original.exists() or original.read_bytes()!=f.read_bytes():changed.append(str(f.relative_to(work)))
 for f in (baseline/'tests').rglob('*.py'):
  if not (work/f.relative_to(baseline)).exists():deleted.append(str(f.relative_to(baseline)))
 stage=D/'regression-audit-work'/hashlib.sha256(str(turn).encode()).hexdigest()[:16]
 if stage.exists():raise RuntimeError('Partial regression audit requires inspection, not overwrite')
 stage.parent.mkdir(exist_ok=True)
 shutil.copytree(work,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
 target=stage/case
 if target.exists():shutil.rmtree(target)
 shutil.copytree(baseline/case,target)
 command=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*mount(str(stage.relative_to(D)),'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',IMAGE,'-s','KILL','90','python','-m','pytest','-q','-p','no:cacheprovider','tests']
 try:
  with (turn/'model-tests-on-original-target.log').open('w') as log:proc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  result={'source':source,'target_replaced_with_original':case,'original_target_sha256':hashlib.sha256((baseline/case/'__init__.py').read_bytes()).hexdigest(),'modified_or_added_tests':changed,'deleted_tests':deleted,'all_model_tests_on_original_target_exit_code':proc.returncode,'test_discovery_scope':'Top-level tests/ only; audit_nested_model_tests.py separately covers nested test files.','manual_failure_review_required':proc.returncode!=0,'interpretation':'Passing on original code means the suite does not detect the defect. Failure alone is insufficient: inspect whether it is the actual requested regression, a later feature requirement, an import/API mismatch, or an unrelated failure. This evidence is not fed to the model.'};out.write_text(json.dumps(result,indent=2));print(turn.parent.name,phase,'original-target exit',proc.returncode,flush=True)
 finally:shutil.rmtree(stage)
if __name__=='__main__':
 for phase in sorted((D/'runs').glob('*/turn*')):
  if (phase/'run.json').exists() and (phase/'forge-snapshot.json').exists():run(phase)
 subprocess.run([sys.executable,str(D/'audit_nested_model_tests.py')],check=True)
 subprocess.run([sys.executable,str(D/'audit_root_test_discovery.py')],check=True)
