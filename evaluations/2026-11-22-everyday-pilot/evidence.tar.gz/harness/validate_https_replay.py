"""Run the two added public TLS replay commands in the pinned isolated runtime."""
from pathlib import Path
import json,shutil,subprocess,time,hashlib
import controller as c
D=c.D;stage=D/'public-replay-layout-check';assert stage.is_dir()
shutil.copy2(D/'posthoc_arr_https.py',stage/'harness/posthoc_arr_https.py')
target=stage/'runs/review-arrrequests/turn1/local-source';shutil.copytree(D/'runs/review-arrrequests/turn1/workspace',target,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','AGENTS.md','__pycache__','.pytest_cache'))
results={}
for name,root in [('reference','reference-controls'),('review-readme','runs/review-arrrequests/turn1/local-source')]:
 log=D/('public-replay-https-'+name+'.log');args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*c.mount('public-replay-layout-check','/replay',True),'-w','/replay','-e','CHECKOUT=/replay/'+root,'-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',c.IMAGE,'harness/posthoc_arr_https.py']
 with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
 assert r.returncode==0,name
 x=json.loads(log.read_text())['results']
 if name=='reference':
  assert all(x[p]['response']['appName']=='Sonarr' and x[p]['error'] is None for p in ['/ok','/absolute','/relative'])
  assert x['/cross']['error']['safe_ArrError'] and not x['/cross']['foreign_key_received']
 else:
  assert x['/ok']['response']['appName']=='Sonarr'
  assert all(x[p]['error']['type']=='AttributeError' and not x[p]['foreign_key_received'] for p in ['/absolute','/relative','/cross'])
 results[name]={'exit_code':r.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'recorded_behavior_reproduced':True}
p=D/'public-replay-validation.json';v=json.loads(p.read_text());v['added_https_replay']={'epoch':time.time(),'native_image':c.IMAGE,'commands_match_public_paths':True,'results':results};p.write_text(json.dumps(v,indent=2));print(json.dumps(results))
