"""Private behavior checks. Root path is an independent checkout, never agent-mounted."""
import os,sys,types,unittest,importlib.util,threading,json,subprocess
from pathlib import Path
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path(os.environ.get('CHECKOUT',Path(__file__).parent/'baseline'))
PHASE=int(os.environ.get('PHASE','0'))
class Events:
 def __init__(self):self.scheduled=[];self.cancelled=[];self.invocations=[]
 def invoke_main_thread(self,fn,*args):self.invocations.append((fn,args));fn(*args)
 def schedule(self,delay,callback,callback_args=None,repeat=False):
  self.scheduled.append((delay,callback,callback_args,repeat));return len(self.scheduled)
 def cancel_scheduled(self,event):self.cancelled.append(event)
def load(name):
 events=Events();base=type('BasePlugin',(),{'log':lambda *a:None})
 with patch.dict(sys.modules,{'pynicotine':types.ModuleType('pynicotine'),'pynicotine.events':types.SimpleNamespace(events=events),'pynicotine.pluginsystem':types.SimpleNamespace(BasePlugin=base)}):
  spec=importlib.util.spec_from_file_location('private_'+name,ROOT/name/'__init__.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
 m._events=events;return m
class Timer:
 def __init__(self,delay,callback,args=(),kwargs=None):self.delay=delay;self.callback=callback;self.args=args;self.kwargs=kwargs or {};self.cancelled=False
 def start(self):pass
 def cancel(self):self.cancelled=True
 def fire(self):self.callback(*self.args,**self.kwargs)
class Beets(unittest.TestCase):
 def setup_workers(self):
  m=load('beetsbridge');p=m.Plugin();p.settings=dict(m.Plugin.settings,auto_import=True);p.outputs=[];p.echo_message=p.outputs.append;p.output=p.outputs.append
  active=threading.Event();release=threading.Event();waiting=threading.Event();started=[];threads=[];guard=threading.Lock();real=threading.Lock();n=[0];Thread=threading.Thread
  class Lock:
   def __enter__(self):
    with guard:n[0]+=1;count=n[0]
    if count==2:waiting.set()
    real.acquire()
   def __exit__(self,*a):real.release()
  p._import_lock=Lock()
  def run(folder):
   started.append(str(folder))
   if str(folder)=='/fake/active':active.set();assert release.wait(4),'test active gate timed out'
   return subprocess.CompletedProcess([],0,'','')
  p._make_runner=lambda:types.SimpleNamespace(import_folder=run)
  def thread(*a,**k):t=Thread(*a,**k);threads.append(t);return t
  patchers=[patch.object(m.threading,'Timer',Timer),patch.object(m.threading,'Thread',thread)]
  for x in patchers:x.start()
  def cleanup():
   release.set()
   for t in threads:t.join(3)
   for x in reversed(patchers):x.stop()
  self.addCleanup(cleanup)
  def queue(path,fire=True):
   p._schedule(Path(path),delay=0);timer=p._pending[Path(path)][1]
   if fire:timer.fire()
   return timer
  queue('/fake/active');self.assertTrue(active.wait(3));queue('/fake/waiting');self.assertTrue(waiting.wait(3))
  return m,p,release,started,threads,queue
 def lifecycle(self,method,reload=False):
  m,p,release,started,threads,queue=self.setup_workers();timer=queue('/fake/timer',False)
  getattr(p,method)()
  if reload:p.loaded_notification()
  release.set()
  for t in threads:t.join(3)
  self.assertEqual(started,['/fake/active']);self.assertTrue(timer.cancelled);self.assertFalse(p._pending)
  if reload:
   queue('/fake/later')
   for t in threads:t.join(3)
   self.assertEqual(started,['/fake/active','/fake/later'])
 def test_disable_discards_waiter_and_timer_not_active(self):self.lifecycle('disable')
 def test_shutdown_discards_waiter_not_active(self):self.lifecycle('shutdown_notification')
 def test_reload_cannot_revive_cancelled_waiter(self):self.lifecycle('disable',True)
 def test_ordinary_serial_imports_preserved(self):
  m,p,release,started,threads,queue=self.setup_workers();self.assertEqual(started,['/fake/active']);release.set()
  for t in threads:t.join(3)
  self.assertEqual(started,['/fake/active','/fake/waiting'])
 @unittest.skipIf(PHASE<2,'dependent feature not requested yet')
 def test_cancel_command_keeps_enabled_and_later_imports(self):
  m,p,release,started,threads,queue=self.setup_workers();timer=queue('/fake/timer',False)
  self.assertIn('beetscancel',p.commands);self.assertTrue(p.commands['beetscancel']['callback'](''));self.assertTrue(p.outputs);self.assertTrue(p.settings['auto_import']);self.assertFalse(p._stopping)
  release.set()
  for t in threads:t.join(3)
  self.assertEqual(started,['/fake/active']);self.assertTrue(timer.cancelled);queue('/fake/later')
  for t in threads:t.join(3)
  self.assertEqual(started,['/fake/active','/fake/later'])
class Announcer(unittest.TestCase):
 def make(self,enabled=False):
  m=load('announcer');p=m.Plugin();p.settings=dict(m.Plugin.settings,room_groups_json=json.dumps({'music':[' Jazz, Blues ','jazz, blues',' Rock ',' Missing, Room ']}),default_rooms='Linux, Books,linux',sending_enabled=enabled)
  p.core=types.SimpleNamespace(chatrooms=types.SimpleNamespace(joined_rooms={r:object() for r in ['Jazz, Blues','Jazz','Blues','Rock','Linux','Books']}));p.out=[];p.sent=[];p.echo_message=p.out.append;p.output=p.out.append;p.echo_private=lambda _user,msg,**kw:p.out.append(msg);p.echo_public=lambda _room,msg,**kw:p.out.append(msg);p.send_public=lambda *a:p.sent.append(a)
  return m,p
 def targets(self,all_rooms=False,enabled=True):
  m,p=self.make(enabled);fn=p.announce_all_command if all_rooms else p.announce_group_command;args='hello' if all_rooms else 'MuSiC hello';self.assertTrue(fn(args,user='owner'))
  if enabled:
   for _d,cb,args,_r in list(m._events.scheduled):cb(*args)
  return m,p
 def test_group_literal_target_and_dedup(self):
  m,p=self.targets();self.assertEqual([x[0] for x in p.sent],['Jazz, Blues','Rock'])
 def test_all_rooms_preserves_json_and_csv(self):
  m,p=self.targets(True);self.assertEqual([x[0] for x in p.sent],['Linux','Books','Jazz, Blues','Rock'])
 def test_preview_has_no_sends_scheduling_or_cooldown(self):
  m,p=self.targets(enabled=False);self.assertFalse(p.sent);self.assertFalse(m._events.scheduled);self.assertFalse(p._recent);self.assertIn('PREVIEW',p.out[-1]);self.assertIn('Jazz, Blues',p.out[-1])
 def test_existing_csv_normalization(self):
  m,p=self.make();self.assertEqual(m._csv_rooms(' Linux,Books, linux , ,BOOKS'),['Linux','Books'])
 @unittest.skipIf(PHASE<2,'dependent feature not requested yet')
 def test_status_group_inspects_without_side_effect(self):
  m,p=self.make(True);before=(list(m._events.scheduled),dict(p._recent),dict(p._scheduled),dict(p.core.chatrooms.joined_rooms));self.assertTrue(p.commands['announcestatus']['callback'](' MuSiC '));text='\n'.join(p.out);self.assertIn('Jazz, Blues',text);self.assertIn('Missing, Room',text);self.assertIn('Rock',text);self.assertRegex(text.lower(),'join');self.assertRegex(text.lower(),'skip|not.join|unjoin');self.assertFalse(p.sent);self.assertEqual(before,(list(m._events.scheduled),dict(p._recent),dict(p._scheduled),dict(p.core.chatrooms.joined_rooms)))
 @unittest.skipIf(PHASE<2,'dependent feature not requested yet')
 def test_status_unknown_and_noargument_preserved(self):
  m,p=self.make();self.assertFalse(p.commands['announcestatus']['callback']('unknown'));self.assertRegex(p.out[-1].lower(),'unknown|not found|no.+group');self.assertTrue(p.commands['announcestatus']['callback'](''));self.assertIn('preview',p.out[-1].lower());self.assertFalse(p.sent);self.assertFalse(m._events.scheduled)
class Arr(unittest.TestCase):
 def setUp(self):
  self.m=load('arrrequests');self.seen=[];seen=self.seen;other=[None]
  class Handler(BaseHTTPRequestHandler):
   def do_GET(self):
    seen.append({'port':self.server.server_port,'path':self.path,'key':self.headers.get('X-Api-Key'),'method':self.command})
    if self.path.startswith('/cross'):
     self.send_response(302);self.send_header('Location',f'http://127.0.0.1:{other[0]}/ok');self.end_headers();return
    if self.path.startswith('/chain'):
     self.send_response(302);self.send_header('Location','/cross');self.end_headers();return
    if self.path.startswith('/same'):
     self.send_response(302);self.send_header('Location','/ok');self.end_headers();return
    payload=[{'title':'Example','year':2020,'tvdbId':7}] if '/lookup' in self.path else {'appName':'Sonarr','version':'test'}
    self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(payload).encode())
   def log_message(self,*a):pass
  self.servers=[ThreadingHTTPServer(('127.0.0.1',0),Handler) for _ in range(2)];other[0]=self.servers[1].server_port;self.threads=[threading.Thread(target=s.serve_forever,kwargs={'poll_interval':.01},daemon=True) for s in self.servers]
  for t in self.threads:t.start()
  self.base=f'http://127.0.0.1:{self.servers[0].server_port}';self.foreign=self.servers[1].server_port
 def tearDown(self):
  for s in self.servers:s.shutdown();s.server_close()
 def client(self,base=None):return self.m.ArrClient('tv',base or self.base,'FAKE-pilot-secret')
 def test_cross_origin_does_not_receive_key(self):
  try:self.client()._get_json('/cross',{},2)
  except self.m.ArrError as e:self.assertNotIn('FAKE-pilot-secret',str(e))
  self.assertFalse(any(x['port']==self.foreign and x['key'] for x in self.seen));self.assertTrue(self.seen)
 def test_redirect_chain_keeps_origin_boundary(self):
  try:self.client()._get_json('/chain',{},2)
  except self.m.ArrError:pass
  self.assertFalse(any(x['port']==self.foreign and x['key'] for x in self.seen));self.assertGreaterEqual(len(self.seen),2)
 def test_same_origin_redirect_keeps_authentication(self):
  self.assertEqual(self.client()._get_json('/same',{},2)['appName'],'Sonarr');self.assertEqual(len(self.seen),2);self.assertTrue(all(x['key']=='FAKE-pilot-secret' for x in self.seen))
 def test_direct_status_lookup_unchanged_and_get_only(self):
  c=self.client();self.assertEqual(c.status(2),'Sonarr test');self.assertEqual(c.lookup('query',3,2)[0].title,'Example');self.assertTrue(all(x['method']=='GET' and x['key']=='FAKE-pilot-secret' and 'FAKE-pilot-secret' not in x['path'] for x in self.seen))
 @unittest.skipIf(PHASE<2,'dependent feature not requested yet')
 def test_allow_redirects_false_propagates_to_status_and_lookup(self):
  p=self.m.Plugin();self.assertIs(self.m.Plugin.settings.get('allow_redirects'),True);self.assertIn('allow_redirects',p.metasettings);p.settings=dict(p.settings,allow_redirects=False,sonarr_url=self.base+'/same',sonarr_api_key='FAKE-pilot-secret')
  for call in (lambda:p._client('tv').status(2),lambda:p._client('tv').lookup('query',3,2)):
   self.seen.clear()
   with self.assertRaises(self.m.ArrError) as error:call()
   self.assertEqual(len(self.seen),1);self.assertNotIn('FAKE-pilot-secret',str(error.exception));self.assertRegex(str(error.exception).lower(),'redirect|30[12378]')
  p.settings['sonarr_url']=self.base;self.assertEqual(p._client('tv').status(2),'Sonarr test')
if __name__=='__main__':unittest.main(verbosity=2)
