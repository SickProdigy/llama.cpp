"""Audit recorded request parameters without exporting prompts or tool payloads."""
from pathlib import Path
import json,collections,hashlib,sys,time
D=Path(__file__).resolve().parent
FIELDS=['temperature','top_p','top_k','min_p','repeat_penalty','presence_penalty','max_tokens','chat_template_kwargs']
def main():
 progress='--progress' in sys.argv;a=json.loads((D/'progress-audit.json').read_text());assert progress or a['completed_turns']==18,'Full18 completed windows required';groups=collections.Counter();mismatches=[];records=[]
 expected={'temperature':0.8,'top_p':1.0,'top_k':0,'min_p':0.0,'repeat_penalty':1.0,'presence_penalty':0.0,'chat_template_kwargs':{'enable_thinking':False}}
 for r in a['requests']:
  phases=[p for p in a['phases'] if p['measurement_start_epoch'] is not None and p['measurement_start_epoch']<=r['received_epoch']<=p['measurement_end_epoch']]
  if not phases:continue
  assert len(phases)==1;phase=phases[0];path=D/r['record_namespace']/(str(r['id']).zfill(5)+'.request.json');body=json.loads(path.read_text());settings={k:body.get(k) for k in FIELDS};critic=r['purpose'].startswith('prepublication-review');want=dict(expected,max_tokens=4096 if critic else 8192);same=settings==want and body.get('model')=='qwen3.8-27b-hermes-adapted-iq3xxs';key=(r['purpose'],json.dumps(settings,sort_keys=True));groups[key]+=1
  item={'namespace':r['record_namespace'],'id':r['id'],'workflow':phase['run'],'phase':phase['phase'],'purpose':r['purpose'],'received_epoch':r['received_epoch'],'model_alias_matches':body.get('model')=='qwen3.8-27b-hermes-adapted-iq3xxs','request_settings_match':same,'request_body_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'final_metrics_present':r.get('final_metrics_present'),'seed_present':body.get('seed') is not None};records.append(item)
  if not same:mismatches.append(item)
 result={'epoch':time.time(),'progress_only':progress,'completed_turns':a['completed_turns'],'requests_in_completed_turn_windows':len(records),'all_observed_requests_match_configured_settings':not mismatches,'mismatches':mismatches,'settings_groups':[{'purpose':purpose,'count':count,'settings':json.loads(settings)} for (purpose,settings),count in groups.items()],'records':records,'scope':'Actual recorded request bodies, attributed by arrival to completed native turn windows. Unknown final usage/execution remains unknown; this does not fill missing usage, establish equal compute, control generation seeds or certify all server internals. CLI defaults are not substituted for recorded request overrides.','not_fed_to_models':True};(D/('request-settings-validation'+('-progress' if progress else '')+'.json')).write_text(json.dumps(result,indent=2));print(json.dumps({'requests':len(records),'completed_turns':a['completed_turns'],'all_match':not mismatches,'progress_only':progress}));assert not mismatches,'Request settings drift requires inspection, not automatic repair'
if __name__=='__main__':main()
