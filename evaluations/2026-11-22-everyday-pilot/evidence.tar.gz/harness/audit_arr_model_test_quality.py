"""Posthoc model-regression discrimination; never edits actor/published code."""
from pathlib import Path
import ast,json,subprocess,shutil,time,hashlib
import controller as c
D=c.D

def check(root,test,log):
 args=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m',*c.mount(str(root.relative_to(D)),'/workspace',True),'-w','/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',c.IMAGE,'-s','KILL','45','python','-m','pytest','-q','-p','no:cacheprovider',test]
 with log.open('w') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
 return {'exit_code':r.returncode,'log':str(log.relative_to(D)),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
def main():
 out=D/'provisional-review-audits/plain-arrrequests-turn0-regression';out.mkdir(exist_ok=True);work=D/'worktrees/audit/plain-arrrequests-turn0';stage=out/'mutant';assert not stage.exists();shutil.copytree(work,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'));target='tests/test_arrrequests.py::RedirectCredentialTests::';records={}
 try:
  records['actual_cross_origin']=check(stage,target+'test_key_not_sent_on_cross_origin_redirect',out/'actual-cross-origin.log')
  p=stage/'arrrequests/__init__.py';s=p.read_text();tree=ast.parse(s);node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_same_origin');lines=s.splitlines(keepends=True);lines[node.lineno:node.end_lineno]=['        return True\n'];s=''.join(lines);old='raise ArrError(f"{self.application} returned HTTP {error.code}.")';assert old in s;s=s.replace(old,'raise ArrError(f"{self.application} returned redirect HTTP {error.code}.")');compile(s,str(p),'exec');p.write_text(s)
  records['boundary_disabled_message_preserved_cross_origin']=check(stage,target+'test_key_not_sent_on_cross_origin_redirect',out/'mutant-cross-origin.log')
  records['boundary_disabled_scheme_test']=check(stage,target+'test_redirect_to_https_same_host_is_refused',out/'mutant-scheme.log')
  result={'epoch':time.time(),'posthoc_not_primary_score':True,'not_fed_to_actor_or_critic':True,'mutant_changes':'Disable only _same_origin boundary predicate; retain module/test APIs. Preserve redirect keyword in generic HTTP error so test reaches foreign-header assertions instead of failing earlier on incidental error wording. No actual/published code edited.','results':records,'interpretation':'Manually inspect failure locations. Original-module paired result had two missing _open_request patch seam errors plus cross-origin message failure before header checks; those are not three demonstrated API-key regressions. Mutation reaching leaked-key assertion supports meaningful cross-origin regression. Scheme test passing with boundary disabled shows its generic ArrError assertion cannot distinguish security refusal from failed HTTPS connection.'};(out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));assert records['actual_cross_origin']['exit_code']==0 and records['boundary_disabled_message_preserved_cross_origin']['exit_code']!=0 and records['boundary_disabled_scheme_test']['exit_code']==0
 finally:shutil.rmtree(stage)
if __name__=='__main__':main()
