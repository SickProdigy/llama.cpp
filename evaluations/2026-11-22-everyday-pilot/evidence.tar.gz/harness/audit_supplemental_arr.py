"""Supplemental operator audit. Read-only source, private logs; never model feedback."""
from pathlib import Path
import json,subprocess,hashlib
import controller as c
D=c.D

def check(source,out):
 grader=D/'supplemental-private-grader';grader.mkdir(exist_ok=True)
 for name in ['hidden_checks.py','supplemental_arr_redirects.py']:
  original=D/name;target=grader/name
  if target.exists():assert target.read_bytes()==original.read_bytes()
  else:target.write_bytes(original.read_bytes())
 command=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g','--cpus','1','--pids-limit','128','--tmpfs','/tmp:rw,size=128m',*c.mount(str(source.relative_to(D)),'/workspace',True),*c.mount('supplemental-private-grader','/grader',True),'-e','CHECKOUT=/workspace','-e','PYTHONDONTWRITEBYTECODE=1','-w','/workspace','--entrypoint','timeout',c.IMAGE,'-s','KILL','45','python','/grader/supplemental_arr_redirects.py']
 with out.open('w') as stream:p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
 return {'exit_code':p.returncode,'log':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'isolation':'Read-only checkout and two private grader modules; no profile, Docker socket or outside network in child process. Loopback HTTP only.'}
def main():
 control=json.loads((D/'supplemental-arr-controls.json').read_text());assert control['supplemental_grader_sha256']==hashlib.sha256((D/'supplemental_arr_redirects.py').read_bytes()).hexdigest()
 for turn in sorted((D/'runs').glob('*-arrrequests/turn*')):
  if not (turn/'forge-snapshot.json').exists() or not (turn/'run.json').exists():continue
  target=turn/'supplemental-arr-audit.json'
  if target.exists():continue
  params=json.loads((turn/'run.json').read_text());snapshot=json.loads((turn/'forge-snapshot.json').read_text());result={'case':'arrrequests','phase':params['phase'],'supplemental_not_primary16':True,'local_unpublished_or_published':check(turn/'workspace',turn/'supplemental-arr-local.log'),'actual_published':None,'not_fed_to_actor_or_critic':True,'grader_sha256':control['supplemental_grader_sha256']}
  if snapshot.get('remote_clone'):
   source=D/'worktrees'/snapshot['remote_clone']['name'];result['actual_published']=check(source,turn/'supplemental-arr-published.log');result['published_head']=snapshot['remote_clone']['head']
  else:result['publication_note']='No successful commit; passing local code is not delivered work.'
  target.write_text(json.dumps(result,indent=2));print(turn.parent.name,turn.name,'supplemental',result['local_unpublished_or_published']['exit_code'],flush=True)
if __name__=='__main__':main()
