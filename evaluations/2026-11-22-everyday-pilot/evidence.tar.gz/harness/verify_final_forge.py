"""Final authenticated forge readback and cleanup of disposable arena issues only."""
from pathlib import Path
import json,time,urllib.parse,hashlib,subprocess
import controller as c
D=c.D

def main():
 assert (D/'all-model-workflows-finished.json').exists()
 epoch=time.time();arenas={};runs=[];closed=[]
 for arm in ['plain','review']:
  repo='hermes-pilot-'+arm+'-20261122';prefix='repos/chatgpt-codex/'+repo
  upstream=c.api('GET',prefix+'/branches/main')['body']
  # Paginate so absence of open test issues is not inferred from a single page.
  issues=[];page=1
  while True:
   batch=c.api('GET',prefix+'/issues?state=open&type=issues&limit=50&page='+str(page))['body']
   issues.extend(x for x in batch if not x.get('pull_request'))
   if len(batch)<50:break
   page+=1
  for issue in issues:
   assert issue['user']['login']=='hermes-agent','Unexpected owner issue in disposable arena; preserve and inspect'
   r=c.api('PATCH',prefix+'/issues/'+str(issue['number']),{'state':'closed'})['body'];assert r['state']=='closed'
   closed.append({'arm':arm,'number':issue['number']})
  remaining=[x for x in c.api('GET',prefix+'/issues?state=open&type=issues&limit=50')['body'] if not x.get('pull_request')]
  arenas[arm]={'upstream_main':upstream['commit']['id'],'expected_main':c.BASE[arm],'upstream_main_unchanged':upstream['commit']['id']==c.BASE[arm],'remaining_open_issues':[x['number'] for x in remaining]}
 for run in sorted((D/'runs').iterdir()):
  if not run.is_dir():continue
  assert (run/'case-finished.json').exists(),str(run)
  arm,case=run.name.split('-',1);repo='hermes-pilot-'+arm+'-20261122';snapshot=json.loads((run/'turn2/forge-snapshot.json').read_text());state=snapshot['proxy_state'];record={'run':run.name,'expected_publication':state,'issue':None,'pr':None,'head_matches_capture':None,'all_tracked_blobs_match_capture':None}
  if state.get('issue'):
   issue=c.api('GET','repos/chatgpt-codex/'+repo+'/issues/'+str(state['issue']))['body']
   record['issue']={'number':issue['number'],'state':issue['state'],'author':issue['user']['login']};assert issue['state']=='closed'
  if state.get('branch'):
   env=dict(x.split('=',1) for x in c.inspect('mcp-gitea-required-eval')['Config']['Env']);name='audit-final/'+run.name+'-'+str(int(epoch))
   live=json.loads(c.operator('clone_operator.py',{'name':name,'branch':state['branch'],'user':'hermes-agent','url':env['GITEA_HOST'].rstrip('/')+'/hermes-agent/'+repo+'.git','public_url':'https://gitea.rcs1.top/hermes-agent/'+repo+'.git','token':env['GITEA_ACCESS_TOKEN']}))
   expected=snapshot['remote_clone'] if state.get('commits') else {'head':c.BASE[arm],'tree':'60e59671ae0973188ae90ac46f7cfec1c06bfd8f'};record['negative_publication_readback']=not bool(state.get('commits')); record['authenticated_clone']=live;record['head_matches_capture']=live['head']==expected['head'];record['all_tracked_blobs_match_capture']=live['tree']==expected['tree']
   assert record['head_matches_capture'] and record['all_tracked_blobs_match_capture']
  if state.get('pr'):
   pr=c.api('GET','repos/chatgpt-codex/'+repo+'/pulls/'+str(state['pr']))['body']
   record['pr']={'number':pr['number'],'state':pr['state'],'merged':pr['merged'],'head_owner':pr['head']['repo']['owner']['login'],'head_sha':pr['head']['sha'],'base_owner':pr['base']['repo']['owner']['login'],'base_ref':pr['base']['ref'],'url':pr['html_url']}
   assert pr['state']=='open' and not pr['merged'] and pr['head']['repo']['owner']['login']=='hermes-agent' and pr['base']['repo']['owner']['login']=='chatgpt-codex' and pr['base']['ref']=='main'
   assert pr['head']['sha']==snapshot['remote_clone']['head']
  runs.append(record)
 discoveries={}
 for arm in ['plain','review']:
  prefix='repos/chatgpt-codex/hermes-pilot-'+arm+'-20261122';items=[];page=1
  while True:
   batch=c.api('GET',prefix+'/issues?state=all&limit=50&page='+str(page))['body'];items.extend(batch)
   if len(batch)<50:break
   page+=1
  actual_issues={x['number'] for x in items if not x.get('pull_request') and x['user']['login']=='hermes-agent'}
  actual_prs={x['number'] for x in items if x.get('pull_request') and x['user']['login']=='hermes-agent'}
  expected_issues={x['expected_publication']['issue'] for x in runs if x['run'].startswith(arm+'-') and x['expected_publication'].get('issue')}
  expected_prs={x['expected_publication']['pr'] for x in runs if x['run'].startswith(arm+'-') and x['expected_publication'].get('pr')}
  discoveries[arm]={'all_actor_issue_numbers':sorted(actual_issues),'all_actor_PR_numbers':sorted(actual_prs),'expected_issues':sorted(expected_issues),'expected_PRs':sorted(expected_prs),'exactly_matches_captures':actual_issues==expected_issues and actual_prs==expected_prs}
  assert discoveries[arm]['exactly_matches_captures'],'Forge discovery differs from scoped captures; independently inspect before scoring'
 result={'epoch':epoch,'authoritative_discovery':discoveries,'arenas':arenas,'runs':runs,'additional_test_issues_closed':closed,'passed':len(runs)==6 and all(x['upstream_main_unchanged'] and not x['remaining_open_issues'] for x in arenas.values()),'scope':'Audit consistency and cleanup, not a claim every workflow published successfully; no PR merges.'}
 c.write(D/'final-forge-audit.json',result);print(json.dumps({'passed':result['passed'],'runs':len(runs),'additional_issues_closed':closed}));assert result['passed']
if __name__=='__main__':main()
