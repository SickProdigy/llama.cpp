"""Operator-only infrastructure recovery; no tasks, findings or hints are supplied."""
from pathlib import Path
import json,hashlib,time,subprocess
D=Path(__file__).resolve().parent
p=D/'public-harness/scope_proxy.py';before=p.read_text();original=(D/'scope_proxy.py').read_text();assert before==original
subprocess.run(['docker','stop','-t','2','hermes-pilot-proxy'],check=True)
records=D/'runs/review-beetsbridge/proxy-records';calls=json.loads((records/'calls.json').read_text());state=json.loads((records/'state.json').read_text())
assert state['commits']==0 and state['issue'] is None and state['pr'] is None
assert state['branch'] in (None,'pilot-64b78f35-beets-disable-race')
# No new-phase forge call has occurred: all records still belong to the captured first turn.
prior=json.loads((D/'runs/review-beetsbridge/turn0/forge-and-review-records/calls.json').read_text());current_calls=calls;calls=prior+calls if calls!=prior else calls
state=json.loads((D/'runs/review-beetsbridge/turn0/forge-snapshot.json').read_text())['proxy_state']
(records/'calls.json').write_text(json.dumps(calls,indent=2));(records/'state.json').write_text(json.dumps(state,indent=2))
(D/'proxy-records-before-restart.json').write_text(json.dumps({'calls':calls,'state':state},indent=2))
old=" lock=threading.RLock();calls=[];dest=os.environ.get('UPSTREAM_MCP','http://mcp-gitea-required-eval:8080/mcp')"
new=""" lock=threading.RLock();record_root=pathlib.Path(os.environ.get('PILOT_RECORDS','/proxy-records'));calls=[]
 # Recover a transport lease after an operator restart, without changing model prompts or review policy.
 if (record_root/'calls.json').exists():
  calls=json.loads((record_root/'calls.json').read_text())
 if (record_root/'state.json').exists():
  prior=json.loads((record_root/'state.json').read_text())
  if prior.get('commits'):raise RuntimeError('Published-state recovery requires full gate reconstruction; refusing unsafe restart')
  if prior.get('branch') and not scope.branch_ok(prior['branch']):raise RuntimeError('Invalid persisted branch lease')
  scope.issue=prior.get('issue');scope.pr=prior.get('pr');scope.branch=prior.get('branch');scope.commits=prior.get('commits',0)
 if gate:
  for review_path in sorted((record_root/'reviews').glob('*-review.json')):
   previous=json.loads(review_path.read_text());phase_id=previous['phase'];gate.attempts[phase_id]=gate.attempts.get(phase_id,0)+1
   if previous.get('approved') is True:gate.cache.add(previous['key'])
 dest=os.environ.get('UPSTREAM_MCP','http://mcp-gitea-required-eval:8080/mcp')"""
assert before.count(old)==1;after=before.replace(old,new);compile(after,str(p),'exec')
variant=D/'scope_proxy_recovered.py';variant.write_text(after);p.write_text(after)
record={'epoch':time.time(),'frozen_original_sha256':hashlib.sha256(original.encode()).hexdigest(),'runtime_variant_sha256':hashlib.sha256(after.encode()).hexdigest(),'trigger':'Recreated proxy would otherwise lose its existing branch lease after review turn0 external timeout','state_recovered':state,'previous_call_count':len(calls),'first_turn_and_current_followup_calls_merged':True,'infrastructure_denials_before_repair':[x.get('denied_or_error') for x in current_calls if x.get('denied_or_error')],'old_phase_review_attempts_preserved':True,'published_commits_before_restart':0,'no_task_or_grading_feedback':True,'future_fresh_cases_have_no_state_to_restore':True,'scope':'Restart recovery only; fails closed if committed published state requires reconstruction'}
(D/'proxy-restart-recovery.json').write_text(json.dumps(record,indent=2))
subprocess.run(['docker','start','hermes-pilot-proxy'],check=True)
print(json.dumps(record))
