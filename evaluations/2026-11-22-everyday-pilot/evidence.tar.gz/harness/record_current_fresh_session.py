"""Read-only live initial-turn isolation proof. Never sends task feedback."""
from pathlib import Path
import sqlite3,json,time,hashlib,sys
import controller as c
D=c.D
arm,case=sys.argv[1:];name=arm+'-'+case;q=json.loads((D/'task-prompts.json').read_text())[case][0];p=D/'arms'/arm/'profile/state.db';db=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True)
try:
 matches=db.execute("select session_id,id from messages where role='user' and content=? order by id",(q,)).fetchall();assert len(matches)==1;sid,ident=matches[0];users=db.execute("select id,content from messages where session_id=? and role='user' order by id",(sid,)).fetchall();assert users==[(ident,q)];counts=db.execute('select role,count(*) from messages where session_id=? group by role',(sid,)).fetchall()
finally:db.close()
prior=[json.loads(f.read_text())['session_id'] for f in (D/'runs').glob('*/turn*/run.json')];assert sid not in prior
actor=c.inspect('hermes-pilot-agent');mounts=[{'target':m['Destination'],'source_relative_to_pilot':str(Path(m['Source']).relative_to(c.ENGINE)) if m['Type']=='bind' and (m['Source']==c.ENGINE or m['Source'].startswith(c.ENGINE+'/')) else None,'readonly':not m['RW'],'type':m['Type']} for m in actor['Mounts']]
assert all(m['target'] not in ['/var/run/docker.sock','/state'] for m in mounts)
for m in mounts:
 if m['type']=='bind':assert m['source_relative_to_pilot'] in ['arms/'+arm+'/profile','worktrees/'+name],m
cl=json.loads((D/'runs'/name/'clone.json').read_text());assert cl['head']==c.BASE[arm] and cl['tree']=='60e59671ae0973188ae90ac46f7cfec1c06bfd8f'
r={'epoch':time.time(),'case':name,'session_id':sid,'accepted_user_message_id':ident,'initial_query_sha256':hashlib.sha256(q.encode()).hexdigest(),'fresh_distinct_from_all_completed_workflows':True,'only_initial_user_query_in_session_so_far':True,'native_message_counts':dict(counts),'actor_mounts':mounts,'actor_has_no_private_grader_or_reference_bind':True,'native_user':actor['Config']['User'],'read_only_rootfs':actor['HostConfig']['ReadonlyRootfs'],'recorded_preinference_clone':cl,'same_arm_profile_persistence_intentional':True,'not_model_task_success':True,'not_fed_to_models':True};(D/(name+'-fresh-session-preflight.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
