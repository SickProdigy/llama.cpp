"""Posthoc no-argument default-status preservation, outside frozen primary checks."""
import json
import hidden_checks as h
m,p=h.Announcer().make();p.settings.update(default_rooms='',room_groups_json='{}');p.out.clear();r=p.announce_status_command('');print(json.dumps({'returned':r,'local_messages':p.out}))
