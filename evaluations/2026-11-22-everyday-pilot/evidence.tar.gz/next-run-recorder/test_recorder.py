"""Offline transport tests: no model, network, credentials, or actor state."""
import unittest,tempfile,runpy,json,io,os
from pathlib import Path
from unittest.mock import patch,Mock
class Upstream:
 status=200;headers={'Content-Type':'application/json'}
 def __init__(self,data):self.data=data;self.pos=0;self.read_calls=0;self.read1_calls=0
 def __enter__(self):return self
 def __exit__(self,*a):pass
 def read(self):self.read_calls+=1;return self.data
 def read1(self,n):
  self.read1_calls+=1;b=self.data[self.pos:self.pos+n];self.pos+=len(b);return b
class Sink(io.BytesIO):
 def __init__(self,broken):super().__init__();self.broken=broken
 def write(self,b):
  if self.broken:raise BrokenPipeError('test disconnected caller')
  return super().write(b)
class Recorder(unittest.TestCase):
 def run_case(self,stream=False,broken=None):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
  with patch.dict(os.environ,{'PILOT_LLM_RECORDS':temp.name}),patch('http.server.ThreadingHTTPServer'):
   ns=runpy.run_path(str(Path(__file__).with_name('llm_proxy.py')))
  body={'model':ns['ALIAS'],'stream':stream};data=json.dumps(body).encode();h=ns['H'].__new__(ns['H']);h.path='/v1/chat/completions';h.headers={'Content-Length':str(len(data))};h.rfile=io.BytesIO(data);h.wfile=Sink(broken=='body');h.send_response=Mock();h.send_header=Mock();h.send_error=Mock()
  h.end_headers=Mock(side_effect=BrokenPipeError('test header disconnect') if broken=='headers' else None)
  response=json.dumps({'choices':[{'message':{'content':'x'*24000},'finish_reason':'stop'}],'usage':{'prompt_tokens':11,'completion_tokens':12}}).encode() if not stream else b'data: '+json.dumps({'choices':[{'delta':{'content':'x'*9000}}]}).encode()+b'\n\n'
  up=Upstream(response)
  with patch('urllib.request.urlopen',return_value=up):h.do_POST()
  root=Path(temp.name);m=json.loads((root/'00001.metrics.json').read_text());raw=(root/'00001.response.txt').read_bytes()
  return m,raw,response,up,h
 def test_connected_complete(self):
  m,raw,response,up,h=self.run_case();self.assertEqual(raw,response);self.assertEqual(h.wfile.getvalue(),response);self.assertEqual(m['usage']['completion_tokens'],12);self.assertEqual(up.read_calls,1)
 def test_disconnected_body_complete(self):
  m,raw,response,up,h=self.run_case(broken='body');self.assertEqual(raw,response);self.assertGreater(len(raw),8192);self.assertEqual(m['usage']['completion_tokens'],12);self.assertIn('BrokenPipeError',m['transport_error']);self.assertNotIn('response_parse_failed',m)
 def test_disconnected_headers_complete(self):
  m,raw,response,up,h=self.run_case(broken='headers');self.assertEqual(raw,response);self.assertEqual(m['usage']['prompt_tokens'],11);self.assertNotIn('response_parse_failed',m)
 def test_stream_cancel_not_drained(self):
  m,raw,response,up,h=self.run_case(stream=True,broken='body');self.assertEqual(up.read_calls,0);self.assertEqual(up.read1_calls,1);self.assertEqual(len(raw),8192);self.assertLess(len(raw),len(response));self.assertTrue(m['response_parse_failed'])
if __name__=='__main__':unittest.main()
