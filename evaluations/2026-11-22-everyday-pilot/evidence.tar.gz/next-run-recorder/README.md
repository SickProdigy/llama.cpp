# Recorder proposal for a later run

Offline only; not deployed during this pilot. Complete nonstream response buffering preserves late review usage after a caller disconnect. This does not make the review arrive before its deadline. Streaming cancellation remains unchanged. Four mocked transport tests cover connected delivery, body and header disconnects with >8 KiB replies, and streaming cancellation. Frozen original fails the disconnect regressions; proposed variant passes all four. No model calls.
