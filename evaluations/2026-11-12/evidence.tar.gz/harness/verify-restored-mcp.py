import sys,json,pathlib,datetime
sys.path.insert(0,'/opt/hermes')
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
discover_mcp_tools()
from tools.registry import registry
def call(suffix,args):
 names=[e.name for e in registry.get_all_entries() if e.name.endswith('__'+suffix)]
 assert len(names)==1,(suffix,names)
 raw=json.loads(model_tools.handle_function_call(names[0],args));assert 'error' not in raw,(suffix,raw)
 value=raw.get('result',raw)
 if isinstance(value,str): value=json.loads(value)
 return value
me=call('get_me',{});assert me['login']=='hermes-agent', 'Wrong Gitea principal'
refs={}
for branch,expected in [('main','762f67b86b137a77a1965bba6f3688665ed92537'),('develop','4c63518a09f2610db201fcb8a16ed72a65d50c9d')]:
 tree=call('get_repository_tree',{'owner':'sickprodigy','repo':'sick-cogs','tree_sha':branch,'per_page':100});refs[branch]={'sha':tree['sha'],'unchanged':tree['sha']==expected,'entries':tree['total_count']}
f=call('get_file_contents',{'owner':'sickprodigy','repo':'SonicRatings','path':'README.md','with_lines':True,'end_line':1});refs['SonicRatings README']={'sha':f['sha'],'unchanged':f['sha']=='e25e51f9d2ac93ffe2638abbb23ba052bc0633c1'}
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authenticated_gitea_read':True,'login':me['login'],'fixtures':refs}))
assert all(x['unchanged'] for x in refs.values()),'Fixture drift; inspect before claiming parity'
