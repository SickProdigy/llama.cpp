import pathlib,json,csv
r=pathlib.Path('/tmp/hermes-routing-eval');dest=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-12');rows=list(csv.DictReader((dest/'runs.csv').open()));history=list(csv.DictReader((dest/'history-turns.csv').open()));agg=json.loads((dest/'aggregate.json').read_text())
readable=[x for x in rows if x['run'].startswith('qwen9-readable-L')];assert len(readable)==9
reads=sum(int(x['file_reads']) for x in readable);plain=sum(int(x['readable_file_reads']) for x in readable);bounded=sum(int(x['bounded_file_reads']) for x in readable)
s='''## Configuration experiments and recommendation

Across all scored runs, the eight observed `manage_connections` calls are
status reads: no connection mutation or remote repository-write attempt was
dispatched. Historical connect/install/authorize activity is separate evidence.
Fresh GitHub attempts use web, browser, terminal or code routes instead.

The configuration chain uses Qwen3.5-9B Q8 at 65,536 with the same native
sampler and output caps. Each step changes one factor relative to the preceding
step and repeats all nine fresh cases plus a separate three-turn sequence:

1. Remove `connections` from `platform_toolsets.cli`. The captured request has
   16 schemas instead of 17; Gitea remains deferred, and web search remains.
   This prevents advertised connection administration, but four of nine fresh
   runs still attempt GitHub through other tools. It is containment, not a
   sufficient default-forge policy.
2. Set `tools.tool_search.enabled: 'off'` while retaining step 1. The request
   has 40 direct schemas, including all 25 Gitea tools, no bridge and no
   connection administration. All nine use Gitea, eight avoid GitHub, but
   none is a complete content pass. Successful discovery/dispatch is distinct
   from understanding the returned repository content.
3. Retain steps 1–2 and append one specific environment-hint sentence asking
   for `with_lines: true` and bounded `start_line`/`end_line` excerpts. This
   fills the demonstrated representation gap; it does not repeat the existing
   branch/count/no-write rules. Its presence is verified in the actual system
   prompt. It is an instruction-adherence experiment, not forced UTF-8 output.

'''+f'In step 3, {plain} of {reads} file-read attempts use `with_lines: true`,\nand {bounded} specify a positive finite end-line bound. '+'''The actual arguments
matter: ignored guidance leaves base64 decoding in place, and readable mode
without bounds can still produce large spilled results. In particular, the
second five-idea run again emits unrepairable copied-base64 code arguments.
The tested hint does not establish a deterministic readable-output default.
A server/client adapter that changes defaults would be new code, not a
supported YAML setting verified by this investigation.

No candidate qualifies as a reliable ordinary-repository agent on this ladder.
Do not switch to Q6 as a routing repair. Qwen 65k is the strongest baseline
candidate for further validation, but its three combined passes in nine are
insufficient for automatic adoption. Direct Gitea schemas are the clearest
observed routing improvement; they do not establish factual or novelty quality.
These small, sequential, stochastic samples are not a full factorial experiment
or proof that either configuration change causes a population-level rate change.

Before further model tuning, correct the obsolete tool examples, replace the
private-only/explicit-Gitea scope ambiguity with a concise default for the
owner's repositories (public and private), align advertised MCP methods with
the server allowlist, and give auxiliary compression requests an explicit
adequate output budget. These are identified repairs, **not isolated successful
fixes measured here**. A larger backend default budget is a possible summary
workaround; it was deliberately not changed in this matrix. Preserve web search
for unrelated research and configure a real extraction backend only if needed.

Connection removal was tested for CLI selection. Discord/API use their own
platform tool selections; removing CLI administration alone does not configure
those surfaces. Validate the selected allowlists and schemas through the native
gateway before making a production reliability claim. No native gateway/API
conversation validation or new issue-write test was performed.

## Separate history sequences

One sequence per row uses the same three prompts in order without manual hints.
The GitHub columns show explicit tool attempts per turn, not links quoted in an
answer. Reusing prior authoritative Gitea content is not by itself routing drift.

| Sequence | Turn seconds | Completed flags | GitHub attempts per turn |
|---|---|---|---|
'''
for name in sorted({x['sequence'] for x in history}):
 group=[x for x in history if x['sequence']==name];s+='| '+name.removesuffix('-L1-R1')+' | '+' / '.join(x['seconds'] for x in group)+' | '+' / '.join(x['completed'] for x in group)+' | '+' / '.join(x['github_attempts'] for x in group)+' |\n'
s+='''
Q4 already uses GitHub in its first turn. Q6 stays on Gitea but later turns fail
context/compression. Both baseline Qwen sequences start on Gitea and use GitHub
later; fresh review prompts also use GitHub, so history alone is not established
as the cause. Qwen 98k reaches the 30-tool limit on turn 2 and later confuses
SonicRatings' rating-sync purpose with the Sick-Cogs Navidrome cog.

The no-connections and direct-schema sequences avoid GitHub throughout, while
content quality varies. The direct-schema sequence has useful later Search and
five-domain proposals; its first lookup still invents a playlist condition.
These positive history outcomes do not erase the failed fresh repetitions.
The readable-guidance sequence starts with an accurate lookup, then invents
TikTok/Clanker inventory and duplicates calendars while incorrectly applying a
Subsonic pattern to YouTube. Repeated decoding and malformed arguments persist.
See manual per-turn notes and full answers in the evidence. No successful summary compression occurred
in these scored baseline sequences; truncated attempts are retained separately.

Core-overlap checks use official [Audio](https://docs.discord.red/en/stable/cog_guides/audio.html),
[Trivia](https://docs.discord.red/en/stable/cog_guides/trivia.html),
[Filter](https://docs.discord.red/en/latest/cog_guides/filter.html), and
[ModLog/Core](https://docs.discord.red/en/stable/cog_guides/core.html) references.
A proposed Fortnite player-stat integration also lacked a validated provider
contract: Epic's [public Data API](https://dev.epicgames.com/documentation/fortnite/using-fortnite-data-api-in-fortnite?lang=en-US)
documents aggregate island metrics, not personal player information. A concept
can be novel while its asserted API mechanism still needs correction.

## Restoration and retained evidence

The original Q4 container/configuration is restored, including 98,304 context,
q4 K/V, one slot, 4,096 main output cap and the original backend default of 512.
`restoration.json` records unchanged container IDs/images, commands, environment,
mounts, published ports, and hash comparisons for original configuration/credential/skill
files, plus backend properties and health. `restored-mcp.json` records an
authenticated read as the expected Gitea principal and unchanged fixture refs.
The native gateway process is checked separately from the core evaluator.

Only README/evaluation documentation and sanitized evidence are retained.
Private snapshots and temporary evaluation resources are removed after export
verification. Original credentials/endpoints are preserved. No remote issue
writes, training, commits or pushes were performed; hermes-codex is untouched.
'''
p=dest/'investigation.md';text=p.read_text();marker='## Configuration experiments and recommendation';text=text.split(marker)[0].rstrip()+'\n\n'+s;p.write_text(text)
readme=dest.parent.parent/'README.md';text=readme.read_text();anchor='See the [full investigation]';note='''No configuration tested here qualifies for reliable ordinary repository work.
The original Q4 configuration was restored. Prefer Qwen 65k for further
validation; direct schemas improve observed forge routing, while content and
novelty failures remain. Compression-budget, namespace and method-surface
repairs need separate validation before training. Credentials and endpoints
were preserved; no commits, pushes or new issue writes were made.

''';text=text.replace(note,'');text=text.replace(anchor,note+anchor,1);readme.write_text(text)
print('Appended final configuration, history, recommendation and restoration sections')
