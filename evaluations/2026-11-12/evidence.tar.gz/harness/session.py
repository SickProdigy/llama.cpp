import sys,pathlib,tarfile,runpy
sys.path.insert(0,'/opt/hermes')
import hermes_yaml as yaml
label,level,rep,model,ctx,variant=sys.argv[1:7]
p=pathlib.Path('/opt/data');p.mkdir(exist_ok=True)
tarfile.open('/eval/profile.tgz').extractall(p,filter='data');(p/'workspace').mkdir(exist_ok=True)
c=yaml.safe_load((p/'config.yaml').read_text());c['model']['default']=model;c['model']['context_length']=int(ctx)
if 'no-connections' in variant:
 c['platform_toolsets']['cli']=[x for x in c['platform_toolsets']['cli'] if x!='connections']
if 'eager' in variant: c['tools']['tool_search']['enabled']='off'
if 'readable' in variant:
 c['agent']['environment_hint'] += ' For Gitea repository file reads, set with_lines: true and bound start_line/end_line to the needed excerpt to receive readable text.'
if 'names' in variant:
 c['agent']['environment_hint']=c['agent']['environment_hint'].replace('mcp_gitea_','mcp__mcp_gitea_hermes__')
 for f in (p/'skills'/'gitea').rglob('SKILL.md'): f.write_text(f.read_text().replace('mcp_gitea_','mcp__mcp_gitea_hermes__'))
(p/'config.yaml').write_text(yaml.safe_dump(c,sort_keys=False))
import urllib.request,json
with urllib.request.urlopen('http://llama:11430/props',timeout=10) as response: props=json.load(response)
assert props['model_alias']==model,(props['model_alias'],model)
assert props['default_generation_settings']['n_ctx']==int(ctx)
reference_path='/eval/qwen-reference-props.json' if model.startswith('qwen3.5-9b') else '/eval/reference-props.json'
reference_props=json.loads(pathlib.Path(reference_path).read_text())
if 'vibeforged' in model: assert props['chat_template']==reference_props['chat_template'], 'VibeForged chat template mismatch'
reference=reference_props['default_generation_settings']['params']
actual=props['default_generation_settings']['params']
for field in ('temperature','dynatemp_range','top_k','top_p','min_p','repeat_penalty','presence_penalty','frequency_penalty','seed','samplers'):
 assert actual.get(field)==reference.get(field),(field,actual.get(field),reference.get(field))
out=pathlib.Path('/eval/results')/f'{label}-L{level}-R{rep}';out.mkdir(parents=True,exist_ok=True)
(out/'props.json').write_text(json.dumps(props,indent=2))
sys.argv=['/eval/run.py',label,level,rep]+(['sequence'] if variant.endswith('sequence') else [])
runpy.run_path('/eval/run.py',run_name='__main__')
