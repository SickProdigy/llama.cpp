import sys,os,json,time,traceback,pathlib,threading
sys.path.insert(0,'/opt/hermes')
# Each scored process starts without checkouts left by earlier runs.
import shutil
for _p in pathlib.Path('/tmp').iterdir():
 if _p.name not in ('.X11-unix','hermes-runtime','node-compile-cache') and not _p.name.startswith('uv-'):
  if _p.is_dir() and not _p.is_symlink(): shutil.rmtree(_p)
  else: _p.unlink(missing_ok=True)
label=sys.argv[1]; level=int(sys.argv[2]); repeat=int(sys.argv[3]); sequence='sequence' in sys.argv
out=pathlib.Path('/eval/results')/f'{label}-L{level}-R{repeat}'; out.mkdir(parents=True,exist_ok=True)
import httpx
send=httpx.Client.send
lock=threading.Lock(); requests=[]
def captured(self,request,*a,**kw):
 if '/chat/completions' in str(request.url):
  try:
   body=json.loads(request.content)
   with lock:
    requests.append(body); (out/f'request-{len(requests):03}.json').write_text(json.dumps(body,indent=2,default=str))
  except Exception: pass
 return send(self,request,*a,**kw)
httpx.Client.send=captured
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
from tools.registry import registry
from hermes_cli.config import load_config
cfg=load_config(); discovered=discover_mcp_tools()
(out/'discovery.json').write_text(json.dumps(discovered))
# Preserve the advertised baseline tool surface, but prevent external writes/admin changes.
orig=registry.dispatch; calls=[]
writes={'branch_write','create_or_update_file','delete_file','issue_write','label_write','pull_request_review_write','pull_request_write','repo_write','wiki_write'}
def dispatch(name,args,**kw):
 t=time.monotonic(); blocked=False
 if name=='manage_connections' and args.get('action','status') not in ('status','display'):
  blocked=True
 if name.startswith('mcp__') and name.split('__')[-1] in writes: blocked=True
 if blocked: result=json.dumps({'error':'Read-only evaluation: action recorded but external writes and administration are disabled.'})
 else: result=orig(name,args,**kw)
 with lock:
  calls.append({'name':name,'args':args,'blocked':blocked,'seconds':time.monotonic()-t,'result':result})
  (out/'calls.json').write_text(json.dumps(calls,indent=2,default=str))
 return result
registry.dispatch=dispatch
from hermes_cli.tools_config import _get_platform_tools
selected=sorted(_get_platform_tools(cfg,'cli'))
(out/'selection.json').write_text(json.dumps(selected))
from run_agent import AIAgent
prompts=['Find my SonicRatings repo and tell me what it does.','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.','Review sickprodigy/sick-cogs and suggest five useful new cogs that aren’t already there. Explain why each would fit.']
a=AIAgent(model=cfg['model']['default'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',max_iterations=30,max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='cli',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
(out/'surface.json').write_text(json.dumps(a.tools,indent=2))
t=time.monotonic(); (out/'started.json').write_text(json.dumps({'epoch':time.time(),'cap_seconds':600})); history=None; results=[]
try:
 for idx in ([0,1,2] if sequence else [level-1]):
  (out/'started.json').write_text(json.dumps({'epoch':time.time(),'cap_seconds':600,'turn':idx+1}))
  turn_start=time.monotonic()
  r=a.run_conversation(prompts[idx],conversation_history=history)
  r['eval_elapsed']=time.monotonic()-turn_start
  results.append(json.loads(json.dumps(r,default=str))); history=r.get('messages')
  (out/'result.json').write_text(json.dumps(results,indent=2,default=str))
except BaseException:
 (out/'exception.txt').write_text(traceback.format_exc())
finally:
 summary={'label':label,'level':level,'repeat':repeat,'sequence':sequence,'elapsed':time.monotonic()-t,'requests':len(requests),'tool_calls':len(calls),'first_tool':calls[0]['name'] if calls else None,'gitea':any('gitea' in c['name'] for c in calls),'usage':{k:v for k,v in vars(a).items() if ('token' in k or 'compression' in k or 'api_calls' in k) and isinstance(v,(int,float,str,bool,type(None)))}}
 (out/'summary.json').write_text(json.dumps(summary,indent=2,default=str)); print(json.dumps(summary),flush=True)
 
 try:
  import shutil
  shutil.copy('/opt/data/logs/agent.log',out/'agent.log')
 except Exception: pass
 a.close()
