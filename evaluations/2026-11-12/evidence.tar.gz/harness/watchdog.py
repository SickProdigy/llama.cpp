import subprocess,json,time,datetime
while True:
 p=subprocess.run(['docker','inspect','hermes-routing-session'],capture_output=True,text=True)
 if p.returncode:time.sleep(5);continue
 d=json.loads(p.stdout)[0]
 if not d['State']['Running']:time.sleep(5);continue
 container_started=datetime.datetime.fromisoformat(d['State']['StartedAt'].replace('Z','+00:00')).timestamp()
 ident=d['Id'];args=d['Config']['Cmd'];label,level,rep=args[1:4];path=f'/eval/results/{label}-L{level}-R{rep}'
 s=subprocess.run(['docker','exec','hermes-routing-store','cat',path+'/started.json'],capture_output=True,text=True)
 try: started=json.loads(s.stdout)['epoch']
 except Exception:time.sleep(5);continue
 if started < container_started-1:time.sleep(5);continue
 if time.time()-started>=600:
  record=json.dumps({'reason':'external wall-clock cap','cap_seconds':600,'observed_seconds':time.time()-started})
  subprocess.run(['docker','exec','hermes-routing-store','python','-c','import pathlib,sys;pathlib.Path(sys.argv[1]).write_text(sys.argv[2])',path+'/timeout.json',record])
  subprocess.run(['docker','kill','--signal=SIGINT',ident],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  time.sleep(5)
  subprocess.run(['docker','stop','-t','5',ident],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  print('TIMEOUT',label,level,rep,flush=True)
 time.sleep(5)
