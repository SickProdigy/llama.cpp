import json,pathlib,csv,statistics
r=pathlib.Path('/tmp/hermes-routing-eval');dest=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-12');data=json.loads((dest/'aggregate.json').read_text())
labels={'q4-baseline':'VibeForged v2 Q4_K_M · 98,304','q6-baseline':'VibeForged v2 Q6_K · 98,304','qwen9-baseline':'Qwen3.5-9B Q8 · 65,536','qwen9-common98':'Qwen3.5-9B Q8 · 98,304','qwen9-no-connections':'Qwen 9B · 65,536 · connections removed','qwen9-no-connections-eager':'Previous + direct tool schemas','qwen9-readable':'Previous + readable bounded file guidance'}
order=list(labels)
table='| Candidate | Gitea used | GitHub attempted | Routing pass | Content pass | Both pass | Median turn |\n|---|---:|---:|---:|---:|---:|---:|\n'
for tag in order:
 x=next((x for x in data if x['candidate']==tag),None)
 if not x:continue
 n=x['n'];table+='| '+labels[tag]+' | '+' | '.join(f'{x[k]}/{n}' for k in ('gitea','github','routing_pass','content_pass','combined_pass'))+f" | {x['median_seconds']}s |\n"
text='''## New scored results

These are new ordinary-language tests, distinct from the historical guided
issue-write probes in the README. Every row contains three fresh repetitions
of each of the three fixed prompts. A combined pass requires both correct
configured-forge routing and a materially correct answer.

'''+table+'''
Content partial/fail grades, timeouts, first tools, tool errors, exact idea
counts/grounding notes, token counters and GPU samples are in `runs.csv` and
the evidence archive. Q4 and Q6 each have one content pass, three partials and
five failures; Q6 additionally has two wall-clock timeouts. Qwen 65k has four
content passes, three partials and two failures; Qwen 98k has three passes,
four partials and two failures. None of the four baseline candidates passed
a five-idea review completely. Some correct answers used GitHub and therefore
fail routing. Conversely, successful Gitea reads frequently preceded inaccurate
or incomplete answers.

The small repeated sample supports the operational finding that Q6 did not
solve this workload; it does not establish a statistically significant
quantization effect. Qwen 65k is the strongest baseline here, but three combined
passes in nine is inadequate for a reliable default agent. Increasing its
context did not improve the combined pass count and increased median elapsed
time. Native Qwen sampling differs from VibeForged as documented above.

### Runtime and memory

All tested models loaded successfully on the P100, with nested
`chat_template_caps.supports_tools`, `supports_tool_calls` and
`supports_object_arguments` true. No CUDA OOM was observed. Sampled peak GPU
memory was 9,084 MiB (Q4), 11,684 MiB (Q6), 9,474 MiB (Qwen 65k), and
9,922 MiB (Qwen 98k). Idle observations were 9,028, 11,630, 9,350 and 9,798
MiB respectively. Five-second samples can miss transient peaks.

Median first API-call latencies were 3.8s (Q4), 5.5s (Q6), 3.3s
(Qwen 65k) and 3.7s (Qwen 98k), across nine fresh runs each.
The CSV records first API-call latency separately from full-turn elapsed time.
These first calls often reuse backend prompt cache; they are not cold model
load or time-to-first-token measurements. Server `--n-predict 512` remained
unchanged throughout this matrix; main requests explicitly used 4,096.

### Evidence pointers

See [evidence layout](EVIDENCE.md), [per-run metrics and grades](runs.csv),
[history turn metrics](history-turns.csv), [aggregate counts](aggregate.json),
and [sanitized requests, logs and harness](evidence.tar.gz). Archive paths
below are relative to its root:

- `runs/q4-baseline-L1-R3/request-001.json`: stale Gitea tool identifier.
- `runs/q6-baseline-L1-R1/request-001.json`: matched main request and tool
  exposure; compare Q4's first request to see model identity as the only
  system-prompt difference.
- `runs/q6-baseline-L1-R1/request-009.json`: auxiliary summary request without
  `max_tokens`; `agent.log` records aborted truncated summaries and
  `harness/q6-backend.log` records 512-token generations.
- `runs/q6-baseline-L1-R2/`: repeated base64 decode failures and timeout.
- `runs/qwen9-common98-L3-R3/`: completed-looking answer that duplicates
  gitforge, tickets and calendarevents.
- `harness/historical-log-excerpt.txt`: original log lines around 28,403,
  including the administration/authentication sequence; this is historical,
  not part of the new score matrix.

The novelty catalog comes from local Git objects at the exact Gitea-verified
`develop` SHA, not a stale local main ref. Red core overlap is checked against
its [official Audio guide](https://docs.discord.red/en/stable/cog_guides/audio.html).
Its [official Trivia guide](https://docs.discord.red/en/stable/cog_guides/trivia.html)
also verifies custom question lists, categories, timed answers and leaderboards.
The Q4 answer claiming OpenWeather needs no API key conflicts with the
[official current-weather API](https://openweathermap.org/api/current), which
requires `appid`. Targeted excerpts are retained in `grading-evidence.json`.
'''
p=dest/'investigation.md';s=p.read_text();start=s.index('## New scored results');end=s.index('## Diagnosed mechanisms',start);s=s[:start]+text+'\n'+s[end:];p.write_text(s)
# Final configuration/history interpretation and restoration evidence are appended separately.
readme=dest.parent.parent/'README.md';s=readme.read_text();heading='## November 12, 2026 ordinary repository prompt evaluation'
if heading in s:
 start=s.index(heading);end=s.index('## Current Test Setup',start);s=s[:start]+s[end:]
section=heading+'''

These new measurements use the complete Hermes conversation loop, ordinary
repository prompts, three fresh repetitions per prompt, and separate history
sequences. They supersede any inference that the older guided issue-write
passes prove reliable ordinary repository work. All runs are read-only against
the forge; **no issue-write test was performed in this evaluation**.

'''+table+'''
“Both pass” requires Gitea repository use, no GitHub attempt, and a grounded,
complete answer with distinct ideas. Task completion alone is insufficient.
Fixtures are public on Gitea (`private: false`), so this measures default-forge
choice rather than private authorization. `sptnr` was verified as renamed to
SonicRatings and the lookup prompt was fixed once before the scored matrix.

Q4/Q6 used identical 98,304 context, q4 K/V, one slot, native sampler settings,
4,096 output cap and tool configuration. Qwen used its native 0.8/top-k40
sampler, versus VibeForged's 1.0/top-k20; it is a separate model/configuration
comparison. The Q4/Q6 system prompt differs in its visible model-identity
line; this is not blinded. All models fit the P100: sampled peaks were Q4 9,084 MiB, Q6 11,684 MiB,
Qwen 65k 9,474 MiB and Qwen 98k 9,922 MiB. Median first API-call
latencies were respectively 3.8s, 5.5s, 3.3s and 3.7s (warm-cache
measurements, not first-token latency). Neither higher precision nor more context
established reliable task quality.

The investigation confirmed stale Gitea tool names, deferred Gitea discovery
beside eager connection administration, and a separate compression defect:
auxiliary requests omit an output cap and inherit server `--n-predict 512`.
Historical OAuth-token removal does **not** establish broken authentication.

See the [full investigation](evaluations/2026-11-12/investigation.md),
[per-run metrics and grades](evaluations/2026-11-12/runs.csv), and
[evidence layout](evaluations/2026-11-12/EVIDENCE.md) for configuration factors,
history outcomes, limits and restoration verification. These are uniform core
CLI evaluations; native Discord/API gateway parity is not claimed.

'''
s=s.replace('## Current Test Setup',section+'## Current Test Setup',1)
if 'The matrix below preserves historical guided workflow probes' not in s:s=s.replace('## Test Matrix\n','## Test Matrix\n\nThe matrix below preserves historical guided workflow probes (primarily June/July\n2026, with later dated retests). Its “pass” labels do not use the new ordinary\nrepository-prompt acceptance test above.\n',1)
readme.write_text(s)
print('Updated investigation and README from completed aggregate rows')
