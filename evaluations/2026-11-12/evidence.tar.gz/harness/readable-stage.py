import subprocess,pathlib,json,time,urllib.request
r=pathlib.Path('/tmp/hermes-routing-eval')
def sh(args,**kw): return subprocess.run(args,check=True,text=True,**kw)
def ready():
 for _ in range(180):
  try:
   with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=3) as f: p=json.load(f)
   if p.get('model_path'):
    return p
  except Exception: pass
  time.sleep(2)
 raise RuntimeError('Backend did not become ready')
def batch(label,ctx,model,variant='baseline'):
 sh(['python3',str(r/'batch.py'),label,str(ctx),model,variant])
def switch(file,alias,ctx,label):
 sh(['docker','stop','-t','20','llama-cpp'],stdout=subprocess.DEVNULL)
 subprocess.run(['docker','rm','-f','llama-routing-eval'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 image=json.load(open(r/'original-llama-inspect.json'))[0]['Image']
 cmd=['docker','run','-d','--name','llama-routing-eval','--network','homelab','--network-alias','llama','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','25g','--memory-swap','25g',image,'-m','/models/'+file,'--alias',alias,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(ctx),'--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--n-predict','512','-ngl','999']
 sh(cmd,stdout=subprocess.DEVNULL)
 p=ready(); (r/(label+'-props.json')).write_text(json.dumps(p,indent=2))
 gpu=sh(['docker','exec','llama-routing-eval','nvidia-smi','--query-gpu=name,memory.used,memory.total,utilization.gpu','--format=csv'],capture_output=True).stdout
 (r/(label+'-idle-gpu.txt')).write_text(gpu)
 print('BACKEND',label,p.get('model_alias'),p.get('default_generation_settings',{}).get('n_ctx'),gpu.strip(),flush=True)
def follow(label):
 f=open(r/(label+'-backend.log'),'w')
 subprocess.Popen(['docker','logs','-f','llama-routing-eval'],stdout=f,stderr=subprocess.STDOUT)
 f.close()
while pathlib.Path('/proc/265408').exists(): time.sleep(5)
# This is a separately scored, single additional prompt-format factor.
sh(['docker','stop','-t','30','hermes'],stdout=subprocess.DEVNULL)
try:
 switch('Qwen3.5-9B-Q8_0.gguf','qwen3.5-9b-q8_0',65536,'qwen9-readable')
 follow('qwen9-readable')
 batch('qwen9-readable',65536,'qwen3.5-9b-q8_0','no-connections-eager-readable')
 batch('qwen9-readable-history',65536,'qwen3.5-9b-q8_0','no-connections-eager-readable-sequence')
finally:
 subprocess.run(['docker','rm','-f','llama-routing-eval'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 sh(['docker','start','llama-cpp'],stdout=subprocess.DEVNULL)
 ready()
 sh(['docker','start','hermes'],stdout=subprocess.DEVNULL)
 print('RESTORED originals',flush=True)
