"""Strict fresh-baseline resource postflight, including both owned staged weights."""
from pathlib import Path
import json,hashlib,subprocess,time,urllib.request
D=Path(__file__).resolve().parent;key='adapted-q3km-current';S=D/('resource-'+key)
assert json.loads((S/'runtime-restoration.json').read_text())['restored']and not(S/'RESTORATION-ERROR.json').exists()
B=json.loads((D/'baseline-20261127-before-current-adapted-q3km-resource/runtime.json').read_text());owner=json.loads((D/'baseline-20261127-before-current-adapted-q3km-resource/owner.json').read_text());admit=json.loads((D/'current-adapted-q3km-resource-storage-admission.json').read_text());P=json.loads((D/'current-adapted-q3km-resource-protocol.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest();docker=lambda *a:subprocess.check_output(['docker',*a],text=True)
current={}
for name in ['hermes','llama-cpp','hermes-codex']:
 c=json.loads(docker('inspect',name))[0];current[name]={'id':c['Id'],'image':c['Image'],'configuration_signature':sha(json.dumps({k:c[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()),'running':c['State']['Running'],'started':c['State']['StartedAt'],'restarts':c['RestartCount'],'health':c['State'].get('Health',{}).get('Status')}
 for field in ['id','image','configuration_signature','running']:assert current[name][field]==B['containers'][name][field]
assert current['hermes-codex']==B['containers']['hermes-codex']
code="""from pathlib import Path
import json,hashlib,shutil
def inventory(root):return [{'name':p.name,'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}for p in sorted(Path(root).glob('*.gguf'))]
print(json.dumps({'profile_hashes':{n:hashlib.sha256((Path('/opt/data')/n).read_bytes()).hexdigest()for n in ['config.yaml','.env','auth.json','SOUL.md']},'original_models':inventory('/models'),'stage_models':inventory('/stage'),'free_bytes':{n:shutil.disk_usage(n).free for n in ['/models','/stage']}}))
"""
a=['run','--rm','--runtime','runc','--network','none','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--memory','256m','--memory-swap','256m','--cpus','1','--volumes-from','llama-cpp:ro','--volumes-from','hermes:ro','--mount','type=volume,source=hermes-gpuquant-20261124-model-stage,target=/stage,readonly','-e','NVIDIA_VISIBLE_DEVICES=void','--entrypoint','python','sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b','-c',code]
data=json.loads(docker(*a));assert data['profile_hashes']==B['profile_hashes']and data['original_models']==B['models']['files']and len(data['original_models'])==30
assert data['stage_models']==admit['stage_files']and len(data['stage_models'])==2
assert min(data['free_bytes'].values())>=100*1024**3
with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=15)as f:props=json.load(f)
assert props['model_alias']==B['original_runtime_props']['alias']and props['default_generation_settings']['n_ctx']==B['original_runtime_props']['context']
O=Path('/media/prodigy/Coding-Programming/Repos/nicotineplus-plugins');git=lambda *a:subprocess.check_output(['git','-C',str(O),*a]);assert git('rev-parse','HEAD').decode().strip()==owner['head']and sha(git('status','--porcelain=v1','-z'))==owner['status_SHA256']
for n,h in owner['tracked_file_SHA256'].items():assert sha((O/n).read_bytes())==h,n
assert sha((O/'AGENTS.md').read_bytes())==owner['ignored_AGENTS_SHA256']
identity=json.loads((S/'model-identity.json').read_text());assert identity['sha256']==P[key]['sha256']and identity['bytes']==P[key]['expected_bytes']
out={'epoch':time.time(),'passed':True,'original_ids_images_config_running_preserved':True,'Codex_full_recorded_state_unchanged':True,'four_owner_profile_hashes_unchanged':True,'all_30_original_model_metadata_unchanged':True,'both_staged_model_metadata_unchanged':True,'owner_pending_and_40_source_files_unchanged':True,'original_alias_and_context_restored':True,'both_disk_reserves_at_least_100GiB':True,'free_GiB':{n:v/1024**3 for n,v in data['free_bytes'].items()},'containers':current,'model_identity':identity,'scope':'Fresh staged-Q3KM baseline; no waiver of prior IQ4 Codex timestamp failure.'}
(D/'current-adapted-q3km-resource-preservation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
