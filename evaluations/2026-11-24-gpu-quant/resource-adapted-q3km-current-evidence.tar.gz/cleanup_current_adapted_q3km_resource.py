"""Exact normal-completion resource cleanup, gated on strict current preservation."""
from pathlib import Path
import json,subprocess,re,time
D=Path(__file__).resolve().parent;key='adapted-q3km-current';S=D/('resource-'+key)
docker=lambda *a:subprocess.check_output(['docker',*a],text=True)
absent=lambda kind,n:subprocess.run(['docker',kind,'inspect',n],capture_output=True).returncode!=0
assert json.loads((S/'runtime-restoration.json').read_text())['restored']and not(S/'RESTORATION-ERROR.json').exists()
assert not(S/'controller-error.json').exists()
assert sum(bool(r.get('resource_probes_completed'))for r in json.loads((S/'finished.json').read_text())['results'])==1
preservation=json.loads((D/'current-adapted-q3km-resource-preservation.json').read_text());assert preservation['passed']and preservation['Codex_full_recorded_state_unchanged']and preservation['both_staged_model_metadata_unchanged']
h=json.loads((D/'current-adapted-q3km-resource-supervisor.json').read_text());c=json.loads(docker('inspect',h['id']))[0];assert c['Id']==h['id']and c['Name']=='/hermes-gpuquant-adapted-q3km-current-resource-supervisor'
assert c['Id']=='db8f036555cccfda4b29701dbfe5e7d37b945c5d7b2daf11d811bfb080bfbc0a'
assert c['Image']=='sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b'and c['Config']['Labels']['hermes.gpuquant.study']=='20261124'
assert not c['State']['Running']and c['State']['ExitCode']==0 and not c['State']['OOMKilled']
assert absent('container','hermes-gpuquant-resource-'+key+'-model')and absent('network','hermes-gpuquant-resource-'+key)
assert not docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124').strip()
volumes=[m for m in c['Mounts']if m['Type']=='volume'and re.fullmatch('[a-f0-9]{64}',m['Name'])];assert len(volumes)==1 and volumes[0]['Destination']=='/opt/data';v=volumes[0]
assert '/opt/data'in c['Config']['Volumes']and not any(m.get('Target')=='/opt/data'for m in(c['HostConfig'].get('Mounts')or[]))
assert docker('ps','-a','-q','--no-trunc','--filter','volume='+v['Name']).split()==[c['Id']]
(D/'current-adapted-q3km-resource-terminal-supervisor.json').write_text(json.dumps(c,indent=2)+'\n');r=subprocess.run(['docker','logs',c['Id']],capture_output=True,check=True);(D/'current-adapted-q3km-resource-terminal-supervisor.log').write_bytes(r.stdout+r.stderr)
(D/'current-adapted-q3km-resource-owned-anonymous-volume-proof.json').write_text(json.dumps({'epoch':time.time(),'volume':v,'sole_exact_supervisor_reference':True},indent=2)+'\n')
subprocess.run(['docker','rm','-v',c['Id']],capture_output=True,check=True);assert absent('container',c['Id'])and absent('volume',v['Name'])and not absent('volume','hermes-gpuquant-20261124-model-stage')
out={'epoch':time.time(),'passed':True,'exact_terminal_supervisor_and_exclusive_anonymous_volume_removed':True,'owned_backend_and_network_absent':True,'strict_fresh_originals_owner_Codex_and_both_staged_weights_preserved':True,'model_stage_preserved':True,'no_unowned_cleanup':True};(D/'current-adapted-q3km-resource-cleanup.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
