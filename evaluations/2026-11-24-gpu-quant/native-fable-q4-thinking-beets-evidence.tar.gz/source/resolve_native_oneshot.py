"""Resolve native one-shot compression descendants without relying on copied prompts."""
import sqlite3

def resolve_native_session(database,query,first=False):
    db=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)
    db.row_factory=sqlite3.Row
    try:
        row=db.execute('select session_id from messages where role=? and content=? order by id '+('asc'if first else'desc')+' limit 1',('user',query)).fetchone()
        if row is None:return None
        current=row['session_id']
        if first:return current
        seen=set()
        for _ in range(64):
            if current in seen:raise ValueError('Native session ancestry cycle')
            seen.add(current)
            parent=db.execute('select id,source,started_at,end_reason from sessions where id=?',(current,)).fetchone()
            if parent is None or parent['source']!='oneshot':raise ValueError('Missing or non-oneshot native parent')
            children=db.execute('select id,source,started_at from sessions where parent_session_id=?',(current,)).fetchall()
            if not children:return current
            if parent['end_reason']!='compression' or len(children)!=1:raise ValueError('Ambiguous or non-compression native continuation')
            child=children[0]
            if child['source']!='oneshot' or child['started_at']<parent['started_at']:raise ValueError('Invalid native compression descendant')
            current=child['id']
        raise ValueError('Native compression ancestry exceeds audit depth')
    finally:db.close()
