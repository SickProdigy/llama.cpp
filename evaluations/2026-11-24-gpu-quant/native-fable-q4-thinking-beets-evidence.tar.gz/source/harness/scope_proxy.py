"""Stateless MCP gateway scoped to one disposable coding-evaluation trial.
No credentials are exposed to the agent; upstream MCP owns authentication.
"""
import json,pathlib,os,re,urllib.request,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
READS={'get_me','search_repos','search_users','repo_read','get_repository_tree','get_dir_contents','get_file_contents','branch_read','commit_read','issue_read','list_issues','search_issues','pull_request_read','list_pull_requests'}
WRITES={'repo_write','issue_write','branch_write','create_or_update_file','pull_request_write'}
class Denied(ValueError):pass
class Scope:
 def __init__(self,p):self.p=p;self.issue=None;self.pr=None;self.branch=None;self.commits=0;self.branch_shas=set()
 def repo_ok(self,a):return (a.get('owner'),a.get('repo')) in [(self.p['owner'],self.p['repo']),('hermes-agent',self.p['fork_repo'])]
 def branch_ok(self,b):return isinstance(b,str) and b.startswith(self.p['branch_prefix']) and len(b)<120 and '..' not in b and bool(re.fullmatch(r'[A-Za-z0-9._/-]+',b))
 def check(self,n,a):
  p=self.p;up=(p['owner'],p['repo']);fork=('hermes-agent',p['fork_repo']);target=(a.get('owner'),a.get('repo'))
  if n not in READS|WRITES:raise Denied('Tool outside this evaluation lease')
  if n in {'get_me','search_repos','search_users'}:return 'read'
  if not self.repo_ok(a):raise Denied('Repository outside this evaluation lease')
  if n in READS:
   if n=='issue_read' and (self.issue is None or a.get('issue_number')!=self.issue):raise Denied('Other trials issue content is hidden')
   if n=='pull_request_read' and (self.pr is None or a.get('pull_number')!=self.pr):raise Denied('Other trials PR content is hidden')
   ref=a.get('ref') or a.get('tree_sha') or a.get('branch') or a.get('sha')
   if ref and ref not in {'main',p.get('base_sha'),self.branch} and not (target==fork and ref in self.branch_shas) and not str(ref).startswith(p['branch_prefix']):raise Denied('Other trials refs are hidden')
   return 'read'
  if p.get('read_only'):raise Denied('Unrequested mutation in read-only trial')
  if n=='repo_write':
   if set(a)-{'method','owner','repo','name','org'}:raise Denied('Unrequested fork fields')
   if a.get('method')!='fork' or target!=up or a.get('name',p['repo'])!=p['fork_repo'] or a.get('org') not in (None,'','hermes-agent'):raise Denied('Only the designated personal fork may be created')
   return 'fork'
  if n=='issue_write':
   if a.get('method')=='update' and a.get('issue_number')==self.issue and self.issue is not None:
    if set(a)-{'method','owner','repo','issue_number','title','body'} or target!=up:raise Denied('Only this trial issue prose may be corrected')
    return 'issue-update'
   if a.get('method')!='create' or target!=up or self.issue is not None:raise Denied('Only one new upstream issue is allowed')
   if set(a)-{'method','owner','repo','title','body'} or not a.get('title') or not a.get('body'):raise Denied('Issue requires title and body only')
   return 'issue'
  if n=='branch_write':
   if set(a)-{'method','owner','repo','branch','old_branch'}:raise Denied('Unrequested branch fields')
   if a.get('method')!='create' or target!=fork or a.get('old_branch','main')!='main' or not self.branch_ok(a.get('branch')) or self.branch:raise Denied('Use a fresh lease-prefixed feature branch from main in the fork')
   return 'branch'
  if n=='create_or_update_file':
   branch=a.get('new_branch_name') or a.get('branch_name')
   if target!=fork or not self.branch_ok(branch) or (self.branch and branch!=self.branch):raise Denied('Commits must target this trial fork feature branch')
   if a.get('new_branch_name') and (a.get('branch_name')!='main' or self.branch):raise Denied('Invalid combined branch creation')
   if not a.get('new_branch_name') and not self.branch:raise Denied('Create the feature branch first')
   files=a.get('files') or [{k:a[k] for k in ['path','content','edits','sha'] if k in a}]
   if not 1<=len(files)<=10:raise Denied('Exceeded bounded fixture commit scope')
   for f in files:
    path=f.get('path','');parts=path.split('/')
    if (f.get('new_path') or f.get('from_path')):raise Denied('Use explicit file changes instead of rename fields in this bounded arena')
    if not path or path.startswith('/') or '..' in parts or '.git' in parts or '\\' in path or not (path in p['allowed_paths'] or any(path.startswith(prefix) for prefix in p.get('allowed_path_prefixes',[])) or path.startswith('tests/') and path.endswith('.py')):raise Denied('File outside task scope')
    if len(str(f.get('content','')))>200000:raise Denied('Fixture file too large')
   return 'commit'
  if n=='pull_request_write':
   if a.get('method')=='update' and a.get('pull_number')==self.pr and self.pr is not None:
    if set(a)-{'method','owner','repo','pull_number','title','body','draft'} or target!=up:raise Denied('Only this trial PR prose may be corrected')
    return 'pr-update'
   if a.get('method')!='create' or target!=up or self.pr is not None or not self.commits or not self.issue:raise Denied('Create one upstream PR after a commit and upstream issue')
   if a.get('base')!='main' or a.get('head')!='hermes-agent:'+str(self.branch):raise Denied('Wrong PR head/base direction')
   if not re.search(r'#'+str(self.issue)+r'\b',a.get('body',''),re.I):raise Denied('Reference this trial upstream issue in the PR body')
   if set(a)-{'method','owner','repo','title','body','base','head','draft'}:raise Denied('Unrequested PR fields')
   return 'pr'
  raise Denied('Unsupported mutation')
 def after(self,stage,a,value):
  if stage=='issue' and isinstance(value,dict):self.issue=value.get('number')
  if stage=='pr' and isinstance(value,dict):self.pr=value.get('number')
  if stage=='branch':self.branch=a['branch']
  if stage=='commit':self.branch=a.get('new_branch_name') or a['branch_name'];self.commits+=1
 def filter(self,n,value,args=None):
  if isinstance(value,list):return [v for x in value if (v:=self.filter(n,x,args)) is not None]
  if isinstance(value,dict):
   full=value.get('full_name')
   if isinstance(full,str) and '/' in full and full not in {self.p['owner']+'/'+self.p['repo'],'hermes-agent/'+self.p['fork_repo']}:return None
   if n in {'list_issues','search_issues'} and 'number' in value and value['number']!=self.issue:return None
   if n=='list_pull_requests' and 'number' in value and value['number']!=self.pr:return None
   if n=='branch_read' and 'name' in value and set(value)&{'commit','commit_sha','protected'} and value['name'] not in {'main',self.branch}:return None
   if n=='branch_read' and value.get('name')==self.branch and args and (args.get('owner'),args.get('repo'))==('hermes-agent',self.p['fork_repo']):
    commit=value.get('commit');sha=value.get('commit_sha') or (commit.get('sha') or commit.get('id') if isinstance(commit,dict) else None)
    if isinstance(sha,str) and re.fullmatch(r'[0-9a-fA-F]{40}',sha):self.branch_shas.add(sha)
   return {k:self.filter(n,v,args) for k,v in value.items()}
  return value

def unpack(result):
 if isinstance(result,dict) and isinstance(result.get('content'),list):
  texts=[b.get('text','') for b in result['content'] if b.get('type')=='text']
  if len(texts)==1:
   try:return json.loads(texts[0])
   except ValueError:return texts[0]
 return result

def main():
 p=json.loads(pathlib.Path(os.environ.get('PILOT_SCOPE_CONFIG','/eval/publication-parameters.json')).read_text());scope=Scope(p);gate=None
 if p.get('execution_required'):
  import sys
  sys.path.insert(0,'/evaluation-library')
  sys.path.insert(0,'/harness')
  from execution_gate import ExecutionGate
  base_root=pathlib.Path('/baseline')
  base={str(f.relative_to(base_root)):f.read_bytes().decode() for f in base_root.rglob('*') if f.is_file() and not any(part in {'.git','__pycache__','.pytest_cache'} for part in f.relative_to(base_root).parts)}
  gate=ExecutionGate(base=base,record_root=pathlib.Path('/proxy-records/executions'),
       engine_record_root=p['engine_records']+'/executions',image=p['test_image'],
       phase_file=pathlib.Path('/eval/current-phase.json'),preservation_tests=p['engine_baseline_tests'])
 lock=threading.RLock();record_root=pathlib.Path(os.environ.get('PILOT_RECORDS','/proxy-records'));calls=[]
 if (record_root/'state.json').exists():raise RuntimeError('New stage queues must not reuse previous state')
 dest=os.environ.get('UPSTREAM_MCP','http://mcp-gitea-required-eval:8080/mcp')
 def forward(method,params):
  data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode();req=urllib.request.Request(dest,data=data,headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'})
  with urllib.request.urlopen(req,timeout=40) as r:text=r.read().decode()
  if not text.lstrip().startswith('{'):text=next(x[6:] for x in text.splitlines() if x.startswith('data: '))
  j=json.loads(text)
  if 'error' in j:raise RuntimeError(str(j['error']))
  return j['result']
 tools=[t for t in forward('tools/list',{})['tools'] if t['name'] in READS|WRITES]
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_GET(self):self.send_response(405);self.end_headers()
  def do_DELETE(self):self.send_response(200);self.end_headers()
  def do_POST(self):
   try:
    size=int(self.headers.get('Content-Length',0));assert 0<size<2**22;req=json.loads(self.rfile.read(size));method=req.get('method');params=req.get('params',{})
    if method.startswith('notifications/'):
     self.send_response(204);self.end_headers();return
    if method=='initialize':result={'protocolVersion':params.get('protocolVersion','2024-11-05'),'capabilities':{'tools':{'listChanged':False}},'serverInfo':{'name':'scoped-eval-mcp','version':'0.1.3'}}
    elif method=='ping':result={}
    elif method=='tools/list':result={'tools':tools}
    elif method=='tools/call':
     with lock:
      name=params['name'];args=params.get('arguments',{});entry={'name':name,'args':args,'epoch':time.time()};calls.append(entry)
      try:
       stage=scope.check(name,args)
       if gate:gate.check(name,args)
       if stage!='read' and p.get('phase_lease'):
        phase=json.loads(pathlib.Path(os.environ.get('PILOT_PHASE_FILE','/eval/current-phase.json')).read_text())
        if not phase.get('active'):raise Denied('This turn publication lease has ended')
       raw=forward(method,params);value=unpack(raw)
       if not raw.get('isError') and not (isinstance(value,dict) and 'error' in value):scope.after(stage,args,value)
       if gate and not raw.get('isError') and not (isinstance(value,dict) and 'error' in value):gate.after(name,args)
       value=scope.filter(name,value,args);result={'content':[{'type':'text','text':json.dumps(value)}],'isError':bool(raw.get('isError'))};entry.update(stage=stage,result=result)
      except Exception as e:result={'content':[{'type':'text','text':json.dumps({'error':str(e)})}],'isError':True};entry['denied_or_error']=str(e)
      entry['end_epoch']=time.time()
      (pathlib.Path(os.environ.get('PILOT_RECORDS','/proxy-records'))/'calls.json').write_text(json.dumps(calls,indent=2));(pathlib.Path(os.environ.get('PILOT_RECORDS','/proxy-records'))/'state.json').write_text(json.dumps({'issue':scope.issue,'pr':scope.pr,'branch':scope.branch,'commits':scope.commits},indent=2))
    else:raise Denied('Unsupported MCP method')
    data=json.dumps({'jsonrpc':'2.0','id':req.get('id'),'result':result}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
   except Exception as e:
    data=json.dumps({'jsonrpc':'2.0','id':None,'error':{'code':-32603,'message':str(e)}}).encode();self.send_response(400);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 ThreadingHTTPServer((os.environ.get('PILOT_BIND_HOST','0.0.0.0'),int(os.environ.get('PILOT_BIND_PORT','8080'))),Handler).serve_forever()
if __name__=='__main__':main()
