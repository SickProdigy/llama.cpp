"""No-inference actual SDK serialization check using copied fresh native profile."""
import os,sys,json,shutil,contextlib,hashlib
from pathlib import Path
name=sys.argv[1];assert name.startswith(('fable-','vibe-'));home=Path('/tmp/wide-wire-'+name);shutil.copytree('/state/profiles/'+name+'/profile',home);os.environ['HERMES_HOME']=str(home);sys.path.insert(0,'/opt/hermes')
with contextlib.redirect_stdout(sys.stderr):
 from hermes_cli.config import load_config_readonly
 from run_agent import AIAgent
 from hermes_cli.runtime_provider_custom import _custom_provider_request_overrides
 from agent.chat_completion_helpers import build_api_kwargs
 import httpx
 from openai import OpenAI
 control=json.loads(Path('/state/native-compression-control-audit.json').read_text());assert control['native']['passed']and not control['native']['used_fallback']and control['runtime_restoration']['restored'];assert control['recorded_calls'][0]['actual_progress_frames']>0
 amendment=json.loads(Path('/state/reasoning-compression-amendment.json').read_text());entry=next(x for x in amendment['profiles']if x['profile']==name);assert hashlib.sha256((home/'config.yaml').read_bytes()).hexdigest()==entry['new_config_SHA256']
 c=load_config_readonly();m=c['model'];extra=next(x for x in c['custom_providers']if x['name']=='wide')['extra_body']
 # This is an SDK-only configuration check, not a scored normal-policy session.
 a=AIAgent(model=m['default'],provider='custom',base_url=m['base_url'],api_key=m['api_key'],enabled_toolsets=[],request_overrides=_custom_provider_request_overrides(next(x for x in c['custom_providers']if x['name']=='wide')),max_tokens=m['max_tokens'],platform='cli',quiet_mode=True,skip_memory=True,skip_background_review=True,load_soul_identity=False,cwd='/tmp')
 kwargs=build_api_kwargs(a,[{'role':'user','content':'Configuration preflight'}],tools_for_api=[]);kwargs['stream']=False;kwargs.pop('stream_options',None);captured=[]
 def respond(request):
  captured.append(json.loads(request.content));return httpx.Response(200,json={'id':'preflight','object':'chat.completion','created':0,'model':m['default'],'choices':[{'index':0,'message':{'role':'assistant','content':'OK'},'finish_reason':'stop'}]})
 client=OpenAI(api_key=m['api_key'],base_url=m['base_url'],http_client=httpx.Client(transport=httpx.MockTransport(respond)));client.chat.completions.create(**kwargs);client.close();assert len(captured)==1
 body=captured[0]
 for k,v in extra.items():assert body[k]==v,(k,body.get(k),v)
 expected_cap=16384
 assert body['model']==m['default'] and body.get('max_tokens',body.get('max_completion_tokens'))==expected_cap
 from hermes_cli.timeouts import get_provider_request_timeout,get_provider_stale_timeout
 from agent.chat_completion_helpers import _local_stream_stale_timeout_default
 for provider in ['custom:wide','custom','wide']:
  assert get_provider_request_timeout(provider,m['default'])==get_provider_stale_timeout(provider,m['default'])==5400
 assert _local_stream_stale_timeout_default()==5400
 assert c['agent']['run_budget_seconds']==10800 and m['context_length']==98304
 from agent.auxiliary_client import _effective_aux_timeout
 from agent.conversation_compression_deadline import resolve_context_compression_timeouts
 assert _effective_aux_timeout('compression',None)==5400
 assert resolve_context_compression_timeouts()==(5400,5400)
 assert a.context_compressor.context_length==98304
 assert body['return_progress']is True
 assert c['auxiliary']['compression']['extra_body']['return_progress']is True
 assert c['title_generation']['enabled']is False and c['title_generation']['model_upgrade_enabled']is False
 assert body['chat_template_kwargs']==dict(enable_thinking=True) and body['temperature']==1.0 and body['top_k']==20 and body['seed']==20261124
 assert c['auxiliary']['compression']['extra_body']['max_tokens']==8192 and c['auxiliary']['compression']['extra_body']['chat_template_kwargs']=={'enable_thinking':False}
print(json.dumps({'profile':name,'passed':True,'native_timeout_getters_verified':True,'actual_auxiliary_timeout_seconds':5400,'actual_compression_host_budgets':[5400,5400],'actual_native_compressor_context':98304,'main_progress_serialized':True,'auxiliary_progress_configured':True,'auxiliary_progress_live_support_proven_separately':True,'not_live_auxiliary_serialization_proof_for_this_profile':True,'model_inference':False,'not_native_tool_or_persistence_proof':True,'endpoint':m['base_url'],'serialized_sampler':{k:body[k]for k in extra},'alias':body['model']}))
