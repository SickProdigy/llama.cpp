"""Export completed observed reasoning workflow; preserve negative results and method limits."""
from pathlib import Path
import json,hashlib,shutil,tarfile
R=Path.cwd();D=R/'.git/hermes-gpu-quant-20261124';E=R/'evaluations/2026-11-24-gpu-quant';k='fable-q4-thinking';label='native-'+k+'-beets';S=D/('native-'+k)/'beets_lifecycle';X=D/(label+'-export');read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();final=read(D/(k+'-beets-final-audit.json'));assert final['audit_complete']and not final['overall_workflow_passed'];assert read(D/(k+'-beets-cleanup.json'))['passed'];X.mkdir(exist_ok=False)
def cp(src,name):
 target=X/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
def write(name,value):
 target=X/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(value,indent=2)+'\n')
rt=read(D/(k+'-beets-runtime-context-audit.json'));summary={'candidate':k,'classification':'observed reasoning-enabled workflow with shared read-control MCP state and nonthinking auxiliary; not an independent cold-health quantization trial','model':rt['model_identity'],'runtime':{x:rt[x]for x in ['placement','phases','coding_elapsed_seconds','read_control_seconds','whole_launch_to_restore_seconds','wire_schema_canonical_UTF8_SHA256','HTTP_records','HTTP_complete_without_transport_errors','auxiliary_requests','observed_output_length_finishes','requests_without_full_requested_output_headroom','minimum_actual_context_headroom','maximum_completed_main_prompt_tokens','literal_user_request_retention','measurements','limits']},'independent_final_audit':final,'independent_read_audit':read(D/(k+'-beets-read-control-audit.json')),'independent_initial_audit':read(D/(k+'-beets-initial-manual-audit.json')),'independent_docs_audit':read(D/(k+'-beets-README-manual-audit.json')),'independent_feature_audit':read(D/(k+'-beets-feature-manual-audit.json')),'MCP_read_control_coupling':read(D/(k+'-mcp-read-control-coupling-audit.json')),'auxiliary_semantic_audit':read(D/(k+'-aux-summary-semantic-audit.json')),'original_runtime_preservation':read(D/('native-'+k+'-beets_lifecycle-preservation.json')),'all_results_historical_before_owner_rebuilds':True,'comparison_limits':['One observed lineage with three dependent coding turns and separate logical read-control conversation sharing a gateway; not autonomous reliability evidence.','Requested publisher-motivated main reasoning mode changes sampler/output cap/runtime with respect to nonthinking baselines; no precision-only causal claim.','Exact user-query preservation is not faithful summary or useful whole-window reasoning proof.','No operator corrective hints/resends; automatic native iteration-budget finalizers are part of the measured runtime.','Current production containers changed after the pause; preserve current state before further tests.']}
write('summary.json',summary)
for name in ['read-control-audit','initial-manual-audit','README-manual-audit','feature-manual-audit','publication-independent-readback','runtime-context-audit','final-audit','report-visibility-control','command-dispatch-control','cancel-reschedule-control','fork-independent-readback','cleanup']:
 cp(D/(k+'-beets-'+name+'.json'),'audits/'+name+'.json')
for suffix in ['preservation','owner-preservation']:cp(D/('native-'+k+'-beets_lifecycle-'+suffix+'.json'),'audits/'+suffix+'.json')
for name in ['mcp-read-control-coupling-audit','aux-summary-semantic-audit','feature-test-count-audit']:cp(D/(k+'-'+name+'.json'),'audits/'+name+'.json')
for phase in [0,1,2]:
 O=S/k/f'turn{phase}';cp(O/'local-grade/grade.json',f'phases/{phase}/grade.json')
 for log in ['project.log','preservation.log']:cp(O/'local-grade'/log,f'phases/{phase}/{log}')
 write(f'phases/{phase}/private-independent-log-fingerprint.json',{'SHA256':sha(O/'local-grade/independent.log'),'not_exported':'Private grader output'})
for phase in [0,2]:
 P=D/f'{k}-beets_lifecycle-phase{phase}-test-adequacy';cp(P/'result.json',f'controls/test-adequacy-{phase}.json')
 for arm in ['candidate','prior_with_authored_tests']:cp(P/arm/'project.log',f'controls/test-adequacy-{phase}-{arm}.log')
for name in ['memory-samples.jsonl','events.jsonl','backend-ready-placement.log','placement-check.json','model-identity.json','runtime-before.json','runtime-restoration.json']:cp(S/name,'runtime/'+name)
cp(D/('native-'+k+'-supervisor-exit-state.json'),'runtime/supervisor-exit-state.json')
for row in rt['requests']:write(f"requests/{row['id']:05}.json",row)
protocol=read(D/f'native-{k}-beets_lifecycle-protocol.json');safe={x:v for x,v in protocol.items()if x not in ['profile_sha256','code_sha256']};safe['original_private_protocol_SHA256']=sha(D/f'native-{k}-beets_lifecycle-protocol.json');safe['private_code_fingerprints']=protocol['code_sha256'];safe['private_profile_manifest_excluded']=True;write('controls/protocol.json',safe)
for kind in ['branches','issues','prs']:cp(D/(k+'-connected-final-'+kind+'.json'),'remote/connected-final-'+kind+'.json')
cp(D/(k+'-preactor-remote-audit.json'),'controls/fixture-admission.json');cp(D/(k+'-preactor-permission-audit.json'),'controls/actor-permission-admission.json');write('controls/model-pin.json',read(D/'reasoning-resource-protocol.json')[k])
launch=read(S/'backend-launch.json');write('runtime/backend-launch.json',{'argv':launch['argv'],'seconds':launch['seconds'],'props':{name:launch['props'][name]for name in ['model_alias','model_path','build_info','default_generation_settings']}})
cp(D/(k+'-runtime-wire-preflight.json'),'controls/profile-runtime-wire-preflight.json');cp(D/(k+'-actual-code-preflight.json'),'controls/code-smoke-preflight.json');cp(D/'reasoning-scope-proxy-cache-preflight.json','controls/proxy-startup-preflight.json')
F=D/'fable-q4-thinking-preactor-setup-failure-1';cp(F/'classification.json','controls/excluded-preactor-setup-failure.json');write('controls/excluded-setup-binding.json',{'private_frozen_protocol_SHA256':sha(F/'protocol.json'),'zero_model_calls':True,'not_model_quality_score':True})
for name in ['reasoning_native_controller.py','model_cache_probe.py','resolve_native_oneshot.py','reasoning_runtime_wire_preflight.py','amend_unused_reasoning_compression.py','preflight_reasoning_scope_proxy.py','audit_test_adequacy.py','audit_beets_command_dispatch_published.py','audit_fable_q4_thinking_runtime.py','export_fable_q4_thinking_observed.py']:
 cp(D/name,'source/'+name)
for name in ['llm_proxy.py','scope_proxy.py']:cp(D/'harness'/name,'source/harness/'+name)
for root in ['harness','evaluation-library']:
 p=D/root/'native_session_lineage.py'
 if p.exists():cp(p,'source/'+root+'/native_session_lineage.py')
for name in ['mcp_tool.py','mcp_tool_health.py','mcp_tool_handlers.py','cli_single_query.py']:cp(D/'mcp-cooldown-source-audit'/name,'source/pinned-runtime/'+name)
write('privacy-boundary.json',{'excluded':['Raw primary/auxiliary request and response payloads','Actor consoles and session DBs','Original and experimental full profiles/credentials','Private tasks/graders/reference implementations','Full private source snapshots','Private signing keys'],'included':'Numeric observations, source fingerprints, actor-authored/original-suite failure logs, independent audits, generic runtime/control source; no private grader output.'})
write('reproduction-scope.json',{'private_inputs_required':True,'not_full_public_model_replay':'Use the pinned public artifact/runtime images and privately supplied baseline/profile/tasks/grader inputs; exported verification checks saved consistency, not behavior reexecution.','frozen_model_source_inputs_preserved_privately':True})
manifest={str(p.relative_to(X)):sha(p)for p in sorted(X.rglob('*'))if p.is_file()};write('manifest.json',manifest);archive=E/(label+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for p in sorted(X.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(X)))
(E/(label+'-summary.json')).write_bytes((X/'summary.json').read_bytes());(E/(label+'-evidence.sha256')).write_text(sha(archive)+'  '+archive.name+'\n');print(json.dumps({'archive_SHA256':sha(archive),'files':len(manifest)+1,'workflow_passed':False,'coding_minutes':rt['coding_elapsed_seconds']/60}))
