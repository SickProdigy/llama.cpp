"""Trusted fresh native experiment. Private graders never become actor feedback."""
from pathlib import Path
import os,sys,json,subprocess,time,hashlib,urllib.request,sqlite3,shutil,signal,traceback,threading,re
from model_cache_probe import advise_inactive_model
D=Path('/state');P=D;sys.path.insert(0,'/evaluation-library');sys.path.insert(0,str(P/'harness'))
from review_packet import source_digest,encoded,sha
from docker_execution import DockerExecution
from native_session_lineage import compression_lineage
FAMILY=sys.argv[1];assert FAMILY=='beets_lifecycle';KEY=sys.argv[2];assert KEY in ['fable-q4-thinking','fable-q6-thinking'];NATIVE_ROOT='native-'+KEY;PARAMS=json.loads((D/'profile-parameters'/(KEY+'-'+FAMILY+'.json')).read_text());RESOURCE_KEY=KEY;RESOURCE=json.loads((D/'reasoning-resource-protocol.json').read_text())[RESOURCE_KEY]
SHORT='beets';MODULE='beetsbridge'
S=P/NATIVE_ROOT/FAMILY;S.mkdir(parents=True,exist_ok=False)
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp'
EP=ENGINE+'/.git/hermes-gpu-quant-20261124'
BACKEND='sha256:7561b4761f849925a728c5ac2bd1f4a649b6a76f24544e7f992b047ad016cec3';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
ALIAS=PARAMS['alias'];NET='hermes-gpuquant-'+KEY+'-fresh2-'+SHORT;MAIN='gpuquant-'+KEY+'-fresh2-'+SHORT+'-main';LLM='gpuquant-'+KEY+'-fresh2-'+SHORT+'-llm';AGENT='gpuquant-'+KEY+'-fresh2-'+SHORT+'-agent';PROXY='gpuquant-'+KEY+'-fresh2-'+SHORT+'-gitea'
owned={};network_id=None;stopped=False;baseline={};monitor_stop=threading.Event();abort=threading.Event();monitor_thread=None;tasks=json.loads((P/'tasks.json').read_text())['families'][FAMILY]
arenas={KEY:json.loads((P/('arena-'+KEY+'.json')).read_text())}
def save(path,obj):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(obj,indent=2)+'\n');temp.replace(path)
def event(kind,**kw):
 obj={'epoch':time.time(),'kind':kind,**kw}
 with (S/'events.jsonl').open('a') as f:f.write(json.dumps(obj)+'\n')
 print(json.dumps(obj),flush=True)
def docker(*args,check=True,timeout=180):
 r=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and r.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+r.stderr[-1200:])
 return r.stdout

def inspect(name):return json.loads(docker('inspect',name))[0]
def state(name):
 c=inspect(name);return {'id':c['Id'],'image':c['Image'],'signature':sha(encoded({k:c[k]for k in ['Image','Config','HostConfig','Mounts']})),'running':c['State']['Running'],'started':c['State']['StartedAt'],'restarts':c['RestartCount'],'health':c['State'].get('Health',{}).get('Status')}
def http(url,body=None):
 req=urllib.request.Request(url,data=None if body is None else encoded(body),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
def ready(name,alias,ctx):
 end=time.monotonic()+900
 while time.monotonic()<end:
  if abort.is_set():raise RuntimeError('Measured runtime resource guard during readiness')
  if not inspect(name)['State']['Running']:raise RuntimeError('Backend exited during readiness')
  try:
   x=http('http://'+name+':11430/props');health=http('http://'+name+':11430/health')
   if x['model_alias']==alias and x['default_generation_settings']['n_ctx']==ctx and health['status']=='ok':return x
  except (OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Backend readiness expired')
def run(name,args):
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0,'Owned name already exists'
 if name!=MAIN:args=['--runtime','runc',*args]
 ident=docker('run','-d','--pull','never','--name',name,'--label','hermes.gpuquant.study=20261124',*args).strip();owned[name]=ident;return ident

def remove(name):
 if name not in owned:return
 assert inspect(name)['Id']==owned[name],'Refuse cleanup of replaced container'
 x=inspect(name);save(S/(name+'-'+str(time.time_ns())+'-state.json'),{'id':x['Id'],'state':x['State'],'memory_limit':x['HostConfig']['Memory'],'memory_swap_limit':x['HostConfig']['MemorySwap']})
 log=subprocess.run(['docker','logs',name],capture_output=True);(S/(name+'-'+str(time.time_ns())+'.log')).write_bytes(log.stdout+log.stderr)
 docker('rm','-f','-v',name);owned.pop(name)
def mount(relative,target,ro=False):return ['--mount','type=bind,source='+EP+'/'+relative+',target='+target+(',readonly'if ro else '')]
def credentials(identity):
 c=inspect(identity);env=dict(x.split('=',1)for x in c['Config']['Env']);return env['GITEA_HOST'].rstrip('/'),env['GITEA_ACCESS_TOKEN']
def api(method,path,body=None,identity='mcp-gitea-codex'):
 host,token=credentials(identity);req=urllib.request.Request(host+'/api/v1/'+path,data=encoded(body or {})if method!='GET'else None,method=method,headers={'Authorization':'token '+token,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60) as response:
  raw=response.read();return json.loads(raw) if raw else None

def clone(name,arm,branch='main',fork=False):
 identity='mcp-gitea-required-eval' if fork else 'mcp-gitea-codex';host,token=credentials(identity);owner='hermes-agent'if fork else 'chatgpt-codex';repo=arenas[arm]['repo']
 payload={'name':name,'branch':branch,'user':owner,'url':host+'/'+owner+'/'+repo+'.git','public_url':'https://gitea.rcs1.top/'+owner+'/'+repo+'.git','token':token}
 r=subprocess.run([sys.executable,str(P/'clone_operator.py')],input=json.dumps(payload),capture_output=True,text=True,timeout=120)
 if r.returncode:raise RuntimeError('Trusted clone failed, code '+str(r.returncode))
 return json.loads(r.stdout)
def inventory(root):
 files={}
 for f in sorted(root.rglob('*')):
  rel=f.relative_to(root)
  if any(x in {'.git','__pycache__','.pytest_cache'}for x in rel.parts)or f.name=='AGENTS.md':continue
  if f.is_symlink():raise ValueError('Unsupported symlink source')
  if f.is_file():files[str(rel)]=f.read_bytes().decode()
 source_digest(files);return files

def grade(work,out,phase,kind):
 out.mkdir(parents=True,exist_ok=True)
 try:
  files=inventory(work);source=out/'source';source.mkdir()
  for path,text in files.items():
   f=source/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(text.encode())
  rel=str(source.relative_to(P));engine=EP+'/'+rel;digest=source_digest(files)
  runner=DockerExecution(source,engine,IMAGE,output_log=out/'project.log')
  result=runner.run(expected_digest=digest,key=os.urandom(32));save(out/'project-receipt-payload.json',result['payload'])
  preservation=DockerExecution(source,engine,IMAGE,suite_id='preservation',preservation_tests=EP+'/baseline/tests',output_log=out/'preservation.log')
  old=preservation.run(expected_digest=digest,key=os.urandom(32));save(out/'preservation-receipt-payload.json',old['payload'])
  checker=protocol.get('feature_checker','feature_checks.py') if phase==2 else 'initial_checks.py'
  cmd=['docker','run','--rm','--pull','never','--label','hermes.gpuquant.study=20261124','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g','--memory-swap','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m','--mount','type=bind,source='+engine+',target=/workspace,readonly',*mount('initial_checks.py','/state/initial_checks.py',True),*mount('baseline/tests','/state/baseline/tests',True),'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',IMAGE,'-s','KILL','90','python','/state/'+checker,'/workspace',FAMILY]
  if phase==2:cmd[cmd.index('-e'):cmd.index('-e')]=mount(checker,'/state/'+checker,True)
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(out/'independent.log').write_text(r.stdout+r.stderr)
  base=inventory(P/'baseline');changed=[n for n in sorted(set(base)|set(files))if base.get(n)!=files.get(n)]
  save(out/'grade.json',{'kind':kind,'family':FAMILY,'phase':phase,'source_digest':digest,'project_exit':result['payload']['returncode'],'preservation_exit':old['payload']['returncode'],'independent_exit':r.returncode,'changed_paths':changed,'not_fed_to_models':True})
 except Exception as error:save(out/'grade-error.json',{'error':str(error),'traceback':traceback.format_exc(),'not_fed_to_models':True})

def session(profile,query,first=False):
 from resolve_native_oneshot import resolve_native_session
 return resolve_native_session(profile/'state.db',query,first)
def transcript(profile):
 if not(profile/'state.db').exists():return None
 db=sqlite3.connect('file:'+str(profile/'state.db')+'?mode=ro',uri=True)
 try:return sha(encoded(db.execute('select id,session_id,role,content,tool_name,tool_calls from messages order by id').fetchall()))
 finally:db.close()
def capture_db(profile,out):
 db=sqlite3.connect(profile/'state.db',timeout=10);copy=sqlite3.connect(out/'state.db');db.backup(copy);copy.close();db.close()
def remote_audit(run,arm,phase,out):
 state_path=run/'proxy-records/state.json';x=json.loads(state_path.read_text())if state_path.exists()else{};repo=arenas[arm]['repo'];audit={'scope_state':x,'phase':phase}
 if x.get('issue'):audit['issue']=api('GET','repos/chatgpt-codex/'+repo+'/issues/'+str(x['issue']))
 if x.get('pr'):audit['pr']=api('GET','repos/chatgpt-codex/'+repo+'/pulls/'+str(x['pr']))
 if x.get('branch') and x.get('commits'):
  name=arm+'-'+FAMILY+'-remote-'+str(phase);audit['clone']=clone(name,arm,x['branch'],True);grade(P/'worktrees'/name,out/'remote-grade',phase,'actual-fork-commit')
 save(out/'forge-snapshot.json',audit)

def case(arm):
 name=arm+'-'+FAMILY;runroot=S/arm;runroot.mkdir();records=runroot/'proxy-records';records.mkdir();config=runroot/'proxy-config';config.mkdir();profile=P/'profiles'/(KEY+'-'+FAMILY)/'profile';work=P/'worktrees'/name
 cl=clone(name,arm);assert cl['head']==arenas[arm]['base_revision']and cl['tree']==arenas[arm]['tree'];save(runroot/'clone.json',cl)
 prefix='wide-'+SHORT+'-'+arm+'-';agents=work/'AGENTS.md';agents.write_text(agents.read_text()+'\nContribution branches in this disposable evaluation must start with '+prefix+'.\n')
 scope={'owner':'chatgpt-codex','repo':arenas[arm]['repo'],'fork_repo':arenas[arm]['repo'],'base_sha':arenas[arm]['base_revision'],'branch_prefix':prefix,'allowed_paths':['README.md'],'allowed_path_prefixes':[MODULE+'/'],'execution_required':True,'phase_lease':True,'test_image':IMAGE,'engine_records':EP+'/'+NATIVE_ROOT+'/'+FAMILY+'/'+arm+'/proxy-records','engine_baseline_tests':EP+'/baseline/tests'}
 save(config/'publication-parameters.json',scope);save(config/'current-phase.json',{'id':name+'-not-started','active':False,'tasks_so_far':[]})
 try:
  args=['--network','homelab','--runtime','runc','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--memory','1g','--memory-swap','1g','--cpus','1','--mount','type=bind,source=/var/run/docker.sock,target=/var/run/docker.sock','--mount','type=bind,source='+ENGINE+'/.git/hermes-goal-recovery-20261121/rebuilt/docker,target=/usr/local/bin/docker,readonly','--mount','type=bind,source='+EP+'/evaluation-library,target=/evaluation-library,readonly',*mount('harness','/harness',True),*mount('baseline','/baseline',True),*mount(str(config.relative_to(P)),'/eval',True),*mount(str(records.relative_to(P)),'/proxy-records'),'-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/harness/scope_proxy.py']
  # Create, attach internal alias, then start so initialization can reach both networks.
  ident=docker('create','--name',PROXY,'--label','hermes.gpuquant.study=20261124',*args).strip();owned[PROXY]=ident;docker('network','connect','--alias','gitea-wide',NET,PROXY);docker('start',PROXY)
  end=time.monotonic()+60
  while time.monotonic()<end:
   if not inspect(PROXY)['State']['Running']:raise RuntimeError('Scoped proxy preflight exited')
   try:
    x=http('http://'+PROXY+':8080/mcp',{'jsonrpc':'2.0','id':1,'method':'tools/list','params':{}})
    if x.get('result',{}).get('tools'):break
   except OSError:pass
   time.sleep(1)
  else:raise TimeoutError('Scoped proxy readiness')
  run(AGENT,['--network',NET,'--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','2g','--memory-swap','2g','--cpus','2','--tmpfs','/tmp:rw,size=1g,mode=1777',*mount(str(profile.relative_to(P)),'/opt/data'),*mount('worktrees/'+name,'/workspace'),'-e','HOME=/opt/data','-e','HERMES_HOME=/opt/data','-e','HERMES_WRITE_SAFE_ROOT=/workspace:/opt/data/cache/scratch','-e','PYTHONDONTWRITEBYTECODE=1','-e','HERMES_API_TIMEOUT=5400','-e','HERMES_API_CALL_STALE_TIMEOUT=5400','-e','HERMES_STREAM_STALE_TIMEOUT=5400','-e','HERMES_LOCAL_STREAM_STALE_TIMEOUT=5400','--entrypoint','sleep',IMAGE,'infinity'])
  sid=None;root_sid=None
  read_query='Find the selected repository through its configured forge and briefly explain what it contains.'
  for phase,query in [(-1,read_query),*enumerate(tasks)]:
   out=runroot/('turn'+str(phase));out.mkdir()
   if sid:
    before=transcript(profile);r=subprocess.run(['docker','exec',AGENT,'/opt/hermes/bin/hermes','sessions','discard',sid,'--yes'],capture_output=True,text=True,timeout=60);(out/'native-admission-control.log').write_text(r.stdout+r.stderr);assert transcript(profile)==before,'Native discard changed conversation';save(out/'native-admission-control.json',{'command':'hermes sessions discard SID --yes','returncode':r.returncode,'conversation_unchanged':True,'force_unlock':False,'task_replayed':False})
   if phase==0:
    selected=inventory(work);original=inventory(P/'baseline');save(runroot/'before-coding-source-admission.json',{'source_digest':source_digest(selected),'baseline_digest':source_digest(original),'source_unchanged_after_read_control':selected==original,'not_actor_feedback':True});assert selected==original,'Readonly control changed selected source; do not score contaminated fresh coding';sid=None;root_sid=None
   phase_data={'id':name+'-turn'+str(phase),'active':phase>=0,'tasks_so_far':tasks[:phase+1]if phase>=0 else[]};save(config/'current-phase.json',phase_data);event('turn_start',arm=arm,phase=phase)
   command=['docker','exec','-i','-w','/workspace',AGENT,'/opt/hermes/bin/hermes','chat','--cli','--oneshot','-Q','--query-file','-','--in','/workspace','--accept-hooks','--max-turns','60','--run-budget',str(3600 if phase<0 else 10800)]
   if sid:command+=['--resume',sid]
   start=time.monotonic();external=False;samples=[]
   with (out/'console.log').open('w')as log:
    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT);proc.stdin.write(query.encode());proc.stdin.close()
    while proc.poll()is None:
     if not inspect(MAIN)['State']['Running']:raise RuntimeError('Backend exited during native workflow; inspect runtime evidence before assigning quality')
     if abort.is_set():
      phase_data['active']=False;save(config/'current-phase.json',phase_data);docker('stop','-t','15',AGENT);proc.wait(timeout=60);raise RuntimeError('Measured runtime resource guard; inspect memory/disk evidence before assigning quality')
     if time.monotonic()-start>(3900 if phase<0 else 11100):external=True;phase_data['active']=False;save(config/'current-phase.json',phase_data);docker('stop','-t','15',AGENT);break
     samples.append({'epoch':time.time(),'seconds':time.monotonic()-start,'gpu':docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits',check=False,timeout=15).strip()});time.sleep(5)
    code=proc.wait()
   elapsed=time.monotonic()-start;phase_data['active']=False;save(config/'current-phase.json',phase_data)
   found=session(profile,query);assert found,'Frozen query missing in native state';incoming=sid;root_sid=root_sid or session(profile,query,True);lineage=compression_lineage(profile/'state.db',root_sid,found)
   if incoming and incoming!=found:compression_lineage(profile/'state.db',incoming,found)
   handles=re.findall(r'(?m)^session_id:\s*([A-Za-z0-9_-]+)\s*$',(out/'console.log').read_text());assert handles,'Native CLI resume handle missing from completed output'
   sid=handles[-1];assert sid in [node['id']for node in lineage],'CLI handle outside verified native compression ancestry'
   capture_db(profile,out);save(out/'run.json',{'family':FAMILY,'arm':arm,'phase':phase,'elapsed_seconds':elapsed,'exit_code':code,'external_timeout':external,'query_sha256':sha(query.encode()),'logical_root':root_sid,'incoming_sid':incoming,'effective_sid':found,'cli_resume_handle':sid,'lineage':lineage,'gpu':samples})
   if phase>=0:grade(work,out/'local-grade',phase,'unpublished-local-draft');remote_audit(runroot,arm,phase,out)
   shutil.copytree(records,out/'forge-records',dirs_exist_ok=True);event('turn_end',arm=arm,phase=phase,seconds=elapsed,exit_code=code)
   if external:docker('start',AGENT)
  save(runroot/'case-finished.json',{'turns':3,'logical_root':root_sid,'effective_sid':found,'cli_resume_handle':sid})
 finally:
  save(config/'current-phase.json',{'id':name+'-ended','active':False,'tasks_so_far':[]})
  try:
   x=json.loads((records/'state.json').read_text())if(records/'state.json').exists()else{}
   if x.get('issue'):
    issue=api('PATCH','repos/chatgpt-codex/'+arenas[arm]['repo']+'/issues/'+str(x['issue']),{'state':'closed'});save(runroot/'issue-cleanup.json',{'number':x['issue'],'state':issue['state'],'pr_preserved_unmerged':True})
  finally:
   remove(AGENT);remove(PROXY)
   if not(runroot/'case-finished.json').exists():
    emergency=runroot/'interrupted-snapshot';emergency.mkdir(exist_ok=False)
    if (profile/'state.db').exists():capture_db(profile,emergency)
    try:
     files=inventory(work);save(emergency/'source-digests.json',{n:sha(text.encode())for n,text in files.items()})
     for n,text in files.items():
      path=emergency/'source'/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(text.encode())
    except Exception as e:save(emergency/'snapshot-error.json',{'error':str(e)})

def monitor_runtime():
 command='for f in /sys/fs/cgroup/memory.current /sys/fs/cgroup/memory.peak /sys/fs/cgroup/memory.swap.current /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.stat /proc/[0-9]*/smaps_rollup; do printf "FILE %s\\n" "$f"; cat "$f" 2>/dev/null; done'
 while not monitor_stop.is_set():
  row={'epoch':time.time(),'containers':{},'model_disk_free_bytes':shutil.disk_usage('/models').free}
  try:
   mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());row['host']={'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
   cg_total=0;pss_total=0;swap_total=0
   targets=dict(owned);targets['supervisor']=inspect(os.environ['HOSTNAME'])['Id']
   for ident in docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124',timeout=20).split():
    item=inspect(ident);targets[item['Name'].lstrip('/')]=item['Id']
   unique={ident:name for name,ident in targets.items()}
   for ident,name in unique.items():
    raw=docker('exec',ident,'/bin/sh','-c',command,check=False,timeout=25)
    match=re.search(r'FILE /sys/fs/cgroup/memory.current\n(\d+)',raw);current=int(match.group(1))if match else 0
    match=re.search(r'FILE /sys/fs/cgroup/memory.swap.current\n(\d+)',raw);swap=int(match.group(1))if match else 0
    pss=sum(int(n)*1024 for n in re.findall(r'^Pss:\s*(\d+) kB',raw,re.M))
    row['containers'][name]={'raw':raw,'pss_all_processes_bytes':pss,'cgroup_current_bytes':current,'cgroup_swap_bytes':swap};cg_total+=current;pss_total+=pss;swap_total+=swap
   row.update(total_cgroup_bytes=cg_total,total_process_pss_bytes=pss_total,total_cgroup_swap_bytes=swap_total)
   row['gpu_csv']=docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits',check=False,timeout=20).strip()
   if cg_total>8*1024**3 or pss_total>8*1024**3 or swap_total or mem['MemAvailable']<4*1024**3 or row['model_disk_free_bytes']<100*1024**3:
    row['budget_guard_triggered']=True;row['disk_reserve_guard_triggered']=row['model_disk_free_bytes']<100*1024**3;abort.set()
    if MAIN in owned and inspect(MAIN)['Id']==owned[MAIN]:docker('stop','-t','10',owned[MAIN],check=False)
  except Exception as error:row['measurement_error']=type(error).__name__+': '+str(error)
  with(S/'memory-samples.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  monitor_stop.wait(10)

def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(42000)
try:
 protocol=json.loads((P/(NATIVE_ROOT+'-'+FAMILY+'-protocol.json')).read_text())
 resource=P/('resource-'+RESOURCE_KEY)
 assert json.loads((resource/'runtime-restoration.json').read_text())['restored']
 result=json.loads((resource/'finished.json').read_text())['results'][0]
 assert result['resource_probes_completed'] and result['layout']=={'context':98304,'gpu_layers':99}
 launch_path=resource/'layout0/launch.json'
 assert sha(launch_path.read_bytes())==protocol['resource_launch_sha256']
 measured=json.loads(launch_path.read_text())['argv'];layout=protocol['measured_resource_layout']
 for option,value in [('--memory','6656m'),('--memory-swap','6656m'),('--ctx-size','98304'),('-ngl','99'),('--ctx-checkpoints','2'),('--cache-type-k','q4_0'),('--cache-type-v','q4_0'),('--load-mode','none')]:assert measured[measured.index(option)+1]==value
 assert json.loads((P/'private-checker-validation.json').read_text())['passed']
 assert json.loads((P/'pinned-reference-suite-validation.json').read_text())['passed']
 for relative,digest in protocol['code_sha256'].items():assert sha((D/relative).read_bytes())==digest,relative
 for relative,digest in protocol['profile_sha256'][FAMILY].items():assert sha((D/relative).read_bytes())==digest,relative
 model=Path('/models')/RESOURCE['file'];h=hashlib.sha256()
 with model.open('rb')as f:
  for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
 assert h.hexdigest()==RESOURCE['sha256'] and model.stat().st_size==RESOURCE['expected_bytes']
 with model.open('rb')as f:os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 save(S/'model-identity.json',{'file':model.name,'bytes':model.stat().st_size,'sha256':h.hexdigest(),'after_full_SHA_advised_DONTNEED_for_only_selected_model_file':True,'not_global_cache_flush_or_proof_of_cold_cache':True})
 assert json.loads((P/(KEY+'-sdk-wire-preflight.json')).read_text())['passed']
 assert json.loads((P/'native-transport-preflight.json').read_text())['passed']
 assert shutil.disk_usage('/models').free>=100*1024**3,'Disk reserve insufficient before GPU stage'
 for ident in docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124').split():assert inspect(ident)['Id']==inspect(os.environ['HOSTNAME'])['Id'],'Other study job still active'
 baseline={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};save(S/'runtime-before.json',baseline);assert all(v['running']for v in baseline.values())
 network_id=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME'])
 stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 cache_observation=advise_inactive_model(model);save(S/'selected-file-cache-after-original-stop.json',cache_observation);assert cache_observation['mincore_cached_page_bytes_after']==0,'Selected model file cache not cleared after original backend stop'
 launch=['--network',NET,'--gpus','all','--memory','6656m','--memory-swap','6656m','--cpus','8','--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=256m','--no-healthcheck',BACKEND,'-m','/models/'+RESOURCE['file'],'--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(layout['context']),'--parallel','1','--cache-type-k',layout.get('cache_k','q4_0'),'--cache-type-v',layout.get('cache_v','q4_0'),'--n-predict','1024','-lv','5','--load-mode','none','--cache-ram','512','--ctx-checkpoints','2','--fit','off','-ngl',str(layout['gpu_layers']),'--threads','8','-b','512','-ub','128','--temp',str(PARAMS['sampler']['temperature']),'--top-k',str(PARAMS['sampler']['top_k']),'--top-p',str(PARAMS['sampler']['top_p']),'--min-p','0','--repeat-penalty','1','--presence-penalty','0']
 if 'cpu_moe_layers'in layout:launch+=['--n-cpu-moe',str(layout['cpu_moe_layers'])]
 t=time.monotonic();run(MAIN,launch);monitor_thread=threading.Thread(target=monitor_runtime,daemon=True);monitor_thread.start();props=ready(MAIN,ALIAS,layout['context']);save(S/'backend-launch.json',{'argv':launch,'seconds':time.monotonic()-t,'props':props});event('backend_ready')
 placement_log=subprocess.run(['docker','logs',owned[MAIN]],capture_output=True,text=True,timeout=60);placement_text=placement_log.stdout+placement_log.stderr;(S/'backend-ready-placement.log').write_text(placement_text);placement_matches=re.findall(r'offloaded (\d+)/(\d+) layers to GPU',placement_text);assert placement_matches and all(a==b for a,b in placement_matches),'Full GPU layer placement not confirmed before actor';save(S/'placement-check.json',{'all_layers_offloaded':True,'observed_layer_counts':placement_matches,'automatic_fit_disabled':True,'log_sha256':sha(placement_text.encode()),'not_quality_proof':True})
 llmrecords=S/'llm-records';llmrecords.mkdir();os.chown(llmrecords,1000,1000)
 run(LLM,['--network',NET,'--network-alias','wide-llm','--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','512m','--memory-swap','512m',*mount('harness','/harness',True),*mount(str(llmrecords.relative_to(P)),'/records'),'-e','PILOT_LLM_BACKEND=http://'+MAIN+':11430','-e','PILOT_ALIAS='+ALIAS,'-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/harness/llm_proxy.py'])
 time.sleep(2)
 case(KEY)
 save(S/'workflows-finished.json',{'family':FAMILY,'workflows':1,'turns':3,'not_whole_workflow_quality_verdict':True});event('stage_trials_finished')
except BaseException as error:save(S/'controller-error.json',{'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()});event('controller_error',error=str(error))
finally:
 signal.alarm(0);errors=[];monitor_stop.set()
 if monitor_thread:monitor_thread.join(150)
 for name in [AGENT,PROXY,LLM,MAIN]:
  try:remove(name)
  except Exception as e:errors.append(str(e))
 try:
  if stopped:
   abort.clear();docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304);docker('start','hermes')
  # Reconcile ambiguous issue-write responses only inside our disposable arenas.
  for arm,arena in (arenas.items()if stopped else []):
   issues=api('GET','repos/chatgpt-codex/'+arena['repo']+'/issues?state=open&limit=50')
   for issue in issues:
    if 'pull_request' not in issue and issue.get('user',{}).get('login')=='hermes-agent':
     api('PATCH','repos/chatgpt-codex/'+arena['repo']+'/issues/'+str(issue['number']),{'state':'closed'})
  after={n:state(n)for n in baseline}
  for n,b in baseline.items():
   assert all(after[n][k]==b[k]for k in ['id','image','signature','running'])
  assert after['hermes-codex']==baseline['hermes-codex']
  if network_id:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network_id and not net['Containers'];docker('network','rm',network_id)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors});event('original_runtime_restored')
 except BaseException as error:save(S/'RESTORATION-ERROR.json',{'error':str(error),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(error))
