"""Prospective experimental-profile amendment, gated on completed live native control."""
from pathlib import Path
import json,hashlib,shutil,os,time
from ruamel.yaml import YAML
D=Path('/state');control=json.loads((D/'native-compression-control-audit.json').read_text());assert control['native']['passed']and not control['native']['used_fallback'];assert control['runtime_restoration']['restored'];assert control['stream_probe']['progress_supported'];assert control['recorded_calls'][0]['actual_progress_frames']>0
names=[k+'-beets_lifecycle'for k in ['fable-q4-thinking','fable-q6-thinking','vibe-q4-thinking','vibe-q6-thinking']];stamp=D/'unused-reasoning-before-compression-amendment';stamp.mkdir(exist_ok=False);results=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Validate the entire set before mutating any config.
for name in names:
 root=D/'profiles'/name;key=name.removesuffix('-beets_lifecycle');assert not list(root.rglob('*.db'));assert not(D/('native-'+key)).exists();assert not(D/f'native-{name}-protocol.json').exists();assert (root/'profile/config.yaml').exists()
for name in names:
 root=D/'profiles'/name;p=root/'profile/config.yaml';manifest=root/'manifest.json';archive=stamp/name;archive.mkdir();shutil.copyfile(p,archive/'config.yaml');shutil.copyfile(manifest,archive/'manifest.json');c=YAML(typ='safe').load(p.read_text());before=sha(p)
 c['compression'].update(context_timeout_seconds=5400,context_total_ceiling_seconds=5400);c.setdefault('auxiliary',{}).setdefault('compression',{}).update(timeout=5400);c['auxiliary']['compression'].setdefault('extra_body',{})['return_progress']=True
 selected=[x for x in c['custom_providers']if x['name']=='wide'];assert len(selected)==1;selected[0].setdefault('extra_body',{})['return_progress']=True
 YAML().dump(c,p.open('w'));m=json.loads(manifest.read_text());m['config_sha256']=sha(p);m['sampler_extra_body']=selected[0]['extra_body'];m['compression_sampler_extra_body']=c['auxiliary']['compression']['extra_body'];m.update(auxiliary_compression_timeout_seconds=5400,context_compression_idle_timeout_seconds=5400,context_compression_total_ceiling_seconds=5400,prompt_progress_requested=True,prospective_runtime_amendment_control_SHA256=sha(D/'native-compression-control-audit.json'));manifest.write_text(json.dumps(m,indent=2)+'\n');results.append({'profile':name,'prior_config_SHA256':before,'new_config_SHA256':sha(p),'new_manifest_SHA256':sha(manifest),'model_calls_started':False});os.chown(p,1000,1000);os.chown(manifest,1000,1000)
receipt={'epoch':time.time(),'classification':'prospective combined runtime amendment; not a quantization quality result','source_SHA256':sha(Path(__file__)),'control_audit_SHA256':sha(D/'native-compression-control-audit.json'),'profiles':results,'old_configs_manifests_preserved_privately':True,'owner_settings_touched':False,'actual_new_profile_preflights_still_required':True}
(D/'reasoning-compression-amendment.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'amended_unused_profiles':len(results),'owner_settings_touched':False,'preflights_required':True}))
