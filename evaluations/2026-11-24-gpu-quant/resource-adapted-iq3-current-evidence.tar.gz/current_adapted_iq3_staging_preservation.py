"""Capture/verify useful staged IQ4 metadata around a future retained-IQ3 stage."""
from pathlib import Path
import json,sys,subprocess,time
D=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ['capture','verify']
code="from pathlib import Path;import json,shutil;p=Path('/stage');print(json.dumps({'files':[{'name':f.name,'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}for f in sorted(p.glob('*.gguf'))],'free_bytes':shutil.disk_usage(p).free}))"
a=['docker','run','--rm','--runtime','runc','--network','none','--read-only','--cap-drop','ALL','--memory','256m','--memory-swap','256m','--cpus','1','--mount','type=volume,source=hermes-gpuquant-20261124-model-stage,target=/stage,readonly','-e','NVIDIA_VISIBLE_DEVICES=void','--entrypoint','python','sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b','-c',code]
x=json.loads(subprocess.check_output(a,text=True,timeout=90));assert x['free_bytes']>=100*1024**3
assert len(x['files'])==1 and x['files'][0]['name']=='Qwen3.8-27B-hermes-IQ4_XS.gguf' and x['files'][0]['bytes']==15321491104
p=D/'current-adapted-iq3-staged-IQ4-preservation-baseline.json'
if mode=='capture':
 assert not p.exists();p.write_text(json.dumps({'epoch':time.time(),**x},indent=2)+'\n')
else:
 assert x['files']==json.loads(p.read_text())['files'];(D/'current-adapted-iq3-staged-IQ4-preservation-after.json').write_text(json.dumps({'epoch':time.time(),'passed':True,**x},indent=2)+'\n')
print(json.dumps({'staged_IQ4_metadata':mode,'reserve_GiB':x['free_bytes']/1024**3,'read_only_no_inference':True}))
