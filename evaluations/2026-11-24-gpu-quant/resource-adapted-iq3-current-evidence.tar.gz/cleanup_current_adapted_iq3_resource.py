"""Exact IQ3 terminal cleanup after strict fresh-baseline preservation; no broad prune."""
from pathlib import Path
import json,subprocess,re,time
D=Path(__file__).resolve().parent;key='adapted-iq3-current';S=D/('resource-'+key)
def docker(*a):return subprocess.check_output(['docker',*a],text=True)
def absent(kind,n):return subprocess.run(['docker',kind,'inspect',n],capture_output=True).returncode!=0
assert json.loads((S/'runtime-restoration.json').read_text())['restored'] and not(S/'RESTORATION-ERROR.json').exists()
assert not(S/'controller-error.json').exists()
assert sum(bool(x.get('resource_probes_completed'))for x in json.loads((S/'finished.json').read_text())['results'])==1
p=json.loads((D/'current-adapted-iq3-resource-preservation.json').read_text());assert p['passed'] and p['Codex_full_recorded_state_unchanged']
assert json.loads((D/'current-adapted-iq3-staged-IQ4-preservation-after.json').read_text())['passed']
h=json.loads((D/'current-adapted-iq3-resource-supervisor.json').read_text());c=json.loads(docker('inspect',h['id']))[0];assert c['Id']==h['id']=='d146da8cf00639ab2917c932b5715808f54ab562b15a3d6458d87996c11c8f59'
assert c['Name']=='/hermes-gpuquant-adapted-iq3-current-resource-supervisor' and c['Config']['Labels']['hermes.gpuquant.study']=='20261124'
assert c['Image']=='sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b'
assert not c['State']['Running'] and c['State']['ExitCode']==0 and not c['State']['OOMKilled']
assert absent('container','hermes-gpuquant-resource-'+key+'-model') and absent('network','hermes-gpuquant-resource-'+key)
assert not docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124').strip()
volumes=[m for m in c['Mounts']if m['Type']=='volume'and re.fullmatch('[a-f0-9]{64}',m['Name'])];assert len(volumes)==1 and volumes[0]['Destination']=='/opt/data';v=volumes[0];assert '/opt/data'in c['Config']['Volumes'] and not any(m.get('Target')=='/opt/data'for m in(c['HostConfig'].get('Mounts')or[]))
refs=docker('ps','-a','-q','--no-trunc','--filter','volume='+v['Name']).split();assert refs==[c['Id']]
(D/'resource-adapted-iq3-current-terminal-supervisor.json').write_text(json.dumps(c,indent=2)+'\n');r=subprocess.run(['docker','logs',c['Id']],capture_output=True,check=True);(D/'resource-adapted-iq3-current-terminal-supervisor.log').write_bytes(r.stdout+r.stderr)
(D/'resource-adapted-iq3-current-owned-anonymous-volume-proof.json').write_text(json.dumps({'epoch':time.time(),'volume':v,'sole_supervisor_reference_verified':True},indent=2)+'\n')
subprocess.run(['docker','rm','-v',c['Id']],capture_output=True,check=True);assert absent('container',c['Id']) and absent('volume',v['Name']);assert not absent('volume','hermes-gpuquant-20261124-model-stage')
out={'epoch':time.time(),'passed':True,'exact_terminated_supervisor_removed':True,'owned_backend_and_network_absent':True,'exclusive_anonymous_optdata_volume_removed':True,'model_stage_preserved':True,'fresh_strict_Codex_and_original_preservation_passed':True,'no_unrelated_container_network_or_volume_changes':True};(D/'resource-adapted-iq3-current-cleanup.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
