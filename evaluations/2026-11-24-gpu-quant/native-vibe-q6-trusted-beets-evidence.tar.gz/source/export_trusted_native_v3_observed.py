"""Sanitized completed-stage observations; failed quality is retained as failure."""
from pathlib import Path
import hashlib,json,shutil,statistics,sys,tarfile
R=Path.cwd();D=R/'.git/hermes-gpu-quant-20261124';E=R/'evaluations/2026-11-24-gpu-quant'
key=sys.argv[1];assert key=='vibe-q6-trusted'
family='beets_lifecycle';label='native-'+key+'-beets';S=D/('native-'+key)/family
final=json.loads((D/(key+'-beets-final-audit.json')).read_text())
assert final['audit_complete'] and final['not_actor_feedback']
assert json.loads((S/'runtime-restoration.json').read_text())['restored']
assert json.loads((S/key/'case-finished.json').read_text())['turns']==3
assert json.loads((D/(label+'-cleanup.json')).read_text())['passed']
X=D/(label+'-export');X.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def write(name,value):
    p=X/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def cp(source,name):
    p=X/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,p)
for suffix in ['Git-flag-control.json','diagnostic-overlap.json','approval-policy-control.json','initial-manual-audit.json','README-manual-audit.json','feature-manual-audit.json','read-control-audit.json','context-instruction-audit.json','publication-independent-readback.json','fork-independent-readback.json','command-dispatch-control.json','final-audit.json']:
    name=key+'-beets-'+suffix;cp(D/name,'audits/'+name)
for suffix in ['preservation.json','owner-preservation.json']:
    name='native-'+key+'-'+family+'-'+suffix;cp(D/name,'audits/'+name)
cp(D/(label+'-cleanup.json'),'audits/cleanup.json')
cp(D/('native-'+key+'-supervisor-exit-state.json'),'runtime/supervisor-exit-state.json')
for name in ['events.jsonl','memory-samples.jsonl','model-identity.json','runtime-before.json','runtime-restoration.json','placement-check.json','selected-file-cache-after-original-stop.json']:
    cp(S/name,'runtime/'+name)
launch=json.loads((S/'backend-launch.json').read_text())
write('runtime/backend-launch.json',{'argv':launch['argv'],'seconds':launch['seconds'],'props':{k:launch['props'][k]for k in ['model_alias','model_path','build_info','default_generation_settings']}})
protocol_file=D/f'native-{key}-{family}-protocol-v3.json';protocol=json.loads(protocol_file.read_text())
safe={k:v for k,v in protocol.items()if k not in ['profile_sha256','code_sha256']}
safe['private_original_protocol_SHA256']=sha(protocol_file.read_bytes())
safe['private_code_fingerprints']={k:v for k,v in protocol['code_sha256'].items()if not k.startswith(('baseline/','profiles/'))}
safe['profile_manifest_excluded']=True;write('controls/protocol.json',safe)
write('controls/immutable-baseline-source-sha256.json',{str(p.relative_to(D/'baseline')):sha(p.read_bytes())for p in sorted((D/'baseline').rglob('*'))if p.is_file()and'__pycache__'not in p.parts})
for name in ['trusted_native_controller_v3.py','resolve_native_oneshot.py','native_seeded_compression_handle_preflight_v3.py','prepare_trusted_profile.py','probe_trusted_profile_code.py','model_cache_probe.py','audit_test_adequacy.py','audit_trusted_originals_after_stage.py','audit_beets_command_dispatch_published.py','read_trusted_actor_fork.py','export_trusted_native_v3_observed.py','scan_native_public.py','run_native_scan.py']:
    cp(D/name,'source/'+name)
cp(D/'nicotine-dispatch-primary-source/pins.json','controls/upstream-dispatch-pins.json')
cp(S/key/'before-coding-source-admission.json','controls/fresh-coding-source-admission.json')
cp(D/'vibe-accounting-preactor-amendment.json','controls/vibe-accounting-preactor-amendment.json')
cp(D/'native-lineage-owner-v3-decision.json','controls/native-lineage-owner-v3-decision.json')
cp(D/'native-seeded-compression-handle-preflight-v3.json','controls/native-seeded-compression-handle-preflight-v3.json')
cache=D/(key+'-poststage-file-cache-observation.json')
if cache.exists():cp(cache,'controls/poststage-file-cache-observation.json')
metrics=[]
for p in sorted((S/'llm-records').glob('*.metrics.json')):
    m=json.loads(p.read_text());request=p.with_name(p.name.replace('.metrics.json','.request.json'));response=p.with_name(p.name.replace('.metrics.json','.response.txt'))
    raw=response.read_bytes();complete=raw.rstrip().endswith(b'data: [DONE]')
    if not complete and raw.lstrip().startswith(b'{'):
        try:complete=bool(json.loads(raw).get('choices'))
        except ValueError:pass
    row={k:m[k]for k in ['id','received_epoch','request_sha256','backend_start_epoch','end_epoch','usage','finish_reasons']if k in m}
    row.update(private_original_metrics_SHA256=sha(p.read_bytes()),private_saved_request_file_SHA256=sha(request.read_bytes()),private_response_SHA256=sha(raw),backend_body_complete=bool(complete and not m.get('response_parse_failed')),transport_error_present=bool(m.get('transport_error')),raw_capture_excluded=True)
    metrics.append(row);write('requests/'+p.name,row)
phases=[]
for phase in range(3):
    root=S/key/f'turn{phase}';run=json.loads((root/'run.json').read_text())
    safe={k:run[k]for k in ['family','arm','phase','elapsed_seconds','exit_code','external_timeout','query_sha256']}
    safe['native_session_fingerprints']={k:sha(run[k].encode())if run.get(k)else None for k in ['logical_root','incoming_sid','effective_sid','cli_resume_handle']}
    write(f'phases/{phase}/run.json',safe);grades={}
    for kind in ['local-grade','remote-grade']:
        g=root/kind/'grade.json'
        if not g.exists():
            assert kind=='remote-grade' and 'clone'not in json.loads((root/'forge-snapshot.json').read_text())
            continue
        grade=json.loads(g.read_text());grades[kind]=grade;write(f'phases/{phase}/{kind}/grade.json',grade)
        source=root/kind/'source';write(f'phases/{phase}/{kind}/source-sha256.json',{str(p.relative_to(source)):sha(p.read_bytes())for p in sorted(source.rglob('*'))if p.is_file()})
        for name in ['project.log','preservation.log']:cp(root/kind/name,f'phases/{phase}/{kind}/'+name)
    forge=json.loads((root/'forge-snapshot.json').read_text());out={'scope_state':forge.get('scope_state',{}),'phase':phase}
    for name in ['issue','pr']:
        if name in forge:
            obj=forge[name];out[name]={k:obj[k]for k in ['number','state','merged','title']if k in obj}
            if name=='pr':out[name].update(head={'sha':obj['head']['sha'],'ref':obj['head']['ref'],'repo':obj['head']['repo']['full_name']},base={'sha':obj['base']['sha'],'ref':obj['base']['ref'],'repo':obj['base']['repo']['full_name']})
    if 'clone'in forge:out['clone']={k:forge['clone'][k]for k in ['name','head','tree']}
    write(f'phases/{phase}/forge-readback.json',out)
    phases.append({**safe,'local_grade':grades['local-grade'],'remote_grade':grades.get('remote-grade'),'remote_grade_absent':'remote-grade'not in grades,'forge':out})
for phase in [0,2]:
    control=D/f'{key}-{family}-phase{phase}-test-adequacy'
    if control.exists():
        for p in sorted(control.rglob('*')):
            if p.is_file()and 'source'not in p.relative_to(control).parts and p.suffix in ['.json','.log']:cp(p,'controls/'+control.name+'/'+str(p.relative_to(control)))
rows=[json.loads(line)for line in(S/'memory-samples.jsonl').read_text().splitlines()]
good=[r for r in rows if all(k in r for k in ['total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes','host'])]
assert good
latency=[m['end_epoch']-m['backend_start_epoch']for m in metrics if m['backend_body_complete']and not m['transport_error_present']]
supervisor=json.loads((D/('native-'+key+'-supervisor.json')).read_text())
restored=next(x['epoch']for x in [json.loads(line)for line in(S/'events.jsonl').read_text().splitlines()]if x['kind']=='original_runtime_restored')
summary={'classification':'fresh_explicitly_trusted_nonthinking_comparison','candidate_key':key,'family':family,'model':json.loads((S/'model-identity.json').read_text()),'phases':phases,'coding_elapsed_seconds':sum(p['elapsed_seconds']for p in phases),'whole_supervised_stage_seconds':restored-supervisor['launched_epoch'],'read_only_control_seconds':json.loads((S/key/'turn-1/run.json').read_text())['elapsed_seconds'],'independent_final_audit':final,'measurements':{'sample_count':len(rows),'complete_aggregate_sample_count':len(good),'measurement_error_sample_count':sum('measurement_error'in r for r in rows),'peak_GPU_MiB':max(int(r['gpu_csv'].split(',')[0])for r in good if r.get('gpu_csv')),'peak_observed_cgroup_bytes':max(r['total_cgroup_bytes']for r in good),'peak_observed_all_process_PSS_bytes':max(r['total_process_pss_bytes']for r in good),'peak_observed_experiment_swap_bytes':max(r['total_cgroup_swap_bytes']for r in good),'resource_guard_samples':sum(bool(r.get('budget_guard_triggered'))for r in rows),'minimum_model_disk_free_bytes':min(r['model_disk_free_bytes']for r in good),'global_pswpin_delta_pages':good[-1]['host']['pswpin_pages']-good[0]['host']['pswpin_pages'],'global_pswpout_delta_pages':good[-1]['host']['pswpout_pages']-good[0]['host']['pswpout_pages'],'global_swap_not_attributed_to_model':True,'HTTP_records':len(metrics),'completed_HTTP_records_without_transport_error':len(latency),'maximum_completed_prompt_tokens':max(m.get('usage',{}).get('prompt_tokens',0)for m in metrics if m['backend_body_complete']),'HTTP_latency_seconds':{'min':min(latency),'median':statistics.median(latency),'max':max(latency),'sum':sum(latency)},'sampling_not_continuous_whole_host_bound':True,'not_isolated_decode_throughput':True},'comparison_limits':['One fresh native coding lineage with dependent followups; read control is separate.','Matched sampler/seed within checkpoint; seed does not isolate precision causally.','Current baseline disables thinking; publisher reasoning mode remains a separately registered comparison.','Internal actor network permits selected checkout and scoped configured MCP, but external terminal Git/DNS is blocked. Unrestricted-network performance is unmeasured.','Actual CLI includes normal skills and 33 tools, a larger schema than explicit-subset transport preflight.','Native budget-message presence is audited per candidate; no operator resend, continuation or private grader feedback.','Actual prompt size and context composition are audited per candidate; neither allocation nor literal retention proves useful whole-window reasoning.','Private source snapshots, raw requests/responses, profiles, session DBs, graders, references and signing keys stay local. Saved-evidence consistency verification does not rerun the private workflow or prove behavior correct.']}
write('summary.json',summary)
write('privacy-boundary.json',{'excluded':['Raw primary/auxiliary requests and responses','Native consoles and verbose model logs','Profiles, session databases and owner instructions','Task text, private graders and reference implementations','Credentials and signing keys','Full private project source'],'included':'Numeric runtime observations, selected timing/usage/fingerprints, source hashes, project/original-suite logs and independent source/docs/claims/publication audits.'})
manifest={str(p.relative_to(X)):sha(p.read_bytes())for p in sorted(X.rglob('*'))if p.is_file()};write('manifest.json',manifest)
archive=E/(label+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz')as tar:
    for p in sorted(X.rglob('*')):
        if p.is_file():tar.add(p,arcname=str(p.relative_to(X)),recursive=False)
(E/(label+'-evidence.sha256')).write_text(sha(archive.read_bytes())+'  '+archive.name+'\n')
(E/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'files':len(manifest)+1,'archive_bytes':archive.stat().st_size,'archive_SHA256':sha(archive.read_bytes()),'coding_seconds':summary['coding_elapsed_seconds'],'measurements':summary['measurements']}))
