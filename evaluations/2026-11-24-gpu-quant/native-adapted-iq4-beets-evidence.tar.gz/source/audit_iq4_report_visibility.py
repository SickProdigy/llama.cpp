"""Run after timed GPU trial: actual result handler during normal/disabled/re-enabled finishes."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,types,time
from unittest.mock import patch
class DeferredThread:
 instances=[]
 def __init__(self,target,args=(),kwargs=None,**options):
  self.target=target;self.args=args;self.kwargs=kwargs or {};self.__class__.instances.append(self)
 def start(self):pass
 def run(self):self.target(*self.args,**self.kwargs)
D=Path(__file__).resolve().parent;S=D/'native-adapted-iq4/beets_lifecycle';assert json.loads((S/'runtime-restoration.json').read_text())['restored'];record=json.loads((D/'native-adapted-iq4-supervisor.json').read_text());state=json.loads(subprocess.check_output(['docker','inspect',record['id']],text=True))[0]['State'];assert not state['Running']
results=[]
for phase in [1,2]:
 source=S/'adapted-iq4'/f'turn{phase}/local-grade/source';spec=importlib.util.spec_from_file_location('visibility_fixture',D/'baseline/tests/test_beetsbridge.py');fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture);fixture.PLUGIN_PATH=source/'beetsbridge/__init__.py'
 for mode in ['normal','disable_during_import','disable_then_reenable_during_import']:
  module,events=fixture.load_plugin_module();p=module.Plugin();p.settings=dict(module.Plugin.settings);p.loaded_notification();logs=[];p.log=lambda *args:logs.append(args);completed=[]
  def run(folder):
   if mode!='normal':p.disable()
   if mode=='disable_then_reenable_during_import':p.loaded_notification();logs.clear()
   completed.append(str(folder));return types.SimpleNamespace(returncode=0,stdout='completed')
  p._make_runner=lambda:types.SimpleNamespace(import_folder=run);DeferredThread.instances.clear()
  with patch.object(module.threading,'Timer',fixture.FakeTimer):p._schedule(Path('/downloads/Running'),delay=0)
  timer=fixture.FakeTimer.instances[-1]
  with patch.object(module.threading,'Thread',DeferredThread):timer.callback(*timer.args)
  assert len(DeferredThread.instances)==1;DeferredThread.instances[0].run();assert completed==['/downloads/Running'];assert len(events.invocations)==1
  results.append({'phase':phase,'mode':mode,'import_finished':True,'actual_main_thread_dispatches':len(events.invocations),'actual_log_calls':len(logs),'actual_source_SHA256':hashlib.sha256(fixture.PLUGIN_PATH.read_bytes()).hexdigest(),'not_actor_feedback':True})
assert next(r for r in results if r['phase']==1 and r['mode']=='disable_during_import')['actual_log_calls']==0
out={'epoch':time.time(),'passed':True,'actual_candidate_handler_used':True,'actual_schedule_and_timer_entrypoints_used_without_hardcoded_worker_signature':True,'fake_runner_and_main_thread_fixture_no_real_beets_or_GUI':True,'observed_readme_phase1_exit_status_claim_contradicted':True,'not_actor_feedback':True,'results':results};(D/'adapted-iq4-beets-report-visibility-control.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
