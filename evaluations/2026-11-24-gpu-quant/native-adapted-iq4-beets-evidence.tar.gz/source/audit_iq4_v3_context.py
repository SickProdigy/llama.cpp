"""Audit actual CLI handles, physical lineage and context; summaries are not literal retention."""
from pathlib import Path
import json,hashlib,sqlite3,statistics,sys,time,re
D=Path(__file__).resolve().parent;key=sys.argv[1];assert key=='adapted-iq4';S=D/('native-'+key)/'beets_lifecycle';params=json.loads((D/'profile-parameters'/f'{key}-beets_lifecycle.json').read_text());tasks=json.loads((D/'tasks.json').read_text())['families']['beets_lifecycle'];events=[json.loads(l)for l in(S/'events.jsonl').read_text().splitlines()];sha=lambda b:hashlib.sha256(b).hexdigest()
requests=[];extras={};incomplete=[];summary_prefix='You are a summarization agent creating a context checkpoint.'
for p in sorted((S/'llm-records').glob('*.metrics.json')):
 m=json.loads(p.read_text());q=p.with_name(p.name.replace('.metrics.json','.request.json'));r=p.with_name(p.name.replace('.metrics.json','.response.txt'));b=json.loads(q.read_text());raw=r.read_bytes();complete=raw.rstrip().endswith(b'data: [DONE]')
 if not complete and raw.lstrip().startswith(b'{'):
  try:complete=bool(json.loads(raw).get('choices'))
  except ValueError:pass
 summary=any(x['role']=='system'and str(x.get('content','')).startswith(summary_prefix)for x in b['messages'])
 m['_audit_complete']=bool(complete and not m.get('transport_error')and not m.get('response_parse_failed'))
 if not m['_audit_complete']:incomplete.append({'metrics_file':p.name,'request_file':q.name,'native_summary':summary,'transport_error':m.get('transport_error'),'response_parse_failed':bool(m.get('response_parse_failed')),'elapsed_backend_seconds':m['end_epoch']-m['backend_start_epoch'],'runtime_classification':'Confirmed300second native compression stall; native deterministic fallback after retry49'if summary and m['id']in [47,49] else 'Requires independent runtime classification'})
 assert b['model']==params['alias']and b['max_tokens']==params['max_tokens']
 for name,value in params['sampler'].items():assert b[name]==value,(p.name,name)
 for msg in b['messages']:
  if msg['role']!='user':continue
  u=str(msg.get('content',''))
  if any(task in u for task in tasks)or'Find the selected repository through its configured forge'in u:continue
  if summary:kind='native_summarization_instruction'
  elif u.startswith('[CONTEXT COMPACTION'):kind='native_compacted_summary'
  elif u.startswith("You've reached the maximum number of tool-calling iterations allowed."):kind='native_iteration_limit_instruction'
  else:kind='requires_manual_classification'
  extras[sha(u.encode())]=kind
 requests.append((m,b,q,summary))
phases=[];previous_handle=None;root=None
for phase in [-1,0,1,2]:
 out=S/key/f'turn{phase}';run=json.loads((out/'run.json').read_text());start=next(x['epoch']for x in events if x['kind']=='turn_start'and x.get('phase')==phase);end=next(x['epoch']for x in events if x['kind']=='turn_end'and x.get('phase')==phase)
 main=[x for x in requests if start<=x[0]['received_epoch']<=end and not x[3]and x[0]['_audit_complete']];assert main,'No completed main-model request in phase'
 m,b,p,_=main[-1];db=sqlite3.connect((out/'state.db').resolve().as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row;nodes={r['id']:dict(r)for r in db.execute('select id,parent_session_id,source,started_at,ended_at,end_reason from sessions')};query='Find the selected repository through its configured forge and briefly explain what it contains.'if phase==-1 else tasks[phase]
 first=db.execute('select session_id from messages where role=?and content=? order by id asc limit 1',('user',query)).fetchone();assert first
 if phase in [-1,0]:root=first['session_id'];previous_handle=None
 assert run['logical_root']==root and run['incoming_sid']==previous_handle
 chain=[];current=run['effective_sid'];seen=set()
 while True:
  assert current not in seen;seen.add(current);node=nodes[current];assert node['source']=='oneshot';chain.append(node)
  if current==root:break
  parent=nodes[node['parent_session_id']];assert parent['end_reason']=='compression'and parent['started_at']<=node['started_at'];current=parent['id']
 chain=list(reversed(chain));assert chain==run['lineage']
 children=[n for n in nodes.values()if n['parent_session_id']==run['effective_sid']];assert not children,'Recorded effective SID is not the actual physical leaf'
 handles=re.findall(r'(?m)^session_id:\s*([A-Za-z0-9_-]+)\s*$',(out/'console.log').read_text());assert handles and handles[-1]==run['cli_resume_handle'];assert run['cli_resume_handle']in[n['id']for n in chain]
 previous_handle=run['cli_resume_handle'];users=[str(x.get('content',''))for x in b['messages']if x['role']=='user'];present=[any(task in u for u in users)for task in(tasks[:phase+1]if phase>=0 else[query])];summaries=[str(x.get('content',''))for x in b['messages']if str(x.get('content','')).startswith('[CONTEXT COMPACTION')]
 row={'phase':phase,'completed_phase':True,'completed_HTTP':len(main),'user_role_messages':len(users),'all_tasks_so_far_present_verbatim':present,'last_complete_request':p.name,'saved_request_JSON_sha256':sha(p.read_bytes()),'wire_request_SHA256':m['request_sha256'],'last_complete_prompt_tokens':(m.get('usage')or{}).get('prompt_tokens'),'last_request_matches_last_complete':p.name==[x[2].name for x in requests if start<=x[0]['received_epoch']<=end and not x[3]][-1],'literal_presence_not_attention_proof':True,'native_handoff_verified_from_actual_CLI_output_and_DB':True,'native_compression_segment_count':len(chain),'physical_effective_SID_SHA256':sha(run['effective_sid'].encode()),'CLI_resume_handle_SHA256':sha(run['cli_resume_handle'].encode()),'incoming_CLI_handle_SHA256':sha(run['incoming_sid'].encode())if run['incoming_sid']else None,'native_summary_messages_SHA256':[sha(u.encode())for u in summaries],'native_summary_message_roles':[x['role']for x in b['messages']if str(x.get('content','')).startswith('[CONTEXT COMPACTION')],'summary_semantic_coverage_requires_manual_audit':not all(present),'missing_literal_tasks_not_a_harness_error_if_native_summary':not all(present)and bool(summaries)}
 if not all(present):assert len(chain)>1 and summaries,'Missing task without native compaction needs separate investigation'
 phases.append(row);db.close()
lat=[m['end_epoch']-m['backend_start_epoch']for m,_,_,_ in requests if m['_audit_complete']];report={'epoch':time.time(),'audit_complete':True,'not_actor_feedback':True,'phases':[x for x in phases if x['phase']>=0],'read_control':phases[0],'all_HTTP_complete':not incomplete,'incomplete_HTTP_records':incomplete,'completed_HTTP_records':len(requests)-len(incomplete),'HTTP_records':len(requests),'actual_sampler_and_caps_verified_every_request':True,'compression_requests_observed':sum(x[3]for x in requests),'compression_classification':'Actual native summary requests counted; CLI receipt-owner handle and physical transcript tip independently verified. Literal retention and summary semantic coverage are separate. Missing summarized instructions are model/profile context behavior, not automatically a wrong harness resume.','largest_completed_prompt_tokens':max((m.get('usage')or{}).get('prompt_tokens',0)for m,_,_,_ in requests if m['_audit_complete']),'extra_user_role_messages_SHA256':sorted(extras),'extra_user_role_messages_classified':extras,'extra_messages_require_manual_classification':any(v=='requires_manual_classification'for v in extras.values()),'operator_continuations_or_corrective_hints':0,'backend_seconds':{'min':min(lat),'median':statistics.median(lat),'max':max(lat),'sum':sum(lat)},'latency_scope':'Backend interval statistics cover completed requests; incomplete intervals are retained separately. Phase and total wall times include failures and native compression. Not isolated decode throughput.','context_limitations':'No whole-window reasoning claim. Inspect actual private summaries if literal tasks are missing; task correctness is independently audited against unchanged requirements.'}
(D/(key+'-beets-context-instruction-audit.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
