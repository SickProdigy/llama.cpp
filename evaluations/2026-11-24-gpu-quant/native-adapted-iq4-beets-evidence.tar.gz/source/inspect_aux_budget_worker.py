"""No model calls. Inspect actual native getters on a scratch copy only."""
from pathlib import Path
import sys,os,json,hashlib,contextlib
from ruamel.yaml import YAML
variant=sys.argv[1];assert variant in ['baseline','extended_aux_budget'];source=Path('/state/profiles/adapted-iq4-beets_lifecycle/profile/config.yaml');before=hashlib.sha256(source.read_bytes()).hexdigest();home=Path('/tmp/aux-budget-'+variant);home.mkdir();(home/'config.yaml').write_bytes(source.read_bytes());os.environ['HERMES_HOME']=str(home);sys.path.insert(0,'/opt/hermes')
if variant=='extended_aux_budget':
 c=YAML(typ='safe').load((home/'config.yaml').read_text());c.setdefault('auxiliary',{}).setdefault('compression',{})['timeout']=5400;c.setdefault('compression',{}).update(context_timeout_seconds=5400,context_total_ceiling_seconds=5400);YAML().dump(c,(home/'config.yaml').open('w'))
with contextlib.redirect_stdout(sys.stderr):
 from hermes_cli.timeouts import get_provider_request_timeout
 from agent.auxiliary_client import _effective_aux_timeout
 from agent.conversation_compression_deadline import resolve_context_compression_timeouts
 from agent.auxiliary_managed_local import _is_managed_local_endpoint
 aux=_effective_aux_timeout('compression',None);idle,ceiling=resolve_context_compression_timeouts();main=get_provider_request_timeout('custom:wide','gpuquant-adapted-iq4');managed=_is_managed_local_endpoint('http://wide-llm:11431/v1')
assert (aux,idle,ceiling)==((300,300,600)if variant=='baseline'else(5400,5400,5400));assert main==5400;assert not managed;assert hashlib.sha256(source.read_bytes()).hexdigest()==before
print(json.dumps({'passed':True,'variant':variant,'main_provider_timeout_seconds':main,'actual_auxiliary_compression_timeout_seconds':aux,'actual_context_idle_seconds':idle,'actual_context_ceiling_seconds':ceiling,'custom_proxy_recognized_as_Hermes_managed_endpoint':managed,'original_profile_config_unchanged':True,'model_inference':False,'not_backend_progress_compatibility_or_slow_native_compression_success_proof':True}))
