"""Scripted OpenAI-compatible responses through the real native CLI and persistence."""
from pathlib import Path
import os,sys,json,time,threading,subprocess,sqlite3,hashlib,re,shutil,stat
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
sys.path.insert(0,'/opt/hermes')
import hermes_yaml as yaml
O=Path('/results');home=Path('/opt/data');shutil.copytree('/input-profile',home,ignore=lambda directory,names:[n for n in names if stat.S_ISSOCK((Path(directory)/n).lstat().st_mode)],dirs_exist_ok=True);
for filename in ['gateway.pid','gateway.lock','gateway.sock']:
 (home/filename).unlink(missing_ok=True)
shutil.copyfile('/read-snapshot',home/'state.db');
for filename in ['state.db-wal','state.db-shm']:(home/filename).unlink(missing_ok=True)
work=Path('/tmp/lineage-control-work');work.mkdir()
alias='gpuquant-vibe-q4-trusted';requests=[];lock=threading.Lock()
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def answer(self,body):
  data=json.dumps(body).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):self.answer({'object':'list','data':[{'id':alias,'object':'model'}]})
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  with lock:
   requests.append(body);number=len(requests);(O/('request-'+str(number)+'.json')).write_text(json.dumps(body,indent=2))
  summary=any(m.get('role')=='system'and str(m.get('content','')).startswith('You are a summarization agent creating a context checkpoint.')for m in body['messages'])
  if summary:
   delta={'role':'assistant','content':'Earlier user requested FIRST_MARKER. Assistant completed the harmless first control. Preserve FIRST_MARKER for subsequent turns.'};finish='stop'
  else:
   delta={'role':'assistant','content':'CONTROL_FOLLOWUP_1 CONTROL_FOLLOWUP_2 acknowledged.'};finish='stop'
  if body.get('stream'):
   chunks=[{'id':'history-control','object':'chat.completion.chunk','created':0,'model':alias,'choices':[{'index':0,'delta':delta,'finish_reason':None}]},{'id':'history-control','object':'chat.completion.chunk','created':0,'model':alias,'choices':[{'index':0,'delta':{},'finish_reason':finish}],'usage':{'prompt_tokens':100,'completion_tokens':10,'total_tokens':110}}]
   data=(''.join('data: '+json.dumps(v)+'\n\n' for v in chunks)+'data: [DONE]\n\n').encode();self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  else:self.answer({'id':'history-control','object':'chat.completion','created':0,'model':alias,'choices':[{'index':0,'message':delta,'finish_reason':finish}],'usage':{'prompt_tokens':100,'completion_tokens':10,'total_tokens':110}})
server=ThreadingHTTPServer(('127.0.0.1',11431),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();url='http://wide-llm:11431/v1';extra={'temperature':.7,'top_p':1,'top_k':0,'min_p':0,'repeat_penalty':1,'presence_penalty':0,'max_tokens':16384,'chat_template_kwargs':{'enable_thinking':True,'clear_thinking':False}}
config={'model':{'default':alias,'provider':'custom:wide','base_url':url,'api_key':'local-wide-evaluation-only','context_length':65536,'max_tokens':16384},'custom_providers':[{'name':'wide','base_url':url,'api_key':'local-wide-evaluation-only','model':alias,'extra_body':extra}],'providers':{'custom:wide':{'request_timeout_seconds':30,'stale_timeout_seconds':30}},'plugins':{'enabled':[]},'mcp_servers':{},'tools':{'tool_search':{'enabled':'off'}},'terminal':{'backend':'local','cwd':str(work),'timeout':10},'platform_toolsets':{'cli':['terminal']},'memory':{'enabled':False},'title_generation':{'enabled':False,'model_upgrade_enabled':False},'compression':{'enabled':True,'threshold':.85},'agent':{'max_turns':5,'run_budget_seconds':90,'gateway_timeout':150}}
(home/'config.yaml').write_text(yaml.safe_dump(config));env=dict(os.environ,HOME=str(home),HERMES_HOME=str(home),HERMES_WRITE_SAFE_ROOT=str(work)+':'+str(home/'cache/scratch'),PYTHONDONTWRITEBYTECODE='1')
first='Find the selected repository through its configured forge and briefly explain what it contains.'
follow='For this isolated persistence control, acknowledge only CONTROL_FOLLOWUP_1.'
third='For this isolated persistence control, acknowledge CONTROL_FOLLOWUP_2 and retain CONTROL_FOLLOWUP_1.'
runs=[]
db=sqlite3.connect(home/'state.db');db.row_factory=sqlite3.Row;segments_before=[dict(r)for r in db.execute('select id,parent_session_id,source,started_at,end_reason from sessions order by started_at')];root=db.execute('select session_id from messages where role=?and content=? order by id asc limit 1',('user',first)).fetchone()[0];db.close();assert len(segments_before)==2 and segments_before[0]['end_reason']=='compression'
def cli(query,sid):
 z=subprocess.run(['/opt/hermes/bin/hermes','chat','--cli','--oneshot','-Q','--query-file','-','--in','/workspace','--accept-hooks','--resume',sid],input=query,capture_output=True,text=True,env=env,timeout=150);text=z.stdout+z.stderr;(O/('cli-'+str(len(runs))+'.log')).write_text(text);assert z.returncode==0,text[-1800:]
 matches=re.findall(r'(?m)^session_id:\s*([A-Za-z0-9_-]+)\s*$',text);assert matches,text[-500:];handle=matches[-1];runs.append({'query':query,'incoming_CLI_handle':sid,'emitted_CLI_handle':handle,'exit_code':z.returncode});return handle
sid=root
for query in [follow,third]:
 db=sqlite3.connect(home/'state.db');before=repr(db.execute('select * from messages order by id').fetchall());db.close()
 z=subprocess.run(['/opt/hermes/bin/hermes','sessions','discard',sid,'--yes'],capture_output=True,text=True,env=env,timeout=60);assert z.returncode==0,z.stderr[-700:]
 db=sqlite3.connect(home/'state.db');assert repr(db.execute('select * from messages order by id').fetchall())==before;db.close();sid=cli(query,sid)
normal=[b for b in requests if not any(m.get('role')=='system'and str(m.get('content','')).startswith('You are a summarization agent creating a context checkpoint.')for m in b['messages'])];assert len(normal)==2
assert follow in json.dumps(normal[0]['messages']) and third in json.dumps(normal[1]['messages']) and follow in json.dumps(normal[1]['messages'])
assert 'CONTEXT COMPACTION'in json.dumps(normal[0]['messages']) and 'Nicotine'in json.dumps(normal[0]['messages'])
db=sqlite3.connect(home/'state.db');db.row_factory=sqlite3.Row;segments_after=[dict(r)for r in db.execute('select id,parent_session_id,source,started_at,end_reason from sessions order by started_at')];db.close()
out={'passed':True,'native_CLI_processes':2,'scripted_HTTP_responses':len(requests),'actual_scored_read_control_compression_seeded_into_scratch':True,'runs':runs,'actual_native_segments_before':segments_before,'actual_native_segments_after':segments_after,'followup_after_actual_compression_and_third_turn_verified':True,'logical_CLI_resume_handle_distinguished_from_physical_segment':True,'native_discard_preserved_all_message_rows':True,'model_inference':False,'forge_actions':False,'owner_or_scored_profile_modified':False,'scope':'Scratch copy of completed actual compressed read session, two new CLI followups with scripted HTTP responses. Earlier failed force-compression attempts retained, not successful controls or model results.'};(O/'result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));server.shutdown()
