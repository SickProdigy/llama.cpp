"""Post-terminal preservation and exact owned cleanup; never stops an active run."""
from pathlib import Path
import json,subprocess,time
D=Path(__file__).resolve().parent;S=D/'resource-adapted-iq4-current'
h=json.loads((D/'current-adapted-iq4-resource-supervisor.json').read_text())
ident=h['id'];expected='hermes-gpuquant-adapted-iq4-current-resource-supervisor'
def run(*args):return subprocess.run(list(args),capture_output=True,text=True,timeout=120)
z=run('docker','inspect',ident);assert z.returncode==0,z.stderr[-500:]
x=json.loads(z.stdout)[0]
assert x['Id']==ident and x['Name']=='/'+expected
assert x['Config']['Labels']['hermes.gpuquant.study']=='20261124'
assert x['Image']=='sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b'
assert x['State']['Status']=='exited'and not x['State']['Running'],'Run remains active; do not interrupt/restart'
assert not x['State']['OOMKilled']
assert (S/'runtime-restoration.json').exists() and json.loads((S/'runtime-restoration.json').read_text())['restored']
assert not(S/'RESTORATION-ERROR.json').exists()
z=run('python3',str(D/'audit_current_adapted_iq4_resource_originals.py'),'current-adapted-iq4-resource')
(D/'current-adapted-iq4-resource-preservation-driver.log').write_text(z.stdout+z.stderr)
assert z.returncode==0,z.stderr[-1000:]
assert json.loads((D/'current-adapted-iq4-resource-preservation.json').read_text())['passed']
(D/'current-adapted-iq4-resource-terminal-supervisor.json').write_text(json.dumps({'id':ident,'state':x['State']},indent=2)+'\n')
z=run('docker','logs',ident);assert z.returncode==0
(D/'current-adapted-iq4-resource-terminal-supervisor.log').write_text(z.stdout+z.stderr)
for kind,name in [('container','hermes-gpuquant-resource-adapted-iq4-current-model'),('network','hermes-gpuquant-resource-adapted-iq4-current')]:
 z=run('docker',kind,'inspect',name)
 assert z.returncode==1 and name in z.stderr and any(t in z.stderr.lower()for t in ['no such','not found']),(kind,name,'Still present or observation error')
z=run('docker','rm',ident);assert z.returncode==0 and z.stdout.strip()==ident
z=run('docker','ps','-q','--filter','label=hermes.gpuquant.study=20261124');assert z.returncode==0 and not z.stdout.strip()
out={'epoch':time.time(),'passed':True,'terminal_supervisor_removed':ident,'exact_ownership_verified':True,'owned_backend_and_network_absent':True,'original_preservation_audit_passed':True,'other_active_study_jobs_absent':True,'not_model_quality_claim':True}
(D/'resource-adapted-iq4-current-cleanup.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
