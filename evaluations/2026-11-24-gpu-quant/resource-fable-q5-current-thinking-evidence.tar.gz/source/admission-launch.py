"""Fresh post-download header/storage/owner admission, then freeze and launch one resource stage."""
from pathlib import Path
import ast,hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;R=D.parent.parent
EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-gpu-quant-20261124'
I='sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b';key='fable-q5-current-thinking';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((D/'fable-q5-public-download-completion-and-cleanup.json').read_text())['passed']
assert json.loads((D/'cold-current-adapted-iq3-cleanup.json').read_text())['passed']
assert not subprocess.check_output(['docker','ps','-q','--filter','label=hermes.gpuquant.study=20261124']).strip()
assert not(D/('resource-'+key)).exists()and not(D/'current-fable-q5-resource-controller-registration.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=R,text=True).split()[0]
def helper(script,memory='256m'):
 a=['docker','run','--rm','--runtime','runc','--network','none','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--memory',memory,'--memory-swap',memory,'--cpus','1','--volumes-from','llama-cpp:ro','--mount','type=volume,source=hermes-gpuquant-20261124-model-stage,target=/stage,readonly','--mount','type=bind,source='+EP+',target=/state','-e','NVIDIA_VISIBLE_DEVICES=void','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',I]
 r=subprocess.run(a+script,capture_output=True,text=True,timeout=180);assert r.returncode==0,r.stderr[-800:];return json.loads(r.stdout)
probe="from pathlib import Path;import shutil,json;print(json.dumps({'original_free_bytes':shutil.disk_usage('/models').free,'stage_free_bytes':shutil.disk_usage('/stage').free,'stage_files':[{'name':p.name,'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}for p in sorted(Path('/stage').glob('*.gguf'))]}))"
admit=helper(['-c',probe]);assert admit['original_free_bytes']>=100*1024**3 and admit['stage_free_bytes']>=105*1024**3,'Fresh disk admission insufficient; no GPU call or owner stop'
admit.update(epoch=time.time(),passed=True,no_GPU_calls=True,minimum_stage_admission_bytes=105*1024**3,stage_abort_bytes=102*1024**3);(D/'current-fable-q5-resource-storage-admission.json').write_text(json.dumps(admit,indent=2)+'\n')
helper(['/state/inspect_fable_q5_header.py'])
r=subprocess.run(['python3',str(D/'compare_public_fable_q5_headers.py')],capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stderr[-600:]
comparison=json.loads((D/'current-fable-q4-q5-q6-q8-header-comparison.json').read_text());assert comparison['same_shapes_template_count'],'Different public artifacts require manual comparison review before capacity'
subprocess.run(['python3',str(D/'capture_current_fable_q5_resource_baseline.py')],cwd=R,check=True)
controller=D/'current_fable_q5_resource_controller.py';s=controller.read_text();marker="assert hashlib.sha256((D/'model_cache_probe.py').read_bytes()).hexdigest()==registration['cache_helper_sha256']"
assert marker in s
s=s.replace(marker,marker+"\n for relative,digest in P['admission_sha256'].items():assert hashlib.sha256((D/relative).read_bytes()).hexdigest()==digest,relative")
ast.parse(s);controller.write_text(s)
p=D/'current-fable-q5-resource-protocol.json';P=json.loads(p.read_text());P.update(registered_epoch=time.time(),classification='Registered public FableQ5 capacity only after completed pinned transfer/header/fresh-owner/storage admission; no prior inference',reference_stage_not_launched=True)
bindings=['launch_current_fable_q5_resource.py','prepare_current_fable_q5_resource_sources.py','capture_current_fable_q5_resource_baseline.py','inspect_fable_q5_header.py','compare_public_fable_q5_headers.py','fable-q5-header-audit.json','current-fable-q4-q5-q6-q8-header-comparison.json','current-fable-q5-resource-storage-admission.json','fable-q5-download-receipt.json','fable-q5-public-download-completion-and-cleanup.json','baseline-20261127-before-current-fable-q5-resource/runtime.json','baseline-20261127-before-current-fable-q5-resource/owner.json']
for n in bindings:
 if n.endswith('.py'):ast.parse((D/n).read_text())
P['admission_sha256']={n:sha(D/n)for n in bindings};p.write_text(json.dumps(P,indent=2)+'\n')
reg={'registered_epoch':time.time(),'controller_sha256':sha(controller),'protocol_sha256':sha(p),'cache_helper_sha256':sha(D/'model_cache_probe.py'),'not_launched':True,'download_cleanup_header_owner_storage_admitted':True,'no_fit_or_quality_result':True}
(D/'current-fable-q5-resource-controller-registration.json').write_text(json.dumps(reg,indent=2)+'\n')
a=json.loads((D/'current-fable-q6-resource-supervisor.json').read_text())['argv'];a=[v.replace('fable-q6-current-thinking',key).replace('current_fable_q6_resource_controller.py','current_fable_q5_resource_controller.py')for v in a]
assert I in a and '/state/current_fable_q5_resource_controller.py'in a and a[-1]==key
reg.update(not_launched=False,launch_epoch=time.time());(D/'current-fable-q5-resource-controller-registration.json').write_text(json.dumps(reg,indent=2)+'\n')
ident=subprocess.check_output(a,text=True).strip();out={'id':ident,'name':a[a.index('--name')+1],'argv':a,'registration':reg,'launched_epoch':time.time()};(D/'current-fable-q5-resource-supervisor.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'launched':out['name'],'id':ident,'fresh_header_shapes_and_template_match':True,'admission_stage_GiB':admit['stage_free_bytes']/1024**3,'not_actor_or_quality_result':True}))
