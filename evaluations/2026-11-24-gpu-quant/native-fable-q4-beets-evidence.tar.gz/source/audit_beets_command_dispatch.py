"""Posthoc real dispatcher control; candidate and original source stay unchanged."""
from pathlib import Path
import ast,hashlib,importlib.util,json,sys,tempfile,types
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
key=sys.argv[1]
candidate=D/('native-'+key)/'beets_lifecycle'/key/'turn2/local-grade/source'
roots={'baseline':D/'baseline','reference_feature':D/'reference-feature','candidate':candidate}
pins=json.loads((D/'nicotine-dispatch-primary-source/pins.json').read_text())
results=[]
for pin in pins:
    if pin.get('requested_ref') not in ['3.3.11','master']:continue
    path=D/'nicotine-dispatch-primary-source'/pin['file'];raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==pin['sha256']
    cls=next(n for n in ast.parse(raw).body if isinstance(n,ast.ClassDef) and n.name=='PluginHandler')
    method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_trigger_command')
    ns={'CommandInterface':types.SimpleNamespace(CHATROOM='chatroom',PRIVATE_CHAT='private_chat',CLI='cli'),'_':lambda s:s,'log':types.SimpleNamespace(add_debug=lambda *a,**kw:None)}
    exec(compile(ast.Module(body=[method],type_ignores=[]),str(path),'exec'),ns)
    for label,root in roots.items():
        spec=importlib.util.spec_from_file_location('immutable_beets',D/'baseline/tests/test_beetsbridge.py')
        f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);f.PLUGIN_PATH=root/'beetsbridge/__init__.py'
        m,_=f.load_plugin_module();p=m.Plugin();p.settings=dict(m.Plugin.settings)
        p.echoes=[];p.output=p.echo_message=p.echoes.append;p.__publiccommands__=[];p.__privatecommands__=[]
        scheduled=[];p._schedule=lambda folder,delay=None:scheduled.append((str(folder),delay))
        class Handler:
            def __init__(self):self.loaded_plugins={'captured':p};self.enabled_plugins=self.loaded_plugins;self.command_source=None;self.errors=[]
            def show_plugin_error(self,*args):self.errors.append([str(a)for a in args])
        h=Handler();outcomes=[]
        with tempfile.TemporaryDirectory() as temporary:
            p.settings['allowed_download_root']=temporary
            for name in ['Album','Album With Spaces']:
                folder=Path(temporary)/name;folder.mkdir();(folder/'track.flac').write_bytes(b'fake audio')
                before=len(scheduled);p.echoes.clear();accepted=ns['_trigger_command'](h,'beetsimport',str(folder),room='Lobby')
                outcomes.append({'folder_has_spaces':' 'in name,'accepted':bool(accepted),'imports_scheduled':len(scheduled)-before,'output':list(p.echoes),'handler_errors':list(h.errors)})
            cancellations=[]
            for arg in ['',str(Path(temporary)/'Album With Spaces')]:
                p.echoes.clear();accepted=ns['_trigger_command'](h,'beetscancel',arg,room='Lobby')
                cancellations.append({'folder_argument':bool(arg),'accepted':bool(accepted),'output':list(p.echoes),'handler_errors':list(h.errors)})
        results.append({'upstream_ref':pin['requested_ref'],'upstream_commit':pin['commit'],'upstream_source_SHA256':pin['sha256'],'dispatcher_method_AST_SHA256':hashlib.sha256(ast.dump(method).encode()).hexdigest(),'source_kind':label,'candidate_module_SHA256':hashlib.sha256(f.PLUGIN_PATH.read_bytes()).hexdigest(),'manual_import_dispatch':outcomes,'cancel_command_dispatch':cancellations})
assert all(all(o['accepted'] and o['imports_scheduled']==1 for o in r['manual_import_dispatch'])for r in results if r['source_kind']in ['baseline','reference_feature'])
record={'not_actor_feedback':True,'exact_pinned_dispatcher_method_executed':True,'scope':'Pinned dispatcher with immutable fake plugin peers and temporary audio placeholders; no real GUI, beets process or music import.','results':results}
(D/(key+'-beets-command-dispatch-control.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
