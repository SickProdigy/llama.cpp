"""One pinned public artifact into the isolated owned staging volume, never original models."""
from pathlib import Path
import json,hashlib,urllib.request,urllib.error,shutil,time,os,sys
stage=Path('/stage');original=Path('/models');reserve=101*1024**3;original_reserve=101*1024**3
repo='netprojects/Qwen3.8-27B-hermes-adapted-GGUF';revision='10fdf357f14825c61ad7eb42a932e1f1e4390e8f';name='Qwen3.8-27B-hermes-Q3_K_M.gguf';expected=13752764064;expected_sha='a0c809f93de2bcd813e1b6fbd5c2d1f692821814a4261a316f7c8bca9cf23248'
selection=json.loads(Path('/selection.json').read_text());assert hashlib.sha256(Path('/selection.json').read_bytes()).hexdigest()==os.environ['HERMES_Q3KM_SELECTION_SHA256']
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==os.environ['HERMES_Q3KM_WORKER_SHA256']
candidate=selection['candidate'];assert candidate['repo']==repo and candidate['revision']==revision and candidate['file']==name and candidate['bytes']==expected and candidate['advertised_SHA256']==expected_sha
assert selection['download_policy']['original_and_stage_transfer_stop_bytes']==reserve==original_reserve==101*1024**3
assert original.is_dir()and stage.is_dir()and stage.stat().st_dev!=original.stat().st_dev,'Verify separate storage identity before writing'
assert sorted(p.name for p in stage.glob('*.gguf'))==['Qwen3.8-27B-hermes-IQ4_XS.gguf'],'Preserve the previously owned staged IQ4; refuse unexpected weights'
assert shutil.disk_usage(original).free>=102*1024**3
assert shutil.disk_usage(stage).free>=102*1024**3+expected,'Insufficient actual staging reserve'
part=stage/(name+'.part');target=stage/name;assert not target.exists()and not part.exists(),'Refuse to overwrite or silently resume an existing artifact'
url='https://huggingface.co/'+repo+'/resolve/'+revision+'/'+name;digest=hashlib.sha256();count=0;start=time.time();next_log=1024**3;minimum_free=shutil.disk_usage(stage).free
try:
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'isolated-public-model-evaluation'}),timeout=120)as response,part.open('xb')as file:
  assert response.status==200,'Unexpected HTTP status'
  if response.headers.get('Content-Length'):assert int(response.headers['Content-Length'])==expected,'Unexpected advertised length'
  while True:
   chunk=response.read(min(8*1024**2,expected-count+1))
   if not chunk:break
   assert count+len(chunk)<=expected,'Remote artifact exceeds pinned length'
   free=shutil.disk_usage(stage).free;minimum_free=min(minimum_free,free)
   assert free>=reserve+len(chunk)and shutil.disk_usage(original).free>=original_reserve,'Disk reserve guard'
   file.write(chunk);digest.update(chunk);count+=len(chunk)
   if count>=next_log:print(json.dumps({'downloaded_bytes':count,'expected_bytes':expected,'staging_free_bytes':free,'seconds':time.time()-start}),flush=True);next_log+=1024**3
  file.flush();os.fsync(file.fileno())
 assert count==expected and digest.hexdigest()==expected_sha,'Pinned full length/hash verification failed'
 assert shutil.disk_usage(stage).free>=reserve and shutil.disk_usage(original).free>=original_reserve
 part.chmod(0o644);part.rename(target)
 with target.open('rb')as file:os.posix_fadvise(file.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 receipt={'passed':True,'repo':repo,'revision':revision,'file':name,'bytes':count,'sha256':digest.hexdigest(),'full_file_SHA256_verified':True,'seconds':time.time()-start,'volume':'hermes-gpuquant-20261124-model-stage','minimum_observed_staging_free_bytes':minimum_free,'final_staging_free_bytes':shutil.disk_usage(stage).free,'original_model_drive_free_bytes':shutil.disk_usage(original).free,'both_reserves_at_least_100GiB':True,'original_model_files_not_written':True,'download_not_a_GPU_fit_or_quality_test':True,'only_new_owned_file_advised_DONTNEED_after_fsync':True,'transfer_stage_stop_threshold_bytes':reserve,'transfer_original_stop_threshold_bytes':original_reserve,'global_requested_reserve_bytes':100*1024**3,'source_selection_SHA256':os.environ['HERMES_Q3KM_SELECTION_SHA256'],'download_worker_SHA256':os.environ['HERMES_Q3KM_WORKER_SHA256'],'start_stage_free_after_file_minimum_bytes':102*1024**3}
 (stage/'adapted-q3km-download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
except BaseException as error:
 # Keep an owned partial for inspection; no owner model is removed or overwritten.
 result={'passed':False,'exception_type':type(error).__name__,'HTTP_status':getattr(error,'code',None),'bytes_written':count,'partial_file_retained':part.exists(),'original_model_files_not_written':True,'no_signed_redirect_URL_or_credentials_logged':True}
 (stage/'adapted-q3km-download-failure.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);sys.exit(1)
