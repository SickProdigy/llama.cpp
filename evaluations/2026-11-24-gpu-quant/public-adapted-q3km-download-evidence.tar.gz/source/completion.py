"""Verify one completed transfer and clean only its exact stopped container/anonymous volume."""
from pathlib import Path
import json,subprocess,time,re,hashlib,urllib.request
D=Path(__file__).resolve().parent;h=json.loads((D/'adapted-q3km-public-download-supervisor.json').read_text())
docker=lambda *a:subprocess.check_output(['docker',*a],text=True)
c=json.loads(docker('inspect',h['id']))[0];assert c['Id']==h['id']=='3c32f8233af56caeb27df3e3e9620135a74ddb3338a651f21dcaa24182e96d8f'
assert not c['State']['Running']and c['State']['ExitCode']==0 and not c['State']['OOMKilled']
assert c['Name']=='/'+h['name']and c['Config']['Labels']['hermes.gpuquant.study']=='20261124'
assert c['Image']=='sha256:c9b40eb8dea441cba7ded2e6589e5c011545ffc1ec76a0dc736f8e399d8f947b'
assert not docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124').strip()
EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-gpu-quant-20261124'
source="""from pathlib import Path
import json,shutil,hashlib
p=Path('/stage');receipt=json.loads((p/'adapted-q3km-download-receipt.json').read_text());target=p/receipt['file']
assert receipt['passed']and receipt['full_file_SHA256_verified']and target.stat().st_size==receipt['bytes']
assert not target.with_name(target.name+'.part').exists()
print(json.dumps({'profile_hashes':{n:hashlib.sha256((Path('/opt/data')/n).read_bytes()).hexdigest()for n in ['config.yaml','.env','auth.json','SOUL.md']},'receipt':receipt,'stage_files':[{'name':f.name,'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}for f in sorted(p.glob('*.gguf'))],'original_files':[{'name':f.name,'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}for f in sorted(Path('/models').glob('*.gguf'))],'stage_free_bytes':shutil.disk_usage(p).free,'original_free_bytes':shutil.disk_usage('/models').free}))
"""
a=['run','--rm','--runtime','runc','--network','none','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--memory','256m','--memory-swap','256m','--cpus','1','--volumes-from','llama-cpp:ro','--volumes-from','hermes:ro','--mount','type=volume,source=hermes-gpuquant-20261124-model-stage,target=/stage,readonly','-e','NVIDIA_VISIBLE_DEVICES=void','--entrypoint','python',c['Image'],'-c',source];proof=json.loads(docker(*a));r=proof['receipt'];assert r['bytes']==h['bytes']and r['sha256']==h['expected_SHA256']
baseline=json.loads((D/'baseline-20261127-before-public-adapted-q3km-download/runtime.json').read_text());admission=json.loads((D/'adapted-q3km-public-download-admission.json').read_text());assert hashlib.sha256((D/'adapted-q3km-public-download-admission.json').read_bytes()).hexdigest()==h['admission_SHA256'];b={'original_models':baseline['models']['files'],'stage_models':admission['storage']['stage_models']};assert proof['original_files']==b['original_models'];stage={f['name']:f for f in proof['stage_files']};assert set(stage)=={h['model_file'],'Qwen3.8-27B-hermes-IQ4_XS.gguf'};assert stage['Qwen3.8-27B-hermes-IQ4_XS.gguf']==b['stage_models'][0]
assert min(proof['stage_free_bytes'],proof['original_free_bytes'])>=100*1024**3
assert proof['profile_hashes']==baseline['profile_hashes']
assert r['download_worker_SHA256']==h['source_SHA256']==hashlib.sha256((D/'download_owned_adapted_q3km.py').read_bytes()).hexdigest()
assert r['source_selection_SHA256']==admission['selection_SHA256']and r['transfer_stage_stop_threshold_bytes']==r['transfer_original_stop_threshold_bytes']==101*1024**3
assert r['start_stage_free_after_file_minimum_bytes']==102*1024**3 and r['minimum_observed_staging_free_bytes']>=101*1024**3
for name,expected in baseline['containers'].items():
 item=json.loads(docker('inspect',name))[0];actual={'id':item['Id'],'image':item['Image'],'configuration_signature':hashlib.sha256(json.dumps({k:item[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()).hexdigest(),'running':item['State']['Running'],'started':item['State']['StartedAt'],'restarts':item['RestartCount'],'health':item['State'].get('Health',{}).get('Status')};assert actual==expected,name
with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=15)as response:props=json.load(response)
assert props['model_alias']==baseline['original_runtime_props']['alias']and props['default_generation_settings']['n_ctx']==baseline['original_runtime_props']['context']
owner=json.loads((D/'baseline-20261127-before-public-adapted-q3km-download/owner.json').read_text());O=Path('/media/prodigy/Coding-Programming/Repos/nicotineplus-plugins');git=lambda *a:subprocess.check_output(['git','-C',str(O),*a]);sha=lambda b:hashlib.sha256(b).hexdigest();assert git('rev-parse','HEAD').decode().strip()==owner['head']and sha(git('status','--porcelain=v1','-z'))==owner['status_SHA256'];assert all(sha((O/n).read_bytes())==v for n,v in owner['tracked_file_SHA256'].items());assert sha((O/'AGENTS.md').read_bytes())==owner['ignored_AGENTS_SHA256']
logs=subprocess.run(['docker','logs',h['id']],capture_output=True,check=True);(D/'adapted-q3km-public-download.log').write_bytes(logs.stdout+logs.stderr);assert json.loads(logs.stdout.decode().splitlines()[-1])==r
(D/'adapted-q3km-download-receipt.json').write_text(json.dumps(r,indent=2)+'\n');(D/'adapted-q3km-public-download-terminal-supervisor.json').write_text(json.dumps(c,indent=2)+'\n')
volumes=[m for m in c['Mounts']if m['Type']=='volume'and re.fullmatch('[a-f0-9]{64}',m['Name'])];assert len(volumes)==1 and volumes[0]['Destination']=='/opt/data';v=volumes[0];assert '/opt/data'in c['Config']['Volumes']and not any(m.get('Target')=='/opt/data'for m in(c['HostConfig'].get('Mounts')or[]))
assert docker('ps','-a','-q','--no-trunc','--filter','volume='+v['Name']).split()==[h['id']]
(D/'adapted-q3km-public-download-owned-volume-proof.json').write_text(json.dumps({'epoch':time.time(),'volume':v,'sole_exact_supervisor_reference':True},indent=2)+'\n')
subprocess.run(['docker','rm','-v',h['id']],capture_output=True,check=True)
assert subprocess.run(['docker','inspect',h['id']],capture_output=True).returncode!=0 and subprocess.run(['docker','volume','inspect',v['Name']],capture_output=True).returncode!=0
assert subprocess.run(['docker','volume','inspect','hermes-gpuquant-20261124-model-stage'],capture_output=True).returncode==0
out={'epoch':time.time(),'passed':True,'download_stream_fullSHA_verified':True,'owned_target_bytes_metadata_verified':True,'original30_and_staged_IQ4_metadata_unchanged':True,'stage_models_preserved':proof['stage_files'],'both_100GiB_reserves_passed':True,'stage_free_bytes':proof['stage_free_bytes'],'original_free_bytes':proof['original_free_bytes'],'exact_terminal_supervisor_and_exclusive_anonymous_volume_removed':True,'no_unowned_cleanup':True,'not_a_fit_or_quality_result':True,'all_three_original_runtime_records_including_full_Codex_unchanged':True,'four_owner_settings_hashes_unchanged':True,'owner_pending_tracked_and_ignored_instructions_unchanged':True,'original_alias_context_unchanged':True};(D/'adapted-q3km-public-download-completion-and-cleanup.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
