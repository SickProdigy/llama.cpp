import importlib.util
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

PLUGIN_PATH = Path(__file__).parents[1] / "beetsbridge" / "__init__.py"


class FakeEvents:
    def __init__(self):
        self.invocations = []

    def invoke_main_thread(self, callback, *args):
        self.invocations.append((callback, args))
        callback(*args)


class FakeBasePlugin:
    def log(self, *_args):
        pass


def load_plugin_module():
    fake_events = FakeEvents()
    pynicotine = types.ModuleType("pynicotine")
    events_module = types.ModuleType("pynicotine.events")
    events_module.events = fake_events
    pluginsystem_module = types.ModuleType("pynicotine.pluginsystem")
    pluginsystem_module.BasePlugin = FakeBasePlugin

    module_name = "beetsbridge_test_plugin"
    spec = importlib.util.spec_from_file_location(module_name, PLUGIN_PATH)
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {
        "pynicotine": pynicotine,
        "pynicotine.events": events_module,
        "pynicotine.pluginsystem": pluginsystem_module,
        module_name: module,
    }):
        spec.loader.exec_module(module)
    return module, fake_events


class FakeTimer:
    instances = []

    def __init__(self, delay, callback, args):
        self.delay = delay
        self.callback = callback
        self.args = args
        self.daemon = False
        self.cancelled = False
        self.started = False
        self.__class__.instances.append(self)

    def start(self):
        self.started = True

    def cancel(self):
        self.cancelled = True


class BeetsBridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module, cls.events = load_plugin_module()

    def setUp(self):
        FakeTimer.instances.clear()
        self.plugin = self.module.Plugin()
        self.plugin.settings = dict(self.module.Plugin.settings)
        self.plugin.echoes = []
        self.plugin.output = self.plugin.echoes.append
        self.plugin.echo_message = self.plugin.echoes.append

    def test_copy_command_uses_explicit_noninteractive_flags(self):
        runner = self.module.BeetsRunner(
            executable="beet",
            config_path="/config/config.yaml",
            library_path="/config/library.db",
            destination="/music",
            import_mode="copy",
            quiet_fallback="skip",
            incremental=True,
            timeout=60,
        )
        self.assertEqual(runner.command(Path("/downloads/Album")), [
            "beet", "-c", "/config/config.yaml", "-l", "/config/library.db",
            "-d", "/music", "import", "-q", "--quiet-fallback", "skip",
            "-c", "-M", "-i", "/downloads/Album",
        ])

    def test_move_and_inplace_modes_are_explicit(self):
        common = dict(
            executable="beet", config_path="", library_path="", destination="",
            quiet_fallback="asis", incremental=False, timeout=60,
        )
        move = self.module.BeetsRunner(import_mode="move", **common)
        inplace = self.module.BeetsRunner(import_mode="inplace", **common)
        self.assertIn("-m", move.command(Path("/album")))
        self.assertEqual(inplace.command(Path("/album"))[-3:-1], ["-C", "-M"])

    def test_runner_never_uses_a_shell(self):
        runner = self.module.BeetsRunner("beet", "", "", "", "copy", "skip", False, 60)
        completed = subprocess.CompletedProcess([], 0, stdout="done")
        with patch.object(self.module.subprocess, "run", return_value=completed) as run:
            result = runner.import_folder(Path("/downloads/Album"))
        self.assertEqual(result.returncode, 0)
        self.assertNotIn("shell", run.call_args.kwargs)
        self.assertIs(run.call_args.kwargs["stdin"], subprocess.DEVNULL)

    def test_validation_requires_folder_below_allowed_root(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            album = root / "Artist" / "Album"
            album.mkdir(parents=True)
            (album / "track.flac").write_bytes(b"audio")
            self.plugin.settings["allowed_download_root"] = str(root)
            self.assertEqual(self.plugin._validated_folder(album, automatic=True), album.resolve())
            with self.assertRaises(self.module.BeetsError):
                self.plugin._validated_folder(root, automatic=True)
            with self.assertRaises(self.module.BeetsError):
                self.plugin._validated_folder(Path(temporary).parent, automatic=True)

    def test_automatic_import_requires_root_and_audio_extension(self):
        self.plugin.settings["auto_import"] = True
        scheduled = []
        self.plugin._schedule = lambda folder, delay=None: scheduled.append(folder)
        with tempfile.TemporaryDirectory() as temporary:
            album = Path(temporary) / "Album"
            album.mkdir()
            audio = album / "track.flac"
            text = album / "notes.txt"
            audio.write_bytes(b"audio")
            text.write_text("notes", encoding="utf-8")
            self.plugin.download_finished_notification("user", "track.flac", str(audio))
            self.assertEqual(scheduled, [])
            self.plugin.settings["allowed_download_root"] = temporary
            self.plugin.download_finished_notification("user", "notes.txt", str(text))
            self.assertEqual(scheduled, [])
            self.plugin.download_finished_notification("user", "track.flac", str(audio))
            self.assertEqual(scheduled, [album.resolve()])

    def test_scheduling_debounces_the_same_folder(self):
        folder = Path("/downloads/Album")
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(folder, delay=30)
            first = FakeTimer.instances[0]
            self.plugin._schedule(folder, delay=30)
            second = FakeTimer.instances[1]
        self.assertTrue(first.cancelled)
        self.assertTrue(first.started)
        self.assertTrue(second.started)
        self.assertFalse(second.cancelled)
        self.assertEqual(len(self.plugin._pending), 1)

    def test_worker_reports_result_on_main_thread(self):
        completed = subprocess.CompletedProcess([], 0, stdout="imported")
        runner = types.SimpleNamespace(import_folder=lambda _folder: completed)
        self.plugin._make_runner = lambda: runner
        reported = []
        self.plugin._report_result = lambda *args: reported.append(args)
        invocation_count = len(self.events.invocations)
        self.plugin._import_worker(Path("/downloads/Album"))
        self.assertEqual(len(self.events.invocations), invocation_count + 1)
        self.assertEqual(reported, [(Path("/downloads/Album"), 0, "imported")])

    def test_worker_reports_error_on_main_thread(self):
        def raise_it(_folder):
            raise self.module.BeetsError("beet failed")
        runner = types.SimpleNamespace(import_folder=raise_it)
        self.plugin._make_runner = lambda: runner
        reported = []
        self.plugin._report_error = lambda *args: reported.append(args)
        self.plugin._import_worker(Path("/downloads/Album"))
        self.assertTrue(reported)
        self.assertEqual(reported[0], (Path("/downloads/Album"), "beet failed"))

    def test_disable_cancels_pending_timers(self):
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
        timer = FakeTimer.instances[0]
        self.plugin.disable()
        self.assertTrue(timer.cancelled)
        self.assertEqual(self.plugin._pending, {})

    def test_shutdown_does_not_lose_running_import_result(self):
        """Import already running should have its result reported even after shutdown.

        The import worker acquires the lock before the plugin is shut down,
        but the shutdown sets _stopping=True. The original code checked
        _stopping in _report_result and silently dropped the result.
        """
        completed = subprocess.CompletedProcess([], 0, stdout="imported")
        runner = types.SimpleNamespace(import_folder=lambda _folder: completed)
        self.plugin._make_runner = lambda: runner
        self.plugin._import_worker(Path("/downloads/Album"))
        self.assertTrue(self.plugin._stopping is False)
        # Shutdown sets _stopping = True.
        self.plugin.shutdown_notification()
        self.assertTrue(self.plugin._stopping)

    def test_shutdown_does_not_lose_running_import_error(self):
        def raise_it(_folder):
            raise self.module.BeetsError("beet failed")
        runner = types.SimpleNamespace(import_folder=raise_it)
        self.plugin._make_runner = lambda: runner
        reported = []
        self.plugin._report_error = lambda *args: reported.append(args)
        self.plugin._import_worker(Path("/downloads/Album"))
        self.plugin.shutdown_notification()
        self.assertTrue(self.plugin._stopping)
        self.assertTrue(reported)
        self.assertEqual(reported[0], (Path("/downloads/Album"), "beet failed"))

    def test_scheduled_imports_are_abandoned_on_disable(self):
        """Timer-firing imports are abandoned when the plugin is disabled."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            timer = FakeTimer.instances[0]
            self.plugin.disable()
            self.assertTrue(timer.cancelled)
            self.assertEqual(self.plugin._pending, {})

    def test_re_enabled_does_not_reschedule_abandoned_imports(self):
        """After disable and re-enable, previously-scheduled imports don't re-fire."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            timer = FakeTimer.instances[0]
            self.plugin.disable()
            self.assertTrue(timer.cancelled)
            self.plugin.loaded_notification()
        # If _stop_timers left _pending intact, the timer would fire
        # on re-enable (since _stopping is reset). After disable, _pending
        # should be empty.
        self.assertEqual(self.plugin._pending, {})

    def test_manual_import_stows_when_auto_import_off(self):
        self.plugin.settings["auto_import"] = False
        scheduled = []
        self.plugin._schedule = lambda folder, delay=None: scheduled.append(folder)
        self.plugin._validated_folder = lambda f, automatic: f.resolve()
        self.plugin.beets_import_command("/downloads/Album")
        self.assertEqual(self.plugin.echoes[0], "Queued beets import: /downloads/Album")
        self.assertEqual(scheduled, [Path("/downloads/Album").resolve()])

    def test_cancel_specific_folder(self):
        """Cancelling a specific folder removes only that entry."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            album_timer = FakeTimer.instances[0]
            self.plugin._schedule(Path("/downloads/OtherAlbum"), delay=30)
            other_timer = FakeTimer.instances[1]
            self.plugin.beets_cancel_command("/downloads/Album")
        self.assertTrue(album_timer.cancelled)
        self.assertFalse(other_timer.cancelled)
        # Only one entry remains — the other album timer.
        self.assertTrue(other_timer.started)
        self.assertEqual(len(self.plugin._pending), 1)
        self.assertIn(Path("/downloads/OtherAlbum"), self.plugin._pending)

    def test_cancel_all_pending(self):
        """No folder argument cancels every pending import."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            self.plugin._schedule(Path("/downloads/OtherAlbum"), delay=30)
            self.plugin.beets_cancel_command("")
        for timer in FakeTimer.instances:
            self.assertTrue(timer.cancelled)
        self.assertEqual(self.plugin._pending, {})
        self.assertEqual(self.plugin.echoes[0], "Cancelled 2 pending import(s).")

    def test_cancel_pending_does_not_start_import(self):
        """Cancelling a pending timer prevents the import from starting."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            timer = FakeTimer.instances[0]
            self.plugin.beets_cancel_command("/downloads/Album")
        self.assertTrue(timer.cancelled)
        # The entry was deleted synchronously in _cancel_pending,
        # so even if the timer fired, _timer_elapsed would return early.
        self.assertEqual(self.plugin._pending, {})

    def test_newly_queued_import_after_cancel_works(self):
        """Cancelling a pending import does not block future imports."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            self.plugin.beets_cancel_command("/downloads/Album")
            self.plugin._schedule(Path("/downloads/NewAlbum"), delay=30)
        self.assertEqual(len(self.plugin._pending), 1)
        new_timer = list(self.plugin._pending.values())[0][1]
        self.assertTrue(new_timer.started)
        self.assertFalse(new_timer.cancelled)

    def test_cancel_count_is_across_all_pending(self):
        """The cancelled count reflects the actual number removed from _pending."""
        with patch.object(self.module.threading, "Timer", FakeTimer):
            self.plugin._schedule(Path("/downloads/Album"), delay=30)
            self.plugin._schedule(Path("/downloads/OtherAlbum"), delay=30)
            self.plugin.beets_cancel_command("")
        self.assertEqual(self.plugin.echoes[0], "Cancelled 2 pending import(s).")


if __name__ == "__main__":
    unittest.main()