from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path(__file__).resolve().parent;E=D.parent.parent/'evaluations/2026-11-24-gpu-quant'
S=D/'native-adapted-iq4-current-cold-20261127/beets_lifecycle';tag='native-adapted-iq4-current-interrupted'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=read(D/'native-adapted-iq4-current-cold-20261127-beets_lifecycle-protocol.json')
assert all(sha(D/n)==h for n,h in P['code_sha256'].items())
assert read(S/'runtime-restoration.json')['restored']and read(D/'cold-current-adapted-iq4-cleanup.json')['passed']
assert not(S/'workflows-finished.json').exists()
rows=[]
for line in(S/'memory-samples.jsonl').read_text().splitlines():
 r=json.loads(line);rows.append({k:r[k]for k in ['epoch','model_disk_free_bytes','staging_disk_free_bytes','total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes','gpu_csv','budget_guard_triggered','disk_reserve_guard_triggered','measurement_error']if k in r}|{'host_available_bytes':r['host']['MemAvailable']})
guards=[r for r in rows if r.get('budget_guard_triggered')];assert len(guards)==1 and guards[0]['disk_reserve_guard_triggered']
metrics=[]
for p in sorted((S/'llm-records').glob('*.metrics.json')):
 m=read(p);metrics.append({k:m[k]for k in ['id','received_epoch','backend_start_epoch','end_epoch','usage','finish_reasons','transport_error','backend_http_status','response_parse_failed']if k in m})
terminal=read(D/'cold-current-adapted-iq4-terminal-supervisor.json');state=terminal['state'];start=datetime.datetime.fromisoformat(state['StartedAt'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(state['FinishedAt'].replace('Z','+00:00'))
events=[json.loads(l)for l in(S/'events.jsonl').read_text().splitlines()];turn_start=next(e['epoch']for e in events if e['kind']=='turn_start')
forge=read(D/'interrupted-current-iq4-independent-forge-readback.json');issue=json.loads(read(D/'current-iq4-interrupted-issue-closure-independent-MCP.json')['content'][0]['text']);assert issue['state']=='closed'
model=read(S/'model-identity.json');preserve=read(D/'native-adapted-iq4-current-cold-20261127-beets_lifecycle-preservation.json');owner=read(D/'native-adapted-iq4-current-cold-20261127-beets_lifecycle-owner-preservation.json');assert preserve['passed']and owner['passed']
summary={'classification':'Incomplete native workflow: operational staging-disk reserve guard, not a model-quality failure','quality_verdict':None,'completed_coding_turns':0,'candidate':'adapted-iq4-current','model':model,'sampler':P['sampler'],'context':P['context'],'layout':P['measured_resource_layout'],'runtime_images':{'Hermes':P['hermes_runtime_image'],'llama.cpp':P['backend_image']},'guard':guards[0],'reserve_bytes':100*1024**3,'host_limit_bytes':8*1024**3,'samples':len(rows),'peak_aggregate_cgroup_bytes':max(r['total_cgroup_bytes']for r in rows),'peak_PSS_bytes':max(r['total_process_pss_bytes']for r in rows),'peak_study_swap_bytes':max(r['total_cgroup_swap_bytes']for r in rows),'measurement_errors':sum('measurement_error'in r for r in rows),'usage_completed_requests':sum(bool(m.get('usage'))for m in metrics),'failed_requests_after_guard':sum(not m.get('usage')for m in metrics),'supervisor_wall_minutes':(end-start).total_seconds()/60,'first_turn_minutes_until_guard':(guards[0]['epoch']-turn_start)/60,'publication':{'actual_issue_created':True,'actual_personal_fork_parent_verified':forge['actor_fork_parent_id']==34350,'actual_commits_since_baseline':forge['actor_commits_since_baseline'],'actual_fork_head':forge['actor_head_SHA'],'upstream_baseline_blobs_verified':forge['upstream_baseline_blobs_verified'],'PR_found':bool(forge['pull_requests']),'issue_closed_independently_verified':issue['state']=='closed'},'preservation':{k:v for k,v in preserve.items()if k!='epoch'},'owner_preservation':owner,'cleanup':read(D/'cold-current-adapted-iq4-cleanup.json'),'frozen_source_bindings_verified':len(P['code_sha256']),'protocol_SHA256':sha(D/'native-adapted-iq4-current-cold-20261127-beets_lifecycle-protocol.json'),'limitations':['No completed CLI turn or three-turn quality result; partial fork commits are not a successful workflow.','Reserve sampled every10seconds; final sample undershoots100GiB before safeguard stops the run.','Memory remains in budget. Backend transport failures follow intentional guard stop.','Shared Docker-root consumption is not attributed to a model or particular owner workload.','A future fresh operational retry must remain separately labeled, without resuming interrupted conversation or grader feedback.','No raw actor messages/code, private graders, profiles, credentials or signing keys exported.'],'private_evidence_fingerprints':{p.name:sha(p)for p in [S/'controller-error.json',S/'memory-samples.jsonl',S/'runtime-restoration.json',D/'interrupted-current-iq4-independent-forge-readback.json']}}
X=D/(tag+'-export');X.mkdir(exist_ok=False)
for name,data in [('summary.json',summary),('observations/memory.json',rows),('observations/request-metrics.json',metrics),('observations/events.json',events),('observations/terminal-state.json',state)]:
 p=X/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')
for name in ['export_interrupted_iq4_native.py','verify_interrupted_iq4_native.py']:(X/name).write_bytes((D/name).read_bytes())
manifest={str(p.relative_to(X)):sha(p)for p in sorted(X.rglob('*'))if p.is_file()};(X/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');out=E/(tag+'-evidence.tar.gz');assert not out.exists()
with tarfile.open(out,'w:gz')as t:
 for p in sorted(X.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(X)))
(E/(tag+'-summary.json')).write_bytes((X/'summary.json').read_bytes());(E/(tag+'-evidence.sha256')).write_text(sha(out)+'  '+out.name+'\n');print(json.dumps({'archive_SHA256':sha(out),'files':len(manifest)+1,'quality_verdict':None,'wall_minutes':summary['supervisor_wall_minutes']}))
