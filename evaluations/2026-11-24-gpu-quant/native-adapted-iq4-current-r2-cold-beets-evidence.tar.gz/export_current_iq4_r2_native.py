"""Curated completed R2 evidence: published source and numeric observations only."""
from pathlib import Path
import json, hashlib, tarfile, ast, re
D=Path(__file__).resolve().parent
E=D.parent.parent/'evaluations/2026-11-24-gpu-quant'
TAG='adapted-iq4-current-r2-cold-20261127'
NAME='native-adapted-iq4-current-r2-cold-beets'
S=D/('native-'+TAG)/'beets_lifecycle'; C=S/'adapted-iq4-current-r2'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(D/'cold-current-adapted-iq4-r2-completed-audit-reconciled.json')
post=read(D/'current-iq4-r2-postrun-results-summary.json')
P=read(D/('native-'+TAG+'-beets_lifecycle-protocol.json'))
assert all(sha(D/n)==h for n,h in P['code_sha256'].items())
assert a['preservation']['required_configuration_models_profiles_owner_invariants_passed']
assert not a['preservation']['strict_preservation_passed']
assert a['owner_preservation']['passed'] and a['cleanup']['passed']
def mcp(n):return json.loads(read(D/n)['result']['content'][0]['text'])
issue=mcp('current-iq4-r2-final-issue-closure-MCP-readback.json')
pr=mcp('current-iq4-r2-final-PR2-MCP-readback.json')
assert issue['state']=='closed' and pr['head']['sha']==a['forge']['pull_requests'][0]['head_sha']
assert pr['state']=='open' and not pr['merged']
rows=[]
for line in (S/'memory-samples.jsonl').read_text().splitlines():
 r=json.loads(line)
 rows.append({k:r[k] for k in ['epoch','model_disk_free_bytes','staging_disk_free_bytes','total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes','gpu_csv','budget_guard_triggered','measurement_error'] if k in r})
metrics=[]
for p in sorted((S/'llm-records').glob('*.metrics.json')):
 m=read(p);q=read(p.with_name(p.name.replace('.metrics.json','.request.json')))
 metrics.append({k:m[k] for k in ['id','received_epoch','backend_start_epoch','end_epoch','usage','finish_reasons','request_sha256','backend_http_status','transport_error'] if k in m}|{'tools_exposed':bool(q.get('tools'))})
phases=[]
for i in range(3):
 t=C/f'turn{i}';g=read(t/'remote-grade/grade.json');run=read(t/'run.json')
 o=read(D/(TAG+f'-phase{i}-published-turn-observations.json'))['phases'][0]
 phases.append({'phase':i,'coding_seconds':run['elapsed_seconds'],'CLI_exit':run['exit_code'],'external_timeout':run['external_timeout'],'query_sha256':run['query_sha256'],'source_authority':'actual published fork commit','source_digest':g['source_digest'],'changed_paths':g['changed_paths'],'project_exit':g['project_exit'],'original_exit':g['preservation_exit'],'independent_exit':g['independent_exit'],'project_summary':o['snapshots']['remote-grade']['project_summary'],'original_summary':o['snapshots']['remote-grade']['original_summary'],'local_summary':o['snapshots']['local-grade'],'captured_remote_head':o['snapshots']['remote-grade']['captured_remote_head'],'PR_head_matches_snapshot':o['snapshots']['remote-grade']['PR_head_matches_snapshot']})
summary={'candidate':'adapted-iq4-current-r2','whole_workflow_pass':False,'review_date_UTC':'2026-11-27','operational_retry_of':'native-adapted-iq4-current-interrupted; separate fresh profile/process/fixture, no conversation resume or hints','model':a['model'],'model_repository':'netprojects/Qwen3.8-27B-hermes-adapted-GGUF','model_revision':'10fdf357f14825c61ad7eb42a932e1f1e4390e8f','runtime_images':{'Hermes':P['hermes_runtime_image'],'llama.cpp':P['backend_image']},'settings':{'context':P['context'],'layout':P['measured_resource_layout'],'sampler':P['sampler'],'main_output_cap':P['main_output_cap'],'auxiliary_output_cap':P['compression_output_cap'],'cache_K_V':'q4_0','cache_checkpoints':2,'cache_RAM_MiB':512,'fit':'off','load_mode':'none','single_slot':True,'CPU_threads':8},'phases':phases,'coding_minutes':post['coding_minutes'],'supervisor_wall_minutes':post['supervisor_wall_minutes'],'compression_minutes':post['compression_minutes'],'first_resumed_main_minutes':post['first_resumed_main_minutes'],'compression_plus_first_resumed_minutes':post['compression_plus_first_resumed_minutes'],'runtime_audit':a['runtime_audit'],'resource':a['resource'],'publication':{'upstream_issue':1,'issue_closed_single_get_verified':True,'personal_fork_parent_verified':True,'upstream_baseline_blobs_verified':40,'PR':2,'PR_open_unmerged':True,'head_SHA':pr['head']['sha'],'base_SHA':pr['base']['sha'],'independent_connected_MCP_readback':True,'final_actual_tree_unchanged_after_documentation_turn':True,'published_authored_tests':0},'preservation':a['preservation'],'owner_preservation':a['owner_preservation'],'cleanup':a['cleanup'],'restoration_qualification':a['restoration_qualification'],'strict_restoration_error':a['strict_restoration_error'],'native_final_turn_end_reason':post['turn2_end_reason'],'intervention':post['assessor_intervention'],'quant_header_comparison':read(D/'current-adapted-q4-iq4-header-comparison.json'),'frozen_code_files_verified':132,'limitations':['One three-turn workflow, not three independent samples or an autonomous reliability rate. No GPT-5 equivalence claim.','Explicit 1,250.63MiB host model buffer; 63/66 GPU layer count does not establish a compute fraction.','10-second resource sampling can miss peaks; timings share an active host and differ in cache reuse.','Private-worker original-test signature compatibility gate is distinct from public dispatch failure; no gate-free causal ablation.','Auxiliary summarizes older prefix; recent PR/docs and all three literal tasks remain in resumed request. Historical superseded state alone is not a compression failure.','Hermes-Codex start timestamp changed for unknown cause. Strict restoration assertion failed and is retained; only qualified configuration/model/profile/owner invariants pass.','Different calibration/tensor mixes, ubatch and placement prevent precision-only attribution against Q4.','Saved evidence consistency and static published-source checks are reproducible here; private graders, reference code, model conversations/profiles, credentials and receipt signing keys are excluded. No model or behavior replay claimed.']}
X=D/(NAME+'-export');X.mkdir(exist_ok=False)
def save(n,obj):
 p=X/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
save('summary.json',summary);save('observations/memory.json',rows);save('observations/request-metrics.json',metrics)
save('observations/events.json',[json.loads(l)for l in(S/'events.jsonl').read_text().splitlines()])
terminal=read(D/'cold-current-adapted-iq4-r2-terminal-supervisor.json')['State']
save('observations/terminal-state.json',{k:terminal[k]for k in ['Status','Running','ExitCode','OOMKilled','StartedAt','FinishedAt']})
save('observations/phases.json',phases);save('observations/frozen-source-bindings.json',P['code_sha256'])
for label,root in [('baseline',D/'baseline'),*((f'phase{i}',C/f'turn{i}/remote-grade/source')for i in range(3))]:
 index={str(p.relative_to(root)):sha(p)for p in sorted(root.rglob('*'))if p.is_file() and '__pycache__'not in p.parts and p.name!='AGENTS.md'}
 save('published/'+label+'/index.json',index)
 for n in ['beetsbridge/__init__.py','beetsbridge/README.md','tests/test_beetsbridge.py']:
  dest=X/'published'/label/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/n).read_bytes())
audits=['current-iq4-r2-phase0-manual-source-review.json','current-iq4-r2-phase1-manual-docs-review.json','current-iq4-r2-phase2-manual-final-source-review.json','current-iq4-r2-phase0-local-authored-test-static-adequacy.json','current-iq4-r2-private-signature-methodology-qualification.json','current-iq4-r2-phase0-branch-ref-incident-audit.json','current-iq4-r2-completed-aux57-history-boundary-audit.json','current-iq4-r2-phase0-publication-integrity-audit.json','current-iq4-r2-postrun-results-summary.json','current-iq4-r2-restoration-incident.json','current-iq4-r2-codex-docker-events.json','current-iq4-r2-folder-boundary-observations.json']
for n in audits:save('audits/'+n,read(D/n))
save('audits/real-nicotine-controls.json',read(D/'real-nicotine-lifecycle-observations-20261127/observations.json'))
save('observations/independent-forge.json',a['forge'])
save('observations/issue-single-get.json',issue);save('observations/PR-single-get.json',pr)
save('privacy-boundary.json',{'included':'Numeric captured observations, curated audit records and actual published plugin/readme/test snapshots plus baseline and complete source hash indexes.','excluded':['raw actor requests/responses/consoles/databases','local unpublished code','profiles/auth/environment secrets','private graders/reference implementations','receipt signing keys','owner pending edits'],'verifier_scope':'Saved evidence consistency and static published-source checks only; no inference or full behavior replay.'})
for n in ['export_current_iq4_r2_native.py','verify_current_iq4_r2_native.py']:(X/n).write_bytes((D/n).read_bytes())
manifest={str(p.relative_to(X)):sha(p)for p in sorted(X.rglob('*'))if p.is_file()};save('manifest.json',manifest)
archive=E/(NAME+'-evidence.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz')as t:
 for p in sorted(X.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(X)))
(E/(NAME+'-summary.json')).write_bytes((X/'summary.json').read_bytes())
(E/(NAME+'-evidence.sha256')).write_text(sha(archive)+'  '+archive.name+'\n')
print(json.dumps({'archive':archive.name,'SHA256':sha(archive),'manifest_files':len(manifest),'workflow_pass':False}))
