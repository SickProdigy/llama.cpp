"""Retain authored tests on prior implementation; classify failures manually."""
from pathlib import Path
import ast, hashlib, json, os, sys, time
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D/'evaluation-library'))
from docker_execution import DockerExecution
from review_packet import source_digest
key,phase=sys.argv[1],int(sys.argv[2]);assert phase in [0,2]
family='beets_lifecycle';S=D/('native-'+key)/family/key
kind='remote-grade' if (S/f'turn{phase}/remote-grade/grade.json').exists() else 'local-grade'
prior_kind='remote-grade' if (S/'turn1/remote-grade/grade.json').exists() else 'local-grade'
prior=D/'baseline' if phase==0 else S/'turn1'/prior_kind/'source'
candidate=S/f'turn{phase}'/kind/'source'
out=D/f'{key}-{family}-phase{phase}-test-adequacy';out.mkdir(exist_ok=False)
def inventory(root):
    return {str(p.relative_to(root)):p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
before,after=inventory(prior),inventory(candidate)
def functions(raw):
    out={}
    def walk(node,prefix=''):
        for child in getattr(node,'body',[]):
            if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
                out[prefix+child.name]=ast.dump(child,include_attributes=False)
            elif isinstance(child,ast.ClassDef):
                walk(child,prefix+child.name+'.')
    walk(ast.parse(raw))
    return out
def is_test_path(p):
    return p.startswith('tests/') or '/tests/' in p or (p.endswith('.py') and Path(p).name.startswith('test_'))
oldtests={p:v for p,v in before.items() if is_test_path(p)}
newtests={p:v for p,v in after.items() if is_test_path(p)}
oldfunctions={p+':'+n:v for p,raw in oldtests.items() if p.endswith('.py') for n,v in functions(raw).items()}
newfunctions={p+':'+n:v for p,raw in newtests.items() if p.endswith('.py') for n,v in functions(raw).items()}
modified=[n for n,v in oldfunctions.items() if newfunctions.get(n)!=v]
added=[n for n in newfunctions if n not in oldfunctions]
merged={p:v for p,v in before.items() if not is_test_path(p)};merged.update(newtests)
def run(name,files):
    root=out/name/'source';root.mkdir(parents=True)
    for path,raw in files.items():
        p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    hashes={p:hashlib.sha256(v).hexdigest() for p,v in sorted(files.items())}
    (root.parent/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    image='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
    engine='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-gpu-quant-20261124/'+str(root.relative_to(D))
    runner=DockerExecution(root,engine,image,output_log=root.parent/'project.log')
    start=time.monotonic();result=runner.run(expected_digest=source_digest(runner.inventory()),key=os.urandom(32))
    record={'seconds':time.monotonic()-start,'receipt_payload':result['payload']}
    (root.parent/'run.json').write_text(json.dumps(record,indent=2)+'\n')
    return record
actual=run('candidate',after);control=run('prior_with_authored_tests',merged)
result={'key':key,'phase':phase,'source_kind':kind,'prior_source_kind':'immutable-baseline' if phase==0 else prior_kind,'existing_test_functions_AST_unchanged':not modified,'modified_or_removed_original_test_functions':modified,'added_test_methods':[n for n in added if n.split('.')[-1].split(':')[-1].startswith('test')],'added_non_test_helpers':[n for n in added if not n.split('.')[-1].split(':')[-1].startswith('test')],'candidate':actual,'prior_with_authored_tests':control,'all_detected_authored_test_files_retained_in_counterfactual':True,'counterfactual_test_paths':sorted(newtests),'test_path_detection':'Root tests/, nested /tests/, and test_*.py; manually audit helpers and actual executed suite discovery.','requires_manual_failure_classification':True,'not_actor_feedback':True,'no_quality_pass_from_green_tests':True}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'candidate':key,'phase':phase,'source_kind':kind,'candidate_exit':actual['receipt_payload']['returncode'],'prior_with_authored_tests_exit':control['receipt_payload']['returncode'],'original_function_changes':modified,'added_tests':result['added_test_methods']}))
