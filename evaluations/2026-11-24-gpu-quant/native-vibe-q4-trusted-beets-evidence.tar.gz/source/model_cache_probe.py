"""Selected-file page-cache observations; no global cache operation."""
import ctypes,os,time
def advise_inactive_model(path):
    size=path.stat().st_size;page=os.sysconf('SC_PAGESIZE');count=(size+page-1)//page
    lib=ctypes.CDLL(None,use_errno=True);lib.mmap.restype=ctypes.c_void_p
    lib.mmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong]
    lib.mincore.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p]
    lib.munmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
    def cached(fd):
        pointer=lib.mmap(None,size,0,1,fd,0)
        assert pointer not in [None,ctypes.c_void_p(-1).value],ctypes.get_errno()
        try:
            vector=(ctypes.c_ubyte*count)()
            assert lib.mincore(pointer,size,vector)==0,ctypes.get_errno()
            return sum(bool(value&1)for value in vector)*page
        finally:assert lib.munmap(pointer,size)==0
    with path.open('rb')as stream:
        before=cached(stream.fileno())
        os.posix_fadvise(stream.fileno(),0,0,os.POSIX_FADV_DONTNEED)
        after=cached(stream.fileno())
    return {'epoch':time.time(),'file':path.name,'bytes':size,'mincore_cached_page_bytes_before':before,'mincore_cached_page_bytes_after':after,'only_specific_inactive_file_advised':True,'no_global_cache_flush':True,'not_cold_storage_cache_proof':True,'content_not_modified':True,'scope':'After original backend exits, before measured replacement starts. Page residency rounded to page boundaries; no claim about storage-device caches.'}
