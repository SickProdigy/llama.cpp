"""Exact scoped actor-auth readback; credentials arrive via stdin, never persist."""
import json,sys,urllib.request,urllib.error
p=json.load(sys.stdin);repo=p['repo'];assert repo in ['hermes-gpuquant-vibe-q4-trusted-20261124','hermes-gpuquant-vibe-q6-trusted-20261124']
def get(path):
    request=urllib.request.Request(p['host'].rstrip('/')+'/api/v1/'+path,headers={'Authorization':'token '+p['token']})
    with urllib.request.urlopen(request,timeout=45)as response:return json.load(response)
user=get('user');assert user['login']=='hermes-agent'
try:fork=get('repos/hermes-agent/'+repo)
except urllib.error.HTTPError as error:
    assert error.code==404
    print(json.dumps({'authenticated_actor':'hermes-agent','repo':repo,'actor_auth_fork_GET_status':404,'fork_visible_to_own_actor':False,'read_only':True}))
else:
    assert fork['owner']['login']=='hermes-agent' and fork['name']==repo
    branches=get('repos/hermes-agent/'+repo+'/branches?limit=100')
    print(json.dumps({'authenticated_actor':'hermes-agent','repo':repo,'actor_auth_fork_GET_status':200,'fork_visible_to_own_actor':True,'fork_id':fork['id'],'is_fork':fork['fork'],'parent_id':(fork.get('parent')or{}).get('id'),'parent_name':(fork.get('parent')or{}).get('full_name'),'branches':[{'name':b['name'],'head':b['commit']['id']}for b in branches],'read_only':True}))
