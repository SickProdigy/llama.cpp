"""Trusted private profile transform; no production auth/environment/session copy."""
from pathlib import Path
import json,tarfile,shutil,os,re,sys,hashlib
from ruamel.yaml import YAML
D=Path('/state');params=json.loads((D/'profile-parameters'/sys.argv[1]).read_text());name=params['name'];assert re.fullmatch(r'[a-z0-9_-]+',name)
root=D/'profiles'/name;profile=root/'profile';profile.mkdir(parents=True,exist_ok=False)
with tarfile.open(D/'normal-profile-private.tgz')as t:t.extractall(profile,filter='data')
yaml=YAML(typ='safe');c=yaml.load((profile/'config.yaml').read_text());original=json.loads(json.dumps(c))
def strip_secrets(obj):
 if isinstance(obj,dict):
  for key,value in obj.items():
   if re.search(r'(?:^|_)(?:TOKEN|PASSWORD|SECRET|API_KEY|ACCESS_KEY)$',str(key).upper())and isinstance(value,str):obj[key]=''
   else:strip_secrets(value)
 elif isinstance(obj,list):
  for value in obj:strip_secrets(value)
strip_secrets(c)
sampler=params['sampler'];alias=params['alias'];endpoint=params['endpoint'];budget=params['run_budget_seconds'];ctx=params['context'];output_cap=int(params.get('max_tokens',8192));compression_cap=int(params.get('compression_max_tokens',output_cap));assert 1024<=output_cap<=32768 and 1024<=compression_cap<=32768
c['model']={'default':alias,'provider':'custom:wide','base_url':endpoint,'api_key':'local-wide-evaluation-only','context_length':ctx,'max_tokens':output_cap}
c['custom_providers']=[{'name':'wide','base_url':endpoint,'api_key':'local-wide-evaluation-only','model':alias,'extra_body':dict(sampler,max_tokens=output_cap)}]
c['fallback_providers']=[];c['platforms']={};c['dashboard']={'enabled':False};c['telemetry']={'enabled':False};c['secrets']={}
c['mcp_servers']={'mcp-gitea-hermes':{'url':'http://gitea-wide:8080/mcp','transport':'streamable-http','timeout':600}}
a=c['agent'];a['disabled_toolsets']=[x for x in a.get('disabled_toolsets',[])if x!='memory'];a['disabled_toolsets']=list(dict.fromkeys(a['disabled_toolsets']+['mcp-gitea-hermes','discord','discord_admin']))
a['max_turns']=60;a['run_budget_seconds']=budget;a['gateway_timeout']=budget+600
a['local_stream_stale_timeout']=5400
for provider in ['custom:wide','custom','wide']:
 c.setdefault('providers',{}).setdefault(provider,{}).update(request_timeout_seconds=5400,stale_timeout_seconds=5400)
c['custom_providers'][0].update(request_timeout_seconds=5400,stale_timeout_seconds=5400)
mapping={'get_me':'identity','search_repos':'search_repositories','get_file_contents':'read_file','get_dir_contents':'list_directory','get_repository_tree':'list_directory','repo_read':'repository_info','branch_read':'list_branches','issue_read':'read_issue','pull_request_read':'read_pull_request'}
hint=a.get('environment_hint','')
def replace_native(match):
 operation=match.group(1)
 return 'gitea_'+mapping[operation]if operation in mapping else match.group(0)
hint=re.sub(r'mcp__mcp_gitea_hermes__([a-z_]+)',replace_native,hint)
for old,new in [('search_repos','gitea_search_repositories'),('get_dir_contents','gitea_list_directory'),('get_file_contents','gitea_read_file')]:hint=re.sub(r'(?<![A-Za-z0-9_])'+old+r'(?![A-Za-z0-9_])',new,hint)
hint=hint.replace('Hermes data and workspace files live under /opt/data.','Hermes data lives under /opt/data; the selected repository checkout is /workspace.').replace('with with_lines: true, start_line: 1, end_line: 160','with start_line: 1, end_line: 160')
a['environment_hint']=hint+' Infer upstream ownership from the selected Git repository and configured Gitea metadata; infer personal fork ownership from the authenticated Gitea identity. Use local repository tools for code and tests, and configured Gitea MCP for forge operations.'
c['terminal'].update(backend='local',cwd='/workspace',timeout=90)
c['compression'].update(threshold=.85,threshold_tokens=None)
aux=c.setdefault('auxiliary',{});aux.setdefault('compression',{}).update(extra_body=dict(sampler,max_tokens=compression_cap))
redirected=[]
for purpose,settings in aux.items():
 if isinstance(settings,dict)and(settings.get('model')or settings.get('provider')):
  settings.update(model=alias,provider='custom:wide',base_url=endpoint,api_key='local-wide-evaluation-only');redirected.append(purpose)
c.setdefault('title_generation',{}).update(enabled=False,model_upgrade_enabled=False)
plugins=c['plugins'];plugins['enabled']=[x for x in plugins.get('enabled',[])if x!='discord-platform']
for plugin in ['gitea-focused','gitea-workspace','selected-project']:
 shutil.copytree(D/'plugins'/plugin,profile/'plugins'/plugin,dirs_exist_ok=True);plugins['enabled']=list(dict.fromkeys(plugins['enabled']+[plugin]))
up=params['owner']+'/'+params['repo'];entries=plugins.setdefault('entries',{})
entries['gitea-focused']={'settings':{'allowed_upstream_repositories':[up],'public_url':'https://gitea.rcs1.top'}}
entries['gitea-workspace']={'settings':{'workspace_root':'/workspace','baseline_ref':params['base_revision'],'allowed_upstream_repositories':[up],'allowed_paths':['README.md'],'allowed_path_prefixes':[params['module']+'/','tests/'],'public_url':'https://gitea.rcs1.top'}}
entries['selected-project']={'settings':{'workspace_root':'/workspace'}}
c.setdefault('platform_toolsets',{})['cli']=list(dict.fromkeys(c.get('platform_toolsets',{}).get('cli',[])+['memory','gitea-focused','gitea-workspace']))
assert c['memory'].get('write_approval')==original['memory'].get('write_approval');assert c['skills'].get('write_approval')==original['skills'].get('write_approval')
assert params['single_query_mode']=='approve'
c.setdefault('approvals',{})['single_query_mode']='approve'
YAML().dump(c,(profile/'config.yaml').open('w'))
for p in [root,*root.rglob('*')]:
 if not p.is_symlink():os.chown(p,1000,1000)
manifest={'profile':name,'context':ctx,'alias':alias,'provider':'custom:wide','main_output_cap':output_cap,'compression_output_cap':compression_cap,'run_budget_seconds':budget,'per_request_timeout_seconds':5400,'stale_timeout_seconds':5400,'max_turns':60,'sampler_extra_body':sampler,'source_archive_sha256':hashlib.sha256((D/'normal-profile-private.tgz').read_bytes()).hexdigest(),'config_sha256':hashlib.sha256((profile/'config.yaml').read_bytes()).hexdigest(),'normal_memory_write_approval':c['memory'].get('write_approval'),'normal_skills_write_approval':c['skills'].get('write_approval'),'native_persistence_retained':True,'full_native_MCP_toolset_disabled_but_transport_registered':True,'tool_interface':'Native CLI plus focused Gitea/workspace/selected-project plugins; real scoped MCP calls','title_generation_disabled_from_supported_native_setting':True,'explicit_auxiliary_routes_redirected_to_test_backend':redirected,'production_env_auth_sessions_not_copied':True,'single_query_mode':'approve','scope':'explicitly trusted isolated evaluation only','actor_calls_started':False}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');os.chown(root/'manifest.json',1000,1000);print(json.dumps({'profile':name,'context':ctx,'main_output_cap':output_cap,'run_budget_seconds':budget,'single_query_mode':'approve','scope':'explicitly trusted isolated evaluation only','actor_calls_started':False}))
