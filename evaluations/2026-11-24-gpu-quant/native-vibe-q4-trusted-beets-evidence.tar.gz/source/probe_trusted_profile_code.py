"""No-model pure-code control in copied isolated profile; no forge operations."""
from pathlib import Path
import contextlib,hashlib,json,os,shutil,sys,time
from ruamel.yaml import YAML
mode='approve'
home=Path('/tmp/approval-probe-'+mode);shutil.copytree('/input-profile',home)
yaml=YAML();config=yaml.load((home/'config.yaml').read_text())
before=config.setdefault('approvals',{}).get('single_query_mode','deny')
assert before=='approve','Actual copied trusted profile must already approve before probe'
os.environ.update(HERMES_HOME=str(home),HOME=str(home),HERMES_SINGLE_QUERY_SESSION='1',HERMES_INTERACTIVE='1')
sys.path.insert(0,'/opt/hermes')
with contextlib.redirect_stdout(sys.stderr):
    import model_tools
    from tools.registry import registry
    from tools.approval_context import _get_single_query_approval_mode
    assert _get_single_query_approval_mode()==mode
    start=time.monotonic();result=registry.dispatch('execute_code',{'code':'print(2 + 2)'})
    if isinstance(result,str):result=json.loads(result)
    seconds=time.monotonic()-start
paths=['tools/approval.py','tools/approval_context.py','hermes_cli/cli_single_query.py']
record={'mode':mode,'copied_original_mode':before,'resolved_single_query_mode':mode,'seconds':seconds,'model_calls':0,'forge_mutations':0,'source_files_SHA256':{p:hashlib.sha256((Path('/opt/hermes')/p).read_bytes()).hexdigest()for p in paths},'pure_code_result':result,'owner_profile_not_modified':True}
print(json.dumps(record))
