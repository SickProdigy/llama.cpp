"""Launch one retained-file capacity stage only with no other study job live."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
D=Path(__file__).resolve().parent;R=D.parent.parent
key=sys.argv[1];assert key in ['adapted-iq4-compression']
receipt=json.loads((D/'adapted-iq4-download-receipt.json').read_text());assert receipt['passed']and receipt['full_file_SHA256_verified']and receipt['bytes']==15321491104
reg=json.loads((D/'native-compression-controller-registration.json').read_text())
for name,field in [('native_compression_controller.py','controller_sha256'),('native-compression-protocol.json','protocol_sha256')]:
    assert hashlib.sha256((D/name).read_bytes()).hexdigest()==reg[field]
assert hashlib.sha256((D/'model_cache_probe.py').read_bytes()).hexdigest()==reg['cache_helper_sha256']
for rel,digest in reg['additional_source_sha256'].items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==digest,rel
assert not (D/('resource-'+key)).exists()
for label in ['hermes.wide.study=20261123','hermes.gpuquant.study=20261124']:
    assert not subprocess.check_output(['docker','ps','-q','--filter','label='+label],text=True).strip(),label
for service in ['hermes','llama-cpp','hermes-codex']:
    c=json.loads(subprocess.check_output(['docker','inspect',service],text=True))[0]
    assert c['State']['Running']
a=json.loads((D/'resource-fable-q6-supervisor.json').read_text())['argv']
a[a.index('--entrypoint'):a.index('--entrypoint')]=['--mount','type=volume,source=hermes-gpuquant-20261124-model-stage,target=/candidate-models,readonly']
name='hermes-gpuquant-'+key+'-resource-supervisor'
a[a.index('--name')+1]=name;a[-2]='/state/native_compression_controller.py';a[-1]=key
assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
ident=subprocess.check_output(a,text=True).strip()
(D/('resource-'+key+'-supervisor.json')).write_text(json.dumps({'id':ident,'name':name,'argv':a,'launched_epoch':time.time(),'registration':reg},indent=2)+'\n')
print(json.dumps({'launched':name,'id':ident,'no_overlapping_study_jobs':True}))
