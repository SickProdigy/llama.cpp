"""Read-only numeric postflight audit; never exports conversation payloads."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;S=D/'resource-adapted-iq4-compression';L=S/'layout0'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
finished=read(S/'finished.json');restored=read(S/'runtime-restoration.json');assert restored['restored']
registration=read(D/'native-compression-controller-registration.json')
for name,field in [('native_compression_controller.py','controller_sha256'),('native-compression-protocol.json','protocol_sha256')]:assert sha(D/name)==registration[field]
for name,digest in registration['additional_source_sha256'].items():assert sha(D/name)==digest
rows=[json.loads(x)for x in (L/'samples.jsonl').read_text().splitlines()];good=[x for x in rows if all(k in x for k in ['total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes','model_disk_free_bytes','staging_disk_free_bytes'])];assert good
stream=read(L/'progress-stream/capture.json');frames=stream.pop('progress_frames');stream['first_progress_seconds']=frames[0]['seconds']if frames else None;stream['last_progress_seconds']=frames[-1]['seconds']if frames else None
calls=[]
for p in sorted((L/'llm-records').glob('*.request.json')):
 body=read(p);metrics=p.with_name(p.stem.split('.')[0]+'.metrics.json');reply=p.with_name(p.stem.split('.')[0]+'.response.txt');events=[]
 if reply.exists():
  for line in reply.read_text().splitlines():
   if line.startswith('data: ')and line[6:]!='[DONE]':events.append(json.loads(line[6:]))
 calls.append({'request_id':p.name.split('.')[0],'request_SHA256':sha(p),'wire_progress_requested':body.get('return_progress',False),'stream':body.get('stream',False),'output_cap':body.get('max_tokens',body.get('max_completion_tokens')),'sampler':{k:body.get(k)for k in ['temperature','top_p','top_k','seed','chat_template_kwargs']},'metrics':read(metrics)if metrics.exists()else None,'actual_progress_frames':sum(isinstance(e.get('prompt_progress'),dict)for e in events),'response_SHA256':sha(reply)if reply.exists()else None})
native=read(L/'native-worker/native-result.json')if (L/'native-worker/native-result.json').exists()else None
result={'classification':'runtime control only, not coding or forge quality','finished':finished,'runtime_restoration':restored,'native':native,'stream_probe':stream,'recorded_calls':calls,'source_hashes_verified':True,'samples':len(rows),'complete_samples':len(good),'measurement_errors':len(rows)-len(good),'peak_GPU_MiB':max(int(x['gpu_csv'].split(',')[0])for x in good if x.get('gpu_csv')),'peak_study_cgroup_bytes':max(x['total_cgroup_bytes']for x in good),'peak_study_PSS_bytes':max(x['total_process_pss_bytes']for x in good),'peak_study_swap_bytes':max(x['total_cgroup_swap_bytes']for x in good),'guard_samples':sum(bool(x.get('budget_guard_triggered'))for x in rows),'minimum_original_disk_free_bytes':min(x['model_disk_free_bytes']for x in good),'minimum_staging_disk_free_bytes':min(x['staging_disk_free_bytes']for x in good),'limits':['5 second samples can miss transient peaks','Saved prior conversation; no live CLI, session database, coding, or Gitea actions','Longer timeouts and prompt progress are combined runtime changes, not quantization evidence']}
(D/'native-compression-control-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'audit_saved':True,'native_passed':native.get('passed')if native else None,'recorded_calls':len(calls),'original_runtime_restored':True}))
