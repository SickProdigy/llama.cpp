"""Export numeric runtime control and source only; exclude histories and generated text."""
from pathlib import Path
import json,hashlib,tarfile,shutil
D=Path(__file__).resolve().parent;R=D.parent.parent;E=R/'evaluations/2026-11-24-gpu-quant';S=D/'resource-adapted-iq4-compression';X=D/'native-compression-control-export'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(D/'native-compression-control-audit.json');assert a['source_hashes_verified']and a['runtime_restoration']['restored'];assert not a['runtime_restoration']['cleanup_errors'];assert read(D/'resource-adapted-iq4-compression-owner-preservation.json')['passed'];pres=read(D/'resource-adapted-iq4-compression-preservation.json');assert all(v for k,v in pres.items()if isinstance(v,bool));assert a['complete_samples']and a['peak_study_swap_bytes']==0 and a['guard_samples']==0
assert a['native']['passed']and not a['native']['used_fallback'];assert a['native']['native_aux_budget']==5400 and a['native']['native_host_budgets']==[5400,5400]
assert len(a['recorded_calls'])==1;call=a['recorded_calls'][0];assert call['wire_progress_requested']and call['stream']and call['actual_progress_frames']>0;assert call['metrics']and not call['metrics'].get('transport_error');assert call['metrics']['usage']
a['model_identity']=read(S/'model-identity.json');a['request_comparison']=read(D/'native-compression-request-comparison.json');a['preservation']=pres;a['owner_pending_edits_preserved']=True
X.mkdir(exist_ok=False)
for src,dst in [('scan_compression_all_archives.py','source/privacy-scan.py'),('run_compression_all_archive_scan.py','source/privacy-launcher.py'),('native_compression_worker.py','source/worker.py'),('native_compression_controller.py','source/controller.py'),('launch_native_compression_control.py','source/launcher.py'),('preflight_native_compression_worker.py','source/preflight.py'),('native-compression-controller-registration.json','registration.json'),('native-compression-protocol.json','protocol.json'),('native-compression-worker-preflight.json','preflight-result.json'),('harness/llm_proxy.py','source/llm_proxy.py'),('model_cache_probe.py','source/model_cache_probe.py'),('audit_native_compression_control.py','source/audit.py'),('audit_compression_originals_after_stage.py','source/preservation-audit.py'),('export_native_compression_control.py','source/export.py')]:
 target=X/dst;target.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(D/src,target)
(X/'summary.json').write_text(json.dumps(a,indent=2)+'\n');manifest={str(p.relative_to(X)):sha(p)for p in sorted(X.rglob('*'))if p.is_file()};(X/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=E/'compression-runtime-control-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz')as tar:
 for p in sorted(X.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(X)))
(E/'compression-runtime-control-summary.json').write_bytes((X/'summary.json').read_bytes());(E/'compression-runtime-control-evidence.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
print(json.dumps({'archive_SHA256':sha(archive),'files':len(manifest)+1,'native_compression_seconds':a['native']['elapsed_seconds'],'runtime_control_only':True}))
