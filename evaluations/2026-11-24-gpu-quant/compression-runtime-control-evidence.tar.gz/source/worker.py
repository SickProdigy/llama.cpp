"""Isolated native guarded compression control; no coding or forge tools enabled."""
from pathlib import Path
import os,sys,json,time,hashlib,contextlib
from ruamel.yaml import YAML
mode=sys.argv[1];assert mode in ['preflight','live'];progress=os.environ.get('PROBE_PROMPT_PROGRESS')=='1';home=Path('/opt/data');home.mkdir(exist_ok=True);os.environ['HERMES_HOME']=str(home);os.environ['HOME']=str(home);sys.path.insert(0,'/opt/hermes')
c=YAML(typ='safe').load(Path('/input/config.yaml').read_text());endpoint='http://compression-llm:11431/v1';alias='gpuquant-adapted-iq4';c['model'].update(default=alias,provider='custom:wide',base_url=endpoint,api_key='local-wide-evaluation-only',context_length=65536,max_tokens=8192);c['custom_providers']=[dict(c['custom_providers'][0],name='wide',base_url=endpoint,api_key='local-wide-evaluation-only',model=alias)];extra=c['custom_providers'][0]['extra_body']
if progress:extra['return_progress']=True
else:extra.pop('return_progress',None)
c['platforms']={};c['secrets']={};c['mcp_servers']={};c['plugins']={'enabled':[],'entries':{}};c['fallback_providers']=[];c['title_generation']={'enabled':False,'model_upgrade_enabled':False};c['compression'].update(context_timeout_seconds=5400,context_total_ceiling_seconds=5400);aux=c.setdefault('auxiliary',{}).setdefault('compression',{});aux.update(model=alias,provider='custom:wide',base_url=endpoint,api_key='local-wide-evaluation-only',timeout=5400)
for name,settings in c['auxiliary'].items():
 if isinstance(settings,dict)and(settings.get('model')or settings.get('provider')):settings.update(model=alias,provider='custom:wide',base_url=endpoint,api_key='local-wide-evaluation-only')
if progress:aux.setdefault('extra_body',{})['return_progress']=True
YAML().dump(c,(home/'config.yaml').open('w'))
with contextlib.redirect_stdout(sys.stderr):
 from run_agent import AIAgent
 from hermes_cli.runtime_provider_custom import _custom_provider_request_overrides
 from agent.auxiliary_client import _effective_aux_timeout
 from agent.conversation_compression_deadline import resolve_context_compression_timeouts
 a=AIAgent(model=alias,provider='custom',base_url=endpoint,api_key='local-wide-evaluation-only',enabled_toolsets=[],request_overrides=_custom_provider_request_overrides(c['custom_providers'][0]),max_tokens=8192,platform='cli',quiet_mode=True,skip_memory=True,skip_background_review=True,skip_context_files=True,load_soul_identity=False,cwd='/tmp')
 ctx=a.context_compressor.context_length;budgets=resolve_context_compression_timeouts();aux_budget=_effective_aux_timeout('compression',None);assert ctx==65536,(ctx,'actual native context');assert budgets==(5400,5400)and aux_budget==5400
out={'native_context':ctx,'native_aux_budget':aux_budget,'native_host_budgets':budgets,'prompt_progress_configured':progress,'native_guarded_facade_used':True,'no_tools_or_forge_enabled':True,'control_not_coding_quality':True,'full_native_CLI_or_GUI_not_exercised':True}
if mode=='live':
 raw=Path('/input/history.json').read_bytes();history=json.loads(raw);messages=history['messages'];before=len(messages);system=messages[0]['content'];start=time.monotonic()
 with contextlib.redirect_stdout(sys.stderr):compressed,new_system=a._compress_context(messages,system,approx_tokens=57002,force=True,trigger='manual')
 elapsed=time.monotonic()-start;out.update(elapsed_seconds=elapsed,input_history_SHA256=hashlib.sha256(raw).hexdigest(),messages_before=before,messages_after=len(compressed),made_progress=bool(getattr(a.context_compressor,'_last_compression_made_progress',False)),used_fallback=bool(getattr(a.context_compressor,'_last_summary_fallback_used',False)),output_messages_SHA256=hashlib.sha256(json.dumps(compressed,ensure_ascii=False,sort_keys=True).encode()).hexdigest());Path('/output/compressed-private.json').write_text(json.dumps({'messages':compressed,'system':new_system},ensure_ascii=False));out['passed']=out['made_progress']and not out['used_fallback']and len(compressed)<before
 Path('/output/native-result.json').write_text(json.dumps(out,indent=2)+'\n')
else:out['passed']=True
print(json.dumps(out));assert out['passed'], 'Native guarded compression did not complete with a model-produced summary; inspect actual control evidence'
