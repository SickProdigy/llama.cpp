"""Bounded isolated memory pilots; no actor, forge credentials or grading inputs."""
from pathlib import Path
import sys,os,json,time,hashlib,subprocess,urllib.request,threading,signal,traceback,re,shutil
from model_cache_probe import advise_inactive_model
D=Path('/state');KEY=sys.argv[1];assert KEY in ['adapted-iq4-compression'];P=json.loads((D/'native-compression-protocol.json').read_text());S=D/('resource-'+KEY);S.mkdir(exist_ok=False)
MODEL=P[KEY];ALIAS='gpuquant-adapted-iq4';NET='hermes-gpuquant-resource-'+KEY;MAIN='hermes-gpuquant-resource-'+KEY+'-model';BACKEND=P['backend_image'];helpers={};EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-gpu-quant-20261124';HELPER='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';owned=None;network=None;stopped=False;before={};monitor_stop=threading.Event();abort=threading.Event();thread=None

def save(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def event(kind,**kw):
 row={'epoch':time.time(),'kind':kind,**kw}
 with(S/'events.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
def docker(*args,check=True,timeout=180):
 z=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and z.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+z.stderr[-1200:])
 return z.stdout

def inspect(name):return json.loads(docker('inspect',name))[0]
def state(name):
 x=inspect(name);return {'id':x['Id'],'image':x['Image'],'config_sha256':hashlib.sha256(json.dumps({k:x[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()).hexdigest(),'running':x['State']['Running'],'started':x['State']['StartedAt'],'restarts':x['RestartCount']}
def http(host,path,body=None,timeout=60):
 req=urllib.request.Request('http://'+host+':11430'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=timeout)as response:raw=response.read()
 return json.loads(raw),raw

def ready(name,alias,ctx,timeout):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  if abort.is_set():raise RuntimeError('Pilot memory guard')
  if not inspect(name)['State']['Running']:raise RuntimeError('Backend exited before ready')
  try:
   props,_=http(name,'/props',timeout=10);health,_=http(name,'/health',timeout=10)
   if props['model_alias']==alias and props['default_generation_settings']['n_ctx']==ctx and health['status']=='ok':return props
  except(OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Backend readiness expired')

def host_memory():
 mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());return {'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
def monitor(out):
 command='for f in /sys/fs/cgroup/memory.current /sys/fs/cgroup/memory.peak /sys/fs/cgroup/memory.swap.current /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.stat /proc/[0-9]*/smaps_rollup; do printf "FILE %s\\n" "$f"; cat "$f" 2>/dev/null; done'
 while not monitor_stop.is_set():
  row={'epoch':time.time(),'containers':{},'model_disk_free_bytes':shutil.disk_usage('/models').free,'staging_disk_free_bytes':shutil.disk_usage('/candidate-models').free}
  try:
   mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());row['host']={'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
   cg_total=0;pss_total=0;swap_total=0
   targets={MAIN:owned,'supervisor':inspect(os.environ['HOSTNAME'])['Id']}
   for ident in docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124',timeout=20).split():
    item=inspect(ident);targets[item['Name'].lstrip('/')]=item['Id']
   unique={ident:name for name,ident in targets.items()}
   for ident,name in unique.items():
    raw=docker('exec',ident,'/bin/sh','-c',command,check=False,timeout=25)
    match=re.search(r'FILE /sys/fs/cgroup/memory.current\n(\d+)',raw);current=int(match.group(1))if match else 0
    match=re.search(r'FILE /sys/fs/cgroup/memory.swap.current\n(\d+)',raw);swap=int(match.group(1))if match else 0
    pss=sum(int(n)*1024 for n in re.findall(r'^Pss:\s*(\d+) kB',raw,re.M))
    row['containers'][name]={'raw':raw,'pss_all_processes_bytes':pss,'cgroup_current_bytes':current,'cgroup_swap_bytes':swap};cg_total+=current;pss_total+=pss;swap_total+=swap
   row.update(total_cgroup_bytes=cg_total,total_process_pss_bytes=pss_total,total_cgroup_swap_bytes=swap_total)
   row['gpu_csv']=docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits',check=False,timeout=20).strip()
   if cg_total>8*1024**3 or pss_total>8*1024**3 or swap_total or mem['MemAvailable']<4*1024**3 or row['model_disk_free_bytes']<100*1024**3 or row['staging_disk_free_bytes']<100*1024**3:
    row['budget_guard_triggered']=True;row['disk_reserve_guard_triggered']=min(row['model_disk_free_bytes'],row['staging_disk_free_bytes'])<100*1024**3;abort.set()
    if owned and inspect(MAIN)['Id']==owned:docker('stop','-t','10',owned,check=False)
  except Exception as error:row['measurement_error']=type(error).__name__+': '+str(error)
  with out.open('a')as f:f.write(json.dumps(row)+'\n')
  monitor_stop.wait(5)

def measure(body):
 prompt,_=http(MAIN,'/apply-template',{'messages':body['messages'],'tools':body.get('tools',[]),'chat_template_kwargs':body.get('chat_template_kwargs',{})});tokens,_=http(MAIN,'/tokenize',{'content':prompt['prompt'],'add_special':True,'parse_special':True});return len(tokens['tokens'])
def request(messages):
 body={'model':ALIAS,'messages':messages,'seed':20261123,'max_tokens':MODEL['probe_output_cap'],'stream':False}
 body.update(MODEL['sampler']);return body

def call(out,body,kind):
 assert not abort.is_set(),'Resource guard latched before request'
 out.mkdir();save(out/'request.json',body);count=measure(body);save(out/'input.json',{'rendered_tokens':count,'context':layout['context'],'kind':kind});assert count+body['max_tokens']<layout['context'];event('probe_start',probe=kind,input_tokens=count)
 start=time.monotonic();result,raw=http(MAIN,'/v1/chat/completions',body,P['per_probe_deadline_seconds']);elapsed=time.monotonic()-start;(out/'response.bin').write_bytes(raw);usage=result.get('usage',{});assert isinstance(usage.get('prompt_tokens'),int);assert usage['prompt_tokens']==count,(count,usage);assert result.get('choices')
 save(out/'capture.json',{'body_complete':True,'seconds':elapsed,'usage':usage,'finish_reason':result['choices'][0].get('finish_reason'),'response_sha256':hashlib.sha256(raw).hexdigest(),'timings':result.get('timings')});event('probe_end',probe=kind,seconds=elapsed);return result

# Source fragment inserted into a separately registered supervisor before first GPU call.
def stream_progress_probe(out,body):
 out.mkdir();body=dict(body,stream=True,return_progress=True,max_tokens=32);save(out/'request.json',body);count=measure(body);assert count+32<layout['context'];save(out/'input.json',{'rendered_tokens':count,'context':layout['context']});start=time.monotonic();raw=b'';frames=[];error=None
 try:
  req=urllib.request.Request('http://'+MAIN+':11430/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=5400)as response:
   buffer=b''
   while True:
    data=response.read1(8192)
    if not data:break
    raw+=data;buffer+=data
    while b'\n'in buffer:
     line,buffer=buffer.split(b'\n',1)
     if line.startswith(b'data: ')and line[6:].strip()!=b'[DONE]':frames.append((time.monotonic()-start,json.loads(line[6:])))
 except Exception as e:error=type(e).__name__+': '+str(e)
 (out/'response-private.txt').write_bytes(raw);progress=[{'seconds':t,'prompt_progress':b['prompt_progress']}for t,b in frames if isinstance(b.get('prompt_progress'),dict)];done=raw.rstrip().endswith(b'data: [DONE]');usage=next((b['usage']for _,b in reversed(frames)if b.get('usage')),None);result={'seconds':time.monotonic()-start,'input_tokens':count,'HTTP_complete':done,'progress_frame_count':len(progress),'progress_frames':progress,'usage':usage,'error':error,'progress_supported':bool(done and progress),'not_coding_quality':True};save(out/'capture.json',result);return result

def launch_control_helpers(progress_enabled):
 records=current/'llm-records';records.mkdir();os.chown(records,1000,1000);output=current/'native-worker';output.mkdir();os.chown(output,1000,1000)
 def mount(rel,target,ro=True):return ['--mount','type=bind,source='+EP+'/'+rel+',target='+target+(',readonly'if ro else'')]
 proxy=MAIN+'-recorder';worker=MAIN+'-native'
 args=['--runtime','runc','--network',NET,'--network-alias','compression-llm','--user','1000:1000','--read-only','--cap-drop','ALL','--memory','512m','--memory-swap','512m','--cpus','1',*mount('harness','/harness'),*mount(str(records.relative_to(D)),'/records',False),'-e','PILOT_LLM_BACKEND=http://'+MAIN+':11430','-e','PILOT_ALIAS='+ALIAS,'-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',HELPER,'/harness/llm_proxy.py']
 helpers[proxy]=docker('run','-d','--name',proxy,'--label','hermes.gpuquant.study=20261124',*args).strip()
 for attempt in range(60):
  try:
   with urllib.request.urlopen('http://'+proxy+':11431/health',timeout=5)as r:assert json.load(r)['status']=='ok'
   break
  except Exception:time.sleep(1)
 else:raise RuntimeError('Recorder not ready')
 args=['--runtime','runc','--network',NET,'--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','2g','--memory-swap','2g','--cpus','2','--tmpfs','/tmp:rw,size=128m,mode=1777','--tmpfs','/opt/data:rw,size=256m,mode=1777',*mount('native_compression_worker.py','/worker.py'),*mount('profiles/adapted-iq4-beets_lifecycle/profile/config.yaml','/input/config.yaml'),*mount('native-adapted-iq4/beets_lifecycle/llm-records/00048.request.json','/input/history.json'),*mount(str(output.relative_to(D)),'/output',False),'-e','PROBE_PROMPT_PROGRESS='+str(int(progress_enabled)),'-e','PYTHONDONTWRITEBYTECODE=1','-e','HERMES_HOME=/opt/data','-e','HOME=/opt/data','--entrypoint','python',HELPER,'/worker.py','live']
 helpers[worker]=docker('run','-d','--name',worker,'--label','hermes.gpuquant.study=20261124',*args).strip();save(current/'native-worker-launch.json',{'argv':args,'container_id':helpers[worker],'scope':'Native guarded compressor only; no coding, forge or full CLI run.'});event('native_control_start',progress_enabled=progress_enabled)
 end=time.monotonic()+3600
 while inspect(worker)['State']['Running']:
  if abort.is_set():raise RuntimeError('Resource guard during compression control')
  if time.monotonic()>end:raise TimeoutError('Native compression control1hour guard')
  time.sleep(5)
 state=inspect(worker)['State'];save(current/'native-worker-exit.json',state);assert state['ExitCode']==0 and not state['OOMKilled'],'Native compression worker failed; retain its evidence'
 result=json.loads((output/'native-result.json').read_text());assert result['passed'];save(current/'native-control-result.json',result);event('native_control_end',seconds=result['elapsed_seconds'],model_summary_used=not result['used_fallback']);return result

def stop_model():
 global owned,thread
 monitor_stop.set()
 if thread:thread.join(150);assert not thread.is_alive();thread=None
 for name,ident in list(helpers.items()):
  assert inspect(name)['Id']==ident;save(current/(name+'-state.json'),inspect(name)['State']);log=subprocess.run(['docker','logs',ident],capture_output=True);(current/(name+'.log')).write_bytes(log.stdout+log.stderr);docker('rm','-f','-v',ident);helpers.pop(name)
 if owned:
  assert inspect(MAIN)['Id']==owned;x=inspect(MAIN);save(current/'exit-state.json',{'running':x['State']['Running'],'exit_code':x['State']['ExitCode'],'oom_killed':x['State']['OOMKilled'],'memory_limit':x['HostConfig']['Memory'],'memory_swap_limit':x['HostConfig']['MemorySwap']});z=subprocess.run(['docker','logs',owned],capture_output=True);(current/'backend.log').write_bytes(z.stdout+z.stderr);docker('rm','-f','-v',owned);owned=None

def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(P['per_model_stage_guard_seconds'])
try:
 registration=json.loads((D/'native-compression-controller-registration.json').read_text());assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==registration['controller_sha256'];assert hashlib.sha256((D/'native-compression-protocol.json').read_bytes()).hexdigest()==registration['protocol_sha256']
 assert hashlib.sha256((D/'model_cache_probe.py').read_bytes()).hexdigest()==registration['cache_helper_sha256']
 for rel,digest in registration['additional_source_sha256'].items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==digest,rel
 assert shutil.disk_usage('/models').free>=100*1024**3,'Disk reserve before resource stage'
 for ident in docker('ps','-q','--filter','label=hermes.gpuquant.study=20261124').split():
  assert ident==os.environ['HOSTNAME'] or inspect(ident)['Id']==inspect(os.environ['HOSTNAME'])['Id'],'Other study job still active; no overlapping GPU stage'
 before={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};assert all(x['running']for x in before.values());save(S/'runtime-before.json',before);save(S/'host-before.json',host_memory());model=Path('/candidate-models')/MODEL['file'];assert model.is_file();assert shutil.disk_usage('/candidate-models').free>=100*1024**3,'Staging disk reserve before hashing';assert shutil.disk_usage('/models').free>=100*1024**3,'Original model disk reserve before hashing'
 h=hashlib.sha256()
 with model.open('rb')as f:
  for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
 assert h.hexdigest()==MODEL['sha256'] and model.stat().st_size==MODEL['expected_bytes']
 with model.open('rb')as f:os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 save(S/'model-identity.json',{'file':model.name,'bytes':model.stat().st_size,'sha256':h.hexdigest(),'specific_study_file_advised_DONTNEED_after_hash':True,'not_global_cache_flush_or_cold_cache_proof':True})
 assert subprocess.run(['docker','inspect',MAIN],capture_output=True).returncode!=0
 network=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME']);stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 cache_observation=advise_inactive_model(model);save(S/'selected-file-cache-after-original-stop.json',cache_observation);assert cache_observation['mincore_cached_page_bytes_after']==0,'Selected model file still resident after original backend stopped; inspect cache attribution before scoring'
 results=[]
 for index,layout in enumerate(MODEL['layouts']):
  current=S/('layout'+str(index));current.mkdir();abort.clear();monitor_stop.clear();passed=False
  per_layout_cache=advise_inactive_model(model);save(current/'selected-file-cache-before-layout.json',per_layout_cache);assert per_layout_cache['mincore_cached_page_bytes_after']==0,'Inactive candidate pages remain before new layout'
  try:
   launch=['--network',NET,'--gpus','all','--memory','6656m','--memory-swap','6656m','--cpus','8','--volumes-from','llama-cpp:ro','--mount','type=volume,source=hermes-gpuquant-20261124-model-stage,target=/candidate-models,readonly','--read-only','--tmpfs','/tmp:rw,size=128m','--no-healthcheck',BACKEND,'-m','/candidate-models/'+MODEL['file'],'-lv','5','--load-mode',P['load_mode'],'--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(layout['context']),'--parallel','1','--cache-type-k',layout.get('cache_k','q4_0'),'--cache-type-v',layout.get('cache_v','q4_0'),'--cache-ram','512','--ctx-checkpoints','2','--fit','off','-ngl',str(layout['gpu_layers']),'--threads','8','--threads-batch','8','--poll','0','--poll-batch','0','-b','512','-ub',str(layout['ubatch']),'--n-predict',str(MODEL['probe_output_cap'])]
   if 'cpu_moe_layers'in layout:launch+=['--n-cpu-moe',str(layout['cpu_moe_layers'])]
   start=time.monotonic();owned=docker('run','-d','--pull','never','--name',MAIN,'--label','hermes.gpuquant.study=20261124',*launch).strip();save(current/'launch.json',{'argv':launch,'layout':layout,'container_id':owned});thread=threading.Thread(target=monitor,args=(current/'samples.jsonl',),daemon=True);thread.start();props=ready(MAIN,ALIAS,layout['context'],P['load_deadline_seconds']);save(current/'ready.json',{'seconds':time.monotonic()-start,'props':props});event('backend_ready',layout=layout)
   text='Resource streaming probe. Reply ONLY progress-control-ok.\n'+'\n'.join('Record '+str(i)+': amber cedar lake stone north south.'for i in range(1400))
   body=request([{'role':'user','content':text}]);stream=stream_progress_probe(current/'progress-stream',body);event('progress_compatibility',supported=stream['progress_supported'],frames=stream['progress_frame_count'])
   save(current/'placement-before-control.json',{'requested_full_GPU':True,'fit_off':True,'context':layout['context']})
   result=launch_control_helpers(stream['progress_supported']);tool_ok=False
   passed=True;results.append({'layout':layout,'resource_probes_completed':True,'progress_supported':stream['progress_supported'],'native_guarded_compression_completed':result['passed'],'model_summary_used':not result['used_fallback'],'no_agent_quality_claim':True});save(current/'result.json',results[-1])
  except Exception as e:
   backend_state=inspect(MAIN)['State']if owned else{}
   log_result=subprocess.run(['docker','logs',owned],capture_output=True,text=True,timeout=60)if owned else None
   backend_log=(log_result.stdout+log_result.stderr)if log_result else''
   gpu_oom=any(text in backend_log.lower()for text in ['cuda error: out of memory','cuda out of memory','cudamalloc failed','cuda_error_out_of_memory'])
   retry_gpu_layout=gpu_oom and not backend_state.get('OOMKilled',False)and not abort.is_set()
   result={'layout':layout,'resource_probes_completed':False,'error':type(e).__name__+': '+str(e),'no_model_quality_score':True,'backend_state':backend_state,'GPU_OOM_log_marker':gpu_oom,'retry_next_GPU_layout':retry_gpu_layout};results.append(result);save(current/'result.json',result);event('layout_error',error=str(e))
  finally:stop_model()
  if passed or not results[-1].get('retry_next_GPU_layout',False):break
 save(S/'finished.json',{'results':results,'model':KEY,'not_agent_qualification':True})
except BaseException as e:save(S/'controller-error.json',{'error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc()});event('controller_error',error=str(e))
finally:
 signal.alarm(0);errors=[]
 try:
  if owned:stop_model()
 except BaseException as e:errors.append(str(e))
 try:
  if stopped:abort.clear();docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304,600);docker('start','hermes')
  after={n:state(n)for n in before}
  for n,b in before.items():assert all(after[n][k]==b[k]for k in ['id','image','config_sha256','running'])
  if before:assert after['hermes-codex']==before['hermes-codex']
  if network:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network and not net['Containers'];docker('network','rm',network)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors,'host_after':host_memory()});event('original_runtime_restored')
 except BaseException as e:save(S/'RESTORATION-ERROR.json',{'error':str(e),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(e))
