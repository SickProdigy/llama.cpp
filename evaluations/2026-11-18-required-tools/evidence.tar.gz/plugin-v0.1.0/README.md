Reconstructed pre-hook implementation; module hash matches the recorded Fable rerun and preview PR diagnostic. Later versions only add the native-call blocking hook or root-directory handling.
