import copy,json,urllib.request,base64,datetime
from driver import Driver,R
ROOT='https://gitea.rcs1.top/api/v1/repos/'
def get(path):return json.load(urllib.request.urlopen(ROOT+path))
up='sickprodigy/nicotineplus-plugins';file=get(up+'/contents/README.md');original=base64.b64decode(file['content']).decode();before={'repository':get(up),'main':get(up+'/branches/main'),'fork_main':get('hermes-agent/hermes-mcp-test-20261117-vf-144838/branches/main')};(R/'full-source-before.json').write_text(json.dumps(before,indent=2))
existing=get(up+'/issues?state=all&limit=100')
cases=[
 ('qwen9-q5','Qwen3.5-9B-Q5_K_M.gguf','qwen3.5-9b-q5_k_m', [('facade','example-wording','A reference implementation demonstrating best practices for Nicotine+ plugin development.','A reference plugin demonstrating best practices for Nicotine+ plugin development.')]),
 ('preview9-q4','Qwen3.5-9B-9b-v5s1-imat-Q4_K_M.gguf','qwen3.5-9b-toolcall-preview-q4_k_m', [('native','buddy-wording','Automatically manage your buddy list based on channel interactions.','Automatically manage your buddy list based on chat-room interactions.'),('facade','api-wording','Authenticated searches and download batches through your existing Nicotine+ session.','Authenticated searches and download batches using your existing Nicotine+ session.')]),
 ('vibeforged-q4','Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m', [('facade','localai-wording','Connect room or private chat to a local Ollama or llama.cpp server without','Connect room or private chat to a local Ollama or llama.cpp backend without')]),
 ('fablevibes-q4','Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','qwen3.6-14b-a3b-fablevibes-q4_k_m', [('facade','announcer-wording','Preview or send a message to explicitly configured, currently joined rooms. Named','Preview or send a message to explicitly configured, currently joined chat rooms. Named')])]
prepared=[];date=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d')
for model,filename,alias,variants in cases:
 for mode,label,old,new in variants:
  assert original.count(old)==1
  assert not any(old in (x.get('body') or '') for x in existing if not x.get('pull_request')),'Correction already tracked; choose a distinct fixture'
  run=date+'-required-'+model+'-'+mode+'-'+label;branch='mcp-'+run
  p={'run_id':run,'kind':'contribution','task':'full','mode':mode,'alias':alias,'seconds':300,'call_limit':20,'temperature':0.2,'fork_name':'hermes-mcp-test-20261117-vf-144838','branch':branch,'file_sha':file['sha'],'original_content':original,'expected_content':original.replace(old,new,1),'old_text':old,'new_text':new,'issue_title':'MCP test: '+label+' ('+model+' '+mode+')','issue_body':f'In README.md replace exactly `{old}` with `{new}`. Bounded Hermes MCP contribution test; no unrelated implementation requested.','pr_title':'Docs: '+label+' ('+model+' '+mode+')','pr_body':'Refs #<issue-number>\n\nMake only the requested README.md correction. Hermes model evaluation; leave open for review.'}
  p['prompt']=f'Using only the configured Gitea MCP, contribute this documentation correction to sickprodigy/nicotineplus-plugins. In README.md replace the exact text "{old}" with "{new}". First open one issue in that upstream repository with title "{p["issue_title"]}" and this exact body:\n{p["issue_body"]}\n\nVerify and reuse your existing fork hermes-agent/hermes-mcp-test-20261117-vf-144838. Create branch {branch} in that fork from main, then commit only the requested text replacement on that branch. Open one PR from your fork branch to upstream main with title "{p["pr_title"]}" and this exact body (replace <issue-number> with your newly created upstream issue number):\n{p["pr_body"]}\n\nRead back the upstream issue, changed file on the fork branch and upstream PR, then return their URLs. Leave the PR open. Do not change any default branch, merge or close anything, change connections or repository settings, or substitute GitHub/browser/terminal actions. If a step fails, report the exact error and any resources already created, then stop.'
  prepared.append(p)
(R/'full-manifests.json').write_text(json.dumps(prepared,indent=2))
with Driver() as driver:
 for model,filename,alias,variants in cases:
  driver.switch(model,filename,alias)
  for p in prepared:
   if p['alias']==alias:driver.run(p)
