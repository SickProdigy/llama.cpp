import subprocess,json,pathlib,tarfile,hashlib,urllib.request,datetime,base64
r=pathlib.Path('/tmp/hermes-required-eval');out={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'containers':{}}
for name in ['hermes','llama-cpp','mcp-gitea-hermes']:
 before=json.loads((r/(name+'-inspect.json')).read_text())[0];now=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
 out['containers'][name]={'running':now['State']['Running'],'health':now['State'].get('Health',{}).get('Status'),'same_image':before['Image']==now['Image'],'same_command':before['Config']['Cmd']==now['Config']['Cmd'],'same_environment':before['Config']['Env']==now['Config']['Env'],'same_mounts':before['Mounts']==now['Mounts']}
 assert now['State']['Running'] and all(out['containers'][name][k] for k in ['same_image','same_command','same_environment','same_mounts'])
with tarfile.open(r/'profile.tgz') as t:before=t.extractfile('config.yaml').read()
now=subprocess.check_output(['docker','exec','hermes','cat','/opt/data/config.yaml']);out['normal_profile_config_unchanged']=hashlib.sha256(before).digest()==hashlib.sha256(now).digest();assert out['normal_profile_config_unchanged']
p=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props'));out['backend']={'alias':p['model_alias'],'context':p['default_generation_settings']['n_ctx']};assert out['backend']=={'alias':'qwen3.6-14b-a3b-vibeforged-v2-q4_k_m','context':98304}
source=json.load(urllib.request.urlopen('https://gitea.rcs1.top/api/v1/repos/sickprodigy/nicotineplus-plugins/branches/main'));out['nicotine_upstream_main']=source['commit']['id'];assert out['nicotine_upstream_main']=='84afaf401b29753b6810e4f92f253e0d28637dbf'
p=json.loads((r/'freshfork-manifest.json').read_text());f=json.load(urllib.request.urlopen('https://gitea.rcs1.top/api/v1/repos/sickprodigy/SonicRatings/contents/README.md?ref=main'));out['sonicratings_upstream_readme_unchanged']=base64.b64decode(f['content']).decode()==p['original_content'];assert out['sonicratings_upstream_readme_unchanged']
out['focused_plugin_deployed_to_normal_gateway']=False;out['mcp_clone_only']=True;out['hermes_codex_touched']=False;out['disk_free_bytes']=__import__('shutil').disk_usage('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/models').free
(r/'final-restoration.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
