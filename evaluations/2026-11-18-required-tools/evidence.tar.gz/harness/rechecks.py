import copy,json,urllib.request
from driver import Driver,R
cases=json.loads((R/'full-manifests.json').read_text());f=copy.deepcopy(next(p for p in cases if p['alias']=='qwen3.6-14b-a3b-fablevibes-q4_k_m'));old=f['branch'];f['run_id']+='-recheck';f['branch']+='-recheck';f['prompt']=f['prompt'].replace(old,f['branch'])
p=copy.deepcopy(next(p for p in cases if p['mode']=='facade' and p['alias']=='qwen3.5-9b-toolcall-preview-q4_k_m'));p.update({'run_id':'20261118-required-preview-pr-reference-only','task':'pr-only','seed_issue_number':15,'seed_branch':True,'seed_commit':True,'pr_body':'Refs #<issue-number>','seconds':180,'call_limit':8})
p['prompt']=f'Using only configured Gitea MCP, open a PR in sickprodigy/nicotineplus-plugins from hermes-agent/hermes-mcp-test-20261117-vf-144838 branch {p["branch"]} to upstream main. That branch already contains the exact README fix for upstream issue #15. Use title "{p["pr_title"]}" and body "Refs #15". Read the PR back and return its URL. Leave it open; do not create issues, branches or forks, edit files, merge, change settings or use other tools.'
(R/'recheck-manifests.json').write_text(json.dumps([f,p],indent=2))
with Driver() as d:
 d.switch('fablevibes-recheck','Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf',f['alias']);d.run(f)
 d.switch('preview9-reference-only','Qwen3.5-9B-9b-v5s1-imat-Q4_K_M.gguf',p['alias']);d.run(p)
