import json,copy
from driver import Driver,R
base=json.loads((R/'repeat-manifests.json').read_text())[2]
import subprocess
subprocess.run(['docker','exec','hermes-required-store','python','/eval/root_preflight.py'],check=True)
subprocess.run(['docker','cp','hermes-required-store:/eval/root-preflight.json',str(R/'root-preflight.json')],check=True)
with Driver() as d:
 for model,filename,alias in [('vibeforged','Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m'),('fablevibes','Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','qwen3.6-14b-a3b-fablevibes-q4_k_m')]:
  d.switch(model+'-root-tree',filename,alias)
  p=copy.deepcopy(base);p.update(run_id='20261118-required-'+model+'-root-tree-review',kind='read',task='review',seconds=180,call_limit=16,prompt='Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.');d.run(p)
