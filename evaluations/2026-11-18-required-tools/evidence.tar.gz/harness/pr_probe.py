import tarfile,json,copy,pathlib,urllib.request
from driver import Driver,R
archive=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-18-contribution/evidence.tar.gz')
with tarfile.open(archive) as t:manifests=json.load(t.extractfile('harness/manifests.json'))
p=next(x for x in manifests if x['run_id']=='20261118-qwen9-q5-matched-contribution');p=copy.deepcopy(p);p.update({'kind':'contribution','task':'pr-only','seconds':180,'call_limit':8,'seed_issue_number':10,'seed_branch':True,'seed_commit':True,'temperature':0.2})
p['prompt']=f'Using only the configured Gitea MCP, open one pull request in sickprodigy/nicotineplus-plugins from hermes-agent/hermes-mcp-test-20261117-vf-144838 branch {p["branch"]} to upstream main. The requested README correction for upstream issue #10 is already committed on that fork branch. Use this exact PR title: {p["pr_title"]}\nUse this exact PR body:\n{p["pr_body"].replace("<issue-number>","10")}\nRead the PR back and return its URL. Leave it open for review. Do not create another issue, fork or branch, change files or settings, merge or close anything, or use alternatives to Gitea MCP. If a step fails, report the error and stop.'
def existing():
 pulls=json.load(urllib.request.urlopen('https://gitea.rcs1.top/api/v1/repos/sickprodigy/nicotineplus-plugins/pulls?state=all&limit=100'))
 return [x for x in pulls if x.get('head',{}).get('ref')==p['branch']]
assert not existing(),'Existing PR would invalidate this probe'
with Driver() as driver:
 driver.switch('qwen9-q5-required','Qwen3.5-9B-Q5_K_M.gguf','qwen3.5-9b-q5_k_m')
 for mode in ['native','facade']:
  if existing():print('SKIP remaining PR probe: fixture already has a PR',flush=True);break
  case=copy.deepcopy(p);case['mode']=mode;case['run_id']='20261118-required-qwen-pr-'+mode
  driver.run(case)
