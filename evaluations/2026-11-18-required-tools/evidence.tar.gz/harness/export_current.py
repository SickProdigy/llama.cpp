import pathlib,json,re,hashlib,tarfile,io,subprocess
r=pathlib.Path('/tmp/hermes-required-eval');out=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-18-required-tools');secrets=json.loads((r/'secrets.json').read_text());allowed={'sickprodigy/nicotineplus-plugins','sickprodigy/SonicRatings','sickprodigy/sick-cogs','sickprodigy/Sick-Cogs','hermes-agent/SonicRatings','hermes-agent/hermes-mcp-test-20261117-vf-144838','hermes-agent/nicotineplus-plugins'};unrelated=set()
# Add environment secrets from private inspection snapshots without exporting them.
for p in r.glob('*-inspect.json'):
 for c in json.loads(p.read_text()):
  for env in c.get('Config',{}).get('Env',[]):
   k,_,v=env.partition('=')
   if re.search(r'(api.?key|token|secret|password|authorization)',k,re.I) and len(v)>=8 and not v.startswith(('http:','https:')):secrets.append(v)
secrets=sorted(set(secrets),key=len,reverse=True)
def scan(x):
 if isinstance(x,dict):
  full=x.get('full_name')
  if isinstance(full,str) and '/' in full and full not in allowed:
   for k in ('full_name','description','clone_url','html_url','ssh_url'):
    v=x.get(k)
    if isinstance(v,str) and len(v)>3:unrelated.add(v)
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
 elif isinstance(x,str):
  try:scan(json.loads(x))
  except Exception:pass
for f in r.glob('20*-required-*/native-calls.json'):scan(json.loads(f.read_text()))
replacements=[(v,'[REDACTED_SECRET]') for v in secrets]+[(v,'[UNRELATED_REPOSITORY]') for v in sorted(unrelated,key=len,reverse=True)]
def structured(value):
 if isinstance(value,dict):
  full=value.get('full_name')
  if isinstance(full,str) and '/' in full and full not in allowed:return {'redacted':True,'reason':'unrelated repository metadata'},True
  changed=False;result={}
  for key,item in value.items():result[key],c=structured(item);changed=changed or c
  return result,changed
 if isinstance(value,list):
  result=[];changed=False
  for item in value:v,c=structured(item);result.append(v);changed=changed or c
  return result,changed
 if isinstance(value,str):
  try:
   parsed=json.loads(value)
   if isinstance(parsed,(dict,list)):
    result,c=structured(parsed)
    if c:return json.dumps(result,ensure_ascii=False),True
  except Exception:pass
  match=re.fullmatch(r'(.*?\n\n)(.*)(\n</untrusted_tool_result>)',value,re.S)
  if match:
   body,c=structured(match[2])
   if c:return match[1]+body+match[3],True
 return value,False
def scrub(text):
 try:
  parsed=json.loads(text);changed,c=structured(parsed)
  if c:text=json.dumps(changed,indent=2,ensure_ascii=False)
 except Exception:pass
 for old,new in replacements:
  for representation in {old,json.dumps(old,ensure_ascii=False)[1:-1],json.dumps(json.dumps(old,ensure_ascii=False)[1:-1],ensure_ascii=False)[1:-1]}:text=text.replace(representation,new)
 return re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '[USER_EMAIL]',text)
files=[]
for d in sorted(r.glob('20*-required-*')):
 if d.is_dir():
  for f in sorted(d.iterdir()):
   if f.is_file():files.append((str(f.relative_to(r)),f))
# An explicit allowlist prevents private profiles, inspect snapshots and third-party cards leaking.
for pat in ['*-props.json','*-gpu.json','*-console.log','*-backend.log','restoration-*.json','*-manifests.json']:
 for f in sorted(r.glob(pat)):files.append(('harness/'+f.name,f))
for name in ['setup.py','final_verify.py','export_current.py','session.py','session-before-progress-retries.py','guard.py','guard-before-generic.py','guard-before-body-message.py','retry_ledger.py','prepare_profile.py','driver.py','pr_probe.py','full_probe.py','rechecks.py','repeat_probe.py','finalists.py','verify_runs.py','gguf_meta.py','plugin_preflight.py','repeat-probe.log','pr-probe.log','full-probe.log','rechecks.log','finalists.log','test-profile.log','test-harness.log','model-cleanup.json','download-verified.json','candidate-download.json','deletion-preflight.json','full-source-before.json','freshfork-manifest.json','longcontext-input.json','longcontext-verification.json','verification.json','workflow-summary.json','final-restoration.json','metrics.json','manual-grades.json']:
 f=r/name
 if f.exists():files.append(('harness/'+name,f))
repo=out.parents[1]
for f in (repo/'hermes-profile/gitea-focused').iterdir():
 if f.is_file():files.append(('plugin-v0.1.3/'+f.name,f))

for version in ['v0.1.0','v0.1.1','v0.1.2']:
 for f in (r/('plugin-'+version)).iterdir():
  if f.is_file():files.append(('plugin-'+version+'/'+f.name,f))
for name in ['root_rechecks.py','root-rechecks.log','summarize.py','root_preflight.py','root-preflight.json']:
 if (r/name).exists():files.append(('harness/'+name,r/name))
manifest=[];seen=set()
with tarfile.open(out/'evidence.tar.gz','w:gz') as t:
 for name,f in files:
  if name in seen:continue
  seen.add(name);data=scrub(f.read_text(errors='replace')).encode()
  for secret in secrets:
   if secret.encode() in data:raise RuntimeError('Secret redaction failed')
  if f.suffix=='.json':json.loads(data)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'evidence-manifest.json').write_text(json.dumps({'redaction':'Credential values, email addresses and unrelated repository metadata removed. Private profiles, environment and Docker inspections excluded. Third-party model cards are not republished.','members':manifest},indent=2)+'\n')
sha=hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest();(out/'evidence.tar.gz.sha256').write_text(sha+'  evidence.tar.gz\n')
for name in ['verification.json','workflow-summary.json','model-cleanup.json','download-verified.json','candidate-download.json','final-restoration.json','longcontext-verification.json','metrics.json','manual-grades.json']:
 if (r/name).exists():(out/name).write_text(scrub((r/name).read_text())+'\n')
with tarfile.open(out/'evidence.tar.gz') as t:
 for m in manifest:assert hashlib.sha256(t.extractfile(m['path']).read()).hexdigest()==m['sha256']
print('Sanitized and verified',len(manifest),'members; archive',sha)
