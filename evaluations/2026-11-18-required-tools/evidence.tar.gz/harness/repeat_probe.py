import json,base64,urllib.request,copy,datetime
from driver import Driver,R
api='https://gitea.rcs1.top/api/v1/repos/sickprodigy/nicotineplus-plugins/'
file=json.load(urllib.request.urlopen(api+'contents/README.md'));text=base64.b64decode(file['content']).decode();issues=json.load(urllib.request.urlopen(api+'issues?state=all&limit=100'));date=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d')
models=[
 ('qwen9-q5','Qwen3.5-9B-Q5_K_M.gguf','qwen3.5-9b-q5_k_m',[
  ('catalog-wording','interface for adding other authorized catalogs later.','interface for adding additional authorized catalogs later.'),
  ('beets-wording','Automatic imports are disabled by default and guarded by an allowed download','Automatic imports start disabled and are guarded by an allowed download')]),
 ('vibeforged-q4','Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',[
  ('spam-status','ignore list. Room scopes, trusted-user exemptions, status, and counter-reset','ignore list. Room scopes, trusted-user exemptions, status reporting, and counter-reset'),
  ('wolfram-wording','Query Wolfram|Alpha for compact plaintext answers and step-by-step result pods','Query Wolfram|Alpha for concise plaintext answers and step-by-step result pods')]),
 ('fablevibes-q4','Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','qwen3.6-14b-a3b-fablevibes-q4_k_m',[
  ('wolfram-rooms','approved usernames, optional rooms, cooldowns, and concurrency limits. AppIDs','approved usernames, optional room restrictions, cooldowns, and concurrency limits. AppIDs'),
  ('example-api','- Understanding Nicotine+ API','- Understanding the Nicotine+ API')]),
 ('preview9-q4','Qwen3.5-9B-9b-v5s1-imat-Q4_K_M.gguf','qwen3.5-9b-toolcall-preview-q4_k_m',[
  ('book-ui',"blocking Nicotine+'s UI. Remote `!book` requests are opt-in, room-filterable,",'blocking the Nicotine+ UI. Remote `!book` requests are opt-in, room-filterable,')])]
prepared=[]
for model,filename,alias,fixtures in models:
 for label,old,new in fixtures:
  assert text.count(old)==1,(label,text.count(old))
  assert not any(old in (x.get('body') or '') for x in issues if not x.get('pull_request')),'Correction already tracked: '+label
  run=date+'-required-'+model+'-repeat-'+label;branch='mcp-'+run
  p={'run_id':run,'kind':'contribution','task':'full','mode':'facade','alias':alias,'seconds':300,'call_limit':20,'temperature':0.2,'fork_name':'hermes-mcp-test-20261117-vf-144838','branch':branch,'file_sha':file['sha'],'original_content':text,'expected_content':text.replace(old,new,1),'old_text':old,'new_text':new,'issue_title':'MCP test: '+label+' ('+model+')','issue_body':f'In README.md replace exactly `{old}` with `{new}`. Bounded Hermes MCP contribution test; no unrelated implementation requested.','pr_title':'Docs: '+label+' ('+model+')','pr_body':'Refs #<issue-number>'}
  p['prompt']=f'Using only configured Gitea MCP, make this documentation correction in sickprodigy/nicotineplus-plugins. In README.md replace exactly "{old}" with "{new}". Open one upstream issue titled "{p["issue_title"]}" with this exact body:\n{p["issue_body"]}\n\nVerify and reuse fork hermes-agent/hermes-mcp-test-20261117-vf-144838. Create branch {branch} from main in that fork and commit only the requested replacement. Open one PR back to upstream main, titled "{p["pr_title"]}". Its body must be Refs # followed by the number of the issue you created. Read back the issue, changed file and PR and return their URLs. Leave the PR open. Do not change a default branch, create another fork, merge, close anything, change settings or connections, or use GitHub/browser/terminal alternatives. If a step fails, report the error and existing resources, then stop.'
  prepared.append(p)
(R/'repeat-manifests.json').write_text(json.dumps(prepared,indent=2))
with Driver() as d:
 for model,filename,alias,fixtures in models:
  d.switch(model+'-repeat',filename,alias)
  for p in prepared:
   if p['alias']==alias:d.run(p)
  for task,prompt in [('explain','Find my SonicRatings repo and tell me what it does.'),('review','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.')]:
   p=copy.deepcopy(next(p for p in prepared if p['alias']==alias));p.update({'run_id':date+'-required-'+model+'-read-'+task,'kind':'read','task':task,'seconds':180,'call_limit':16,'prompt':prompt});d.run(p)
