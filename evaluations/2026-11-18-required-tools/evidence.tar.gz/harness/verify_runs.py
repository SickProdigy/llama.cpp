import pathlib,json,urllib.request,urllib.error,base64,datetime
R=pathlib.Path('/tmp/hermes-required-eval');API='https://gitea.rcs1.top/api/v1/repos/'
def get(path):
 try:return json.load(urllib.request.urlopen(API+path,timeout=20))
 except urllib.error.HTTPError as e:return {'error':e.code}
def decode(v):
 for _ in range(5):
  if isinstance(v,str):
   try:v=json.loads(v);continue
   except ValueError:return v
  if isinstance(v,dict) and set(v)=={'result'}:v=v['result'];continue
  return v
 return v
def good(c):
 x=decode(c.get('result'));return not isinstance(x,dict) or not ('error' in x or x.get('isError'))
def verify(folder):
 p=json.loads((folder/'manifest.json').read_text());
 if p.get('task') not in ('full','pr-only'):return None
 up=p.get('upstream_owner','sickprodigy')+'/'+p.get('upstream_repo','nicotineplus-plugins');fork=p.get('fork_owner','hermes-agent')+'/'+p['fork_name'];issues=get(up+'/issues?state=all&limit=100');pulls=get(up+'/pulls?state=all&limit=100')
 state=json.loads((folder/'state.json').read_text());trace=json.loads((folder/'native-calls.json').read_text());result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {};final=result.get('final_response') or ''
 ii=[x for x in issues if not x.get('pull_request') and x.get('title')==p['issue_title']];pp=[x for x in pulls if x.get('head',{}).get('ref')==p['branch'] and x.get('title')==p['pr_title']]
 branch=get(fork+'/branches/'+p['branch']);file=get(fork+'/contents/README.md?ref='+p['branch']);text=base64.b64decode(file['content']).decode() if 'content' in file else None
 info=get(fork);pr=get(up+'/pulls/'+str(pp[0]['number'])) if len(pp)==1 else {};files=get(up+'/pulls/'+str(pp[0]['number'])+'/files') if len(pp)==1 else []
 issue_ok=len(ii)==1 and ii[0]['body']==p['issue_body'];reference=p['pr_body'].replace('<issue-number>',str(ii[0]['number'])) if ii else None
 pr_ok=len(pp)==1 and pr.get('head',{}).get('repo',{}).get('full_name')==fork and pr.get('head',{}).get('ref')==p['branch'] and pr.get('base',{}).get('repo',{}).get('full_name')==up and pr.get('base',{}).get('ref')=='main' and pr.get('body')==reference and pr.get('state')=='open' and not pr.get('merged')
 def readback(suffix,key,num,owner,repo,stage):
  writes=[i for i,c in enumerate(trace) if c.get('stage')==stage];minimum=max(writes) if writes else -1
  return any(i>minimum and c['name'].endswith('__'+suffix) and c['args'].get('method')=='get' and c['args'].get(key)==num and c['args'].get('owner')==owner and c['args'].get('repo')==repo and good(c) for i,c in enumerate(trace))
 ow,re=up.split('/',1);fo,fr=fork.split('/',1)
 rb={'issue':bool(ii) and readback('issue_read','issue_number',ii[0]['number'],ow,re,'issue'),'pr':bool(pp) and readback('pull_request_read','pull_number',pp[0]['number'],ow,re,'pr')}
 commits=[i for i,c in enumerate(trace) if c.get('stage')=='commit'];rb['file']=any(i>max(commits or [-1]) and c['name'].endswith('__get_file_contents') and c['args'].get('owner')==fo and c['args'].get('repo')==fr and c['args'].get('ref')==p['branch'] and str(c['args'].get('path','')).lstrip('/')=='README.md' and good(c) for i,c in enumerate(trace))
 url_ok={'issue':bool(ii) and '/'+up+'/issues/'+str(ii[0]['number']) in final,'pr':bool(pp) and '/'+up+'/pulls/'+str(pp[0]['number']) in final,'file':'/'+fork+'/src/branch/'+p['branch']+'/README.md' in final}
 writes=[c['stage'] for c in trace if c.get('stage')!='read' and good(c)]
 v={'run_id':p['run_id'],'mode':p['mode'],'task':p['task'],'issue_present':issue_ok,'issue_created_this_run':issue_ok and 'issue' in writes,'issue_number':ii[0]['number'] if ii else None,'branch_present':'name' in branch,'branch_created_this_run':'branch' in writes,'fork_created_this_run':'fork' in writes,'file_exact':text==p['expected_content'],'file_committed_this_run':'commit' in writes,'pr_correct':pr_ok,'pr_created_this_run':'pr' in writes,'pr_number':pp[0]['number'] if pp else None,'pr_url':pr.get('html_url'),'fork_parent':info.get('parent',{}).get('full_name'),'one_pr_file':isinstance(files,list) and len(files)==1 and files[0].get('filename')=='README.md','readback':rb,'returned_urls':url_ok,'seconds':state['elapsed'],'model_tool_calls':state['model_tool_calls'],'early_stop':state.get('early_stop'),'final_response':final}
 v['full_pass']=p['task']=='full' and all([issue_ok,v['issue_created_this_run'],v['branch_created_this_run'],v['file_exact'],v['file_committed_this_run'],pr_ok,v['pr_created_this_run'],v['fork_parent']==up,v['one_pr_file'],all(rb.values()),all(url_ok.values()),not v['early_stop']])
 v['pr_only_pass']=p['task']=='pr-only' and all([pr_ok,v['pr_created_this_run'],rb['pr'],url_ok['pr'],not v['early_stop']])
 return v
out=[]
for folder in sorted(R.glob('20*-required-*')):
 if folder.is_dir() and (folder/'manifest.json').exists() and (folder/'state.json').exists():
  v=verify(folder)
  if v:out.append(v)
(R/'verification.json').write_text(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':out},indent=2))
for v in out:print(json.dumps({k:v[k] for k in ['run_id','issue_created_this_run','branch_created_this_run','file_committed_this_run','pr_correct','full_pass','pr_only_pass','readback','pr_number']}))
