import pathlib,json,statistics,csv
r=pathlib.Path('/tmp/hermes-required-eval');out=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-18-required-tools');d=json.loads((r/'verification.json').read_text())
for v in d['runs']:
 v['workflow_resources_pass']=v['task']=='full' and all(v[k] for k in ['issue_created_this_run','branch_created_this_run','file_exact','file_committed_this_run','pr_correct','pr_created_this_run','one_pr_file']) and not v['early_stop']
(r/'workflow-summary.json').write_text(json.dumps(d,indent=2));lookup={v['run_id']:v for v in d['runs']};rows=[]
for folder in sorted(r.glob('20*-required-*')):
 if not folder.is_dir() or not (folder/'manifest.json').exists() or not (folder/'state.json').exists():continue
 p=json.loads((folder/'manifest.json').read_text());s=json.loads((folder/'state.json').read_text());v=lookup.get(p['run_id'],{});samples=json.loads((r/(p['run_id']+'-gpu.json')).read_text());peaks=[]
 for x in samples:
  try:peaks.append(int(x['gpu'].split(',')[0]))
  except Exception:pass
 excluded=p['run_id']=='20261118-required-fablevibes-q4-facade-announcer-wording' or p['run_id']=='20261118-required-vibeforged-rootfix-review'
 rows.append({'run_id':p['run_id'],'model':p['alias'],'mode':p['mode'],'task':p['task'],'phase':'excluded_harness_or_interface_defect' if excluded else 'root_adapter_probe' if '-rootfix-' in p['run_id'] else 'root_tree_recheck' if '-root-tree-' in p['run_id'] else 'repeat_reference_body' if '-repeat-' in p['run_id'] else 'fresh_fork' if '-freshfork-' in p['run_id'] else 'long_context' if p['task']=='longcontext' else 'pr_only' if p['task']=='pr-only' else 'pilot_strict_body' if p['task']=='full' else 'read','seconds':s['elapsed'],'first_tool_completed_seconds':(json.loads((folder/'calls.json').read_text()) or [{}])[0].get('elapsed'),'model_tool_calls':s['model_tool_calls'],'native_calls':s['native_calls'],'peak_vram_mib':max(peaks) if peaks else None,'issue':s['issue_number'],'pr':s['pr_number'],'fork_created_this_run':v.get('fork_created_this_run',''),'workflow_resources_pass':v.get('workflow_resources_pass',''),'all_readbacks_and_urls_pass':v.get('full_pass',''),'pr_only_pass':v.get('pr_only_pass',''),'early_stop':s['early_stop']})
with (out/'runs.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
metrics={}
for model in sorted({x['model'] for x in rows}):
 selected=[x for x in rows if x['model']==model];full=[x for x in selected if x['task']=='full' and x['phase'] in ('repeat_reference_body','pilot_strict_body') and x['mode']=='facade'];complete=[x for x in full if x['workflow_resources_pass']]
 metrics[model]={'peak_vram_mib':max(x['peak_vram_mib'] or 0 for x in selected),'full_scored_runs':len(full),'correct_resources':len(complete),'strict_complete':sum(bool(x['all_readbacks_and_urls_pass']) for x in full),'successful_full_seconds':[x['seconds'] for x in complete],'median_successful_full_seconds':statistics.median(x['seconds'] for x in complete) if complete else None}
(r/'metrics.json').write_text(json.dumps(metrics,indent=2));print('Summarized',len(rows),'runs')
