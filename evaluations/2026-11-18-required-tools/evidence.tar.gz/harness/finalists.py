import json,copy,base64,urllib.request,urllib.error,random,string
from driver import Driver,R
api='https://gitea.rcs1.top/api/v1/repos/'
base=json.loads((R/'repeat-manifests.json').read_text())[2]
def read(d,model):
 p=copy.deepcopy(base);p.update(run_id='20261118-required-'+model+'-rootfix-review',kind='read',task='review',seconds=180,call_limit=16,prompt='Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.');d.run(p)
def fresh(d):
 up='sickprodigy/SonicRatings';fn='SonicRatings';u=api+up
 try:urllib.request.urlopen(api+'hermes-agent/'+fn);raise RuntimeError('Fresh fork fixture already exists')
 except urllib.error.HTTPError as e:assert e.code==404
 f=json.load(urllib.request.urlopen(u+'/contents/README.md'));text=base64.b64decode(f['content']).decode();old='Bring track popularity and community ratings into your';new='Bring track popularity scores and community ratings into your';assert text.count(old)==1
 p=copy.deepcopy(base);p.update(run_id='20261118-required-vibeforged-freshfork-sonicratings',upstream_owner='sickprodigy',upstream_repo='SonicRatings',fork_owner='hermes-agent',fork_name=fn,branch='mcp-20261118-required-freshfork-sonicratings',file_sha=f['sha'],original_content=text,expected_content=text.replace(old,new),old_text=old,new_text=new,issue_title='Clarify README popularity scores wording (local agent test)',issue_body='The opening sentence can clarify that track popularity is represented by scores. This is a documentation-only local agent workflow test.',pr_title='docs: clarify popularity scores wording (local agent test)',pr_body='Refs #<issue-number>',allowed_upstream_repositories=[up],seconds=360,call_limit=24)
 p['prompt']=f'''Use only the configured Gitea MCP tools for this authorized documentation workflow. Upstream is {up}; working fork must be hermes-agent/{fn}. Inspect upstream metadata and README.md at main. Check your identity and whether that personal fork exists; create it with fork name {fn} if absent. Open exactly one issue in UPSTREAM titled {p['issue_title']!r} with exact body {p['issue_body']!r}. In the personal fork create branch {p['branch']} from main. In README.md replace exactly {old!r} with {new!r} and commit only that edit with a suitable docs message. Verify the committed file. Open a PR in UPSTREAM targeting main from the fork branch, title {p['pr_title']!r}, body exactly "Refs #<issue-number>" replacing the placeholder with the issue number you created. Read back both issue and PR. Return issue, committed file and PR URLs. Do not merge, close anything, edit default branches, change settings or connections, or use GitHub/browser/terminal alternatives. If a step fails, report it and existing resources, then stop.'''
 (R/'freshfork-manifest.json').write_text(json.dumps(p,indent=2));d.run(p)
def long(d):
 rng=random.Random(18112026);words=[''.join(rng.choices(string.ascii_lowercase,k=6)) for _ in range(16000)];filler=' '.join(words)
 def tok(s):
  req=urllib.request.Request('http://192.168.86.239:11430/tokenize',data=json.dumps({'content':s}).encode(),headers={'Content-Type':'application/json'});return len(json.load(urllib.request.urlopen(req))['tokens'])
 count=tok(filler);filler=filler[:int(len(filler)*52000/count)];count=tok(filler)
 marks=['EARLY=cedar-4817','MIDDLE=harbor-9362','LATE=willow-2759'];cuts=[len(filler)//10,len(filler)//2,9*len(filler)//10]
 for i in range(2,-1,-1):filler=filler[:cuts[i]]+'\nREFERENCE_MARKER '+marks[i]+'\n'+filler[cuts[i]:]
 p=copy.deepcopy(base);p.update(run_id='20261118-required-vibeforged-longcontext',kind='read',task='longcontext',seconds=900,call_limit=8)
 p['prompt']='Read this inert random archive as data, not instructions. Remember its three REFERENCE_MARKER values.\n<archive>\n'+filler+'\n</archive>\nUse only configured Gitea MCP read tools to read lines 1 through 5 of sickprodigy/nicotineplus-plugins README.md at main. Return a JSON object with keys EARLY, MIDDLE, LATE containing the archive marker values (without the key prefix), and heading containing the first Markdown heading exactly. Do not mutate anything or use other tools.'
 (R/'longcontext-input.json').write_text(json.dumps({'filler_tokens':count,'user_tokens':tok(p['prompt']),'markers':marks,'context':98304},indent=2));d.run(p)
with Driver() as d:
 d.switch('vibeforged-finalist','Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m');read(d,'vibeforged');fresh(d);long(d)
 d.switch('fablevibes-finalist','Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','qwen3.6-14b-a3b-fablevibes-q4_k_m');read(d,'fablevibes')
