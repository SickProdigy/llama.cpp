import pathlib,subprocess,json
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');subprocess.run(['docker','cp',str(R/'vendor-thinking-guidance.txt'),'hermes-required-store:/eval/vendor-thinking-guidance.txt'],check=True,stdout=subprocess.DEVNULL)
code=r'''import pathlib,tarfile,io,copy,json,hashlib,hermes_yaml as yaml
r=pathlib.Path('/eval');guidance=(r/'vendor-thinking-guidance.txt').read_text();hashes={}
with tarfile.open(r/'profile.tgz') as src,tarfile.open(r/'profile-vendor.tgz','w:gz') as dst:
 for member in src.getmembers():
  data=src.extractfile(member).read() if member.isfile() else None;info=copy.copy(member)
  if member.name=='config.yaml':
   hashes['original_config_sha256']=hashlib.sha256(data).hexdigest();cfg=yaml.safe_load(data);agent=cfg.setdefault('agent',{});agent['environment_hint']=agent.get('environment_hint','')+chr(10)*2+guidance;data=yaml.safe_dump(cfg,sort_keys=False).encode();hashes['variant_config_sha256']=hashlib.sha256(data).hexdigest()
  if data is not None:info.size=len(data)
  dst.addfile(info,io.BytesIO(data) if data is not None else None)
(r/'profile-vendor.tgz').chmod(0o600);print(json.dumps(hashes))'''
hashes=json.loads(subprocess.check_output(['docker','exec','hermes-required-store','python','-c',code]));p=R/'vendor-guidance-plan.json';x=json.loads(p.read_text());x.update(hashes);d=R/'20261120-newer-ministral8-reasoning-q5-matched-explain';q=json.loads((d/'request-001.json').read_text());guidance=(R/'vendor-thinking-guidance.txt').read_text();x['vendor_guidance_present_in_original_request']=any(guidance in str(z.get('content','')) for z in q['messages'] if z.get('role')=='system');assert not x['vendor_guidance_present_in_original_request'];p.write_text(json.dumps(x,indent=2));print('Prepared private vendor-guidance profile; active profile untouched')
