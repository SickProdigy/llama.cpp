import pathlib,json,csv,statistics
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');OUT=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-19-newer-models');OUT.mkdir(exist_ok=True)
def load(p,default=None):return json.loads(p.read_text()) if p.exists() else default
verification=load(R/'verification.json',{'runs':[]});vs={v['run_id']:v for v in verification['runs']};grades=load(R/'manual-grades.json',{});rows=[]
for folder in sorted(R.glob('20*-newer-*')):
 if not folder.is_dir() or not (folder/'manifest.json').exists() or not (folder/'state.json').exists():continue
 p=load(folder/'manifest.json');s=load(folder/'state.json');v=vs.get(p['run_id'],{});calls=load(folder/'calls.json',[]);result=load(folder/'result.json',{});gpu=load(R/(p['run_id']+'-gpu.json'),[]);peak=[]
 for sample in gpu:
  try:peak.append(int(sample['gpu'].split(',')[0]))
  except Exception:pass
 resources=p['task']=='full' and all(v.get(k) for k in ['issue_created_this_run','branch_created_this_run','file_exact','file_committed_this_run','pr_correct','pr_created_this_run','one_pr_file']) and not s['early_stop']
 final=result.get('final_response') or '';complete=bool(final) and not s['early_stop'] and not result.get('failed') and not result.get('interrupted')
 grade=grades.get(p['run_id'],{});request=load(folder/'request-001.json',{});row={'run_id':p['run_id'],'label':p.get('label'),'alias':p['alias'],'mode':p['mode'],'phase':p.get('phase','matched'),'task':p['task'],'context_length':p.get('context_length',98304),'actual_temperature':request.get('temperature'),'actual_max_tokens':request.get('max_tokens'),'seconds':s['elapsed'],'first_tool_completed_seconds':calls[0].get('elapsed') if calls else None,'model_tool_calls':s['model_tool_calls'],'native_calls':s['native_calls'],'peak_vram_mib':max(peak) if peak else None,'last_prompt_tokens':result.get('last_prompt_tokens'),'completion_tokens':result.get('completion_tokens'),'completed_response':complete,'read_grounded_pass':grade.get('pass',''),'workflow_resources_pass':resources if p['task']=='full' else '', 'strict_full_pass':v.get('full_pass',''),'issue_number':s['issue_number'],'pr_number':s['pr_number'],'early_stop':s['early_stop'],'grade_note':grade.get('note','')};rows.append(row)
with (OUT/'runs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys(),lineterminator='\n');w.writeheader();w.writerows(rows)
summary=[]
for key in sorted({(x['label'],x['phase']) for x in rows}):
 selected=[x for x in rows if (x['label'],x['phase'])==key];full=[x for x in selected if x['task']=='full'];read=[x for x in selected if x['task'] in ('explain','review')]
 summary.append({'label':key[0],'phase':key[1],'contexts':sorted({x['context_length'] for x in selected}),'runs':len(selected),'actual_temperatures':sorted({x['actual_temperature'] for x in selected if x['actual_temperature'] is not None}),'actual_output_caps':sorted({x['actual_max_tokens'] for x in selected if x['actual_max_tokens'] is not None}),'read_passes':sum(x['read_grounded_pass'] is True for x in read),'read_runs':len(read),'correct_workflows':sum(x['workflow_resources_pass'] is True for x in full),'strict_complete_workflows':sum(x['strict_full_pass'] is True for x in full),'full_runs':len(full),'peak_vram_mib':max(x['peak_vram_mib'] or 0 for x in selected),'seconds':[x['seconds'] for x in selected]})
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(R/'metrics.json').write_text(json.dumps({'runs':rows,'summary':summary},indent=2));print('Summarized',len(rows),'runs')
