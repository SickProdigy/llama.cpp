import pathlib,json
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');records=[]
for d in sorted(R.glob('20*-newer-*')):
 if not d.is_dir() or not (d/'state.json').exists():continue
 items=[]
 for p in sorted(d.glob('request-*.json')):
  x=json.loads(p.read_text());a=[z for z in x['messages'] if z.get('role')=='assistant'];items.append({'request':p.name,'prior_assistant_messages':len(a),'messages_with_reasoning_field':sum(bool(z.get('reasoning_content') or z.get('reasoning')) for z in a)})
 records.append({'run_id':d.name,'requests':items})
(R/'reasoning-field-audit.json').write_text(json.dumps(records,indent=2)+'\n');print('Reasoning-field metadata audited for',len(records),'runs; no text displayed')
