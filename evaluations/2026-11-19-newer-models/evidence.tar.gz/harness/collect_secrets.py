import pathlib,subprocess,json,os
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
code=r'''import tarfile,json,re,hermes_yaml as yaml
out=set()
def add(v):
 if isinstance(v,str) and len(v)>=8 and not v.startswith(('http://','https://')) and v not in ['[REDACTED_SECRET]','[USER_EMAIL]']:out.add(v)
def walk(x,parent=False):
 if isinstance(x,dict):
  for k,v in x.items():
   sensitive=parent or bool(re.search(r'(token|secret|password|api.?key|authorization)',str(k),re.I))
   if isinstance(v,(dict,list)):walk(v,sensitive)
   elif sensitive:add(v)
 elif isinstance(x,list):
  for v in x:walk(v,parent)
 elif parent:add(x)
with tarfile.open('/eval/profile.tgz') as t:
 for m in t.getmembers():
  if not m.isfile():continue
  s=t.extractfile(m).read().decode(errors='replace')
  if m.name=='.env':
   for line in s.splitlines():
    key,sep,value=line.partition('=')
    if sep and re.search(r'(token|secret|password|api.?key|authorization)',key,re.I):add(value.strip().strip('"').strip("'"))
  elif m.name.endswith(('.json','.yaml','.yml')):
   try:walk(json.loads(s) if m.name.endswith('.json') else yaml.safe_load(s))
   except Exception:pass
print(json.dumps(sorted(out,key=len,reverse=True)))'''
p=subprocess.run(['docker','exec','hermes-required-store','python','-c',code],capture_output=True,check=True);out=json.loads(p.stdout)
for f in R.glob('*-inspect.json'):
 for x in json.loads(f.read_text()):
  for e in x.get('Config',{}).get('Env',[]):
   k,_,v=e.partition('=')
   if __import__('re').search(r'(token|secret|password|api.?key|authorization)',k,__import__('re').I) and len(v)>=8 and not v.startswith(('http://','https://')):out.append(v)
p=R/'secrets.json';fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
with os.fdopen(fd,'w') as f:json.dump(sorted(set(out),key=len,reverse=True),f)
print('Collected credential values privately for redaction; no values displayed')
