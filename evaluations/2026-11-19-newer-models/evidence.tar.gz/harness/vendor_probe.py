import pathlib,json,subprocess,hashlib
from driver import Driver,R
from case_helpers import base,full,models
assert 'COHORT COMPLETE' in (R/'controller.log').read_text()
assert subprocess.run(['pgrep','-f','^python3 /tmp/hermes-newer-eval-20261120/(controller_new|probe).py'],capture_output=True).returncode!=0
assert subprocess.run(['docker','inspect','llama-required-eval'],capture_output=True).returncode!=0
plan=json.loads((R/'vendor-guidance-plan.json').read_text());m=next(z for z in models if z['label']=='ministral8-reasoning-q5')
subprocess.run(['docker','exec','hermes-required-store','python','-c',"import shutil;shutil.copyfile('/eval/profile.tgz','/eval/profile-before-vendor.tgz');shutil.copyfile('/eval/profile-vendor.tgz','/eval/profile.tgz')"],check=True)
try:
 with Driver() as d:
  d.switch(m['label']+'-publisher-guidance',m['filename'],m['alias'])
  for task,prompt in [('explain','Find my SonicRatings repo and tell me what it does.'),('review','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.'),('full',None)]:
   p=full(m['label'],'publisher-guidance') if task=='full' else base(m['label'],'publisher-guidance')
   if task!='full':p.update(task=task,prompt=prompt,run_id=p['run_id']+'-'+task)
   p.update(request_overrides={'temperature':.7},temperature=.7,max_tokens=8192,seconds=600 if task=='full' else 300,profile_variant='vendor-thinking-guidance',vendor_guidance_sha256=plan['guidance_sha256'],variant_config_sha256=plan['variant_config_sha256']);d.run(p)
finally:
 subprocess.run(['docker','exec','hermes-required-store','python','-c',"import pathlib,shutil,hashlib;shutil.copyfile('/eval/profile-before-vendor.tgz','/eval/profile.tgz');assert hashlib.sha256(pathlib.Path('/eval/profile.tgz').read_bytes()).digest()==hashlib.sha256(pathlib.Path('/eval/profile-before-vendor.tgz').read_bytes()).digest()"],check=True)
 print('RESTORED ORIGINAL TEST PROFILE',flush=True)
