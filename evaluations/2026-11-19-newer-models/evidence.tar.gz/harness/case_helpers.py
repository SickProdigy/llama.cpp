import pathlib,json,time,copy,traceback
from driver import Driver,R
source=json.loads((R/'source-before.json').read_text());pool=json.loads((R/'fixture-pool.json').read_text());assigned=[]
if (R/'allocated-fixtures.json').exists():assigned=json.loads((R/'allocated-fixtures.json').read_text())
models=[{'label':'ministral8-control','filename':'Ministral-3-8B-Instruct-2512-Q5_K_M.gguf','alias':'ministral-3-8b-instruct-q5_k_m','control':True}]+json.loads((R/'download-plan.json').read_text())['models']
(R/'cohort.json').write_text(json.dumps(models,indent=2))
def base(label,phase='matched'):
 return {'run_id':'20261120-newer-'+label+'-'+phase,'kind':'read','task':'explain','mode':'facade','seconds':180,'call_limit':16,'temperature':0.2,'phase':phase,'label':label,'fork_name':'hermes-mcp-test-20261117-vf-144838','original_content':source['readme'],'file_sha':source['readme_sha'],'upstream_owner':'sickprodigy','upstream_repo':'nicotineplus-plugins','fork_owner':'hermes-agent','allowed_upstream_repositories':['sickprodigy/nicotineplus-plugins']}
def full(label,phase='matched'):
 global assigned
 assigned=json.loads((R/'allocated-fixtures.json').read_text()) if (R/'allocated-fixtures.json').exists() else []
 key=label+'-'+phase
 existing=next((x for x in assigned if x['key']==key),None)
 if existing:f=existing['fixture']
 else:
  used={x['fixture']['fixture'] for x in assigned};f=next(x for x in pool if x['fixture'] not in used);assigned.append({'key':key,'fixture':f});(R/'allocated-fixtures.json').write_text(json.dumps(assigned,indent=2))
 p=base(label,phase);p.update(f);p.update(kind='contribution',task='full',seconds=600 if label=='qwen35-q4' else 300,call_limit=20,branch='mcp-20261120-'+key+'-'+f['fixture'],expected_content=source['readme'].replace(f['old_text'],f['new_text']),issue_title='Newer-model MCP test: '+key+' '+f['fixture'],issue_body='Documentation clarity test: replace '+repr(f['old_text'])+' with '+repr(f['new_text'])+' in README.md. No behavior changes.',pr_title='docs: '+f['fixture']+' ('+key+')',pr_body='Refs #<issue-number>')
 p['run_id']+='-full-'+f['fixture']
 p['prompt']=f'''Use only the configured Gitea MCP tools for this authorized documentation contribution. The UPSTREAM repository is sickprodigy/nicotineplus-plugins; the working fork is hermes-agent/{p['fork_name']}. Inspect upstream metadata and README.md on main. Check your identity and verify that personal fork's parent; create the personal fork only if absent. Open exactly one issue in UPSTREAM titled {p['issue_title']!r} with exact body {p['issue_body']!r}. In the working fork create branch {p['branch']} from main. In README.md replace exactly {p['old_text']!r} with {p['new_text']!r} and commit only that edit with a suitable docs message. Read back the committed file. Open a PR in UPSTREAM targeting main from the fork branch, with title {p['pr_title']!r} and body exactly "Refs #<issue-number>" replacing the placeholder with your newly created upstream issue number. Read back the issue and PR. Return the issue URL, changed file URL and PR URL. Do not commit to a default branch, create another fork, merge, close anything, change settings or connections, or use GitHub/browser/terminal alternatives. If a step fails, report the error and existing resources, then stop.'''
 return p

def runs(d,m,phase='matched',overrides=None):
 results=[]
 for task,prompt in [('explain','Find my SonicRatings repo and tell me what it does.'),('review','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.')]:
  p=base(m['label'],phase);p.update(run_id=p['run_id']+'-'+task,task=task,prompt=prompt)
  if overrides:p['request_overrides']=overrides
  results.append(d.run(p))
 p=full(m['label'],phase)
 if overrides:p['request_overrides']=overrides
 results.append(d.run(p));return results

