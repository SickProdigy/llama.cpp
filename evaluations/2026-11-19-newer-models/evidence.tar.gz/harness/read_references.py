import pathlib,json,urllib.request,base64,concurrent.futures,datetime
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');root='https://gitea.rcs1.top/api/v1/repos/'
paths=['sickprodigy/SonicRatings/contents/README.md?ref=main','sickprodigy/sick-cogs/contents?ref=main','sickprodigy/sick-cogs/contents?ref=develop','sickprodigy/sick-cogs/contents/calendarevents/info.json?ref=develop','sickprodigy/sick-cogs/contents/CONTRIBUTING.md?ref=main']
def fetch(p):
 x=json.load(urllib.request.urlopen(root+p,timeout=25))
 if isinstance(x,dict) and x.get('encoding')=='base64':x['decoded_content']=base64.b64decode(x['content']).decode()
 return p,x
x=dict(concurrent.futures.ThreadPoolExecutor(4).map(fetch,paths));(R/'read-references-live.json').write_text(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'references':x},indent=2));print('Captured current ground-truth references')
