import pathlib,json,subprocess,time,threading,traceback,urllib.request
from driver import Driver,R
from case_helpers import models,base,full
stop=threading.Event()
def bridge():
 while not stop.is_set():
  code="import pathlib,json;r=pathlib.Path('/eval');s=r/'download-status.json';print(json.dumps({'status':json.loads(s.read_text()) if s.exists() else {},'records':{p.name:json.loads(p.read_text()) for p in r.glob('*-download.json')}}))"
  try:
   x=json.loads(subprocess.check_output(['docker','exec','hermes-required-store','python','-c',code],stderr=subprocess.DEVNULL));tmp=R/'download-status.bridge';tmp.write_text(json.dumps(x['status'],indent=2));tmp.replace(R/'download-status.json')
   for name,v in x['records'].items():(R/name).write_text(json.dumps(v,indent=2))
  except Exception:pass
  stop.wait(10)
threading.Thread(target=bridge,daemon=True).start()
plans={'qwen38-q5':{'temperature':.6},'qwen38-q8':{'temperature':.6},'lfm25-q5':{'temperature':.2,'extra_body':{'top_k':80,'repeat_penalty':1.05}},'gemma4-e4b-q5':{'temperature':1.,'top_p':.95,'extra_body':{'top_k':64,'min_p':0.}},'ministral8-reasoning-q5':{'temperature':.7}}
(R/'publisher-plan.json').write_text(json.dumps(plans,indent=2))
def run_tasks(d,m,phase='matched',overrides=None):
 results=[]
 for task,prompt in [('explain','Find my SonicRatings repo and tell me what it does.'),('review','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.'),('full',None)]:
  p=full(m['label'],phase) if task=='full' else base(m['label'],phase)
  if task!='full':p.update(run_id=p['run_id']+'-'+task,task=task,prompt=prompt)
  if overrides:p.update(request_overrides=overrides,max_tokens=8192,seconds=300 if task!='full' else 600)
  results.append(d.run(p))
 return results
try:
 for m in models:
  label=m['label'];record=R/(label+'-tested.json')
  if record.exists():continue
  if not m['control']:
   print('WAIT DOWNLOAD',label,flush=True)
   while not (R/(label+'-download.json')).exists():
    running=subprocess.run(['docker','inspect','-f','{{.State.Running}}','hermes-newer-download'],capture_output=True,text=True).stdout.strip()=='true'
    if not running:
     time.sleep(12)
     if not (R/(label+'-download.json')).exists():raise RuntimeError('Download process exited before '+label)
    time.sleep(5)
  print('MODEL START',label,flush=True)
  try:
   with Driver() as d:
    phase='matched';cache='q4_0'
    try:d.switch(label+'-matched',m['filename'],m['alias'])
    except Exception:
     log=(R/(label+'-matched-backend.log')).read_text(errors='replace').lower()
     if any(x in log for x in ['out of memory','failed to allocate','buffer allocation failed']):
      phase='fit64k';d.switch(label+'-'+phase,m['filename'],m['alias'],context=65536)
     elif 'cache' in log and any(x in log for x in ['unsupported','not supported','type']):
      phase='q8-cache';cache='q8_0';d.switch(label+'-'+phase,m['filename'],m['alias'],cache=cache)
     else:raise
    result=run_tasks(d,m,phase);record.write_text(json.dumps({'model':m,'phase':phase,'context':d.context,'cache':cache,'runs':result},indent=2))
    needs=not m['control'] and any(s.get('early_stop') or (i==2 and not s.get('pr_number')) for i,s in enumerate(result))
    if needs:
     print('PUBLISHER PROFILE',label,flush=True);diag=run_tasks(d,m,'publisher',plans[label]);(R/(label+'-publisher.json')).write_text(json.dumps({'overrides':plans[label],'max_tokens':8192,'runs':diag},indent=2))
  except Exception as e:
   (R/(label+'-failure.json')).write_text(json.dumps({'label':label,'error':str(e),'traceback':traceback.format_exc()},indent=2));print('MODEL RUNTIME FAILURE',label,type(e).__name__,flush=True)
 print('COHORT COMPLETE',flush=True)
finally:
 stop.set()
 p=subprocess.run(['docker','logs','hermes-newer-download'],capture_output=True);(R/'download-console.log').write_bytes(p.stdout+p.stderr)
