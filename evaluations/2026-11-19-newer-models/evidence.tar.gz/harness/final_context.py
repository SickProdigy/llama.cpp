import pathlib,subprocess,time,json
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
while True:
 log=(R/'probe-vendor-guidance.log').read_text() if (R/'probe-vendor-guidance.log').exists() else ''
 active=subprocess.run(['pgrep','-f','^python3 /tmp/hermes-newer-eval-20261120/(controller_new|probe|vendor_probe).py'],capture_output=True).returncode==0
 backend=subprocess.run(['docker','inspect','llama-required-eval'],capture_output=True).returncode==0
 if 'RESTORED ORIGINAL TEST PROFILE' in log and not active and not backend:break
 time.sleep(5)
print('FINAL CONTEXT START',flush=True)
with (R/'probe-gemma-long.log').open('w') as f:p=subprocess.run(['python3',str(R/'probe.py'),'gemma4-e4b-q5','long-probe','--tasks','longcontext'],stdout=f,stderr=subprocess.STDOUT)
(R/'gemma-long-probe.json').write_text(json.dumps({'exit_code':p.returncode},indent=2));print('FINAL CONTEXT COMPLETE',flush=True)
