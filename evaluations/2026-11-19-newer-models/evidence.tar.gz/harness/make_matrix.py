import pathlib,json
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');OUT=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-19-newer-models');rows=json.loads((R/'metrics.json').read_text())['runs'];models=json.loads((R/'cohort.json').read_text());names={'ministral8-control':'Ministral 3 8B Instruct Q5 control','qwen38-q5':'Empero Qwen3.8 distill 9B Q5','qwen38-q8':'Same Empero checkpoint Q8','lfm25-q5':'LFM2.5 8B-A1B Q5','gemma4-e4b-q5':'Gemma 4 E4B Instruct Q5','ministral8-reasoning-q5':'Ministral 3 8B Reasoning Q5'}
quality=['| Model | Phase | Grounded read answers | Correct contribution resources | All read-backs and URLs |','|---|---|---:|---:|---:|'];fit=['| Model | File GB | Loaded context | Cache | Peak GPU MiB | Explain first tool seconds | Full-task seconds |','|---|---:|---:|---|---:|---:|---:|']
for m in models:
 label=m['label'];rs=[x for x in rows if x['label']==label and x['phase'] in ['matched','fit64k','q8-cache']];name=names[label]
 if not rs:
  if (R/(label+'-failure.json')).exists():quality.append(f'| {name} | Runtime failure; see retained log | — | — | — |')
  continue
 phase=rs[0]['phase'];read=[x for x in rs if x['task'] in ['explain','review']];full=[x for x in rs if x['task']=='full'];quality.append(f"| {name} | {phase} | {sum(x['read_grounded_pass'] is True for x in read)}/{len(read)} | {sum(x['workflow_resources_pass'] is True for x in full)}/{len(full)} | {sum(x['strict_full_pass'] is True for x in full)}/{len(full)} |")
 size=m.get('bytes') or (OUT.parents[1]/'models'/m['filename']).stat().st_size;record=R/(label+'-tested.json');cache=json.loads(record.read_text())['cache'] if record.exists() else 'q4_0';ex=next((x for x in rs if x['task']=='explain'),{});first=ex.get('first_tool_completed_seconds');first=f'{first:.1f}' if first is not None else '—';seconds=', '.join(f"{x['seconds']:.1f}" for x in full) or '—';fit.append(f"| {name} | {size/1e9:.2f} | {rs[0]['context_length']:,} | {cache} | {max(x['peak_vram_mib'] or 0 for x in rs):,} | {first} | {seconds} |")
text='# Primary comparison\n\n'+'\n'.join(quality)+'\n\n# Observed fit and conversation time\n\n'+'\n'.join(fit)+'''\n
Each primary row has one sample per task, not a reliability estimate. Public
Q5 and Q8 are two files of one checkpoint. Publisher samplers and larger output
budgets are separate phases in runs.csv/summary.json. Correct resources and
strict completion are distinct. Read grades are conservative whole-answer
checks; see manual-grades.json for unsupported claims despite correct core
summaries. Failed/incomplete full-task elapsed times remain visible.

GB is decimal file size; GPU memory is sampled whole-card MiB every three
seconds. Loaded capacity is not active full-window validation. Conversation
and first-tool times exclude model loading and initial agent/MCP setup; the
conversation includes subsequent inference/tool execution. Publisher probes
reuse a warm backend cache and should not be treated as isolated sampler-speed
comparisons. No CPU/GPU hardware change is made during this cohort.
''';(OUT/'matrix.md').write_text(text);print('Primary matrix generated')
