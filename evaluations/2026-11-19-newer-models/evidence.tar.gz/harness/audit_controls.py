import pathlib,json,hashlib
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');rows=[]
for d in sorted(R.glob('20*-newer-*')):
 if not d.is_dir() or not (d/'state.json').exists():continue
 m=json.loads((d/'manifest.json').read_text());h=json.loads((d/'code-hashes.json').read_text());schema=json.loads((d/'schemas.json').read_text());q=json.loads((d/'request-001.json').read_text());rows.append({'run_id':m['run_id'],'phase':m['phase'],'mode':m['mode'],'schema_count':len(schema),'gitea_schema_sha256':hashlib.sha256(json.dumps([t for t in schema if t['function']['name'].startswith('gitea_')],sort_keys=True).encode()).hexdigest(),'schema_sha256':hashlib.sha256(json.dumps(schema,sort_keys=True).encode()).hexdigest(),'code_hashes':h,'context_length':m['context_length'],'actual_temperature':q['temperature'],'actual_max_tokens':q['max_tokens']})
primary=[x for x in rows if x['phase']=='matched'];out={'checked_primary_runs':len(primary),'primary_schema_hashes':sorted({x['schema_sha256'] for x in primary}),'primary_temperatures':sorted({x['actual_temperature'] for x in primary}),'primary_output_caps':sorted({x['actual_max_tokens'] for x in primary}),'runs':rows}
out['primary_gitea_schema_hashes']=sorted({x['gitea_schema_sha256'] for x in primary});assert len(out['primary_gitea_schema_hashes'])==1
out['schema_caveat']='Hermes exposes the mode/patch extension of the unrelated local patch tool for GPT-OSS. The 15 focused Gitea schemas are identical; forbidden local patch would be blocked before dispatch. All complete schemas retained.'
assert out['primary_temperatures']==[.2] and out['primary_output_caps']==[4096]
for name in rows[0]['code_hashes']:
 hashes={x['code_hashes'][name] for x in rows};assert len(hashes)==1,(name,hashes)
 path=R/name if not name.startswith('gitea-focused/') else pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/hermes-profile')/name
 assert hashlib.sha256(path.read_bytes()).hexdigest() in hashes,name
out['frozen_runner_guard_profile_plugin_match_retained_sources']=True
(R/'comparison-controls.json').write_text(json.dumps(out,indent=2)+'\n');print('Audited',len(rows),'runs;',len(primary),'primary; frozen sources match')
