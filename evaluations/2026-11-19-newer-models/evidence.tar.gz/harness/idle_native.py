import subprocess,pathlib,json
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
try:
 with (R/'probe-gemma-native.log').open('w') as f:p=subprocess.run(['python3',str(R/'probe.py'),'gemma4-e4b-q5','native-diagnostic','--mode','native','--tasks','full'],stdout=f,stderr=subprocess.STDOUT)
 (R/'gemma-native-probe.json').write_text(json.dumps({'exit_code':p.returncode},indent=2))
finally:
 print('RESUMING PRIMARY COHORT',flush=True)
 with (R/'controller.log').open('a') as f:p=subprocess.run(['python3',str(R/'controller_new.py')],stdout=f,stderr=subprocess.STDOUT)
 print('PRIMARY COHORT EXIT',p.returncode,flush=True)
