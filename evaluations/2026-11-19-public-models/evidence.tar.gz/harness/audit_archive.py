import pathlib,tarfile,json,hashlib
out=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-19-public-models');manifest=json.loads((out/'evidence-manifest.json').read_text());sources={'gitea-focused/__init__.py':'plugin-v0.1.3/__init__.py'};count=0
with tarfile.open(out/'evidence.tar.gz') as t:
 names=t.getnames();assert len(names)==len(set(names));assert set(names)=={x['path'] for x in manifest['members']}
 for m in manifest['members']:
  data=t.extractfile(m['path']).read();assert hashlib.sha256(data).hexdigest()==m['sha256'];assert len(data)==m['bytes']
  if m['path'].endswith('.json'):json.loads(data)
  if m['path'].endswith('/code-hashes.json'):
   h=json.loads(data)
   for name,sha in h.items():assert hashlib.sha256(t.extractfile(sources.get(name,'harness/'+name)).read()).hexdigest()==sha,(m['path'],name)
   count+=1
assert hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()==(out/'evidence.tar.gz.sha256').read_text().split()[0]
print('Verified archive/member SHA256, JSON, and retained source hashes for',count,'runs')
