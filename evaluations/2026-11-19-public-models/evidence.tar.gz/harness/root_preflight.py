import sys,pathlib,json
sys.path[:0]=['/eval','/opt/hermes']
from prepare_profile import prepare
prepare()
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
from tools.registry import registry
from hermes_cli.config import load_config
from hermes_cli.tools_config import _get_platform_tools
from run_agent import AIAgent
discover_mcp_tools();c=load_config();selected=sorted(_get_platform_tools(c,'discord'))
a=AIAgent(model=c['model']['default'],base_url=c['model']['base_url'],api_key=c['model']['api_key'],provider='custom',max_iterations=20,max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=c['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
assert 'gitea_create_pull_request' in [x['function']['name'] for x in a.tools]
assert not any(x['function']['name'].startswith('mcp__mcp_gitea_hermes__') for x in a.tools)
results={}
for n,args in [('gitea_identity',{}),('gitea_list_directory',{'owner':'sickprodigy','repo':'Sick-Cogs','path':'.','ref':'main'}),('gitea_repository_info',{'owner':'hermes-agent','repo':'hermes-mcp-test-20261117-vf-144838'}),('gitea_read_file',{'owner':'sickprodigy','repo':'nicotineplus-plugins','path':'README.md','ref':'main','start_line':1,'end_line':10})]:
 raw=model_tools.handle_function_call(n,args);results[n]=raw;assert '"error"' not in raw,raw
blocked=model_tools.handle_function_call('mcp__mcp_gitea_hermes__get_me',{});assert 'focused' in blocked and 'error' in blocked,blocked
pathlib.Path('/eval/root-preflight.json').write_text(json.dumps({'selected':selected,'schemas':a.tools,'results':results},indent=2));print(json.dumps({'tool_count':len(a.tools),'facade_tools':len([x for x in a.tools if x['function']['name'].startswith('gitea_')]),'native_hidden':True,'reads_passed':list(results)}));a.close()
