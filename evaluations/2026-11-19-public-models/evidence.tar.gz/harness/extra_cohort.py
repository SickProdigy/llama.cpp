import subprocess,json,pathlib,time
R=pathlib.Path('/tmp/hermes-public-eval-20261119')
while True:
 s=json.loads((R/'download-status.json').read_text())
 running=subprocess.run(['docker','inspect','-f','{{.State.Running}}','hermes-public-download-helper'],capture_output=True,text=True).stdout.strip()=='true'
 if s.get('phase')=='all_downloads_verified' and not running:break
 if (R/'download-failed.json').exists():raise RuntimeError('Original download queue failed')
 time.sleep(5)
image=json.loads((R/'hermes-inspect.json').read_text())[0]['Image'];subprocess.run(['docker','run','-d','--name','hermes-public-extra-download','--network','homelab','--volumes-from','llama-cpp:rw','--mount','type=volume,source=hermes-required-evidence,target=/eval','--memory','3g','--memory-swap','3g','--entrypoint','python',image,'-u','/eval/extra_download.py'],check=True,stdout=subprocess.DEVNULL);print('EXTRA PUBLIC DOWNLOAD STARTED',flush=True)
code="import pathlib,json;r=pathlib.Path('/eval');s=r/'extra-download-status.json';d=r/'ministral14-q4-download.json';print(json.dumps({'status':json.loads(s.read_text()) if s.exists() else {},'record':json.loads(d.read_text()) if d.exists() else None}))"
while True:
 x=json.loads(subprocess.check_output(['docker','exec','hermes-required-store','python','-c',code]));(R/'extra-download-status.json').write_text(json.dumps(x['status'],indent=2))
 if x['record']:(R/'ministral14-q4-download.json').write_text(json.dumps(x['record'],indent=2));break
 running=subprocess.run(['docker','inspect','-f','{{.State.Running}}','hermes-public-extra-download'],capture_output=True,text=True).stdout.strip()=='true'
 if not running:raise RuntimeError('Extra download failed; inspect retained logs')
 time.sleep(10)
print('EXTRA PUBLIC MODEL READY',flush=True)
while True:
 done='PRIMARY COHORT COMPLETE' in (R/'controller.log').read_text();zero=(R/'ministral-zero-probe.json').exists();active=subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/(controller_resume|probe).py'],capture_output=True).returncode==0;backend=subprocess.run(['docker','inspect','llama-required-eval'],capture_output=True).returncode==0
 if done and zero and not active and not backend:break
 time.sleep(5)
print('EXTRA MODEL TEST START',flush=True)
with (R/'extra-controller.log').open('w') as f:p=subprocess.run(['python3',str(R/'probe.py'),'ministral14-q4','matched'],stdout=f,stderr=subprocess.STDOUT)
if p.returncode:
 print('EXTRA MODEL RETRY AT64K',flush=True)
 with (R/'extra-controller-64k.log').open('w') as f:p=subprocess.run(['python3',str(R/'probe.py'),'ministral14-q4','fit64k','--context','65536'],stdout=f,stderr=subprocess.STDOUT)
(R/'extra-cohort-result.json').write_text(json.dumps({'exit_code':p.returncode},indent=2));print('EXTRA COHORT COMPLETE',flush=True)
