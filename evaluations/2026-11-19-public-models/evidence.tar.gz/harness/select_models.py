import pathlib,json,urllib.request,concurrent.futures
R=pathlib.Path('/tmp/hermes-public-eval-20261119')
specs=[('ornith9-q5','mradermacher/Ornith-1.5-9B-uncensored-GGUF','Q5_K_M'),('ministral8-q5','mistralai/Ministral-3-8B-Instruct-2512-GGUF','Q5_K_M'),('armand9-q5','armand0e/Qwen3.5-9B-Agent-GGUF','Q5_K_M'),('flash9-q5','flashback2k/FlashModel-Qwen3.5-9B-GGUF','Q5_K'),('gptoss20','ggml-org/gpt-oss-20b-GGUF','gpt-oss-20b-MXFP4.gguf'),('qwen35-q4','unsloth/Qwen3.6-35B-A3B-GGUF','UD-Q4_K_XL'),('willhar9','willhar/Qwen3.5-9B-AgentTuned-GGUF','Q5_K')]
def get(spec):
 label,repo,wanted=spec;x=json.load(urllib.request.urlopen('https://huggingface.co/api/models/'+repo+'?blobs=true',timeout=30));(R/(label+'-hub.json')).write_text(json.dumps(x,indent=2));files=[f for f in x['siblings'] if f['rfilename'].endswith('.gguf')];matches=[f for f in files if wanted.lower() in f['rfilename'].lower()];out={'label':label,'repo':repo,'revision':x['sha'],'matches':[{'filename':f['rfilename'],'bytes':f.get('size'),'sha256':f.get('lfs',{}).get('sha256')} for f in matches],'all_gguf_files':[{'filename':f['rfilename'],'bytes':f.get('size')} for f in files]}
 try:(R/(label+'-card.md')).write_bytes(urllib.request.urlopen('https://huggingface.co/'+repo+'/raw/'+x['sha']+'/README.md',timeout=20).read())
 except Exception as e:out['card_error']=str(e)
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(get,specs))
(R/'candidate-inventory.json').write_text(json.dumps(out,indent=2));
for x in out:print(json.dumps({k:x[k] for k in ['label','repo','revision','matches']}));print('Other GGUFs',x['all_gguf_files'] if not x['matches'] else '')
