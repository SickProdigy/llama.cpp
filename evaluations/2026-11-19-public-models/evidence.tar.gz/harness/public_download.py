import pathlib,json,time,urllib.request,concurrent.futures,threading,hashlib,shutil
# Range downloading only: no conversion or alteration of the publisher's bytes.
def download(m,target,part,status):
 checkpoint=part.with_suffix('.ranges.json');prefix=part.stat().st_size if part.exists() else 0
 if checkpoint.exists():prefix=json.loads(checkpoint.read_text())['prefix_bytes']
 else:checkpoint.write_text(json.dumps({'prefix_bytes':prefix}))
 assert 0<=prefix<=m['bytes'];remaining=m['bytes']-prefix;count=4;size=(remaining+count-1)//count;pieces=[]
 for i in range(count):
  start=prefix+i*size;end=min(m['bytes'],start+size)-1
  if start<=end:pieces.append((i,start,end,part.with_name(part.name+'.segment'+str(i))))
 with part.open('ab') as f:f.truncate(prefix)
 base='https://huggingface.co/'+m['repo']+'/resolve/'+m['revision']+'/'+m['filename'];progress={i:(f.stat().st_size if f.exists() else 0) for i,a,b,f in pieces};lock=threading.Lock();last=[0];begin=time.monotonic()
 def publish(force=False):
  with lock:
   if not force and time.monotonic()-last[0]<30:return
   done=prefix+sum(progress.values());x={'label':m['label'],'phase':'downloading','bytes':done,'total':m['bytes'],'percent':round(done/m['bytes']*100,1),'elapsed_seconds':round(time.monotonic()-begin),'connections':4};status(x);print(json.dumps(x),flush=True);last[0]=time.monotonic()
 def worker(piece):
  i,start,end,path=piece
  for attempt in range(4):
   have=path.stat().st_size if path.exists() else 0;assert have<=end-start+1
   if have==end-start+1:return
   first=start+have
   try:
    req=urllib.request.Request(base+'?download=true&range_eval='+str(time.time_ns()),headers={'Range':'bytes='+str(first)+'-'+str(end),'User-Agent':'Hermes-public-model-evaluation/1.0'})
    with urllib.request.urlopen(req,timeout=90) as response:
     assert response.status==206 and response.headers.get('Content-Range')=='bytes '+str(first)+'-'+str(end)+'/'+str(m['bytes']),'Server did not honor exact byte range'
     with path.open('ab') as f:
      while block:=response.read(4*2**20):
       assert f.tell()+len(block)<=end-start+1,'Response exceeds requested range';f.write(block)
       with lock:progress[i]=f.tell()
       publish()
    assert path.stat().st_size==end-start+1;return
   except Exception as e:
    print(json.dumps({'label':m['label'],'segment':i,'attempt':attempt+1,'error_type':type(e).__name__,'http_status':getattr(e,'code',None)}),flush=True)
    if attempt==3:raise
    time.sleep(3)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for _ in pool.map(worker,pieces):pass
 publish(True);status({'label':m['label'],'phase':'assembling_publisher_bytes','total':m['bytes']})
 with part.open('ab') as out:
  for i,start,end,path in pieces:
   assert out.tell()==start
   with path.open('rb') as src:shutil.copyfileobj(src,out,8*2**20)
 assert part.stat().st_size==m['bytes'];status({'label':m['label'],'phase':'verifying_sha256','total':m['bytes']})
 with part.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 assert sha==m['sha256'],'Publisher SHA256 mismatch'
 part.rename(target)
 for i,start,end,path in pieces:path.unlink()
 checkpoint.unlink();return sha
