import pathlib,json,urllib.request,base64
R=pathlib.Path('/tmp/hermes-public-eval-20261119');api='https://gitea.rcs1.top/api/v1/repos/';up='sickprodigy/nicotineplus-plugins';fork='hermes-agent/hermes-mcp-test-20261117-vf-144838'
def get(path):return json.load(urllib.request.urlopen(api+path,timeout=20))
f=get(up+'/contents/README.md?ref=main');text=base64.b64decode(f['content']).decode();ff=get(fork+'/contents/README.md?ref=main');assert ff['sha']==f['sha'];sources={'upstream':get(up+'/branches/main'),'fork':get(fork),'readme_sha':f['sha'],'readme':text,'issues':get(up+'/issues?state=all&limit=100'),'pulls':get(up+'/pulls?state=all&limit=100')};(R/'source-before.json').write_text(json.dumps(sources,indent=2))
pairs=[
 ('client-wording','a graphical client for the Soulseek file sharing network.','a graphical client for the Soulseek file-sharing network.'),
 ('module-wording','A plugin is a Python module that extends the functionality of the main application.','A plugin is a Python module that extends the functionality of Nicotine+.'),
 ('clone-wording','Clone or download the plugin files','Clone the repository or download the plugin files'),
 ('restart-wording','Restart Nicotine+ to load the plugins','Restart Nicotine+ so it can load the plugins'),
 ('enable-wording','Enable plugins in Preferences','Enable the plugins in Preferences'),
 ('learn-wording','Learning plugin architecture','Learning the plugin architecture'),
 ('custom-wording','Creating custom plugins','Developing custom plugins'),
 ('welcome-wording','Contributions are welcome! Feel free to:','Contributions are welcome! You can:'),
 ('descriptions-wording','A plugin is a Python module','Each plugin is a Python module'),
 ('features-wording','Add new features','Add new plugin features'),
 ('integration-wording','Integrate with other applications','Integrate Nicotine+ with other applications'),
 ('automation-wording','Automate common tasks','Automate common Nicotine+ tasks'),
 ('buddy-description','Automatically manage your buddy list based on channel interactions.','Automatically manage your buddy list based on chat channel interactions.'),
 ('watched-channels','When a user joins a monitored channel and says a trigger phrase,','When a user joins a monitored channel and sends a trigger phrase,'),
 ('local-room-wording','Owner `/ai` prompts work immediately after server','Owner `/ai` prompts are available immediately after server'),
 ('arr-foundation','The staged foundation verifies connections and searches catalogs,','The staged foundation checks connections and searches catalogs,'),
 ('beets-queue','Queue completed music folders for a configured, non-interactive beets import.','Queue completed music folders for a configured non-interactive beets import.'),
 ('book-optin','Remote `!book` requests are opt-in, room-filterable,','Remote `!book` requests require opt-in, are room-filterable,'),
 ('chat-network','This directory contains plugins for **Nicotine+**,','This repository contains plugins for **Nicotine+**,'),
 ('http-api','Authenticated searches and download batches through your existing Nicotine+ session.','Authenticated searches and download batches using your existing Nicotine+ session.'),
 ('initial-target','Initial supported target:','Initial supported versions:'),
 ('announcer-status','status output keep announcements controlled.','status output help keep announcements controlled.'),
 ('safe-replies','and bounded for chat-safe replies.','and bounded to produce chat-safe replies.'),
 ('no-join','the plugin has no remote trigger, auto-join behavior, or recurring schedule.','the plugin has no remote trigger, automatic room joining, or recurring schedule.'),
]
prior='\n'.join(x.get('body') or '' for x in sources['issues']+sources['pulls']);available=[]
for key,old,new in pairs:
 if text.count(old)==1 and old not in prior and new not in prior:available.append({'fixture':key,'old_text':old,'new_text':new})
assert len(available)>=12,len(available);(R/'fixture-pool.json').write_text(json.dumps(available,indent=2));print('Verified',len(available),'unused exact corrections; source',sources['upstream']['commit']['id'])
