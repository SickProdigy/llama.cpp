import pathlib,json,urllib.request,urllib.parse,hashlib,time,shutil,datetime
from gguf_meta import metadata
R=pathlib.Path('/tmp/hermes-public-eval-20261119');MODELS=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/models');reserve=100*2**30
inventory=json.loads((R/'candidate-inventory.json').read_text());selected=[]
for item in inventory:
 if not item['matches']:continue
 f=next((x for x in item['matches'] if 'Q5_K_M' in x['filename']),item['matches'][0]);selected.append({k:item[k] for k in ['label','repo','revision']}|f)
(R/'download-plan.json').write_text(json.dumps({'reserve_bytes':reserve,'models':selected,'deferred':[{'repo':x['repo'],'reason':'Only 18.4 GB F16 published; no quantization authorized, no ready-made small GGUF found.'} for x in inventory if not x['matches']]},indent=2))
def status(x):
 p=R/'download-status.tmp';p.write_text(json.dumps(x,indent=2));p.replace(R/'download-status.json')
for m in selected:
 target=MODELS/m['filename'];part=MODELS/(m['filename']+'.public-eval.part');begin=time.monotonic();status({'label':m['label'],'phase':'starting','bytes':0,'total':m['bytes']})
 if target.exists():
  assert target.stat().st_size==m['bytes'],'Existing file has different size'
  with target.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
  assert sha==m['sha256'],'Existing file has different hash'
  m['reused']=True
 else:
  assert shutil.disk_usage(MODELS).free-m['bytes']>=reserve,'Download would cross free-space reserve'
  from public_download import download
  sha=download(m,target,part,status)
 with target.open('rb') as f:m['gguf_metadata']=metadata(f)
 m['verified_sha256']=sha;m['seconds']=round(time.monotonic()-begin,1);m['free_bytes_after']=shutil.disk_usage(MODELS).free;m['verified_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(R/(m['label']+'-download.json')).write_text(json.dumps(m,indent=2));status({'label':m['label'],'phase':'verified','total':m['bytes'],'seconds':m['seconds']});print('VERIFIED',m['label'],m['filename'],m['seconds'],flush=True)
status({'phase':'all_downloads_verified','models':len(selected)});print('ALL DOWNLOADS VERIFIED',flush=True)
