import pathlib,json
R=pathlib.Path('/tmp/hermes-public-eval-20261119');OUT=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-19-public-models');rows=json.loads((R/'metrics.json').read_text())['runs'];models=json.loads((R/'cohort.json').read_text());models={m['label']:m for m in models}
names={'vibeforged-control':'VibeForged v2 Q4 control','fablevibes-control':'FableVibes Q4 control','ornith9-q5':'Ornith 1.5 9B Q5','ministral8-q5':'Ministral 3 8B Q5','armand9-q5':'Armand Qwen3.5 9B Agent Q5','flash9-q5':'FlashModel Qwen3.5 9B Q5','gptoss20':'GPT-OSS 20B MXFP4','qwen35-q4':'Full Qwen3.6 35B Q4, CPU experts','ministral14-q4':'Ministral 3 14B Q4 follow-up'}
lines=['| Model | Public file GB | Grounded reads | Correct workflow | Strict contribution | Contribution seconds | Peak VRAM MiB | First completed tool, explain seconds |','|---|---:|---:|---:|---:|---:|---:|---:|']
for label,name in names.items():
 rs=[x for x in rows if x['label']==label and x['phase']=='matched']
 if not rs:continue
 read=[x for x in rs if x['task'] in ['review','explain']];full=[x for x in rs if x['task']=='full'];ex=next(x for x in rs if x['task']=='explain');m=models[label];size=m.get('bytes')
 if not size:size=(pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/models')/m['filename']).stat().st_size
 lines.append('| '+name+' | '+f'{size/1e9:.2f}'+f" | {sum(x['read_grounded_pass'] is True for x in read)}/{len(read)} | {sum(x['workflow_resources_pass'] is True for x in full)}/{len(full)} | {sum(x['strict_full_pass'] is True for x in full)}/{len(full)} | "+(', '.join(f"{x['seconds']:.1f}" for x in full) or '—')+f" | {max(x['peak_vram_mib'] or 0 for x in rs):,} | {ex['first_tool_completed_seconds']:.1f} |")
(OUT/'matrix.md').write_text('\n'.join(lines)+"""

Primary temperature 0.2, focused Gitea tools, loaded context 98,304. The 14B
row is an adaptive follow-up under matched conditions. One sample per task per
row; repetitions and diagnostics remain separate. GB is decimal file size.
Tool latency includes inference and tool execution, not model-loading time.
Contribution seconds include elapsed time in failed or incomplete attempts.
Strict completion additionally requires all requested read-backs and final URLs.
Read pass requires the whole answer to be grounded; see manual grades for
correct core summaries that still contained unsupported additions.
""")
print('Generated primary matrix')
