import pathlib,json,subprocess,time,os,signal
r=pathlib.Path('/tmp/hermes-public-eval-20261119');paused=False
while True:
 records=json.loads((r/'finalist-probes.json').read_text()) if (r/'finalist-probes.json').exists() else []
 if len(records)<4:time.sleep(3);continue
 lines=(r/'controller.log').read_text().splitlines();p=subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/controller_resume.py$'],capture_output=True,text=True)
 if p.returncode!=0 and 'PRIMARY COHORT COMPLETE' in '\n'.join(lines[-5:]):break
 if p.returncode==0 and lines[-1]=='WAIT DOWNLOAD qwen35-q4' and not (r/'qwen35-q4-download.json').exists() and subprocess.run(['docker','inspect','llama-required-eval'],capture_output=True).returncode!=0:
  os.kill(int(p.stdout.strip()),signal.SIGINT)
  for _ in range(60):
   if subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/controller_resume.py$'],capture_output=True).returncode!=0:break
   time.sleep(1)
  else:raise RuntimeError('Controller did not yield at idle')
  paused=True;print('IDLE PUBLISHER TEMPERATURE CHECK',flush=True);break
 time.sleep(3)
try:
 with (r/'probe-publisher-sampler.log').open('w') as f:p=subprocess.run(['python3',str(r/'probe.py'),'ministral8-q5','publisher-sampler','--temperature','0'],stdout=f,stderr=subprocess.STDOUT)
 (r/'ministral-zero-probe.json').write_text(json.dumps({'temperature':0,'reason':'Repeated completed answers contained unsupported attribution and a proposal duplicating calendarevents on develop. Test publisher-recommended below-0.1 temperature separately.','exit_code':p.returncode},indent=2))
finally:
 if paused:
  with (r/'controller.log').open('a') as f:subprocess.run(['python3',str(r/'controller_resume.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('PUBLISHER TEMPERATURE CHECK COMPLETE',flush=True)
