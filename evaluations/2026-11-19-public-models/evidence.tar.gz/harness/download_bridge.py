import pathlib,json,subprocess,time
r=pathlib.Path('/tmp/hermes-public-eval-20261119');known=set();labels=[x['label'] for x in json.loads((r/'download-plan.json').read_text())['models']]
code="import pathlib,json;r=pathlib.Path('/eval');out={'status':json.loads((r/'download-status.json').read_text()) if (r/'download-status.json').exists() else {}};out['records']={p.name:json.loads(p.read_text()) for p in r.glob('*-download.json')};print(json.dumps(out))"
while True:
 p=subprocess.run(['docker','exec','hermes-required-store','python','-c',code],capture_output=True,text=True)
 if p.returncode==0:
  x=json.loads(p.stdout);tmp=r/'download-status.bridge';tmp.write_text(json.dumps(x['status'],indent=2));tmp.replace(r/'download-status.json')
  for name,v in x['records'].items():
   if v.get('label') in labels:
    (r/name).write_text(json.dumps(v,indent=2))
    if name not in known:print('READY',v['label'],v['filename'],flush=True);known.add(name)
 running=subprocess.run(['docker','inspect','-f','{{.State.Running}}','hermes-public-download-helper'],capture_output=True,text=True).stdout.strip()=='true'
 if not running:
  log=subprocess.run(['docker','logs','hermes-public-download-helper'],capture_output=True);(r/'remote-download.log').write_bytes(log.stdout+log.stderr)
  if x.get('status',{}).get('phase')!='all_downloads_verified':(r/'download-failed.json').write_text(json.dumps({'reason':'Server-local download process exited early','last_status':x.get('status')},indent=2))
  print('DOWNLOAD BRIDGE COMPLETE',flush=True);break
 time.sleep(10)
