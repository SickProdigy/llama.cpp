import pathlib,json,shutil,time,hashlib,datetime
from gguf_meta import metadata
from public_download import download
R=pathlib.Path('/eval');MODELS=pathlib.Path('/models');m=json.loads((R/'extra-model.json').read_text());start=time.monotonic()
def status(x):
 p=R/'extra-download-status.tmp';p.write_text(json.dumps(x,indent=2));p.replace(R/'extra-download-status.json')
target=MODELS/m['filename'];part=MODELS/(m['filename']+'.public-eval.part');status({'label':m['label'],'phase':'starting'})
if not target.exists():
 assert shutil.disk_usage(MODELS).free-2*m['bytes']>=100*2**30,'Temporary download would cross reserve';sha=download(m,target,part,status)
else:
 with target.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 assert sha==m['sha256']
with target.open('rb') as f:m['gguf_metadata']=metadata(f)
m.update(verified_sha256=sha,seconds=round(time.monotonic()-start,1),free_bytes_after=shutil.disk_usage(MODELS).free,verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(R/(m['label']+'-download.json')).write_text(json.dumps(m,indent=2));status({'label':m['label'],'phase':'verified','seconds':m['seconds']});print('EXTRA MODEL VERIFIED',m['filename'],flush=True)
