import struct,io,json,pathlib,urllib.request
SIZES={0:1,1:1,2:2,3:2,4:4,5:4,6:4,7:1,10:8,11:8,12:8};FMT={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
def metadata(f):
 def read(n):
  b=f.read(n)
  if len(b)!=n:raise EOFError()
  return b
 def num(t):return struct.unpack('<'+FMT[t],read(SIZES[t]))[0]
 def string():return read(num(10)).decode('utf8',errors='replace')
 def skip(t):
  if t==8:f.seek(num(10),1)
  elif t==9:
   et=num(4);n=num(10)
   if et in SIZES:f.seek(SIZES[et]*n,1)
   else:
    for _ in range(n):skip(et)
  else:f.seek(SIZES[t],1)
 assert read(4)==b'GGUF';version=num(4);tensors=num(10);n=num(10);out={'version':version,'tensors':tensors,'metadata_count':n}
 for _ in range(n):
  try:
   key=string();t=num(4)
   keep=key in ['general.architecture','general.name','general.type','general.file_type','general.parameter_count'] or any(x in key for x in ['context_length','rope.scaling','block_count','embedding_length'])
   if keep and t!=9:out[key]=string() if t==8 else num(t)
   else:skip(t)
  except EOFError:break
 return out
if __name__=='__main__':
 import sys
 for path in sys.argv[1:]:
  with open(path,'rb') as f:print(json.dumps({'path':path,**metadata(f)}))
