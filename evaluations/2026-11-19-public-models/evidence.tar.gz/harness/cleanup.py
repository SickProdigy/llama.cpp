import pathlib,json,subprocess,shutil,datetime
R=pathlib.Path('/tmp/hermes-public-eval-20261119');OUT=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-19-public-models')
assert json.loads((R/'final-restoration.json').read_text())['normal_profile_config_unchanged']
subprocess.run(['python3',str(R/'audit_archive.py')],check=True)
assert 'EXTRA COHORT COMPLETE' in (R/'extra-cohort.log').read_text()
assert 'PRIMARY COHORT COMPLETE' in (R/'controller.log').read_text()
active=subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/(controller_resume|probe).py'],capture_output=True);assert active.returncode==1
names=['hermes-required-store','mcp-gitea-required-eval','hermes-public-download-helper','hermes-public-extra-download','hermes-required-session','llama-required-eval'];records=[];anon=[]
for name in names:
 p=subprocess.run(['docker','inspect',name],capture_output=True,text=True)
 if p.returncode:continue
 x=json.loads(p.stdout)[0];vols=[m['Name'] for m in x['Mounts'] if m['Type']=='volume'];anon.extend(v for v in vols if len(v)==64 and all(c in '0123456789abcdef' for c in v));records.append({'container':name,'was_running':x['State']['Running'],'volumes':vols});subprocess.run(['docker','rm','-fv',name],check=True,stdout=subprocess.DEVNULL)
p=subprocess.run(['docker','volume','rm','hermes-required-evidence'],capture_output=True,text=True);assert p.returncode==0,p.stderr
for name in names:assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
for v in anon:assert subprocess.run(['docker','volume','inspect',v],capture_output=True).returncode!=0
result={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task_containers_removed':records,'anonymous_home_volumes_removed':anon,'named_evidence_volume_removed':True,'broad_prune_used':False,'private_snapshot_directory_removed':False,'free_bytes':shutil.disk_usage(OUT).free}
(OUT/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n');print('Removed exact task containers and volumes; no broad prune')
