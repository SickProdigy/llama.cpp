import pathlib,json,time,copy,traceback
from driver import Driver,R
source=json.loads((R/'source-before.json').read_text());pool=json.loads((R/'fixture-pool.json').read_text());assigned=[]
if (R/'allocated-fixtures.json').exists():assigned=json.loads((R/'allocated-fixtures.json').read_text())
models=[{'label':'vibeforged-control','filename':'Qwen3.6-14B-A3B-VibeForged-v2-Q4_K_M.gguf','alias':'qwen3.6-14b-a3b-vibeforged-v2-q4_k_m','control':True},{'label':'fablevibes-control','filename':'Qwen3.6-14B-A3B-FableVibes-Q4_K_M.gguf','alias':'qwen3.6-14b-a3b-fablevibes-q4_k_m','control':True}]
aliases={'ornith9-q5':'ornith-1.5-9b-uncensored-q5_k_m','ministral8-q5':'ministral-3-8b-instruct-q5_k_m','armand9-q5':'qwen3.5-9b-agent-q5_k_m','flash9-q5':'flashmodel-qwen3.5-9b-q5_k_m','gptoss20':'gpt-oss-20b-mxfp4','qwen35-q4':'qwen3.6-35b-a3b-q4_k_xl'}
for m in json.loads((R/'download-plan.json').read_text())['models']:models.append(m|{'alias':aliases[m['label']],'control':False})
(R/'cohort.json').write_text(json.dumps(models,indent=2))
def base(label,phase='matched'):
 return {'run_id':'20261119-public-'+label+'-'+phase,'kind':'read','task':'explain','mode':'facade','seconds':180,'call_limit':16,'temperature':0.2,'phase':phase,'label':label,'fork_name':'hermes-mcp-test-20261117-vf-144838','original_content':source['readme'],'file_sha':source['readme_sha'],'upstream_owner':'sickprodigy','upstream_repo':'nicotineplus-plugins','fork_owner':'hermes-agent','allowed_upstream_repositories':['sickprodigy/nicotineplus-plugins']}
def full(label,phase='matched'):
 key=label+'-'+phase
 existing=next((x for x in assigned if x['key']==key),None)
 if existing:f=existing['fixture']
 else:
  used={x['fixture']['fixture'] for x in assigned};f=next(x for x in pool if x['fixture'] not in used);assigned.append({'key':key,'fixture':f});(R/'allocated-fixtures.json').write_text(json.dumps(assigned,indent=2))
 p=base(label,phase);p.update(f);p.update(kind='contribution',task='full',seconds=600 if label=='qwen35-q4' else 300,call_limit=20,branch='mcp-20261119-'+key+'-'+f['fixture'],expected_content=source['readme'].replace(f['old_text'],f['new_text']),issue_title='Public-model MCP test: '+key+' '+f['fixture'],issue_body='Documentation clarity test: replace '+repr(f['old_text'])+' with '+repr(f['new_text'])+' in README.md. No behavior changes.',pr_title='docs: '+f['fixture']+' ('+key+')',pr_body='Refs #<issue-number>')
 p['run_id']+='-full-'+f['fixture']
 p['prompt']=f'''Use only the configured Gitea MCP tools for this authorized documentation contribution. The UPSTREAM repository is sickprodigy/nicotineplus-plugins; the working fork is hermes-agent/{p['fork_name']}. Inspect upstream metadata and README.md on main. Check your identity and verify that personal fork's parent; create the personal fork only if absent. Open exactly one issue in UPSTREAM titled {p['issue_title']!r} with exact body {p['issue_body']!r}. In the working fork create branch {p['branch']} from main. In README.md replace exactly {p['old_text']!r} with {p['new_text']!r} and commit only that edit with a suitable docs message. Read back the committed file. Open a PR in UPSTREAM targeting main from the fork branch, with title {p['pr_title']!r} and body exactly "Refs #<issue-number>" replacing the placeholder with your newly created upstream issue number. Read back the issue and PR. Return the issue URL, changed file URL and PR URL. Do not commit to a default branch, create another fork, merge, close anything, change settings or connections, or use GitHub/browser/terminal alternatives. If a step fails, report the error and existing resources, then stop.'''
 return p

def runs(d,m,phase='matched',overrides=None):
 results=[]
 for task,prompt in [('explain','Find my SonicRatings repo and tell me what it does.'),('review','Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.')]:
  p=base(m['label'],phase);p.update(run_id=p['run_id']+'-'+task,task=task,prompt=prompt)
  if overrides:p['request_overrides']=overrides
  results.append(d.run(p))
 p=full(m['label'],phase)
 if overrides:p['request_overrides']=overrides
 results.append(d.run(p));return results


for m in models:full(m['label'])
sampler_plan={
 'ornith9-q5':{'phase':'q8-cache-diagnostic','cache':'q8_0','read_only':True,'request_overrides':None},
 'ministral8-q5':{'phase':'publisher-sampler','cache':'q4_0','read_only':False,'request_overrides':{'temperature':0.0}},
 'armand9-q5':{'phase':'publisher-sampler','cache':'q4_0','read_only':False,'request_overrides':{'temperature':1.0,'top_p':0.95,'presence_penalty':1.5,'extra_body':{'top_k':20,'min_p':0.0,'repeat_penalty':1.0}}},
 'flash9-q5':{'phase':'precise-coding-sampler','cache':'q4_0','read_only':False,'request_overrides':{'temperature':0.6,'top_p':0.95,'presence_penalty':0.0,'extra_body':{'top_k':20,'min_p':0.0,'repeat_penalty':1.0}}}
}
(R/'sampler-plan.json').write_text(json.dumps(sampler_plan,indent=2))
def spare(waiting=None):
 for candidate in models:
  label=candidate['label'];plan=sampler_plan.get(label);record=R/(label+'-tested.json')
  if not plan or not record.exists() or (R/(label+'-diagnostic.json')).exists():continue
  old=json.loads(record.read_text())
  if not any(s.get('early_stop') or (i==2 and not s.get('pr_number')) for i,s in enumerate(old['runs'])):
   (R/(label+'-diagnostic.json')).write_text(json.dumps({'skipped':'Primary completed all tasks without early stop'}));continue
  print('DIAGNOSTIC START',label,plan['phase'],flush=True)
  try:
   with Driver() as d:
    d.switch(label+'-'+plan['phase'],candidate['filename'],candidate['alias'],context=old['context'],cache=plan['cache'])
    if plan['read_only']:
     p=base(label,plan['phase']);p.update(run_id=p['run_id']+'-review',task='review',prompt='Look over sickprodigy/sick-cogs and suggest one useful new cog that isn’t already there.');results=[d.run(p)]
    else:results=runs(d,candidate,plan['phase'],plan['request_overrides'])
   (R/(label+'-diagnostic.json')).write_text(json.dumps({'plan':plan,'runs':results},indent=2))
  except Exception as e:(R/(label+'-diagnostic.json')).write_text(json.dumps({'plan':plan,'error':str(e),'traceback':traceback.format_exc()},indent=2));print('DIAGNOSTIC FAILURE',label,str(e),flush=True)
  return True
 return False
summary=[]
for m in models:
 done=R/(m['label']+'-tested.json')
 if done.exists():continue
 if not m['control']:
  print('WAIT DOWNLOAD',m['label'],flush=True)
  while not (R/(m['label']+'-download.json')).exists():
   if (R/'download-failed.json').exists():raise RuntimeError('Download queue failed')
   ds=json.loads((R/'download-status.json').read_text())
   nearly_ready=ds.get('label')==m['label'] and ds.get('percent',0)>80
   if not nearly_ready and spare(m):continue
   time.sleep(5)
 print('MODEL START',m['label'],flush=True)
 try:
  with Driver() as d:
   opts=['--n-cpu-moe','24'] if m['label']=='qwen35-q4' else []
   try:d.switch(m['label']+'-matched',m['filename'],m['alias'],extra_args=opts)
   except Exception as first:
    log=(R/(m['label']+'-matched-backend.log')).read_text(errors='replace')
    if any(x in log.lower() for x in ['out of memory','failed to allocate','cuda error','buffer allocation failed']):
     print('MEMORY FALLBACK',m['label'],flush=True);d.switch(m['label']+'-64k',m['filename'],m['alias'],context=65536,extra_args=['--cpu-moe'] if opts else [])
    elif m['label']=='gptoss20' and 'cache' in log.lower():
     print('CACHE FALLBACK',m['label'],flush=True);d.switch(m['label']+'-q8-cache',m['filename'],m['alias'],context=65536,cache='q8_0')
    else:raise
   result=runs(d,m);done.write_text(json.dumps({'model':m,'runs':result,'context':d.context},indent=2));summary.append({'label':m['label'],'runs':result})
 except Exception as e:
  record={'label':m['label'],'error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()};(R/(m['label']+'-failure.json')).write_text(json.dumps(record,indent=2));print('MODEL FAILURE',m['label'],str(e),flush=True)
while spare():pass
(R/'cohort-summary.json').write_text(json.dumps(summary,indent=2));print('PRIMARY COHORT COMPLETE',flush=True)
