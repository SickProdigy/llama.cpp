import pathlib,subprocess,json,os,signal,time
r=pathlib.Path('/tmp/hermes-public-eval-20261119');p=int(subprocess.check_output(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/controller.py$']).strip())
while True:
 log=(r/'controller.log').read_text().splitlines();last=log[-1] if log else ''
 if 'PRIMARY COHORT COMPLETE' in last:break
 if len(list(r.glob('*-tested.json')))>=4 and last.startswith('WAIT DOWNLOAD '):
  label=last.split()[-1]
  if not (r/(label+'-download.json')).exists() and subprocess.run(['docker','inspect','llama-required-eval'],capture_output=True).returncode!=0:
   os.kill(p,signal.SIGINT)
   for _ in range(30):
    if subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/controller.py$'],capture_output=True).returncode!=0:break
    time.sleep(1)
   else:raise RuntimeError('Primary controller did not yield at idle handoff')
   print('Idle handoff after',len(list(r.glob('*-tested.json'))),'completed models',flush=True);break
 time.sleep(2)
with (r/'controller.log').open('a') as f:subprocess.run(['python3',str(r/'controller_resume.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
