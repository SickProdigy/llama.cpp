import pathlib,subprocess,json,time,os,signal
r=pathlib.Path('/tmp/hermes-public-eval-20261119');paused=False
while True:
 lines=(r/'controller.log').read_text().splitlines();last=lines[-1] if lines else '';p=subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/controller_resume.py$'],capture_output=True,text=True)
 if p.returncode!=0 and 'PRIMARY COHORT COMPLETE' in '\n'.join(lines[-5:]):break
 if last=='WAIT DOWNLOAD qwen35-q4' and not (r/'qwen35-q4-download.json').exists() and subprocess.run(['docker','inspect','llama-required-eval'],capture_output=True).returncode!=0:
  pid=int(p.stdout.strip());os.kill(pid,signal.SIGINT)
  for _ in range(60):
   if subprocess.run(['pgrep','-f','^python3 /tmp/hermes-public-eval-20261119/controller_resume.py$'],capture_output=True).returncode!=0:break
   time.sleep(1)
  else:raise RuntimeError('Controller did not yield while waiting on final download')
  paused=True;print('PRIMARY YIELDED AT IDLE QWEN DOWNLOAD',flush=True);break
 time.sleep(3)
commands=[['ministral8-q5','matched-repeat-1'],['ministral8-q5','matched-repeat-2'],['ministral8-q5','native-diagnostic','--mode','native'],['ministral8-q5','long-probe','--tasks','longcontext']]
results=[]
try:
 for args in commands:
  name=args[1];print('FINALIST PROBE',name,flush=True)
  with (r/('probe-'+name+'.log')).open('w') as f:p=subprocess.run(['python3',str(r/'probe.py'),*args],stdout=f,stderr=subprocess.STDOUT)
  results.append({'args':args,'exit_code':p.returncode});(r/'finalist-probes.json').write_text(json.dumps(results,indent=2))
  if p.returncode:print('Probe error retained; continuing remaining checks',name,flush=True)
finally:
 if paused:
  print('RESUMING PRIMARY COHORT',flush=True)
  with (r/'controller.log').open('a') as f:subprocess.run(['python3',str(r/'controller_resume.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('FINALIST SCHEDULER COMPLETE',flush=True)
