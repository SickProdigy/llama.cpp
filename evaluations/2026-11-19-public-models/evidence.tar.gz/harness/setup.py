import subprocess,json,pathlib
r=pathlib.Path('/tmp/hermes-public-eval-20261119')
def sh(a,**kw):return subprocess.run(a,check=True,**kw)
for n in ['hermes','llama-cpp','mcp-gitea-hermes']:
 p=r/(n+'-inspect.json');p.write_bytes(subprocess.check_output(['docker','inspect',n]));p.chmod(0o600)
hi=json.loads((r/'hermes-inspect.json').read_text())[0];mi=json.loads((r/'mcp-gitea-hermes-inspect.json').read_text())[0]
sh(['docker','volume','create','hermes-required-evidence'],stdout=subprocess.DEVNULL)
sh(['docker','run','-d','--name','hermes-required-store','--network','homelab','--mount','type=volume,source=hermes-required-evidence,target=/eval','--entrypoint','sleep',hi['Image'],'infinity'],stdout=subprocess.DEVNULL)
with (r/'profile.tgz').open('wb') as f:sh(['docker','exec','hermes','tar','-czf','-','-C','/opt/data','config.yaml','.env','auth.json','mcp-tokens','SOUL.md','skills','memories','plugins','hooks','.skills_prompt_snapshot.json'],stdout=f)
(r/'profile.tgz').chmod(0o600);sh(['docker','cp',str(r/'profile.tgz'),'hermes-required-store:/eval/profile.tgz'])
envs=[]
for e in mi['Config']['Env']:
 if e.startswith('GITEA_TOOLS='):e+=',repo_read'
 envs.extend(['-e',e])
sh(['docker','run','-d','--name','mcp-gitea-required-eval','--network','homelab',*envs,mi['Image'],*mi['Config']['Cmd']],stdout=subprocess.DEVNULL)
print('Private profile and isolated same-account MCP with expanded repository reads ready')
