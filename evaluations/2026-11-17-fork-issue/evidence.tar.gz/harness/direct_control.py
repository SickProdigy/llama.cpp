import sys,pathlib,tarfile,json,urllib.request,urllib.error,time
sys.path.insert(0,'/opt/hermes')
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
params=json.loads(pathlib.Path('/eval/parameters.json').read_text());root=pathlib.Path('/eval/control');root.mkdir(exist_ok=True)
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
discover_mcp_tools();calls=[]
def call(name,args):
 raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__'+name,args);calls.append({'name':name,'args':args,'result':raw});(root/'calls.json').write_text(json.dumps(calls,indent=2))
 value=json.loads(raw)
 if 'error' in value:return value
 value=value.get('result',value)
 return json.loads(value) if isinstance(value,str) else value
me=call('get_me',{});assert me['login']=='hermes-agent'
source=call('search_repos',{'query':'nicotineplus-plugins'});assert any(x['full_name']=='sickprodigy/nicotineplus-plugins' for x in source)
url='https://gitea.rcs1.top/api/v1/repos/hermes-agent/'+params['fork_name']
try:
 with urllib.request.urlopen(url,timeout=10) as f:existing=json.load(f)
 raise RuntimeError('Control aborted: fork already exists; not repeating creation')
except urllib.error.HTTPError as e:assert e.code==404
result={'type':'direct MCP control, not a model pass','principal':me['login']}
fork=call('repo_write',{'method':'fork','owner':'sickprodigy','repo':'nicotineplus-plugins','name':params['fork_name']});result['fork']=fork
if isinstance(fork,dict) and 'error' not in fork:
 assert fork['full_name']=='hermes-agent/'+params['fork_name'] and fork['fork'] is True
 parent=fork.get('parent') or {};assert parent.get('full_name')=='sickprodigy/nicotineplus-plugins',parent
 result['fork_readback']=call('get_repository_tree',{'owner':'hermes-agent','repo':params['fork_name'],'tree_sha':'main','per_page':100})
 issue=call('issue_write',{'method':'create','owner':'hermes-agent','repo':params['fork_name'],'title':params['issue_title'],'body':params['issue_body']});result['issue']=issue
 if isinstance(issue,dict) and 'error' not in issue:
  assert issue['title']==params['issue_title'] and issue['body']==params['issue_body']
  result['issue_readback']=call('issue_read',{'method':'get','owner':'hermes-agent','repo':params['fork_name'],'issue_number':issue['number']})
(root/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({'control':'not model-generated','fork_created':isinstance(result.get('fork'),dict) and 'error' not in result['fork'],'issue_created':isinstance(result.get('issue'),dict) and 'error' not in result['issue'],'fork_error':result.get('fork',{}).get('error'),'issue_error':result.get('issue',{}).get('error')}))
