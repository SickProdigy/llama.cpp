import sys,pathlib,tarfile,json
sys.path.insert(0,'/opt/hermes')
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
discover_mcp_tools();p=json.loads(pathlib.Path('/eval/parameters.json').read_text());r=pathlib.Path('/eval/control');calls=json.loads((r/'calls.json').read_text());args={'owner':'hermes-agent','repo':p['fork_name'],'tree_sha':'main','per_page':100}
raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__get_repository_tree',args);calls.append({'name':'get_repository_tree','args':args,'result':raw});(r/'calls.json').write_text(json.dumps(calls,indent=2));d=json.loads(raw);assert 'error' not in d;d=d.get('result',d);d=json.loads(d) if isinstance(d,str) else d
assert d['sha']=='84afaf401b29753b6810e4f92f253e0d28637dbf';v=json.loads((r/'result.json').read_text());v['fork_mcp_readback']=d;(r/'result.json').write_text(json.dumps(v,indent=2));print('Same-account MCP fork tree read-back verified')
