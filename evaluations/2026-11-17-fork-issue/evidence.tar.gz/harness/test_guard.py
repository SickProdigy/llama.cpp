import ast,pathlib,unittest,threading,json,time
src=pathlib.Path(__file__).with_name('fork_test.py').read_text();tree=ast.parse(src)
functions=ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['unpack','stop','invalid','dispatch']],type_ignores=[])
class Agent:
 def hard_interrupt(self,**kw):pass
class Sink:
 def __truediv__(self,x):return self
 def write_text(self,x):pass
class Guard(unittest.TestCase):
 def setUp(self):
  self.sent=[];self.env={'json':json,'time':time,'re':__import__('re'),'lock':threading.RLock(),'r':Sink(),'start':time.monotonic(),'prefix':'mcp__mcp_gitea_hermes__','readers':{'get_me','get_file_contents'},'params':{'fork_name':'test-fork','issue_title':'title','issue_body':'body'},'state':{'calls':0,'validation_rejections':0,'fork_dispatches':0,'issue_dispatches':0,'fork_definitively_rejected':False,'issue_definitively_rejected':False,'early_stop':None,'rejected_fingerprints':[]},'calls':[],'a':Agent()}
  self.env['orig']=lambda n,a,**kw:self.sent.append((n,a)) or json.dumps({'result':{'ok':True}})
  exec(compile(functions,'guard','exec'),self.env)
 def call(self,n,args):return self.env['dispatch']('mcp__mcp_gitea_hermes__'+n,args)
 def test_only_requested_fork_and_one_issue(self):
  self.call('repo_write',{'method':'fork','owner':'sickprodigy','repo':'nicotineplus-plugins','name':'test-fork'})
  self.call('issue_write',{'method':'create','owner':'hermes-agent','repo':'test-fork','title':'title','body':'body'})
  self.call('issue_write',{'method':'create','owner':'hermes-agent','repo':'test-fork','title':'title','body':'body'})
  self.assertEqual(len(self.sent),2);self.assertIn('duplicate',self.env['state']['early_stop'])
 def test_upstream_issue_write_never_dispatches(self):
  self.call('issue_write',{'method':'create','owner':'sickprodigy','repo':'nicotineplus-plugins','title':'title','body':'body'});self.assertFalse(self.sent)
 def test_tangent_never_dispatches(self):
  self.env['dispatch']('terminal',{'command':'git clone anything'});self.assertFalse(self.sent);self.assertTrue(self.env['state']['early_stop'])
 def test_wrong_body_one_correction(self):
  args={'method':'create','owner':'hermes-agent','repo':'test-fork','title':'title','body':'wrong'};self.call('issue_write',args);self.assertFalse(self.sent);args['body']='body';self.call('issue_write',args);self.assertEqual(len(self.sent),1)
 def test_ambiguous_fork_not_blindly_retried(self):
  self.env['orig']=lambda *a,**kw:self.sent.append(a) or json.dumps({'error':'request timed out'})
  args={'method':'fork','owner':'sickprodigy','repo':'nicotineplus-plugins','name':'test-fork'};self.call('repo_write',args);self.call('repo_write',args);self.assertEqual(len(self.sent),1)
 def test_identical_rejected_fork_is_not_dispatched_twice(self):
  self.env['orig']=lambda *a,**kw:self.sent.append(a) or json.dumps({'error':'request failed with status 404'})
  args={'method':'fork','owner':'sickprodigy','repo':'nicotineplus-plugins','name':'test-fork','org':'hermes-agent'};self.call('repo_write',args);self.call('repo_write',args);self.assertEqual(len(self.sent),1)
if __name__=='__main__':unittest.main()
