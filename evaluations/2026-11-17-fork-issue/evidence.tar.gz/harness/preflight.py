import sys,pathlib,tarfile,json
sys.path.insert(0,'/opt/hermes')
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
from tools.registry import registry
names=discover_mcp_tools()
def call(name,args):
 raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__'+name,args);d=json.loads(raw);assert 'error' not in d,d
 d=d.get('result',d)
 return json.loads(d) if isinstance(d,str) else d
me=call('get_me',{});assert me['login']=='hermes-agent',me['login']
repos=call('search_repos',{'query':'nicotineplus-plugins'})
source=next(x for x in repos if x['full_name']=='sickprodigy/nicotineplus-plugins')
existing=[x for x in call('repo_read',{'method':'list_my_repos','per_page':100}) if x.get('fork')]
tree=call('get_repository_tree',{'owner':'sickprodigy','repo':'nicotineplus-plugins','tree_sha':'main','recursive':True,'per_page':100})
assert not tree['truncated']
from hermes_cli.config import load_config
from hermes_cli.tools_config import _get_platform_tools
from run_agent import AIAgent
cfg=load_config();selected=sorted(_get_platform_tools(cfg,'discord'))
a=AIAgent(model=cfg['model']['default'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',max_iterations=12,max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
schemas=a.tools;methodsets={x['function']['name']:x['function']['parameters'].get('properties',{}).get('method',{}).get('enum') for x in schemas}
assert 'fork' in methodsets['mcp__mcp_gitea_hermes__repo_write']
assert 'create' in methodsets['mcp__mcp_gitea_hermes__issue_write']
out={'principal':me['login'],'source':source,'existing_forks':existing,'source_tree_sha':tree['sha'],'file_count':sum(x['type']=='blob' for x in tree['tree']),'checkout_file_bytes':sum(x.get('size',0) for x in tree['tree']),'methodsets':methodsets,'model':cfg['model']['default'],'context':cfg['model']['context_length'],'hermes_image_note':'Current live image; revalidated schemas, not assumed historical image'}
pathlib.Path('/eval/preflight.json').write_text(json.dumps(out,indent=2));pathlib.Path('/eval/schemas.json').write_text(json.dumps(schemas,indent=2));print(json.dumps({k:out[k] for k in ['principal','file_count','checkout_file_bytes','source_tree_sha','model','context']}));print('existingforks',[(x['full_name'],x.get('parent',{}).get('full_name')) for x in existing]);a.close()
