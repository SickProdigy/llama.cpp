import subprocess,pathlib,json,time,urllib.request
r=pathlib.Path('/tmp/hermes-fork-eval');im=json.loads((r/'hermes-inspect.json').read_text())[0]['Image']
subprocess.run(['docker','stop','-t','30','hermes'],check=True,stdout=subprocess.DEVNULL)
try:
 with open(r/'console.log','w') as log:
  proc=subprocess.Popen(['docker','run','--rm','--name','hermes-fork-session','--network','homelab','--mount','type=volume,source=hermes-fork-evidence,target=/eval','-e','HERMES_HOME=/opt/data','-e','PYTHONUNBUFFERED=1','--entrypoint','python',im,'/eval/fork_test.py'],stdout=log,stderr=subprocess.STDOUT)
  launch=time.monotonic()
  while proc.poll() is None:
   started=subprocess.run(['docker','exec','hermes-fork-store','cat','/eval/run/started.json'],capture_output=True,text=True)
   try:over=time.time()-json.loads(started.stdout)['epoch']>185
   except Exception:over=False
   if over or time.monotonic()-launch>300:
    subprocess.run(['docker','exec','hermes-fork-store','python','-c',"from pathlib import Path;Path('/eval/run/external-timeout.json').write_text('External stop after180s plus5s grace')"],check=True)
    subprocess.run(['docker','kill','--signal=SIGINT','hermes-fork-session'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(3)
    subprocess.run(['docker','stop','-t','5','hermes-fork-session'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);break
   time.sleep(1)
  proc.wait();print('Agent container exit',proc.returncode)
finally:
 subprocess.run(['docker','start','hermes'],check=True,stdout=subprocess.DEVNULL);print('Original Hermes restored')
subprocess.run(['docker','cp','hermes-fork-store:/eval/run',str(r/'run')],check=True)
