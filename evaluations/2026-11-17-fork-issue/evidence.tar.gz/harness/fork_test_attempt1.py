import sys,os,time,json,tarfile,pathlib,threading,re,hashlib
sys.path.insert(0,'/opt/hermes')
r=pathlib.Path('/eval/run');r.mkdir(exist_ok=True)
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
pathlib.Path('/opt/data/workspace').mkdir(exist_ok=True)
params=json.loads(pathlib.Path('/eval/parameters.json').read_text())
import httpx
send=httpx.Client.send;requests=[];lock=threading.RLock()
def captured(self,request,*args,**kwargs):
 if '/chat/completions' in str(request.url):
  try:
   body=json.loads(request.content)
   with lock:requests.append(body);(r/f'request-{len(requests):03d}.json').write_text(json.dumps(body,indent=2))
  except Exception:pass
 return send(self,request,*args,**kwargs)
httpx.Client.send=captured
import model_tools
from tools.registry import registry
from tools.mcp_tool_discovery import discover_mcp_tools
from hermes_cli.config import load_config
from hermes_cli.tools_config import _get_platform_tools
from run_agent import AIAgent
names=discover_mcp_tools();cfg=load_config();selected=sorted(_get_platform_tools(cfg,'discord'))
a=AIAgent(model=cfg['model']['default'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',max_iterations=12,max_tokens=4096,enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
(r/'schemas.json').write_text(json.dumps(a.tools,indent=2));calls=[];state={'calls':0,'validation_rejections':0,'fork_dispatches':0,'issue_dispatches':0,'fork_definitively_rejected':False,'issue_definitively_rejected':False,'early_stop':None}
start=time.monotonic();orig=registry.dispatch
prefix='mcp__mcp_gitea_hermes__'
readers={'get_me','search_users','search_repos','repo_read','get_dir_contents','get_file_contents','get_repository_tree','branch_read','commit_read','issue_read','list_issues','search_issues','label_read','pull_request_read','list_pull_requests','wiki_read'}
def unpack(raw):
 try:
  value=json.loads(raw) if isinstance(raw,str) else raw
  if isinstance(value,dict) and 'result' in value:
   value=value['result'];value=json.loads(value) if isinstance(value,str) else value
  return value
 except Exception:return {'unparsed_result':str(raw)}
def stop(reason):
 if state['early_stop'] is None:
  state['early_stop']=reason;a.hard_interrupt(tool_reason='Bounded Gitea workflow: '+reason)
 return json.dumps({'error':'Evaluation stopped: '+reason})
def invalid(reason):
 state['validation_rejections']+=1
 if state['validation_rejections']>1:return stop('repeated invalid arguments: '+reason)
 return json.dumps({'error':'Invalid arguments: '+reason})
def dispatch(name,args,**kwargs):
 with lock:
  state['calls']+=1;record={'number':state['calls'],'name':name,'args':args,'dispatched':False};calls.append(record)
  def finish(value):
   record['result']=value;record['elapsed']=round(time.monotonic()-start,3);(r/'calls.json').write_text(json.dumps(calls,indent=2,default=str));(r/'state.json').write_text(json.dumps(state,indent=2));return value
  if state['early_stop']:return finish(json.dumps({'error':'Evaluation already stopped'}))
  if state['calls']>12:return finish(stop('12-tool-call limit'))
  if time.monotonic()-start>=180:return finish(stop('180-second limit'))
  if name=='skill_view':
   record['dispatched']=True;return finish(orig(name,args,**kwargs))
  if not name.startswith(prefix):return finish(stop('off-task tool attempt: '+name))
  method=name[len(prefix):]
  owner=args.get('owner');repo=args.get('repo')
  if owner and owner not in ['sickprodigy','hermes-agent']:return finish(stop('read/write outside approved owners'))
  if repo and repo not in ['nicotineplus-plugins',params['fork_name']]:return finish(stop('read/write outside approved repositories'))
  if method=='repo_write':
   if args.get('method')!='fork':return finish(stop('repository mutation other than fork'))
   if not all(args.get(k) for k in ['owner','repo','name']):return finish(invalid('fork needs owner, repo and the requested fork name'))
   if (owner,repo,args['name'])!=('sickprodigy','nicotineplus-plugins',params['fork_name']):return finish(stop('fork target differs from approved source/name'))
   if args.get('org') not in (None,'','hermes-agent'):return finish(stop('fork namespace differs from hermes-agent'))
   extra=set(args)-{'method','owner','repo','name','org','private'}
   if extra:return finish(invalid('unneeded fork arguments: '+','.join(sorted(extra))))
   if state['fork_dispatches'] and not (state['fork_dispatches']==1 and state['fork_definitively_rejected']):return finish(stop('duplicate or ambiguous fork creation attempt'))
   state['fork_dispatches']+=1;record['dispatched']=True;value=orig(name,args,**kwargs);parsed=unpack(value)
   state['fork_definitively_rejected']=isinstance(parsed,dict) and 'error' in parsed and bool(re.search(r'(?:status|HTTP)\s*(?:code\s*)?[:=]?\s*(400|404|422)\b',str(parsed),re.I))
   return finish(value)
  if method=='issue_write':
   if args.get('method')!='create':return finish(stop('issue mutation other than create'))
   if not all(args.get(k) for k in ['owner','repo','title','body']):return finish(invalid('issue creation needs owner, repo, title and body'))
   if (owner,repo)!=('hermes-agent',params['fork_name']):return finish(stop('issue would affect the upstream or another repository'))
   if args['title']!=params['issue_title'] or args['body']!=params['issue_body']:return finish(invalid('issue title/body must match the requested test text'))
   if set(args)-{'method','owner','repo','title','body'}:return finish(invalid('unrequested issue options'))
   if state['issue_dispatches'] and not (state['issue_dispatches']==1 and state['issue_definitively_rejected']):return finish(stop('duplicate or ambiguous issue creation attempt'))
   state['issue_dispatches']+=1;record['dispatched']=True;value=orig(name,args,**kwargs);parsed=unpack(value)
   state['issue_definitively_rejected']=isinstance(parsed,dict) and 'error' in parsed and bool(re.search(r'(?:status|HTTP)\s*(?:code\s*)?[:=]?\s*(400|404|422)\b',str(parsed),re.I))
   return finish(value)
  if method not in readers:return finish(stop('unapproved mutation/tool: '+name))
  record['dispatched']=True;return finish(orig(name,args,**kwargs))
registry.dispatch=dispatch
(r/'prompt.txt').write_text(params['prompt']);(r/'started.json').write_text(json.dumps({'epoch':time.time(),'cap_seconds':180}))
timer=threading.Timer(180,lambda:stop('180-second limit'));timer.daemon=True;timer.start()
try:
 result=a.run_conversation(params['prompt']);(r/'result.json').write_text(json.dumps(result,indent=2,default=str))
except BaseException as e:
 (r/'exception.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e)}))
finally:
 timer.cancel();state['elapsed']=time.monotonic()-start;(r/'state.json').write_text(json.dumps(state,indent=2));print(json.dumps(state));
 try:
  import shutil;shutil.copy('/opt/data/logs/agent.log',r/'agent.log')
 except Exception:pass
 a.close()
