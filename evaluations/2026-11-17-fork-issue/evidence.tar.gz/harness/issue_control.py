import sys,pathlib,tarfile,json,urllib.request
sys.path.insert(0,'/opt/hermes')
with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
params=json.loads(pathlib.Path('/eval/parameters.json').read_text());root=pathlib.Path('/eval/control');calls=json.loads((root/'calls.json').read_text())
import model_tools
from tools.mcp_tool_discovery import discover_mcp_tools
discover_mcp_tools()
def call(name,args):
 raw=model_tools.handle_function_call('mcp__mcp_gitea_hermes__'+name,args);calls.append({'name':name,'args':args,'result':raw});(root/'calls.json').write_text(json.dumps(calls,indent=2));v=json.loads(raw)
 if 'error' in v:return v
 v=v.get('result',v);return json.loads(v) if isinstance(v,str) else v
me=call('get_me',{});assert me['login']=='hermes-agent'
with urllib.request.urlopen('https://gitea.rcs1.top/api/v1/repos/hermes-agent/'+params['fork_name'],timeout=10) as f:fork=json.load(f)
assert fork['parent']['full_name']=='sickprodigy/nicotineplus-plugins' and fork['open_issues_count']==0
result={'type':'direct MCP control, not model-generated','principal':me['login'],'fork_created':True,'fork_independent_parent_verified':True,'has_issues_before':fork['has_issues'],'fork':fork}
issue=call('issue_write',{'method':'create','owner':'hermes-agent','repo':params['fork_name'],'title':params['issue_title'],'body':params['issue_body']});result['issue']=issue
if 'error' not in issue:
 assert issue['title']==params['issue_title'] and issue['body']==params['issue_body'];result['issue_readback']=call('issue_read',{'method':'get','owner':'hermes-agent','repo':params['fork_name'],'issue_number':issue['number']})
(root/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({'fork_created':True,'issue_created':'error' not in issue,'issue_error':issue.get('error')}))
