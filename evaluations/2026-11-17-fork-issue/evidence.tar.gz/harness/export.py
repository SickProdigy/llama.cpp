import pathlib,json,tarfile,io,hashlib,re,csv
r=pathlib.Path('/tmp/hermes-fork-eval');d=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-17-fork-issue');d.mkdir(parents=True,exist_ok=True)
secrets=set();sensitive=re.compile(r'key|token|password|secret|credential|authorization|cookie',re.I)
def walk_secret(x,key=''):
 if isinstance(x,dict):
  for k,v in x.items():walk_secret(v,k)
 elif isinstance(x,list):
  for v in x:walk_secret(v,key)
 elif isinstance(x,str) and sensitive.search(key) and len(x)>=8 and not x.startswith('${'):secrets.add(x)
walk_secret(json.loads((r/'private-config.json').read_text()))
for name in ['hermes-inspect.json','llama-cpp-inspect.json']:
 for item in json.loads((r/name).read_text()):
  for ev in item['Config'].get('Env',[]):
   k,_,v=ev.partition('=')
   if sensitive.search(k) and len(v)>=8:secrets.add(v)
with tarfile.open(r/'profile.tgz') as t:
 for name in ['auth.json','.env']:
  data=t.extractfile(name).read().decode()
  if name.endswith('.json'):walk_secret(json.loads(data))
  else:
   for line in data.splitlines():
    m=re.match(r'\s*([\w.-]+)\s*=\s*(.*?)\s*$',line)
    if m and sensitive.search(m[1]) and len(m[2])>=8:secrets.add(m[2].strip('\"\''))
allowed={'sickprodigy/nicotineplus-plugins','hermes-agent/'+json.loads((r/'parameters.json').read_text())['fork_name']}
def redact_records(x):
 if isinstance(x,dict):
  if x.get('full_name') and x['full_name'] not in allowed and 'private' in x:return {'redacted':'Unrelated repository metadata omitted'}
  return {k:redact_records(v) for k,v in x.items()}
 if isinstance(x,list):return [redact_records(v) for v in x]
 if isinstance(x,str) and x[:1] in ['{','[']:
  try:return json.dumps(redact_records(json.loads(x)),ensure_ascii=False)
  except Exception:pass
 return x
ordered=sorted(secrets,key=len,reverse=True)
def clean(b):
 text=b.decode()
 try:text=json.dumps(redact_records(json.loads(text)),indent=2,ensure_ascii=False)
 except Exception:pass
 for s in ordered:
  text=text.replace(s,'[REDACTED]').replace(json.dumps(s)[1:-1],'[REDACTED]')
 for name in json.loads((r/'private-repository-names.json').read_text()):text=text.replace(name,'[UNRELATED PRIVATE REPOSITORY]')
 text=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9_.~+/=-]{12,}',r'\1[REDACTED]',text)
 return text.encode()
files=[]
for folder in ['attempt-1','run','control']:
 for p in (r/folder).rglob('*'):
  if p.is_file():files.append((p,('attempt-2' if folder=='run' else folder)+'/'+str(p.relative_to(r/folder))))
for name in ['fork_test_attempt1.py','fork_test.py','test_guard.py','preflight.py','direct_control.py','issue_control.py','verify_fork_mcp.py','execute.py','export.py','parameters.json','parameters-attempt-1.json','preflight.json','source-before.json','after-first.json','fork-independent.json','independent-verification.json','operator-settings-check.json','source-tree-after.json','runtime-verification.json','props.json','console-attempt-1.log','console.log','execution-attempt-1.log','execution.log']:
 if (r/name).exists():files.append((r/name,'harness/'+name))
manifest=[]
with tarfile.open(d/'evidence.tar.gz','w:gz') as t:
 for p,name in sorted(files,key=lambda v:v[1]):
  b=clean(p.read_bytes());assert not any(s.encode() in b for s in ordered),'Unsanitized credential in '+name
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b));manifest.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(d/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));(d/'evidence.tar.gz.sha256').write_text(hashlib.sha256((d/'evidence.tar.gz').read_bytes()).hexdigest()+'  evidence.tar.gz\n')
rows=[]
for folder,label in [('attempt-1','baseline'),('run','personal-account-guidance')]:
 s=json.loads((r/folder/'state.json').read_text());rows.append({'variant':label,'seconds':round(s['elapsed'],1),'tool_calls':s['calls'],'fork_dispatched':s['fork_dispatches'],'fork_created':False,'issue_dispatched':s['issue_dispatches'],'issue_created':False,'whole_workflow_pass':False,'early_stop':s['early_stop']})
with (d/'model-results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
verification={'runtime':json.loads((r/'runtime-verification.json').read_text()),'independent':redact_records(json.loads((r/'independent-verification.json').read_text())),'source_tree':json.loads((r/'source-tree-after.json').read_text()),'operator_settings_change':'Rejected by existing MCP allowlist; no expansion or setting change','created_resources':'One direct-control fork and one accepted test issue; neither a model pass','temporary_cleanup':'Pending archive verification'}
(d/'verification.json').write_bytes(clean(json.dumps(verification).encode()));print('Exported',len(manifest),'sanitized evidence members; unrelated repository metadata omitted')
