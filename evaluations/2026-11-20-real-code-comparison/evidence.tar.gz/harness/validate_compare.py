import ast,json,urllib.request,base64,pathlib
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
def validate(text):
 node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='_bounded_int');ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),'helper','exec'),ns);f=ns['_bounded_int']
 cases=[(float('inf'),20),(float('-inf'),20),(float('nan'),20),(None,20),('bad',20),('12',12),(3,3),(-10,3),(999,200),(42.9,42)]
 rows=[]
 for value,want in cases:
  try:got=f(value,20,3,200);rows.append({'input':repr(value),'expected':want,'actual':got,'pass':got==want})
  except Exception as e:rows.append({'input':repr(value),'expected':want,'exception':type(e).__name__,'pass':False})
 return rows

def check(run):
 p=R/run;state=json.loads((p/'state.json').read_text());base='https://gitea.rcs1.top/api/v1/repos/';m=json.loads((p/'manifest.json').read_text());out={'baseline':validate((R/'original.py').read_text()),'state':state}
 if state.get('commit_present'):
  j=json.load(urllib.request.urlopen(base+'hermes-agent/'+m['fork_name']+'/contents/autospamignore/__init__.py?ref='+m['branch']));text=base64.b64decode(j['content']).decode();(p/'patched.py').write_text(text);out['patched']=validate(text)
 if state.get('pr_number'):
  pr=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/pulls/'+str(state['pr_number'])));files=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/pulls/'+str(state['pr_number'])+'/files'));out['pr']={'url':pr['html_url'],'base':pr['base']['ref'],'head':pr['head']['ref'],'head_repo':pr['head']['repo']['full_name'],'body':pr['body'],'files':[f['filename'] for f in files]}
 if state.get('pr_number'):
  calls=json.loads((p/'calls.json').read_text());final=json.loads((p/'result.json').read_text()).get('final_response') or ''
  out['readbacks']={name:any(c['name']==name and c.get('dispatched') for c in calls) for name in ['gitea_read_issue','gitea_read_pull_request']}
  out['readbacks']['file']=any(c['name']=='gitea_read_file' and c['args'].get('ref')==m['branch'] for c in calls)
  expected=['https://gitea.rcs1.top/sickprodigy/nicotineplus-plugins/issues/'+str(state['issue_number']),'https://gitea.rcs1.top/sickprodigy/nicotineplus-plugins/pulls/'+str(state['pr_number']),'https://gitea.rcs1.top/hermes-agent/'+m['fork_name']+'/src/branch/'+m['branch']+'/autospamignore/__init__.py']
  out['all_expected_final_urls']=all(u in final for u in expected)
 if state.get('issue_number'):
  i=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/issues/'+str(state['issue_number'])));out['issue']={k:i[k] for k in ['html_url','title','body']}
 now=json.load(urllib.request.urlopen(base+'sickprodigy/nicotineplus-plugins/branches/main'));before=json.loads((R/'upstream-before.json').read_text());out['upstream_main_unchanged']=now['commit']['id']==before['commit']['id'];(p/'independent-validation.json').write_text(json.dumps(out,indent=2));print(run,json.dumps(out))
if __name__=='__main__':
 import sys
 for run in sys.argv[1:]:check(run)
