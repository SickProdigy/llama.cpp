import pathlib,subprocess,json,time,urllib.request
R=pathlib.Path('/tmp/hermes-newer-eval-20261120')
def sh(a,**kw):return subprocess.run(a,check=True,**kw)
def rm(n):subprocess.run(['docker','rm','-f',n],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
def ready(alias,context=98304,container=None,seconds=240):
 start=time.monotonic()
 while time.monotonic()-start<seconds:
  if container:
   c=json.loads(subprocess.check_output(['docker','inspect',container]))[0]
   if not c['State']['Running']:raise RuntimeError('Backend exited with code '+str(c['State']['ExitCode']))
  try:
   p=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=3))
   if p.get('model_alias')==alias and p['default_generation_settings']['n_ctx']==context:return p
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('Backend readiness timeout')
class Driver:
 def __enter__(self):
  self.hi=json.loads((R/'hermes-inspect.json').read_text())[0];self.li=json.loads((R/'llama-cpp-inspect.json').read_text())[0];self.label=None
  sh(['docker','stop','-t','30','hermes'],stdout=subprocess.DEVNULL);sh(['docker','stop','-t','20','llama-cpp'],stdout=subprocess.DEVNULL);return self
 def log_backend(self):
  if self.label:
   logs=subprocess.run(['docker','logs','llama-required-eval'],capture_output=True);(R/(self.label+'-backend.log')).write_bytes(logs.stdout+logs.stderr)
 def switch(self,label,filename,alias,context=98304,extra_args=None,cache='q4_0'):
  self.log_backend();rm('llama-required-eval');self.label=label;self.alias=alias;self.context=context
  args=['docker','run','-d','--name','llama-required-eval','--network','homelab','--network-alias','llama','--gpus','all','--volumes-from','llama-cpp:ro','-p','11430:11430','--memory','40g','--memory-swap','40g',self.li['Image'],'-m','/models/'+filename,'--alias',alias,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(context),'--parallel','1','--cache-type-k',cache,'--cache-type-v',cache,'--n-predict','512','-ngl','999','--temp','0.2','--top-k','20','--top-p','0.95','--min-p','0.05','--repeat-penalty','1','--presence-penalty','0','--frequency-penalty','0',*(extra_args or [])]
  (R/(label+'-launch.json')).write_text(json.dumps({'image':self.li['Image'],'args':args[args.index(self.li['Image'])+1:],'context':context,'extra_args':extra_args or []},indent=2));sh(args,stdout=subprocess.DEVNULL)
  try:p=ready(alias,context,'llama-required-eval')
  except Exception:self.log_backend();raise
  (R/(label+'-props.json')).write_text(json.dumps(p,indent=2));print('BACKEND READY',label,context,flush=True)
 def run(self,p):
  p=dict(p);p['alias']=self.alias;p['context_length']=self.context;(R/'parameters.json').write_text(json.dumps(p,indent=2));sh(['docker','cp',str(R/'parameters.json'),'hermes-required-store:/eval/parameters.json']);print('RUN START',p['run_id'],flush=True)
  with (R/(p['run_id']+'-console.log')).open('w') as f:
   proc=subprocess.Popen(['docker','run','--rm','--name','hermes-required-session','--network','homelab','--mount','type=volume,source=hermes-required-evidence,target=/eval','-e','HERMES_HOME=/opt/data','-e','PYTHONUNBUFFERED=1','--entrypoint','python',self.hi['Image'],'/eval/session.py'],stdout=f,stderr=subprocess.STDOUT);start=time.monotonic();gpu=[]
   while proc.poll() is None:
    if time.monotonic()-start>p['seconds']+50:rm('hermes-required-session');(R/(p['run_id']+'-external-timeout.json')).write_text(json.dumps({'seconds':p['seconds']+50}));break
    x=subprocess.run(['docker','exec','llama-required-eval','nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True)
    if x.returncode==0:gpu.append({'seconds':round(time.monotonic()-start,2),'gpu':x.stdout.strip()})
    time.sleep(3)
   proc.wait();(R/(p['run_id']+'-gpu.json')).write_text(json.dumps(gpu,indent=2))
  target=R/p['run_id'];copied=subprocess.run(['docker','cp','hermes-required-store:/eval/runs/'+p['run_id'],str(target)],capture_output=True)
  if copied.returncode:raise RuntimeError('Session did not produce a run directory')
  state=json.loads((target/'state.json').read_text()) if (target/'state.json').exists() else {'harness_error':'no state'};print('RUN DONE',p['run_id'],json.dumps(state),flush=True);return state
 def __exit__(self,exc_type,exc,tb):
  self.log_backend();rm('hermes-required-session');rm('llama-required-eval');sh(['docker','start','llama-cpp'],stdout=subprocess.DEVNULL);original=json.loads((R/'initial-props.json').read_text());ready(original['model_alias'],original['default_generation_settings']['n_ctx']);sh(['docker','start','hermes'],stdout=subprocess.DEVNULL)
  (R/('restoration-'+str(int(time.time()))+'.json')).write_text(json.dumps({'exception':str(exc) if exc else None,'hermes_running':True,'llama_running':True},indent=2));print('RESTORED ORIGINALS',flush=True)
