import sys,pathlib,json,time,threading,hashlib,shutil,functools
sys.path[:0]=['/eval','/opt/hermes']
p=json.loads(pathlib.Path('/eval/parameters.json').read_text());r=pathlib.Path('/eval/runs')/p['run_id'];r.mkdir(parents=True,exist_ok=True)
from prepare_profile import prepare
prepare(p['mode'],p['alias'],p.get('allowed_upstream_repositories'),p.get('context_length',98304))
import httpx
send=httpx.Client.send;lock=threading.RLock();requests=[]
def captured(self,request,*args,**kwargs):
 if '/chat/completions' in str(request.url):
  try:
   with lock:
    requests.append(json.loads(request.content));(r/f'request-{len(requests):03d}.json').write_text(json.dumps(requests[-1],indent=2))
  except Exception:pass
 return send(self,request,*args,**kwargs)
httpx.Client.send=captured
import model_tools
from tools.registry import registry
from tools.mcp_tool_discovery import discover_mcp_tools
from hermes_cli.config import load_config
from hermes_cli.tools_config import _get_platform_tools
from run_agent import AIAgent
from guard import Guard,Reject,PREFIX
from retry_ledger import RetryLedger
discover_mcp_tools();cfg=load_config();selected=sorted(_get_platform_tools(cfg,'discord'))
a=AIAgent(model=p['alias'],base_url=cfg['model']['base_url'],api_key=cfg['model']['api_key'],provider='custom',request_overrides=p.get('request_overrides',{'temperature':p.get('temperature',0.2)}),max_iterations=p['call_limit'],max_tokens=p.get('max_tokens',4096),enabled_toolsets=selected,disabled_toolsets=cfg['agent']['disabled_toolsets'],platform='discord',quiet_mode=True,skip_background_review=True,load_soul_identity=True,cwd='/opt/data/workspace')
(r/'code-hashes.json').write_text(json.dumps({name:hashlib.sha256(pathlib.Path('/eval',name).read_bytes()).hexdigest() for name in ['session.py','guard.py','retry_ledger.py','prepare_profile.py','gitea-focused/__init__.py']},indent=2))
(r/'schemas.json').write_text(json.dumps(a.tools,indent=2));(r/'prompt.txt').write_text(p['prompt']);(r/'manifest.json').write_text(json.dumps(p,indent=2));g=Guard(p)
if p.get('seed_issue_number'):g.issue=p['seed_issue_number'];g.sent.add('issue')
if p.get('seed_branch'):g.branch=True;g.sent.add('branch')
if p.get('seed_commit'):g.commit=True;g.sent.add('commit')
if p.get('task')=='pr-only':g.sent.add('fork')
ledger=RetryLedger();orig=registry.dispatch;calls=[];native_calls=[];state={'early_stop':None,'validation_rejections':{}};start=time.monotonic()
def unpack(value):
 for _ in range(5):
  if isinstance(value,str):
   try:value=json.loads(value);continue
   except ValueError:return value
  if isinstance(value,dict) and set(value)=={'result'}:value=value['result'];continue
  return value
 return value
def iserror(value):
 v=unpack(value);return isinstance(v,dict) and ('error' in v or v.get('isError'))
def stop(reason):
 if state['early_stop'] is None:state['early_stop']=reason;a.hard_interrupt(tool_reason='Bounded contribution evaluation: '+reason)
 return json.dumps({'error':'Evaluation stopped: '+reason})
def save():
 state.update({'elapsed':round(time.monotonic()-start,3),'model_tool_calls':len(calls),'native_calls':len(native_calls),'issue_number':g.issue,'branch_present':g.branch,'commit_present':g.commit,'pr_number':g.pr,'mutation_epoch':ledger.epoch})
 for name,value in [('calls.json',calls),('native-calls.json',native_calls),('state.json',state)]: (r/name).write_text(json.dumps(value,indent=2,default=str))
def invalid(name,args,message):
 state['validation_rejections'][name]=state['validation_rejections'].get(name,0)+1;ledger.reject(name,args)
 return stop('repeated invalid arguments: '+message) if state['validation_rejections'][name]>1 else json.dumps({'error':'Invalid arguments: '+message})
def native(name,args):
 stage=g.check(name,args);g.before(stage);entry={'model_call':len(calls),'name':name,'args':args,'stage':stage};native_calls.append(entry)
 value=orig(name,args);entry['result']=value;entry['elapsed']=round(time.monotonic()-start,3);g.after(stage,unpack(value));ledger.advance_after_write(succeeded=stage!='read' and not iserror(value));save();return value

def intent(name,args):
 # Check visible write targets before invoking a facade; required-field errors
 # remain ordinary tool validation. No operator argument correction occurs.
 op=name.removeprefix('gitea_');s=args
 if op=='create_issue' and all(k in s for k in ['upstream_owner','upstream_repo','title','body']):return PREFIX+'issue_write',{'method':'create','owner':s['upstream_owner'],'repo':s['upstream_repo'],'title':s['title'],'body':s['body']}
 if op=='fork_repository' and all(k in s for k in ['upstream_owner','upstream_repo','fork_name']):return PREFIX+'repo_write',{'method':'fork','owner':s['upstream_owner'],'repo':s['upstream_repo'],'name':s['fork_name']}
 if op=='create_branch' and all(k in s for k in ['fork_owner','fork_repo','branch_name','base_branch']):return PREFIX+'branch_write',{'method':'create','owner':s['fork_owner'],'repo':s['fork_repo'],'branch':s['branch_name'],'old_branch':s['base_branch']}
 if op=='edit_file' and all(k in s for k in ['fork_owner','fork_repo','branch_name','path','commit_message','old_text','new_text']):return PREFIX+'create_or_update_file',{'owner':s['fork_owner'],'repo':s['fork_repo'],'branch_name':s['branch_name'],'path':s['path'],'message':s['commit_message'],'edits':[{'old_string':s['old_text'],'new_string':s['new_text']}]}
 if op=='create_pull_request' and all(k in s for k in ['upstream_owner','upstream_repo','fork_owner','head_branch','base_branch','title','body']):return PREFIX+'pull_request_write',{'method':'create','owner':s['upstream_owner'],'repo':s['upstream_repo'],'head':s['fork_owner']+':'+s['head_branch'],'base':s['base_branch'],'title':s['title'],'body':s['body']}
 return None
if p['mode']=='facade':
 assert any(t['function']['name']=='gitea_create_pull_request' for t in a.tools)
 assert not any(t['function']['name'].startswith(PREFIX) for t in a.tools)
 bridges={id(registry.get_entry(t['function']['name']).handler.func.__self__):registry.get_entry(t['function']['name']).handler.func.__self__ for t in a.tools if t['function']['name'].startswith('gitea_')}
 for bridge in bridges.values():bridge.transport=native

def dispatch(name,args,**kwargs):
 with lock:
  entry={'number':len(calls)+1,'name':name,'args':args,'dispatched':False};calls.append(entry)
  try:
   if state['early_stop']:value=json.dumps({'error':'Evaluation already stopped'})
   elif len(calls)>p['call_limit']:value=stop('model tool-call limit')
   elif time.monotonic()-start>=p['seconds']:value=stop('time limit')
   else:
    fingerprint=ledger.key(name,args)
    if fingerprint in ledger.rejected:raise Reject('repeated identical rejected call')
    if name in ('skill_view','skills_list'):entry['dispatched']=True;value=orig(name,args,**kwargs)
    elif p['mode']=='native' and name.startswith(PREFIX):entry['dispatched']=True;value=native(name,args)
    elif p['mode']=='facade' and name.startswith('gitea_'):
     mapped=intent(name,args)
     if mapped:g.check(*mapped)
     entry['dispatched']=True;value=orig(name,args,**kwargs)
    else:raise Reject('off-task tool attempt: '+name)
    if iserror(value):ledger.rejected.add(fingerprint)
  except ValueError as e:value=invalid(name,args,str(e))
  except Reject as e:value=stop(str(e))
  except BaseException as e:entry['exception']=str(e);save();raise
  entry['result']=value;entry['elapsed']=round(time.monotonic()-start,3);save();return value
registry.dispatch=dispatch
(r/'started.json').write_text(json.dumps({'epoch':time.time(),'seconds':p['seconds']}));timer=threading.Timer(p['seconds'],lambda:stop('time limit'));timer.daemon=True;timer.start()
try:(r/'result.json').write_text(json.dumps(a.run_conversation(p['prompt']),indent=2,default=str))
except BaseException as e:(r/'exception.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e)}))
finally:
 timer.cancel();save()
 try:shutil.copy('/opt/data/logs/agent.log',r/'agent.log')
 except Exception:pass
 print(json.dumps(state),flush=True);a.close()
