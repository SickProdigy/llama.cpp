import pathlib,tarfile,shutil

def prepare(mode='facade',alias=None,allowed_upstream_repositories=None,context_length=98304):
 with tarfile.open('/eval/profile.tgz') as t:t.extractall('/opt/data',filter='data')
 pathlib.Path('/opt/data/workspace').mkdir(exist_ok=True)
 import hermes_yaml as yaml
 p=pathlib.Path('/opt/data/config.yaml');c=yaml.safe_load(p.read_text());c['mcp_servers']['mcp-gitea-hermes']['url']='http://mcp-gitea-required-eval:8080/mcp'
 if alias:c['model']['default']=alias
 c['model']['context_length']=context_length
 if mode=='facade':
  dest=pathlib.Path('/opt/data/plugins/gitea-focused');shutil.copytree('/eval/gitea-focused',dest,dirs_exist_ok=True)
  plugins=c.setdefault('plugins',{});plugins['enabled']=list(dict.fromkeys(plugins.get('enabled',[])+['gitea-focused']));plugins.setdefault('entries',{})['gitea-focused']={'settings':{'allowed_upstream_repositories':allowed_upstream_repositories if allowed_upstream_repositories is not None else ['sickprodigy/nicotineplus-plugins'],'public_url':'https://gitea.rcs1.top'}}
  platforms=c.setdefault('platform_toolsets',{});platforms['discord']=list(dict.fromkeys(platforms.get('discord',['hermes-discord'])+['gitea-focused']))
  agent=c.setdefault('agent',{});agent['disabled_toolsets']=list(dict.fromkeys(agent.get('disabled_toolsets',[])+['mcp-gitea-hermes','discord','discord_admin']))
  hint=c['agent'].get('environment_hint','')
  hint=hint.replace('mcp__mcp_gitea_hermes__get_file_contents','gitea_read_file').replace('mcp__mcp_gitea_hermes__','gitea_').replace('search_repos','gitea_search_repositories').replace('get_dir_contents','gitea_list_directory').replace('get_file_contents','gitea_read_file').replace('with with_lines: true, start_line: 1, end_line: 160','with start_line: 1, end_line: 160')
  c['agent']['environment_hint']=hint
 p.write_text(yaml.safe_dump(c,sort_keys=False));return c
