import pathlib,json,csv
R=pathlib.Path('/tmp/hermes-newer-eval-20261120');O=pathlib.Path('/media/prodigy/Coding-Programming/docker-containers2/llama.cpp/evaluations/2026-11-20-real-code-comparison');rows=[]
for p in sorted(R.glob('20261120-*')):
 if not p.is_dir() or not (p/'state.json').exists():continue
 m=json.loads((p/'manifest.json').read_text());s=json.loads((p/'state.json').read_text());calls=json.loads((p/'calls.json').read_text());gpu=json.loads((R/(p.name+'-gpu.json')).read_text());res=json.loads((p/'result.json').read_text()) if (p/'result.json').exists() else {};v=json.loads((p/'independent-validation.json').read_text()) if (p/'independent-validation.json').exists() else {};first=calls[0] if calls else {};row={'run_id':p.name,'model':m['label'],'phase':m['phase'],'context':m['context_length'],'seconds':s['elapsed'],'first_tool_seconds':first.get('elapsed'),'first_tool':first.get('name'),'calls':len(calls),'peak_vram_mib':max(int(x['gpu'].split(',')[0]) for x in gpu),'early_stop':s['early_stop'],'issue':s['issue_number'],'pr':s['pr_number'],'patch_tests_pass':all(t['pass'] for t in v['patched']) if v.get('patched') else None}
 if m['task']=='routing':
  row['gitea_routing_pass']=bool(calls) and all(x['name'].startswith('gitea_') for x in calls) and not s['early_stop'] and bool(res.get('final_response'));(p/'routing-verification.json').write_text(json.dumps({'route_pass':row['gitea_routing_pass'],'prompt':m['prompt'],'tool_names':[x['name'] for x in calls],'whole_answer_grounding':'manual review required; route score is separate'},indent=2))
 rows.append(row)
(O/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');keys=list(dict.fromkeys(k for row in rows for k in row))
with (O/'runs.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
print(json.dumps(rows,indent=2))
