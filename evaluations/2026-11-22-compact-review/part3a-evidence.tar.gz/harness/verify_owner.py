from pathlib import Path
import subprocess,json,hashlib,sys
P=Path(__file__).resolve().parent;root=Path('/media/prodigy/Coding-Programming/Repos/nicotineplus-plugins');sha=lambda x:hashlib.sha256(x).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
b=json.loads((P/'owner-before.json').read_text());names=git('ls-files','-z').decode().split('\0');files={n:sha((root/n).read_bytes()) for n in names if n}
x={'head':git('rev-parse','HEAD').decode().strip(),'status_sha256':sha(git('status','--porcelain=v1','-z')),'tracked_file_sha256':files,'ignored_owner_instructions_sha256':sha((root/'AGENTS.md').read_bytes())}
result={'head_unchanged':x['head']==b['head'],'status_unchanged':x['status_sha256']==b['status_sha256'],'all_tracked_files_unchanged':x['tracked_file_sha256']==b['tracked_file_sha256'],'ignored_owner_instructions_unchanged':x['ignored_owner_instructions_sha256']==b['ignored_owner_instructions_sha256'],'no_owner_contents_exported':True}
(P/('owner-preservation-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert all(result.values())
