"""Posthoc negative control; never feeds private evaluation results to models."""
from pathlib import Path
import json,sys,os,hashlib
P=Path(__file__).parent;R=Path.cwd();sys.path.insert(0,str(R/'hermes-profile/compact-review'))
from review_packet import source_digest,encoded
from docker_execution import DockerExecution
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-compact-review-20261122/part3'
def files(root):return {str(f.relative_to(root)):f.read_bytes().decode()for f in root.rglob('*')if f.is_file()and not any(x in {'.git','__pycache__','.pytest_cache'}for x in f.relative_to(root).parts)}
base=files(P/'baseline');index=P/'relevance-index.json';results=json.loads(index.read_text())if index.exists()else{}
for grade_path in sorted((P/'stages').glob('*/*/turn*/*grade/grade.json')):
 root=grade_path.parent;candidate=files(root/'source');test_files={n:t for n,t in candidate.items()if n.endswith('.py')and(n.startswith('tests/')or Path(n).name.startswith('test_')or Path(n).name.endswith('_test.py'))}
 changed=[n for n,t in test_files.items()if base.get(n)!=t];selected=[n for n in changed if Path(n).name.startswith('test_')or Path(n).name.endswith('_test.py')]
 label=str(root.relative_to(P));assembled={**base,**test_files};key=hashlib.sha256(encoded({'source':source_digest(assembled),'selected':sorted(selected),'image':IMAGE})).hexdigest()
 if label in results:continue
 same=next((v for v in results.values()if v.get('control_key')==key),None)
 if same:
  results[label]={**same,'reused_identical_control':True};continue
 if not selected:
  results[label]={'control_key':key,'changed_test_modules':changed,'selected_test_files':[],'baseline_nonzero':False,'meaningful_regression_evidence':False,'reason':'No added or changed Python test module'};continue
 out=P/'relevance-controls'/key;source=out/'source';source.mkdir(parents=True,exist_ok=False)
 for n,t in assembled.items():
  f=source/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t.encode())
 runner=DockerExecution(source,ENGINE+'/relevance-controls/'+key+'/source',IMAGE,suite_id='regression-relevance',output_log=out/'baseline-with-authored-tests.log')
 from review_packet import run_suite
 receipt=run_suite(suite_id='regression-relevance',argv=['python','-m','pytest','-q','-p','no:cacheprovider',*sorted(selected)],expected_digest=source_digest(assembled),inventory=runner.inventory,execute=runner.execute,key=os.urandom(32),environment_id=IMAGE)
 (out/'receipt-payload.json').write_bytes(encoded(receipt['payload']))
 results[label]={'control_key':key,'changed_test_modules':changed,'selected_test_files':selected,'baseline_exit':receipt['payload']['returncode'],'baseline_nonzero':receipt['payload']['returncode']!=0,'manual_failure_reason_audit_required':True,'nonzero_alone_is_not_test_adequacy':True,'not_fed_to_models':True}
 index.write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'source':label,**results[label]}),flush=True)
index.write_text(json.dumps(results,indent=2)+'\n')
