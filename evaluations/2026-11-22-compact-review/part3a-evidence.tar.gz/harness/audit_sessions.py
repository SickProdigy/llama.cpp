from pathlib import Path
import sqlite3,json,hashlib,sys
P=Path(__file__).resolve().parent;family=sys.argv[1];tasks=json.loads((P/'tasks.json').read_text())[family];rows=[]
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
for f in sorted((P/'stages'/family).glob('*/turn*/run.json')):
 run=json.loads(f.read_text());phase=run['phase'];db=sqlite3.connect('file:'+str(f.parent/'state.db')+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
 users=[r['content'] for r in db.execute("select content from messages where role='user' order by id")]
 admissions=[]
 for a in db.execute('select * from session_admissions order by seq'):
  payload=a['payload_json'];admissions.append({'seq':a['seq'],'target_is_current_or_root':a['target_session_id']in[run['logical_root'],run['effective_sid']],'status':a['status'],'matching_frozen_tasks':[i for i,q in enumerate(tasks)if q in payload or q in json.dumps(json.loads(payload),ensure_ascii=False)],'payload_sha256':sha(payload)})
 row={'arm':run['arm'],'phase':phase,'frozen_query_sha_matches':sha(tasks[phase])==run['query_sha256'],'raw_user_tasks_exact':users==tasks[:phase+1],'raw_user_task_hashes':[sha(x)for x in users],'logical_root':run['logical_root'],'effective_sid':run['effective_sid'],'lineage_nodes':len(run['lineage']),'admissions':admissions,'private_full_transcripts_not_exported':True}
 control=f.parent/'native-admission-control.json'
 if control.exists():row['native_admission_control']=json.loads(control.read_text())
 rows.append(row);db.close()
(P/(family+'-session-audit.json')).write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'turns':len(rows),'frozen_queries_all_match':all(x['frozen_query_sha_matches']for x in rows),'raw_prefixes_all_match':all(x['raw_user_tasks_exact']for x in rows)}))
