"""Trusted-only receipt/source/log audit. Never exports private issuer keys."""
from pathlib import Path
import json,sys,hashlib
P=Path(__file__).resolve().parent;family=sys.argv[1];sys.path.insert(0,'/compact-code')
from review_packet import execution_summaries,source_digest,packet_id,encoded
rows=[]
for records in sorted((P/'stages'/family).glob('*/proxy-records')):
 key=(records/'reviews/receipt-key').read_bytes()
 for root in sorted((records/'reviews').iterdir()):
  if not root.is_dir():continue
  receipts=[json.loads(f.read_text())for f in [root/'receipt.json',root/'preservation-receipt.json']if f.exists()]
  files={str(f.relative_to(root/'source')):f.read_bytes().decode()for f in (root/'source').rglob('*')if f.is_file()};digest=source_digest(files)
  logbind=all(hashlib.sha256((root/('project.log'if r['payload']['suite_id']=='project'else'preservation.log')).read_bytes()).hexdigest()==r['payload']['output_sha256']for r in receipts)
  row={'arm':records.parent.name,'review_id':root.name,'source_digest':digest,'log_hashes_match_receipts':logbind,'suites':{r['payload']['suite_id']:{k:r['payload'][k]for k in ['returncode','timed_out','source_digest','started_ns','finished_ns']}for r in receipts}}
  try:
   evidence=execution_summaries(receipts,key=key,required_suites=['project','preservation'],candidate_digest=digest,environment_id=receipts[0]['payload']['environment_id']);row['authentic_passing_prerequisites']=True
  except Exception as e:row['authentic_passing_prerequisites']=False;row['prerequisite_block_reason']=str(e)
  if(root/'packet.json').exists():
   packet=json.loads((root/'packet.json').read_text());assert row['authentic_passing_prerequisites'];assert packet['execution']==evidence;assert packet_id(packet)==packet['packet_id'];assert packet['candidate_source_digest']==digest
   row.update(packet_id=packet['packet_id'],packet_bytes=len(encoded(packet)),phase=len(packet['tasks'])-1,operation=packet['publication']['operation'],packet_execution_verified=True)
   if(root/'input-metrics.json').exists():row['metrics']=json.loads((root/'input-metrics.json').read_text())
  if(root/'http/capture.json').exists():
   cap=json.loads((root/'http/capture.json').read_text());row['capture']={k:cap.get(k)for k in ['body_complete','finish_reason','backend_http_seconds','usage','parsed_review']};row['tests_before_review']=max(r['payload']['finished_ns']for r in receipts)<=cap['started_epoch']*1e9
  if(root/'http/caller.json').exists():
   c=json.loads((root/'http/caller.json').read_text());row['caller']={k:c.get(k)for k in ['caller_completed','caller_seconds','caller_limit_seconds']}
  row['admitted']=(root/'admitted.json').exists();rows.append(row)
(P/(family+'-receipt-audit.json')).write_text(json.dumps(rows,indent=2)+'\n')
assert all(r['log_hashes_match_receipts']for r in rows)
assert all(not r['admitted']or(r['authentic_passing_prerequisites']and r['packet_execution_verified']and r['tests_before_review'])for r in rows)
print(json.dumps({'attempts':len(rows),'admitted':sum(r['admitted']for r in rows),'all_logs_bound':True,'all_admissions_actual_passing_source_bound_tests_before_review':True,'keys_not_exported':True}))
