"""Trusted fresh native experiment. Private graders never become actor feedback."""
from pathlib import Path
import os,sys,json,subprocess,time,hashlib,urllib.request,sqlite3,shutil,signal,traceback
D=Path('/state');P=D/'part3';sys.path.insert(0,'/compact-code');sys.path.insert(0,str(P/'harness'))
from review_packet import source_digest,encoded,sha
from docker_execution import DockerExecution
from native_session_lineage import compression_lineage
FAMILY=sys.argv[1];assert FAMILY in ['bounded_replies','wolfram_errors']
SHORT={'bounded_replies':'limits','wolfram_errors':'xml'}[FAMILY];MODULE={'bounded_replies':'localai','wolfram_errors':'wolfram'}[FAMILY]
S=P/'stages'/FAMILY;S.mkdir(parents=True,exist_ok=False)
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp'
EP=ENGINE+'/.git/hermes-compact-review-20261122/part3'
BACKEND='sha256:0eee1b477a28c1bd8806885d50447caa302eef5c977846f1177330def5fcd185';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
ALIAS='qwen3.8-27b-hermes-adapted-iq3xxs';NET='hermes-compact-native-'+SHORT;MAIN='compact-native-'+SHORT+'-main';LLM='compact-native-'+SHORT+'-llm';AGENT='compact-native-'+SHORT+'-agent';PROXY='compact-native-'+SHORT+'-gitea'
owned={};network_id=None;stopped=False;baseline={};tasks=json.loads((P/'tasks.json').read_text())[FAMILY]
arenas={x['arm']:x for x in json.loads((P/'arenas.json').read_text())}
def save(path,obj):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(obj,indent=2)+'\n');temp.replace(path)
def event(kind,**kw):
 obj={'epoch':time.time(),'kind':kind,**kw}
 with (S/'events.jsonl').open('a') as f:f.write(json.dumps(obj)+'\n')
 print(json.dumps(obj),flush=True)
def docker(*args,check=True,timeout=180):
 r=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and r.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+r.stderr[-1200:])
 return r.stdout

def inspect(name):return json.loads(docker('inspect',name))[0]
def state(name):
 c=inspect(name);return {'id':c['Id'],'image':c['Image'],'signature':sha(encoded({k:c[k]for k in ['Image','Config','HostConfig','Mounts']})),'running':c['State']['Running'],'started':c['State']['StartedAt'],'restarts':c['RestartCount'],'health':c['State'].get('Health',{}).get('Status')}
def http(url,body=None):
 req=urllib.request.Request(url,data=None if body is None else encoded(body),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
def ready(name,alias,ctx):
 end=time.monotonic()+300
 while time.monotonic()<end:
  if not inspect(name)['State']['Running']:raise RuntimeError('Backend exited during readiness')
  try:
   x=http('http://'+name+':11430/props');health=http('http://'+name+':11430/health')
   if x['model_alias']==alias and x['default_generation_settings']['n_ctx']==ctx and health['status']=='ok':return x
  except (OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Backend readiness expired')
def run(name,args):
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0,'Owned name already exists'
 ident=docker('run','-d','--pull','never','--name',name,*args).strip();owned[name]=ident;return ident

def remove(name):
 if name not in owned:return
 assert inspect(name)['Id']==owned[name],'Refuse cleanup of replaced container'
 log=subprocess.run(['docker','logs',name],capture_output=True);(S/(name+'-'+str(time.time_ns())+'.log')).write_bytes(log.stdout+log.stderr)
 docker('rm','-f',name);owned.pop(name)
def mount(relative,target,ro=False):return ['--mount','type=bind,source='+EP+'/'+relative+',target='+target+(',readonly'if ro else '')]
def credentials(identity):
 c=inspect(identity);env=dict(x.split('=',1)for x in c['Config']['Env']);return env['GITEA_HOST'].rstrip('/'),env['GITEA_ACCESS_TOKEN']
def api(method,path,body=None,identity='mcp-gitea-codex'):
 host,token=credentials(identity);req=urllib.request.Request(host+'/api/v1/'+path,data=encoded(body or {})if method!='GET'else None,method=method,headers={'Authorization':'token '+token,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60) as response:
  raw=response.read();return json.loads(raw) if raw else None

def clone(name,arm,branch='main',fork=False):
 identity='mcp-gitea-required-eval' if fork else 'mcp-gitea-codex';host,token=credentials(identity);owner='hermes-agent'if fork else 'chatgpt-codex';repo=arenas[arm]['repo']
 payload={'name':name,'branch':branch,'user':owner,'url':host+'/'+owner+'/'+repo+'.git','public_url':'https://gitea.rcs1.top/'+owner+'/'+repo+'.git','token':token}
 r=subprocess.run([sys.executable,str(P/'clone_operator.py')],input=json.dumps(payload),capture_output=True,text=True,timeout=120)
 if r.returncode:raise RuntimeError('Trusted clone failed, code '+str(r.returncode))
 return json.loads(r.stdout)
def inventory(root):
 files={}
 for f in sorted(root.rglob('*')):
  rel=f.relative_to(root)
  if any(x in {'.git','__pycache__','.pytest_cache'}for x in rel.parts)or f.name=='AGENTS.md':continue
  if f.is_symlink():raise ValueError('Unsupported symlink source')
  if f.is_file():files[str(rel)]=f.read_bytes().decode()
 source_digest(files);return files

def grade(work,out,phase,kind):
 out.mkdir(parents=True,exist_ok=True)
 try:
  files=inventory(work);source=out/'source';source.mkdir()
  for path,text in files.items():
   f=source/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(text.encode())
  rel=str(source.relative_to(P));engine=EP+'/'+rel;digest=source_digest(files)
  runner=DockerExecution(source,engine,IMAGE,output_log=out/'project.log')
  result=runner.run(expected_digest=digest,key=os.urandom(32));save(out/'project-receipt-payload.json',result['payload'])
  preservation=DockerExecution(source,engine,IMAGE,suite_id='preservation',preservation_tests=EP+'/baseline/tests',output_log=out/'preservation.log')
  old=preservation.run(expected_digest=digest,key=os.urandom(32));save(out/'preservation-receipt-payload.json',old['payload'])
  cmd=['docker','run','--rm','--pull','never','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m','--mount','type=bind,source='+engine+',target=/workspace,readonly',*mount('private_checks.py','/checks/private_checks.py',True),*mount('immutable-fixtures','/checks/immutable-fixtures',True),'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','timeout',IMAGE,'-s','KILL','90','python','/checks/private_checks.py','/workspace',FAMILY,str(phase)]
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=120);(out/'independent.log').write_text(r.stdout+r.stderr)
  base=inventory(P/'baseline');changed=[n for n in sorted(set(base)|set(files))if base.get(n)!=files.get(n)]
  save(out/'grade.json',{'kind':kind,'family':FAMILY,'phase':phase,'source_digest':digest,'project_exit':result['payload']['returncode'],'preservation_exit':old['payload']['returncode'],'independent_exit':r.returncode,'changed_paths':changed,'not_fed_to_models':True})
 except Exception as error:save(out/'grade-error.json',{'error':str(error),'traceback':traceback.format_exc(),'not_fed_to_models':True})

def session(profile,query,first=False):
 db=sqlite3.connect('file:'+str(profile/'state.db')+'?mode=ro',uri=True)
 try:
  row=db.execute('select session_id from messages where role=? and content=? order by id '+('asc'if first else'desc')+' limit 1',('user',query)).fetchone();return row[0]if row else None
 finally:db.close()
def transcript(profile):
 if not(profile/'state.db').exists():return None
 db=sqlite3.connect('file:'+str(profile/'state.db')+'?mode=ro',uri=True)
 try:return sha(encoded(db.execute('select id,session_id,role,content,tool_name,tool_calls from messages order by id').fetchall()))
 finally:db.close()
def capture_db(profile,out):
 db=sqlite3.connect(profile/'state.db',timeout=10);copy=sqlite3.connect(out/'state.db');db.backup(copy);copy.close();db.close()
def remote_audit(run,arm,phase,out):
 state_path=run/'proxy-records/state.json';x=json.loads(state_path.read_text())if state_path.exists()else{};repo=arenas[arm]['repo'];audit={'scope_state':x,'phase':phase}
 if x.get('issue'):audit['issue']=api('GET','repos/chatgpt-codex/'+repo+'/issues/'+str(x['issue']))
 if x.get('pr'):audit['pr']=api('GET','repos/chatgpt-codex/'+repo+'/pulls/'+str(x['pr']))
 if x.get('branch') and x.get('commits'):
  name=arm+'-'+FAMILY+'-remote-'+str(phase);audit['clone']=clone(name,arm,x['branch'],True);grade(P/'worktrees'/name,out/'remote-grade',phase,'actual-fork-commit')
 save(out/'forge-snapshot.json',audit)
def drain_reviews(records):
 end=time.monotonic()+650
 while time.monotonic()<end:
  pending=[p for p in records.glob('reviews/*/http/request.json')if not(p.parent/'capture.json').exists()]
  if not pending:return
  event('waiting_existing_review_capture',count=len(pending));time.sleep(10)
 event('review_capture_guard_expired',count=len(pending))

def case(arm):
 name=arm+'-'+FAMILY;runroot=S/arm;runroot.mkdir();records=runroot/'proxy-records';records.mkdir();config=runroot/'proxy-config';config.mkdir();profile=P/'arms'/name/'profile';work=P/'worktrees'/name
 cl=clone(name,arm);assert cl['head']==arenas[arm]['base_revision']and cl['tree']==arenas[arm]['tree'];save(runroot/'clone.json',cl)
 prefix='compact-'+SHORT+'-'+arm+'-';agents=work/'AGENTS.md';agents.write_text(agents.read_text()+'\nContribution branches in this disposable evaluation must start with '+prefix+'.\n')
 scope={'owner':'chatgpt-codex','repo':arenas[arm]['repo'],'fork_repo':arenas[arm]['repo'],'base_sha':arenas[arm]['base_revision'],'branch_prefix':prefix,'allowed_paths':['README.md'],'allowed_path_prefixes':[MODULE+'/'],'automatic_review':True,'phase_lease':True,'review_mode':'full'if arm=='full'else'docs_only_control','test_image':IMAGE,'engine_records':EP+'/stages/'+FAMILY+'/'+arm+'/proxy-records','engine_baseline_tests':EP+'/baseline/tests','review_endpoint':'http://'+MAIN+':11430/v1/chat/completions','review_alias':ALIAS,'review_deadline':240,'documentation_paths':[MODULE+'/README.md'],'context_paths':['tests/test_'+MODULE+'.py']}
 save(config/'publication-parameters.json',scope);save(config/'current-phase.json',{'id':name+'-not-started','active':False,'tasks_so_far':[]})
 try:
  args=['--network','homelab','--read-only','--memory','1g','--cpus','1','--mount','type=bind,source=/var/run/docker.sock,target=/var/run/docker.sock','--mount','type=bind,source='+ENGINE+'/.git/hermes-goal-recovery-20261121/rebuilt/docker,target=/usr/local/bin/docker,readonly','--mount','type=bind,source='+ENGINE+'/hermes-profile/compact-review,target=/compact-code,readonly',*mount('harness','/harness',True),*mount('baseline','/baseline',True),*mount(str(config.relative_to(P)),'/eval',True),*mount(str(records.relative_to(P)),'/proxy-records'),'-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/harness/scope_proxy.py']
  # Create, attach internal alias, then start so initialization can reach both networks.
  ident=docker('create','--name',PROXY,*args).strip();owned[PROXY]=ident;docker('network','connect','--alias','gitea-compact',NET,PROXY);docker('start',PROXY)
  end=time.monotonic()+60
  while time.monotonic()<end:
   if not inspect(PROXY)['State']['Running']:raise RuntimeError('Scoped proxy preflight exited')
   try:
    x=http('http://'+PROXY+':8080/mcp',{'jsonrpc':'2.0','id':1,'method':'tools/list','params':{}})
    if x.get('result',{}).get('tools'):break
   except OSError:pass
   time.sleep(1)
  else:raise TimeoutError('Scoped proxy readiness')
  run(AGENT,['--network',NET,'--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','4g','--memory-swap','4g','--cpus','2','--tmpfs','/tmp:rw,size=1g,mode=1777',*mount('arms/'+name+'/profile','/opt/data'),*mount('worktrees/'+name,'/workspace'),'-e','HOME=/opt/data','-e','HERMES_HOME=/opt/data','-e','HERMES_WRITE_SAFE_ROOT=/workspace:/opt/data/cache/scratch','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','sleep',IMAGE,'infinity'])
  sid=None;root_sid=None
  for phase,query in enumerate(tasks):
   out=runroot/('turn'+str(phase));out.mkdir()
   if sid:
    before=transcript(profile);r=subprocess.run(['docker','exec',AGENT,'/opt/hermes/bin/hermes','sessions','discard',sid,'--yes'],capture_output=True,text=True,timeout=60);(out/'native-admission-control.log').write_text(r.stdout+r.stderr);assert transcript(profile)==before,'Native discard changed conversation';save(out/'native-admission-control.json',{'command':'hermes sessions discard SID --yes','returncode':r.returncode,'conversation_unchanged':True,'force_unlock':False,'task_replayed':False})
   phase_data={'id':name+'-turn'+str(phase),'active':True,'tasks_so_far':tasks[:phase+1]};save(config/'current-phase.json',phase_data);event('turn_start',arm=arm,phase=phase)
   command=['docker','exec','-i','-w','/workspace',AGENT,'/opt/hermes/bin/hermes','chat','--cli','--oneshot','-Q','--query-file','-','--in','/workspace','--accept-hooks','--max-turns','60','--run-budget','2400']
   if sid:command+=['--resume',sid]
   start=time.monotonic();external=False;samples=[]
   with (out/'console.log').open('w')as log:
    proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT);proc.stdin.write(query.encode());proc.stdin.close()
    while proc.poll()is None:
     if time.monotonic()-start>2700:external=True;phase_data['active']=False;save(config/'current-phase.json',phase_data);docker('stop','-t','15',AGENT);break
     samples.append({'epoch':time.time(),'seconds':time.monotonic()-start,'gpu':docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits',check=False,timeout=15).strip()});time.sleep(5)
    code=proc.wait()
   elapsed=time.monotonic()-start;phase_data['active']=False;save(config/'current-phase.json',phase_data);drain_reviews(records)
   found=session(profile,query);assert found,'Frozen query missing in native state';incoming=sid;root_sid=root_sid or session(profile,tasks[0],True);lineage=compression_lineage(profile/'state.db',root_sid,found)
   if incoming and incoming!=found:compression_lineage(profile/'state.db',incoming,found)
   sid=found;capture_db(profile,out);save(out/'run.json',{'family':FAMILY,'arm':arm,'phase':phase,'elapsed_seconds':elapsed,'exit_code':code,'external_timeout':external,'query_sha256':sha(query.encode()),'logical_root':root_sid,'incoming_sid':incoming,'effective_sid':sid,'lineage':lineage,'gpu':samples})
   grade(work,out/'local-grade',phase,'unpublished-local-draft');shutil.copytree(records,out/'forge-and-review-records',dirs_exist_ok=True);remote_audit(runroot,arm,phase,out);event('turn_end',arm=arm,phase=phase,seconds=elapsed,exit_code=code)
   if external:docker('start',AGENT)
  save(runroot/'case-finished.json',{'turns':3,'logical_root':root_sid,'effective_sid':sid})
 finally:
  try:
   drain_reviews(records)
   x=json.loads((records/'state.json').read_text())if(records/'state.json').exists()else{}
   if x.get('issue'):
    issue=api('PATCH','repos/chatgpt-codex/'+arenas[arm]['repo']+'/issues/'+str(x['issue']),{'state':'closed'});save(runroot/'issue-cleanup.json',{'number':x['issue'],'state':issue['state'],'pr_preserved_unmerged':True})
  finally:
   remove(AGENT);remove(PROXY)

def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(21600)
try:
 protocol=json.loads((P/'native-protocol.json').read_text());assert protocol['fresh_inference_started']is False
 for relative,digest in protocol['code_sha256'].items():assert sha((D/relative).read_bytes())==digest,relative
 for name,digest in protocol['library_sha256'].items():assert sha((Path('/compact-code')/name).read_bytes())==digest,name
 baseline={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};save(S/'runtime-before.json',baseline);assert all(v['running']for v in baseline.values())
 network_id=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME'])
 stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 launch=['--network',NET,'--gpus','all','--memory','40g','--cpus','8','--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=256m','--no-healthcheck',BACKEND,'-m','/models/Qwen3.8-27B-hermes-IQ3_XXS.gguf','--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size','98304','--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--n-predict','1024','-ngl','999','--threads','8','-b','512','-ub','128','--temp','0.8','--top-k','0','--top-p','1','--min-p','0','--repeat-penalty','1','--presence-penalty','0']
 t=time.monotonic();run(MAIN,launch);props=ready(MAIN,ALIAS,98304);save(S/'backend-launch.json',{'argv':launch,'seconds':time.monotonic()-t,'props':props});event('backend_ready')
 llmrecords=S/'llm-records';llmrecords.mkdir();os.chown(llmrecords,1000,1000)
 run(LLM,['--network',NET,'--network-alias','compact-llm','--user','1000:1000','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','1g',*mount('harness','/harness',True),*mount(str(llmrecords.relative_to(P)),'/records'),'-e','PILOT_LLM_BACKEND=http://'+MAIN+':11430','-e','PILOT_ALIAS='+ALIAS,'-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/harness/llm_proxy.py'])
 time.sleep(2)
 order=['docs','full']if FAMILY=='bounded_replies'else['full','docs']
 for arm in order:case(arm)
 save(S/'workflows-finished.json',{'family':FAMILY,'workflows':2,'turns':6,'not_whole_workflow_quality_verdict':True});event('stage_trials_finished')
except BaseException as error:save(S/'controller-error.json',{'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()});event('controller_error',error=str(error))
finally:
 signal.alarm(0);errors=[]
 for name in [AGENT,PROXY,LLM,MAIN]:
  try:remove(name)
  except Exception as e:errors.append(str(e))
 try:
  if stopped:
   docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304);docker('start','hermes')
  # Reconcile ambiguous issue-write responses only inside our disposable arenas.
  for arm,arena in arenas.items():
   issues=api('GET','repos/chatgpt-codex/'+arena['repo']+'/issues?state=open&limit=50')
   for issue in issues:
    if 'pull_request' not in issue and issue.get('user',{}).get('login')=='hermes-agent':
     api('PATCH','repos/chatgpt-codex/'+arena['repo']+'/issues/'+str(issue['number']),{'state':'closed'})
  after={n:state(n)for n in baseline}
  for n,b in baseline.items():
   assert all(after[n][k]==b[k]for k in ['id','image','signature','running'])
  assert after['hermes-codex']==baseline['hermes-codex']
  if network_id:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network_id and not net['Containers'];docker('network','rm',network_id)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors});event('original_runtime_restored')
 except BaseException as error:save(S/'RESTORATION-ERROR.json',{'error':str(error),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(error))
