"""Run only after family GPU stage restored. No result ever goes to models."""
from pathlib import Path
import sys,json,subprocess,hashlib
P=Path(__file__).resolve().parent;family=sys.argv[1];stage=P/'stages'/family
rest=stage/'runtime-restoration.json'
# Controller final record, not merely a stopped poll process.
assert rest.exists(), 'GPU stage has not recorded restoration'
assert json.loads(rest.read_text())['restored'] is True
print('restoration verified',flush=True)
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-compact-review-20261122/part3'
sys.path.insert(0,str(Path.cwd()/'hermes-profile/compact-review'))
from review_packet import source_digest
rows=[]
roots=[P/'baseline',P/('reference-'+family)]
roots += sorted(stage.glob('*/turn*/*grade/source'))
roots += sorted(stage.glob('*/proxy-records/reviews/*/source'))
for root in roots:
 files={str(f.relative_to(root)):f.read_bytes().decode() for f in root.rglob('*') if f.is_file() and not any(x in {'.git','__pycache__','.pytest_cache'} for x in f.relative_to(root).parts)}
 for probe in ['check_exact_fit_preservation.py','check_public_delivery.py']:
  rel=str(root.relative_to(P));cmd=['docker','run','--rm','--pull','never','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--memory','1g','--cpus','1','--mount',f'type=bind,src={ENGINE}/{rel},dst=/workspace,readonly','--mount',f'type=bind,src={ENGINE}/{probe},dst=/checks/{probe},readonly','--mount',f'type=bind,src={ENGINE}/immutable-fixtures,dst=/checks/immutable-fixtures,readonly','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/checks/'+probe,'/workspace']
  c=subprocess.run(cmd,text=True,capture_output=True,timeout=60)
  row={'source':rel,'source_digest':source_digest(files),'probe':probe,'probe_sha256':hashlib.sha256((P/probe).read_bytes()).hexdigest(),'returncode':c.returncode,'not_fed_to_models':True}
  if c.returncode==0:row['result']=json.loads(c.stdout)
  else:row.update(stdout=c.stdout,stderr=c.stderr)
  rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='result'}),flush=True)
(P/(family+'-supplemental-results.json')).write_text(json.dumps(rows,indent=2)+'\n')
