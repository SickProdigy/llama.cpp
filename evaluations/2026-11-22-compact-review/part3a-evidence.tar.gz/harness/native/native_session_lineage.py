"""Read-only proof of native oneshot compaction ancestry, never arbitrary SID drift."""
import sqlite3


def compression_lineage(database, ancestor, descendant):
    db = sqlite3.connect('file:' + str(database) + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    chain = []
    seen = set()
    try:
        current = descendant
        for _ in range(64):
            if current in seen:
                raise ValueError('Native session ancestry contains a cycle')
            seen.add(current)
            row = db.execute(
                'select id,parent_session_id,source,started_at,ended_at,end_reason '
                'from sessions where id=?', (current,)
            ).fetchone()
            if row is None:
                raise ValueError('Native session ancestry is missing a row')
            node = dict(row)
            if node['source'] != 'oneshot':
                raise ValueError('Unexpected native session source')
            chain.append(node)
            if current == ancestor:
                return list(reversed(chain))
            parent_id = node['parent_session_id']
            if not parent_id:
                raise ValueError('Session is not a descendant of the requested workflow')
            parent = db.execute(
                'select end_reason,started_at from sessions where id=?', (parent_id,)
            ).fetchone()
            if parent is None or parent['end_reason'] != 'compression':
                raise ValueError('Session transition is not a native compression rotation')
            if node['started_at'] < parent['started_at']:
                raise ValueError('Session ancestry timestamps are inconsistent')
            current = parent_id
        raise ValueError('Native session ancestry exceeds the audit depth limit')
    finally:
        db.close()
