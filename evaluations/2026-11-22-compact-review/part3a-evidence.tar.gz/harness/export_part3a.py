"""Allowlisted completed LocalAI evidence. Future XML tasks/checks stay private."""
from pathlib import Path
import json,hashlib,shutil,tarfile,sqlite3,ast,csv
R=Path.cwd();D=R/'.git/hermes-compact-review-20261122';P=D/'part3';S=P/'stages/bounded_replies';E=R/'evaluations/2026-11-22-compact-review';X=D/'part3a-export'
assert json.loads((S/'runtime-restoration.json').read_text())['restored']
assert json.loads((S/'workflows-finished.json').read_text())['turns']==6
assert not X.exists();X.mkdir()
def write(rel,obj):
 t=X/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(json.dumps(obj,indent=2)+'\n')
def copy(f,rel):
 t=X/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,t)
def tree(root,rel):
 for f in sorted(root.rglob('*')):
  if f.is_file()and not f.is_symlink()and not any(n in {'.git','__pycache__','.pytest_cache','AGENTS.md'}for n in f.relative_to(root).parts):copy(f,Path(rel)/f.relative_to(root))
# Original committed source is public project source, independent from owner edits.
tree(P/'baseline','baseline');copy(P/'reference-bounded_replies/localai/__init__.py','reference/localai/__init__.py')
copy(P/'immutable-fixtures/test_localai.py','checks/immutable-fixtures/test_localai.py')
source=(P/'private_checks.py').read_text();nodes=ast.parse(source).body
keep=[n for n in nodes if not(isinstance(n,ast.ClassDef)and n.name=='XML')and not isinstance(n,ast.If)]
derived='\n'.join(ast.get_source_segment(source,n)for n in keep)+'\nif __name__=="__main__":\n suite=unittest.defaultTestLoader.loadTestsFromTestCase(Bound)\n result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())\n'
t=X/'checks/primary_localai.py';t.write_text(derived)
write('controls/primary-extraction.json',{'original_private_file_sha256':hashlib.sha256(source.encode()).hexdigest(),'published_sha256':hashlib.sha256(derived.encode()).hexdigest(),'transform':'Remove future XML class and replace entrypoint with Bound-only; retained imports, argument parsing, load helper and exact Bound class source. No grader fed to either model.'})
for n in ['check_exact_fit_preservation.py','check_public_delivery.py']:copy(P/n,Path('checks')/n)
write('controls/tasks.json',{'bounded_replies':json.loads((P/'tasks.json').read_text())['bounded_replies']})
for n in ['native-protocol.json','supplemental-audit-registration.json','bounded_replies-supplemental-results.json','bounded_replies-session-audit.json','bounded_replies-receipt-audit.json','owner-preservation-limits.json','limits-preservation.json','limits-forge-readback.json','limits-initial-request-audit.json','full-initial-request-audit.json','bounded_replies-proposal-primary.json','bounded_replies-manual-audit.json']:
 copy(P/n,Path('controls')/n)
for n in ['part3_controller.py','capture_state.py','export_part3a.py']:copy(D/n,Path('harness')/n)
for n in ['audit_receipts.py','audit_sessions.py','run_supplemental.py','audit_test_relevance.py','verify_owner.py']:copy(P/n,Path('harness')/n)
for n in ['llm_proxy.py','native_session_lineage.py','scope_proxy.py']:copy(P/'harness'/n,Path('harness/native')/n)
protocol=json.loads((P/'native-protocol.json').read_text())
for n,h in protocol['library_sha256'].items():
 f=R/'hermes-profile/compact-review'/n;assert hashlib.sha256(f.read_bytes()).hexdigest()==h;copy(f,Path('harness/frozen-library')/n)
for n in ['events.jsonl','runtime-restoration.json','workflows-finished.json']:copy(S/n,Path('runtime')/n)
# Pinned launch args contain model identity and settings, but no user profile or credentials.
x=json.loads((S/'backend-launch.json').read_text());write('runtime/backend-launch.json',{'argv':x['argv'],'seconds':x['seconds'],'alias':x['props']['model_alias'],'context':x['props']['default_generation_settings']['n_ctx']})
copy(P/'adapter-preflight/result.json','controls/adapter-negative-control.json')
copy(D/'part3_adapter_preflight.py','harness/adapter-negative-control.py')
tree(P/'adapter-preflight/original-tests','adapter-negative-control/original-tests')
for r in (P/'adapter-preflight/records').iterdir():
 if not r.is_dir():continue
 tree(r/'source',Path('adapter-negative-control')/r.name/'source')
 for n in ['project.log','preservation.log']:copy(r/n,Path('adapter-negative-control')/r.name/n)
 for n in ['receipt.json','preservation-receipt.json']:write(Path('adapter-negative-control')/r.name/n.replace('.json','-payload.json'),json.loads((r/n).read_text())['payload'])
copy(P/'framework-validation.log','controls/framework-validation.log')
copy(P/'framework-validation.json','controls/framework-validation.json')
reviews=[];turns=[]
for arm in ['docs','full']:
 a=S/arm
 for n in ['issue-cleanup.json','case-finished.json']:copy(a/n,Path('runs')/arm/n)
 for turn in sorted(a.glob('turn*')):
  run=json.loads((turn/'run.json').read_text());turns.append({k:run[k]for k in ['family','arm','phase','elapsed_seconds','exit_code','external_timeout','query_sha256']});write(Path('runs')/arm/turn.name/'run.json',run)
  for n in ['native-admission-control.json']:
   if(turn/n).exists():copy(turn/n,Path('runs')/arm/turn.name/n)
  for kind in ['local-grade','remote-grade']:
   root=turn/kind
   assert(root/'grade.json').exists(),str(root)
   for n in ['grade.json','project.log','preservation.log','independent.log','project-receipt-payload.json','preservation-receipt-payload.json']:copy(root/n,Path('runs')/arm/turn.name/kind/n)
   tree(root/'source',Path('runs')/arm/turn.name/kind/'source')
  f=json.loads((turn/'forge-snapshot.json').read_text());pr=f.get('pr',{});issue=f.get('issue',{});head=pr.get('head',{});base=pr.get('base',{});repo=head.get('repo',{})
  write(Path('runs')/arm/turn.name/'publication.json',{'scope_state':f['scope_state'],'clone':f.get('clone'),'issue':{k:issue.get(k)for k in ['number','title','body','state']},'pr':{k:pr.get(k)for k in ['number','title','body','state','merged']},'head':{k:head.get(k)for k in ['ref','sha','repo_id']},'head_repo':{'full_name':repo.get('full_name'),'fork':repo.get('fork'),'parent':repo.get('parent',{}).get('full_name')},'base':{k:base.get(k)for k in ['ref','sha','repo_id']}})
  db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
  row=db.execute("select content from messages where role='assistant' and (tool_calls is null or tool_calls='[]') order by id desc limit 1").fetchone();db.close();write(Path('runs')/arm/turn.name/'model-final-claims.json',{'model_authored_claims_not_validation':row[0]if row else None})
 for r in sorted((a/'proxy-records/reviews').iterdir()):
  if not r.is_dir():continue
  rel=Path('reviews')/arm/r.name;tree(r/'source',rel/'source')
  for n in ['packet.json','input-metrics.json','project.log','preservation.log','admitted.json']:
   if(r/n).exists():copy(r/n,rel/n)
  for n in ['receipt.json','preservation-receipt.json']:
   if(r/n).exists():write(rel/(n.replace('.json','-payload.json')),json.loads((r/n).read_text())['payload'])
  for n in ['request.json','response.bin','capture.json','caller.json']:
   if(r/'http'/n).exists():copy(r/'http'/n,rel/'http'/n)
  if(r/'http/capture.json').exists():
   cap=json.loads((r/'http/capture.json').read_text());met=json.loads((r/'input-metrics.json').read_text());packet=json.loads((r/'packet.json').read_text());caller=json.loads((r/'http/caller.json').read_text());reviews.append({'arm':arm,'review_id':r.name,'phase':len(packet['tasks'])-1,'operation':packet['publication']['operation'],'packet_bytes':met['packet_bytes'],'rendered_input_tokens':met['rendered_tokens'],'output_tokens':(cap.get('usage')or{}).get('completion_tokens'),'seconds':cap.get('backend_http_seconds'),'caller_completed':caller['caller_completed'],'body_complete':cap['body_complete'],'finish_reason':cap.get('finish_reason'),'decision':(cap.get('parsed_review')or{}).get('decision'),'admitted':(r/'admitted.json').exists()})
# Only completed family's negative test controls; no future source/checker export.
relevance=json.loads((P/'relevance-index.json').read_text());selected={k:v for k,v in relevance.items()if k.startswith('stages/bounded_replies/')};write('controls/regression-relevance.json',selected)
for key in sorted({v['control_key']for v in selected.values()}):
 if(P/'relevance-controls'/key).exists():tree(P/'relevance-controls'/key,Path('regression-controls')/key)
tree(P/'proposal-primary-logs/bounded_replies','checks/proposal-primary-logs')
write('turns.json',turns);write('reviews.json',reviews)
for name,rows in [('part3a-turns.csv',turns),('part3a-reviews.csv',reviews)]:
 with(E/name).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Allowlisted completed LocalAI stage. No native system/memory/profile, auth/env, receipt keys/MACs, raw native requests, future XML tasks/reference/checker. Historic signatures checked privately; independent public verification can replay source/tests but cannot authenticate historic MACs.'})
copy(S/'llm-records/00001.metrics.json','runtime/first-native-API-metrics.json')
copy(P/'limits-owned-cleanup.json','controls/limits-owned-cleanup.json')
if(E/'part3a-runtime.json').exists():copy(E/'part3a-runtime.json','runtime/measured-runtime.json')
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()and f.name!='manifest.json'and'__pycache__'not in f.parts}
write('manifest.json',{'sha256':manifest,'scope':'Allowlisted completed LocalAI stage; source/test/capture replay, no private profiles/credentials/keys/MACs/raw native prompts or future XML checks.'})
archive=E/'part3a-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/'part3a-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'turns':len(turns),'review_calls':len(reviews)}))
