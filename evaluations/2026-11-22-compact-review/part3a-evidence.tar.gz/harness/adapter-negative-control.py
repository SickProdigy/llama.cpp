from pathlib import Path
import json,sys,subprocess,os
R=Path.cwd();D=R/'.git/hermes-compact-review-20261122';P=D/'part3';sys.path.insert(0,str(R/'hermes-profile/compact-review'))
from publication_gate import PublicationGate
from review_packet import source_digest,ReviewBlocked
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-compact-review-20261122/part3'
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
check=P/'adapter-preflight';check.mkdir(exist_ok=False);tests=check/'original-tests';tests.mkdir();test='from calc import add\ndef test_add(): assert add(2,3)==5\n';(tests/'test_calc.py').write_text(test)
phase=check/'phase.json';phase.write_text(json.dumps({'id':'negative-control','active':True,'tasks_so_far':['Preserve addition; include tests and accurate docs.']}))
g=PublicationGate(base={'calc.py':'def add(a,b): return a+b\n','tests/test_calc.py':test,'README.md':'Returns the sum.\n'},base_revision='a'*40,record_root=check/'records',engine_record_root=ENGINE+'/adapter-preflight/records',image=IMAGE,endpoint='http://unused/v1/chat/completions',alias='unused',phase_file=phase,documentation_paths=['README.md'],preservation_tests=ENGINE+'/adapter-preflight/original-tests',preservation_digest=source_digest({'test_calc.py':test}),class_declarations=True)
try:g.check('create_or_update_file',{'files':[{'path':'calc.py','content':'def add(a,b): return a-b\n'},{'path':'tests/test_calc.py','content':'from calc import add\ndef test_add(): assert add(2,3)==-1\n'}]})
except ReviewBlocked as e:reason=str(e)
else:raise AssertionError('Rewritten-test mutant admitted')
r=next((check/'records').glob('*/receipt.json'));project=json.loads(r.read_text());preservation=json.loads((r.parent/'preservation-receipt.json').read_text());assert project['payload']['returncode']==0 and preservation['payload']['returncode']!=0 and not list((check/'records').glob('*/http'))
result={'actual_project_suite_exit':0,'actual_immutable_suite_exit':preservation['payload']['returncode'],'critic_called':False,'publication_admitted':False,'reason':reason,'image':IMAGE};(check/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
rows=[]
for tree,family in [('baseline','bounded_replies'),('reference-bounded_replies','bounded_replies'),('baseline','wolfram_errors'),('reference-wolfram_errors','wolfram_errors')]:
 command=['docker','run','--rm','--pull','never','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--memory','1g','--cpus','1','--tmpfs','/tmp:rw,size=128m','--mount','type=bind,source='+ENGINE+'/'+tree+',target=/workspace,readonly','--mount','type=bind,source='+ENGINE+'/private_checks.py,target=/checks/private_checks.py,readonly','--mount','type=bind,source='+ENGINE+'/immutable-fixtures,target=/checks/immutable-fixtures,readonly','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','--entrypoint','python',IMAGE,'/checks/private_checks.py','/workspace',family,'0']
 r=subprocess.run(command,capture_output=True,text=True,timeout=90);(P/(tree+'-'+family+'-phase0.log')).write_text(r.stdout+r.stderr);expected=tree!='baseline';assert (r.returncode==0)==expected
 rows.append({'tree':tree,'family':family,'phase':0,'exit_code':r.returncode,'expected_pass':expected})
(P/'phase0-validation.json').write_text(json.dumps({'image':IMAGE,'results':rows,'all_expected':True,'not_fed_to_models':True},indent=2)+'\n');print(json.dumps(rows))
