Returns the sum.
