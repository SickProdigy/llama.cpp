"""Supplemental source-audit property: complete exact-cap answers stay complete.
Separate from frozen primary checks; no model feedback, no private oracle input.
"""
from pathlib import Path
import importlib.util,json,sys
root=Path(sys.argv[1]);fixture=Path('/checks/immutable-fixtures/test_localai.py')
spec=importlib.util.spec_from_file_location('immutable_exactfit_fixture',fixture);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.PLUGIN_PATH=root/'localai/__init__.py';mod,_=m.load_plugin_module()
rows=[]
for size in [200,201,800]:
 for count in [1,2,3]:
  for delta in [-1,0]:
   text='z'*(size*count+delta);chunks=mod._chunk_text(text,size,count)
   rows.append({'size':size,'max_chunks':count,'input_length':len(text),'complete_input_preserved':''.join(chunks)==text,'unexpected_marker':any('…'in x for x in chunks),'all_chunks_within_limit':all(len(x)<=size for x in chunks)})
print(json.dumps({'checks':rows,'all_complete_inputs_preserved':all(r['complete_input_preserved']for r in rows),'primary_frozen_grader':False,'basis':'Issued request to preserve normal complete answers; original exact-cap behavior.'}))
