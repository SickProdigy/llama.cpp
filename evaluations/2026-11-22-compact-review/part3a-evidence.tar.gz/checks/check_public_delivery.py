"""Supplemental end-to-end cap check from the issued 'every delivered reply' contract.
Posthoc source-audit probe, separate from the predeclared helper checks. Never feedback.
"""
from pathlib import Path
import importlib.util,json,sys
from unittest.mock import patch
root=Path(sys.argv[1]);fixture=Path('/checks/immutable-fixtures/test_localai.py')
spec=importlib.util.spec_from_file_location('immutable_localai_delivery_fixture',fixture);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.PLUGIN_PATH=root/'localai/__init__.py';mod,events=m.load_plugin_module()
p=mod.Plugin();p.settings=dict(p.settings);p.settings.update(model='test-model',allow_remote_requests=True,allowed_rooms='Books',reply_chunk_chars=200,max_reply_chunks=1)
sent=[];p.send_public=lambda room,text:sent.append((room,text));p.echo_message=lambda *a,**kw:None;p.output=lambda *a,**kw:None;p.log=lambda *a,**kw:None
class SynchronousThread:
 def __init__(self,target,args=(),**kwargs):self.target=target;self.args=args
 def start(self):self.target(*self.args)
with patch.object(mod.LocalAIClient,'chat',return_value='x'*300),patch.object(mod.threading,'Thread',SynchronousThread):
 p.incoming_public_chat_notification('Books','reader','!ai hi')
assert sent,'Remote opt-in public request did not deliver'
print(json.dumps({'configured_cap':200,'messages':len(sent),'delivered_lengths':[len(t)for _,t in sent],'all_deliveries_within_cap':all(len(t)<=200 for _,t in sent),'caller_prefix_present':sent[0][1].startswith('reader: '),'source_kind':'actual plugin handler, client reply mocked, main-thread fake Nicotine delivery','not_primary_frozen_grader':True}))
