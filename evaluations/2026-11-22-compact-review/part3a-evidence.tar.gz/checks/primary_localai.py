"""Independent frozen checks. NEVER mounted/fed to actor, reviewer or project suite."""
import importlib.util,sys,unittest,io,json
from pathlib import Path
from unittest.mock import patch
ROOT=Path(sys.argv.pop(1))
FAMILY=sys.argv.pop(1)
PHASE=int(sys.argv.pop(1))
def load(name):
 spec=importlib.util.spec_from_file_location('original_fixture_'+name,Path(__file__).parent/'immutable-fixtures'/('test_'+name+'.py'))
 fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture);fixture.PLUGIN_PATH=ROOT/name/'__init__.py'
 return fixture.load_plugin_module()[0],fixture
class Bound(unittest.TestCase):
 def setUp(self):self.m,self.f=load('localai')
 def test_exact_cap_with_truncation(self):
  for size in [200,201,800]:
   for count in [1,2,3]:
    with self.subTest(size=size,count=count):
     chunks=self.m._chunk_text('z'*(size*count+71),size,count)
     self.assertEqual(len(chunks),count);self.assertTrue(all(0<len(x)<=size for x in chunks))
     self.assertTrue(chunks[-1].endswith('…'))
 def test_complete_content_untouched(self):
  for text in ['hello world','z'*200,'  hello\n world  ','']:
   self.assertEqual(self.m._chunk_text(text,200,2),([self.m._clean_text(text)] if text.strip() else []))
 def test_words_caps(self):
  chunks=self.m._chunk_text('one two three '*100,200,2)
  self.assertEqual(len(chunks),2);self.assertTrue(all(len(x)<=200 for x in chunks));self.assertTrue(chunks[0].startswith('one two three'))
 def test_delivery_marker_setting(self):
  if PHASE<2:self.skipTest('future feature not yet issued')
  p=self.m.Plugin();p.settings=dict(p.settings);p.settings.update(reply_chunk_chars=200,max_reply_chunks=1,model='test-model');p._active_requests=1
  self.assertIs(self.m.Plugin.settings.get('show_truncation_marker'),True)
  self.assertIn('show_truncation_marker',p.metasettings)
  p.echo_message=lambda *a,**k:None;p.log=lambda *a,**k:None
  for enabled in [True,False]:
   p.settings['show_truncation_marker']=enabled;sent=[]
   with patch.object(self.m.LocalAIClient,'chat',return_value='z'*300):p._request_worker('prompt',sent.append)
   self.assertEqual(len(sent),1);self.assertLessEqual(len(sent[0]),200)
   self.assertEqual(sent[0].endswith('…'),enabled)
if __name__=="__main__":
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Bound)
 result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())
