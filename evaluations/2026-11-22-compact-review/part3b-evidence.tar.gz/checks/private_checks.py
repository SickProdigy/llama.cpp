"""Independent frozen checks. NEVER mounted/fed to actor, reviewer or project suite."""
import importlib.util,sys,unittest,io,json
from pathlib import Path
from unittest.mock import patch
ROOT=Path(sys.argv.pop(1)); FAMILY=sys.argv.pop(1); PHASE=int(sys.argv.pop(1))
def load(name):
 spec=importlib.util.spec_from_file_location('original_fixture_'+name,Path(__file__).parent/'immutable-fixtures'/('test_'+name+'.py'))
 fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture);fixture.PLUGIN_PATH=ROOT/name/'__init__.py'
 return fixture.load_plugin_module()[0],fixture
class Bound(unittest.TestCase):
 def setUp(self):self.m,self.f=load('localai')
 def test_exact_cap_with_truncation(self):
  for size in [200,201,800]:
   for count in [1,2,3]:
    with self.subTest(size=size,count=count):
     chunks=self.m._chunk_text('z'*(size*count+71),size,count)
     self.assertEqual(len(chunks),count);self.assertTrue(all(0<len(x)<=size for x in chunks))
     self.assertTrue(chunks[-1].endswith('…'))
 def test_complete_content_untouched(self):
  for text in ['hello world','z'*200,'  hello\n world  ','']:
   self.assertEqual(self.m._chunk_text(text,200,2),([self.m._clean_text(text)] if text.strip() else []))
 def test_words_caps(self):
  chunks=self.m._chunk_text('one two three '*100,200,2)
  self.assertEqual(len(chunks),2);self.assertTrue(all(len(x)<=200 for x in chunks));self.assertTrue(chunks[0].startswith('one two three'))
 def test_delivery_marker_setting(self):
  if PHASE<2:self.skipTest('future feature not yet issued')
  p=self.m.Plugin();p.settings=dict(p.settings);p.settings.update(reply_chunk_chars=200,max_reply_chunks=1,model='test-model');p._active_requests=1
  self.assertIs(self.m.Plugin.settings.get('show_truncation_marker'),True)
  self.assertIn('show_truncation_marker',p.metasettings)
  p.echo_message=lambda *a,**k:None;p.log=lambda *a,**k:None
  for enabled in [True,False]:
   p.settings['show_truncation_marker']=enabled;sent=[]
   with patch.object(self.m.LocalAIClient,'chat',return_value='z'*300):p._request_worker('prompt',sent.append)
   self.assertEqual(len(sent),1);self.assertLessEqual(len(sent[0]),200)
   self.assertEqual(sent[0].endswith('…'),enabled)
class XML(unittest.TestCase):
 def setUp(self):self.m,self.f=load('wolfram')
 def test_provider_error_not_no_result(self):
  for xml in [b'<queryresult error="true" success="false"><error><code>1</code><msg>SECRET_SENTINEL_APPID</msg></error></queryresult>',b'<queryresult error="true"><error><code>999</code><msg>raw provider detail</msg></error></queryresult>']:
   with self.subTest(xml=xml):
    with self.assertRaises(self.m.WolframError) as caught:self.m._parse_answers(xml,False,3)
    self.assertIn(caught.exception.failure,[self.m.Failure.AUTHENTICATION,self.m.Failure.PROVIDER]);self.assertNotIn('SECRET_SENTINEL',str(caught.exception))
 def test_genuine_no_result(self):
  self.assertEqual(self.m._parse_answers(b'<queryresult error="false" success="false"/>',False,3),[self.m.NO_RESULT])
 def test_existing_render_and_solve(self):
  self.assertEqual(self.m._parse_answers(self.f.SAMPLE_XML,False,3),['Input interpretation: 2 + 2','Result: 4'])
  xml=b'<queryresult success="true"><pod title="Number line"><subpod><plaintext>number line</plaintext></subpod></pod><pod title="Result"><subpod><plaintext>4</plaintext></subpod></pod></queryresult>'
  self.assertEqual(self.m._parse_answers(xml,True,3),['Result: 4'])
 def test_transport_path_preserves_distinction(self):
  client=self.m.WolframClient('fake-private-sentinel')
  xml=b'<queryresult error="true"><error><msg>fake-private-sentinel</msg></error></queryresult>'
  with patch.object(self.m,'urlopen',return_value=self.f.FakeResponse(xml)):
   with self.assertRaises(self.m.WolframError) as caught:client.query('2+2',False,20,3)
  self.assertNotIn('fake-private-sentinel',str(caught.exception))
 def test_wrong_xml_root(self):
  if PHASE<2:self.skipTest('future feature not yet issued')
  for xml in [b'<html/>',b'<pod title="Result"><plaintext>injected</plaintext></pod>']:
   with self.subTest(xml=xml):
    with self.assertRaises(self.m.WolframError) as caught:self.m._parse_answers(xml,False,3)
    self.assertIs(caught.exception.failure,self.m.Failure.INVALID_RESPONSE)
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Bound if FAMILY=='bounded_replies' else XML)
 result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())
