"""Pytest conftest: mock pynicotine modules for isolated plugin testing."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock

for module_name in ("pynicotine", "pynicotine.events", "pynicotine.pluginsystem"):
    if module_name not in sys.modules:
        sys.modules[module_name] = MagicMock()
