# Wolfram

Wolfram adds compact Wolfram|Alpha text answers to Nicotine+ room and private
chat. It adapts the existing Sick-Cogs integration to Nicotine+'s plugin API and
uses only Python's standard library.

## Setup

Create a Wolfram|Alpha AppID through the Wolfram developer portal and enter it
in the plugin's **App ID** setting. Never paste the AppID into chat, logs, issues,
or screenshots. Nicotine+ stores plugin settings in its configuration, so
protect that file appropriately.

## Commands

- `/wolfram <question>` asks a factual, mathematical, or scientific question.
- `/wa <question>` is an alias.
- `/wolframsolve <question>` requests step-by-step result pods.
- `/wasolve <question>` is an alias.

Examples:

```text
/wolfram 2+2
/wolfram population of Japan
/wolfram derivative of x^3
/wolframsolve x^2 - 5x + 6 = 0
```

The plugin requests Wolfram's Full Results XML endpoint with plaintext pods,
compacts whitespace, omits geo-IP-location answers, limits result sections, and
splits long answers into bounded Soulseek chat messages. Its optional source
link points to the public Wolfram input page and does not contain the AppID.

## Remote queries

Remote use is disabled by default. To enable it:

1. Add exact comma-separated Nicotine+ usernames to **Approved users**.
2. Optionally add a comma-separated room allowlist.
3. Enable **Allow remote queries**.

Approved users type `!wolfram <question>`. Room-triggered answers are returned
privately to avoid flooding the room. Per-user cooldowns and a global
concurrency cap protect the AppID quota.

## Errors and no-result behaviour

The plugin distinguishes two different situations that can otherwise look alike:

- **Provider failure.** When Wolfram|Alpha returns HTTP 200 but the XML
  `<queryresult>` carries `error="true"`, the query did not succeed. The plugin
  raises a provider failure and replies with the safe message
  *"Wolfram|Alpha is temporarily unavailable."* The provider's raw error text is
  never shown in chat, logs, or the exception, and the AppID is never exposed.
  This is distinct from a query that simply found nothing.
- **No-result answer.** When Wolfram|Alpha returns a valid response (no error
  flag) that contains no result pods, the plugin replies with the standard
  no-result sentence *"There is as yet insufficient data for a meaningful
  answer."* This is the expected outcome for questions Wolfram|Alpha cannot
  resolve, and it is not an error.

Other failure modes — authentication rejection, rate limiting, timeout, network
failure, malformed XML, and well-formed XML that is not a `<queryresult>`
document — each receive their own distinct safe message. The AppID is never
logged.

## Images

The first Nicotine+ version is text-only. Wolfram's Simple API places the AppID
in the image request URL, which must not be posted to chat, and Soulseek chat
does not provide Discord's safe file-attachment workflow. Image support would
need a separate authenticated proxy or local temporary-file transfer design.

## Install for local review

Copy the complete `wolfram` directory into the Nicotine+ user plugins directory,
restart Nicotine+, enable **Wolfram**, configure the AppID, and try `/wolfram
2+2`. No third-party Python packages are required.
