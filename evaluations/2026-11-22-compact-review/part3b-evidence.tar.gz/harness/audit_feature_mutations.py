"""Four posthoc API-preserving coverage mutants; never actor/reviewer feedback."""
from pathlib import Path
import ast,json,sys,hashlib,subprocess,difflib,os,re
P=Path(__file__).resolve().parent;assert json.loads((P/'stages/wolfram_errors/runtime-restoration.json').read_text())['restored'];sys.path.insert(0,str(Path.cwd()/'hermes-profile/compact-review'))
from review_packet import source_digest
from docker_execution import DockerExecution
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-compact-review-20261122/part3';rows=[]
def inv(root):return{str(f.relative_to(root)):f.read_bytes().decode()for f in root.rglob('*')if f.is_file()}
def span(raw,node):
 lines=raw.splitlines(keepends=True);return sum(map(len,lines[:node.lineno-1]))+node.col_offset,sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
for family,module in [('bounded_replies','localai'),('wolfram_errors','wolfram')]:
 for arm in ['docs','full']:
  origin=P/'stages'/family/arm/'turn2/remote-grade';grade=json.loads((origin/'grade.json').read_text());files=inv(origin/'source');assert source_digest(files)==grade['source_digest'];path=module+'/__init__.py';before=files[path];raw=before.encode();tree=ast.parse(before);replacements=[]
  if family=='bounded_replies':
   fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='_request_worker');call=next(n for n in ast.walk(fn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='_chunk_text')
   target=call.args[3]if len(call.args)>=4 else next(k.value for k in call.keywords if k.arg=='show_marker');a,b=span(raw,target);assert raw[a:b]!=b'True';replacements=[(a,b,b'True')];kind='force worker marker=True; helper/settings API retained'
  else:
   fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='_parse_answers');targets=[n for n in ast.walk(fn)if isinstance(n,ast.Attribute)and n.attr=='tag'and isinstance(n.value,ast.Name)and n.value.id=='root'];assert targets,'Manual mutation adaptation needed: no root.tag check'
   replacements=[(*span(raw,n),b"'queryresult'")for n in targets];kind='force observed root tag valid; provider fix and actual XML root data retained'
  for a,b,value in sorted(replacements,reverse=True):raw=raw[:a]+value+raw[b:]
  after=raw.decode();ast.parse(after);files[path]=after;label=arm+'-'+family;out=P/'feature-mutations'/label;source=out/'source';source.mkdir(parents=True,exist_ok=False)
  for n,t in files.items():f=source/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t.encode())
  diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path,tofile='b/'+path));(out/'mutation.diff').write_text(diff);digest=source_digest(files);env=IMAGE;results={}
  for suite in ['project','preservation']:
   run=DockerExecution(source,EP+'/'+str(source.relative_to(P)),IMAGE,suite_id=suite,preservation_tests=EP+'/baseline/tests'if suite=='preservation'else None,output_log=out/(suite+'.log'));r=run.run(expected_digest=digest,key=os.urandom(32));(out/(suite+'-receipt-payload.json')).write_text(json.dumps(r['payload'],indent=2)+'\n');results[suite]=r['payload']['returncode']
  cmd=['docker','run','--rm','--pull','never','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--memory','1g','--cpus','1','--mount',f'type=bind,src={EP}/{source.relative_to(P)},dst=/workspace,readonly','--mount',f'type=bind,src={EP}/private_checks.py,dst=/checks/private_checks.py,readonly','--mount',f'type=bind,src={EP}/immutable-fixtures,dst=/checks/immutable-fixtures,readonly','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/checks/private_checks.py','/workspace',family,'2'];c=subprocess.run(cmd,capture_output=True,text=True,timeout=100);(out/'independent.log').write_text(c.stdout+c.stderr)
  baseline_log=(origin/'independent.log').read_text();mutant_log=c.stdout+c.stderr;target='test_delivery_marker_setting'if family=='bounded_replies'else'test_wrong_xml_root';target_preexisting=('FAIL: '+target in baseline_log or 'ERROR: '+target in baseline_log);target_new_assertion_failure=('FAIL: '+target in mutant_log and not target_preexisting)
  row={'case':label,'family':family,'arm':arm,'original_source_digest':grade['source_digest'],'mutant_source_digest':digest,'mutation':kind,'expression_replacements':len(replacements),'project_exit':results['project'],'preservation_exit':results['preservation'],'independent_exit':c.returncode,'original_independent_exit':grade['independent_exit'],'target_check':target,'target_already_failing_in_original':target_preexisting,'target_new_assertion_failure_in_mutant':target_new_assertion_failure,'survives_model_tests_but_fails_independent_check':results['project']==0 and target_new_assertion_failure,'manual_failure_reason_audit_required':True,'mutant_was_published':False,'original_defects_are_reported_separately':True,'never_fed_to_models':True,'not_a_fresh_defect_detection_score':True};rows.append(row);(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
(P/'feature-mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n')
