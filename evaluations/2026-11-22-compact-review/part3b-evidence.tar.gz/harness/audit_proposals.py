"""After-stage frozen private primary check for each attempted publication source."""
from pathlib import Path
import json,subprocess,sys,hashlib
P=Path(__file__).resolve().parent;family=sys.argv[1];S=P/'stages'/family;assert json.loads((S/'runtime-restoration.json').read_text())['restored'];EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-compact-review-20261122/part3';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';rows=[]
sys.path.insert(0,str(Path.cwd()/'hermes-profile/compact-review'));from review_packet import source_digest
starts=[json.loads(x)for x in(S/'events.jsonl').read_text().splitlines()if json.loads(x)['kind']=='turn_start'];cache={}
for root in sorted(S.glob('*/proxy-records/reviews/*')):
 if not root.is_dir():continue
 arm=root.parents[2].name;packet=json.loads((root/'packet.json').read_text())if(root/'packet.json').exists()else None
 receipt=json.loads((root/'receipt.json').read_text())['payload'];phase=len(packet['tasks'])-1 if packet else max((x for x in starts if x['arm']==arm and x['epoch']<=receipt['started_ns']/1e9),key=lambda x:x['epoch'])['phase']
 source=root/'source';files={str(f.relative_to(source)):f.read_bytes().decode()for f in source.rglob('*')if f.is_file()};digest=source_digest(files);key=(digest,phase)
 if key not in cache:
  rel=str(source.relative_to(P));cmd=['docker','run','--rm','--pull','never','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--memory','1g','--cpus','1','--mount',f'type=bind,src={EP}/{rel},dst=/workspace,readonly','--mount',f'type=bind,src={EP}/private_checks.py,dst=/checks/private_checks.py,readonly','--mount',f'type=bind,src={EP}/immutable-fixtures,dst=/checks/immutable-fixtures,readonly','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python',IMAGE,'/checks/private_checks.py','/workspace',family,str(phase)]
  c=subprocess.run(cmd,text=True,capture_output=True,timeout=100);out=P/'proposal-primary-logs'/family/(digest+'-'+str(phase)+'.log');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(c.stdout+c.stderr);cache[key]={'independent_exit':c.returncode,'log':str(out.relative_to(P)),'log_sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
 rows.append({'arm':arm,'review_id':root.name,'phase':phase,'source_digest':digest,'admitted':(root/'admitted.json').exists(),'primary_not_fed_to_models':True,**cache[key]})
(P/(family+'-proposal-primary.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'proposals':len(rows),'unique_source_phase_checks':len(cache),'primary_failures':sum(r['independent_exit']!=0 for r in rows)}))
