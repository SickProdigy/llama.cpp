"""Sanitized actual-wire audit. No native system/memory text leaves private state."""
from pathlib import Path
import json,hashlib,sys
P=Path(__file__).resolve().parent;family=sys.argv[1];S=P/'stages'/family;tasks=json.loads((P/'tasks.json').read_text())[family];events=[json.loads(x)for x in(S/'events.jsonl').read_text().splitlines()];rows=[]
def strings(x):
 if isinstance(x,str):return[x]
 if isinstance(x,list):return sum((strings(v)for v in x),[])
 if isinstance(x,dict):return sum((strings(v)for v in x.values()),[])
 return[]
for arm in ['full','docs']:
 starts=[x['epoch']for x in events if x['kind']=='turn_start'and x['arm']==arm and x['phase']==0]
 if not starts:continue
 for m in sorted((S/'llm-records').glob('*.metrics.json')):
  met=json.loads(m.read_text())
  if met['received_epoch']<starts[0]:continue
  reqpath=m.with_name(m.name.replace('.metrics.json','.request.json'));raw=reqpath.read_bytes();req=json.loads(raw);body='\n'.join(strings(req['messages']))
  row={'arm':arm,'first_request':reqpath.name,'sha256':hashlib.sha256(raw).hexdigest(),'alias':req['model'],'output_cap':req['max_tokens'],'seed':req.get('seed','not supplied; backend default'),'messages':len(req['messages']),'current_frozen_query_present':tasks[0]in body,'future_frozen_queries_present':[q in body for q in tasks[1:]],'configured_arena_present':('hermes-compact-'+arm+'-20261122')in body,'private_grader_path_present':'private_checks.py'in body,'private_grader_sentinel_present':'SECRET_SENTINEL_APPID'in body,'private_reference_path_present':'reference-'+family in body,'raw_native_system_and_memory_not_exported':True}
  assert row['current_frozen_query_present']and not any(row['future_frozen_queries_present'])and not any(row[k]for k in ['private_grader_path_present','private_grader_sentinel_present','private_reference_path_present']);rows.append(row);break
(P/(family+'-first-requests-audit.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'arms_audited':len(rows),'rows':rows}))
