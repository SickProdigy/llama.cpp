from pathlib import Path
from ruamel.yaml import YAML
import json,hashlib
p=Path('/state/part3/arms');y=YAML();rows=[]
for f in p.glob('*/profile/config.yaml'):
 c=y.load(f.read_text());c['agent']['max_turns']=60;c['agent']['run_budget_seconds']=2400;c['agent']['gateway_timeout']=2800;y.dump(c,f.open('w'))
 rows.append({'profile':f.parent.parent.name,'budget':2400,'memory_write_approval':c['memory']['write_approval'],'skills_write_approval':c['skills']['write_approval'],'config_sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
Path('/state/part3/profile-budget-update.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
