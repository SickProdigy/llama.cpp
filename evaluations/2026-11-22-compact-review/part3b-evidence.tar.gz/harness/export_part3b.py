"""Allowlisted completed XML evidence. All frozen fresh cases have finished before unblinding."""
from pathlib import Path
import json,hashlib,shutil,tarfile,sqlite3,ast,csv
R=Path.cwd();D=R/'.git/hermes-compact-review-20261122';P=D/'part3';S=P/'stages/wolfram_errors';E=R/'evaluations/2026-11-22-compact-review';X=D/'part3b-export'
assert json.loads((S/'runtime-restoration.json').read_text())['restored']
assert json.loads((S/'workflows-finished.json').read_text())['turns']==6
assert json.loads((P/'stages/bounded_replies/workflows-finished.json').read_text())['turns']==6
assert not X.exists();X.mkdir()
def write(rel,obj):
 t=X/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(json.dumps(obj,indent=2)+'\n')
def copy(f,rel):
 t=X/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,t)
def tree(root,rel):
 for f in sorted(root.rglob('*')):
  if f.is_file()and not f.is_symlink()and not any(n in {'.git','__pycache__','.pytest_cache','AGENTS.md'}for n in f.relative_to(root).parts):copy(f,Path(rel)/f.relative_to(root))
# Original committed source and reference; all fresh inference is now complete.
tree(P/'baseline','baseline');copy(P/'reference-wolfram_errors/wolfram/__init__.py','reference/wolfram/__init__.py')
for name in ['test_localai.py','test_wolfram.py']:copy(P/'immutable-fixtures'/name,Path('checks/immutable-fixtures')/name)
copy(P/'private_checks.py','checks/private_checks.py')
write('controls/tasks.json',{'wolfram_errors':json.loads((P/'tasks.json').read_text())['wolfram_errors']})
for n in ['native-protocol.json','wolfram_errors-session-audit.json','wolfram_errors-receipt-audit.json','owner-preservation-xml.json','xml-preservation.json','xml-forge-readback.json','wolfram_errors-first-requests-audit.json','wolfram_errors-proposal-primary.json','wolfram_errors-manual-audit.json']:
 copy(P/n,Path('controls')/n)
for name in ['wolfram_errors-publication-drift-audit.json','actor-interface-source-audit.json','wolfram_errors-native-controls-audit.json','wolfram_errors-remote-git-audit.json','feature-mutation-registration.json','feature-mutation-results.json']:
 copy(P/name,Path('controls')/name)
tree(P/'feature-mutations','feature-mutations')
for plugin in ['gitea-focused','gitea-workspace','selected-project']:
 for name in ['__init__.py','plugin.yaml','README.md']:copy(P/'plugins'/plugin/name,Path('harness/actor-plugins')/plugin/name)
for name in ['prepare_profile.py','update_budgets.py','audit_publication_drift.py','audit_native_controls.py','audit_remote_git.py','audit_feature_mutations.py','audit_actor_interface.py']:copy(P/name,Path('harness')/name)
for n in ['part3_controller.py','capture_state.py','export_part3b.py']:copy(D/n,Path('harness')/n)
for n in ['audit_receipts.py','audit_sessions.py','audit_proposals.py','audit_first_requests.py','audit_test_relevance.py','verify_owner.py']:copy(P/n,Path('harness')/n)
for n in ['llm_proxy.py','native_session_lineage.py','scope_proxy.py']:copy(P/'harness'/n,Path('harness/native')/n)
protocol=json.loads((P/'native-protocol.json').read_text())
for n,h in protocol['library_sha256'].items():
 f=R/'hermes-profile/compact-review'/n;assert hashlib.sha256(f.read_bytes()).hexdigest()==h;copy(f,Path('harness/frozen-library')/n)
for n in ['events.jsonl','runtime-restoration.json','workflows-finished.json']:copy(S/n,Path('runtime')/n)
# Pinned launch args contain model identity and settings, but no user profile or credentials.
x=json.loads((S/'backend-launch.json').read_text());write('runtime/backend-launch.json',{'argv':x['argv'],'seconds':x['seconds'],'alias':x['props']['model_alias'],'context':x['props']['default_generation_settings']['n_ctx']})
copy(P/'adapter-preflight/result.json','controls/adapter-negative-control.json')
copy(D/'part3_adapter_preflight.py','harness/adapter-negative-control.py')
tree(P/'adapter-preflight/original-tests','adapter-negative-control/original-tests')
for r in (P/'adapter-preflight/records').iterdir():
 if not r.is_dir():continue
 tree(r/'source',Path('adapter-negative-control')/r.name/'source')
 for n in ['project.log','preservation.log']:copy(r/n,Path('adapter-negative-control')/r.name/n)
 for n in ['receipt.json','preservation-receipt.json']:write(Path('adapter-negative-control')/r.name/n.replace('.json','-payload.json'),json.loads((r/n).read_text())['payload'])
copy(P/'framework-validation.log','controls/framework-validation.log')
copy(P/'framework-validation.json','controls/framework-validation.json')
reviews=[];turns=[]
for arm in ['docs','full']:
 a=S/arm
 for n in ['issue-cleanup.json','case-finished.json']:copy(a/n,Path('runs')/arm/n)
 for turn in sorted(a.glob('turn*')):
  run=json.loads((turn/'run.json').read_text());turns.append({k:run[k]for k in ['family','arm','phase','elapsed_seconds','exit_code','external_timeout','query_sha256']});write(Path('runs')/arm/turn.name/'run.json',run)
  for n in ['native-admission-control.json']:
   if(turn/n).exists():copy(turn/n,Path('runs')/arm/turn.name/n)
  for kind in ['local-grade','remote-grade']:
   root=turn/kind
   assert(root/'grade.json').exists(),str(root)
   for n in ['grade.json','project.log','preservation.log','independent.log','project-receipt-payload.json','preservation-receipt-payload.json']:copy(root/n,Path('runs')/arm/turn.name/kind/n)
   tree(root/'source',Path('runs')/arm/turn.name/kind/'source')
  f=json.loads((turn/'forge-snapshot.json').read_text());pr=f.get('pr',{});issue=f.get('issue',{});head=pr.get('head',{});base=pr.get('base',{});repo=head.get('repo',{})
  write(Path('runs')/arm/turn.name/'publication.json',{'scope_state':f['scope_state'],'clone':f.get('clone'),'issue':{k:issue.get(k)for k in ['number','title','body','state']},'pr':{k:pr.get(k)for k in ['number','title','body','state','merged']},'head':{k:head.get(k)for k in ['ref','sha','repo_id']},'head_repo':{'full_name':repo.get('full_name'),'fork':repo.get('fork'),'parent':repo.get('parent',{}).get('full_name')},'base':{k:base.get(k)for k in ['ref','sha','repo_id']}})
  db=sqlite3.connect('file:'+str(turn/'state.db')+'?mode=ro&immutable=1',uri=True)
  row=db.execute("select content from messages where role='assistant' and (tool_calls is null or tool_calls='[]') order by id desc limit 1").fetchone();db.close();write(Path('runs')/arm/turn.name/'model-final-claims.json',{'model_authored_claims_not_validation':row[0]if row else None})
 for r in sorted((a/'proxy-records/reviews').iterdir()):
  if not r.is_dir():continue
  rel=Path('reviews')/arm/r.name;tree(r/'source',rel/'source')
  for n in ['packet.json','input-metrics.json','project.log','preservation.log','admitted.json']:
   if(r/n).exists():copy(r/n,rel/n)
  for n in ['receipt.json','preservation-receipt.json']:
   if(r/n).exists():write(rel/(n.replace('.json','-payload.json')),json.loads((r/n).read_text())['payload'])
  for n in ['request.json','response.bin','capture.json','caller.json']:
   if(r/'http'/n).exists():copy(r/'http'/n,rel/'http'/n)
  if(r/'http/capture.json').exists():
   cap=json.loads((r/'http/capture.json').read_text());met=json.loads((r/'input-metrics.json').read_text());packet=json.loads((r/'packet.json').read_text());caller=json.loads((r/'http/caller.json').read_text());reviews.append({'arm':arm,'review_id':r.name,'phase':len(packet['tasks'])-1,'operation':packet['publication']['operation'],'packet_bytes':met['packet_bytes'],'rendered_input_tokens':met['rendered_tokens'],'output_tokens':(cap.get('usage')or{}).get('completion_tokens'),'seconds':cap.get('backend_http_seconds'),'caller_completed':caller['caller_completed'],'body_complete':cap['body_complete'],'finish_reason':cap.get('finish_reason'),'decision':(cap.get('parsed_review')or{}).get('decision'),'admitted':(r/'admitted.json').exists()})
# Only completed family's negative test controls; no future source/checker export.
relevance=json.loads((P/'relevance-index.json').read_text());selected={k:v for k,v in relevance.items()if k.startswith('stages/wolfram_errors/')};write('controls/regression-relevance.json',selected)
for key in sorted({v['control_key']for v in selected.values()}):
 if(P/'relevance-controls'/key).exists():tree(P/'relevance-controls'/key,Path('regression-controls')/key)
tree(P/'proposal-primary-logs/wolfram_errors','checks/proposal-primary-logs')
write('turns.json',turns);write('reviews.json',reviews)
for name,rows in [('part3b-turns.csv',turns),('part3b-reviews.csv',reviews)]:
 with(E/name).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator="\n");w.writeheader();w.writerows(rows)
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Allowlisted completed XML stage. No native system/memory/profile, auth/env, receipt keys/MACs, raw native requests, native profile data and credentials. Historic signatures checked privately; independent public verification can replay source/tests but cannot authenticate historic MACs.'})
for f in sorted((S/'llm-records').glob('*.metrics.json')):
 raw=json.loads(f.read_text());safe={k:raw[k]for k in ['id','purpose','received_epoch','request_sha256','backend_start_epoch','end_epoch','usage','finish_reasons','response_parse_failed']if k in raw}
 if 'transport_error'in raw:safe['transport_error_type']=raw['transport_error'].split(':',1)[0]
 write(Path('runtime/native-metrics')/f.name,safe)
copy(S/'llm-records/00001.metrics.json','runtime/first-native-API-metrics.json')
copy(P/'xml-owned-cleanup.json','controls/xml-owned-cleanup.json')
if(E/'part3b-runtime.json').exists():copy(E/'part3b-runtime.json','runtime/measured-runtime.json')
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()and f.name!='manifest.json'and'__pycache__'not in f.parts}
write('manifest.json',{'sha256':manifest,'scope':'Allowlisted completed XML stage; source/test/capture replay, no private profiles/credentials/keys/MACs/raw native prompts or private actor context.'})
archive=E/'part3b-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/'part3b-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'turns':len(turns),'review_calls':len(reviews)}))
