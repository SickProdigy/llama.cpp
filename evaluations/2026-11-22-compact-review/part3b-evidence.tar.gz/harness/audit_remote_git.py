"""Independent exact-commit comparison; runs on existing trusted clone evidence."""
from pathlib import Path
import json,subprocess,sys
P=Path(__file__).resolve().parent;family=sys.argv[1];S=P/'stages'/family;rows=[]
for t in sorted(S.glob('*/turn*')):
 if not(t/'forge-snapshot.json').exists():continue
 f=json.loads((t/'forge-snapshot.json').read_text());pr=f.get('pr',{});cl=f.get('clone')
 if not cl:rows.append({'arm':t.parent.name,'phase':int(t.name[4:]),'actual_published_clone_missing':True});continue
 root=P/'worktrees'/cl['name'];git=lambda *a:subprocess.check_output(['git','-C',str(root),*a]).decode().strip();head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');arena=next(a for a in json.loads((P/'arenas.json').read_text())if a['arm']==t.parent.name);base_sha=pr['base']['sha']if pr else arena['base_revision'];raw=git('diff','--raw',base_sha,head);local=json.loads((t/'local-grade/grade.json').read_text());remote=json.loads((t/'remote-grade/grade.json').read_text());entries=raw.splitlines()
 row={'arm':t.parent.name,'phase':int(t.name[4:]),'head':head,'tree':tree,'upstream_pr_present':bool(pr),'head_matches_actual_pr':head==pr['head']['sha']==cl['head']if pr else None,'head_matches_authenticated_fork_clone_record':head==cl['head'],'tree_matches_record':tree==cl['tree'],'fork_parent_matches_upstream':pr['head']['repo']['fork']and pr['head']['repo']['parent']['full_name']==pr['base']['repo']['full_name']if pr else None,'personal_head_upstream_base':pr['head']['repo']['owner']['login']=='hermes-agent'and pr['base']['repo']['owner']['login']=='chatgpt-codex'if pr else None,'pr_unmerged':pr['merged']is False if pr else None,'audit_base_sha':base_sha,'raw_changed_modes':entries,'regular_text_modifications':all(x.startswith(':100644 100644 ')for x in entries),'local_remote_source_match':local['source_digest']==remote['source_digest'],'local_source_digest':local['source_digest'],'remote_source_digest':remote['source_digest'],'changed_paths':remote['changed_paths']}
 rows.append(row)
(P/(family+'-remote-git-audit.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'snapshots':len(rows),'local_remote_matches':sum(r.get('local_remote_source_match',False)for r in rows),'all_clones_present':all(not r.get('actual_published_clone_missing',False)for r in rows)}))
