"""Sanitize observed native file/command controls without exporting the transcript."""
from pathlib import Path
import sqlite3,json,sys,hashlib
P=Path(__file__).resolve().parent;family=sys.argv[1];tasks=json.loads((P/'tasks.json').read_text())[family];S=P/'stages'/family;rows=[]
for f in sorted(S.glob('*/turn*/run.json')):
 run=json.loads(f.read_text());phase=run['phase'];d=sqlite3.connect('file:'+str(f.parent/'state.db')+'?mode=ro&immutable=1',uri=True);start=d.execute("select max(id)from messages where role='user'and content=?",(tasks[phase],)).fetchone()[0];assert start
 controls=[];test_failures=[]
 for name,content in d.execute("select tool_name,content from messages where role='tool'and id>? order by id",(start,)):
  try:x=json.loads(content)
  except(ValueError,TypeError):continue
  if not isinstance(x,dict):continue
  if x.get('stale_write_blocked'):controls.append({'tool':name,'kind':'stale/full-read overwrite guard','path':x.get('path'),'error':x.get('error')})
  if x.get('status')=='blocked'and'Command flagged as dangerous'in str(x.get('error')):controls.append({'tool':name,'kind':'single-query command approval guard','error':x['error']})
  if x.get('no_change')is True:controls.append({'tool':name,'kind':'successful idempotent no-change','path':x.get('resolved_path'),'success':x.get('success')})
  out=x.get('output','')
  if isinstance(x.get('exit_code'),int)and x['exit_code']>0:
   test_failures.append({'tool':name,'exit_code':x['exit_code'],'output_sha256':hashlib.sha256(out.encode()).hexdigest(),'pynicotine_import_error':"No module named 'pynicotine'"in out,'conftest_in_output':'conftest'in out,'assertion_failure':'AssertionError'in out,'failure_reason_classification_required':True})
 rows.append({'arm':run['arm'],'phase':phase,'native_controls':controls,'nonzero_tool_executions':test_failures,'no_full_native_transcript_export':True});d.close()
(P/(family+'-native-controls-audit.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'turns':len(rows),'native_controls_observed':sum(len(x['native_controls'])for x in rows),'nonzero_tool_executions':sum(len(x['nonzero_tool_executions'])for x in rows)}))
