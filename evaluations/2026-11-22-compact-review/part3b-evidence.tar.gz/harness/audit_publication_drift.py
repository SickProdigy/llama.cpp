"""Compare immutable local/actual-remote snapshots; never feeds findings to actors."""
from pathlib import Path
import json,sys,hashlib
P=Path(__file__).resolve().parent;family=sys.argv[1];S=P/'stages'/family;rows=[]
def inv(root):return{str(f.relative_to(root)):f.read_bytes()for f in root.rglob('*')if f.is_file()}
sha=lambda b:hashlib.sha256(b).hexdigest()if b is not None else None
for arm in ['full','docs']:
 previous=None
 for t in sorted((S/arm).glob('turn*')):
  if not(t/'run.json').exists()or not(t/'local-grade/source').exists()or not(t/'remote-grade/source').exists():continue
  local=inv(t/'local-grade/source');remote=inv(t/'remote-grade/source');names=set(local)|set(remote);mismatch=[n for n in sorted(names)if local.get(n)!=remote.get(n)];overwrites=[]
  if previous:
   pl,pr=previous
   for n in sorted(set(pl)|set(pr)|names):
    if pl.get(n)!=pr.get(n)and local.get(n)==pl.get(n)and remote.get(n)==local.get(n)and remote.get(n)!=pr.get(n):overwrites.append({'path':n,'prior_local_sha256':sha(pl.get(n)),'prior_remote_sha256':sha(pr.get(n)),'new_local_sha256':sha(local.get(n)),'new_remote_sha256':sha(remote.get(n)),'remote_change_replaced_with_unchanged_local_content':True})
  rows.append({'arm':arm,'phase':int(t.name[4:]),'local_remote_different_paths':mismatch,'stale_local_overwrites_of_prior_remote_changes':overwrites,'semantic_impact_requires_manual_audit':True,'not_actor_feedback':True});previous=(local,remote)
(P/(family+'-publication-drift-audit.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'snapshots':len(rows),'stale_local_overwrites':sum(len(r['stale_local_overwrites_of_prior_remote_changes'])for r in rows)}))
