"""Operator-only development corpus; expected findings never enter packets."""
from pathlib import Path
import json,sys,hashlib,os,shutil,time,random,subprocess
R=Path.cwd();D=R/'.git/hermes-compact-review-20261122';O=R/'.git/hermes-everyday-pilot-20261122/export-stage-final'
sys.path.insert(0,str(R/'hermes-profile/compact-review'))
from review_packet import build_packet,source_digest,execution_summaries,ReviewBlocked
from docker_execution import DockerExecution
E=D/'part2';E.mkdir(exist_ok=True);ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-compact-review-20261122'
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
base={str(p.relative_to(O/'source-baseline')):p.read_bytes().decode() for p in (O/'source-baseline').rglob('*') if p.is_file()}
prompts=json.loads((O/'harness/task-prompts.json').read_text())
selected=[
 ('beets','plain-beetsbridge',0,'beetsbridge',['lifecycle reload can revive old waiter'],'revise'),
 ('relative','plain-arrrequests',0,'arrrequests',['relative same-origin redirect rejected'],'revise'),
 ('limitdocs','plain-arrrequests',1,'arrrequests',['50-hop urllib limit claim false','relative redirect claim false'],'revise'),
 ('https','review-arrrequests',1,'arrrequests',['HTTPS redirect missing initialization','certificate predicate documentation false'],'revise'),
 ('rooms','review-announcer',0,'announcer',[],'approve'),
 ('failed','review-arrrequests',2,'arrrequests',['project suite has a failing mock signature'],'execution_block')]
fixtures=[]
for label,run,phase,module,gold,expected in selected:
 root=O/'runs'/run/('turn'+str(phase))/'local-source'
 tree={str(p.relative_to(root)):p.read_bytes().decode() for p in root.rglob('*') if p.is_file()}
 fixtures.append({'private_label':label,'module':module,'base':base,'tree':tree,'tasks':prompts[module][:phase+1],
                  'gold':gold,'expected':expected,'provenance':str(root.relative_to(O)),
                  'caveat':'String GUI room inputs only; None robustness outside contract.' if label=='rooms' else ''})
# Two small clean controls, independent of the old references/graders.
fixtures.extend([
 {'private_label':'integer','module':'limits','base':{'limits.py':'def parse_limit(value):\n    return int(value)\n',
 'README.md':'parse_limit accepts an integer or decimal string, strips surrounding whitespace, rejects booleans and values outside1..100.\n',
 'test_limits.py':'import unittest\nfrom limits import parse_limit\nclass TestLimits(unittest.TestCase):\n def test_inputs(self):\n  self.assertEqual(parse_limit(" 12 "),12)\n  self.assertEqual(parse_limit(100),100)\n  for value in [True,False,0,101,"bad",1.5,None]:\n   with self.subTest(value=value), self.assertRaises(ValueError): parse_limit(value)\n'},
 'tree':None,'tasks':['Make parse_limit accept integers or decimal strings with surrounding whitespace, reject bool and other types, and enforce1..100. Preserve the documented interface and include tests.'],
 'gold':[],'expected':'approve','provenance':'new synthetic clean control','caveat':''},
 {'private_label':'names','module':'names','base':{'names.py':'def unique_names(values):\n    return sorted(set(values))\n',
 'README.md':'unique_names strips surrounding spaces, removes empty values and duplicate exact names while preserving first occurrence order and internal spaces. Input is a list of strings.\n',
 'test_names.py':'import unittest\nfrom names import unique_names\nclass TestNames(unittest.TestCase):\n def test_order_and_spaces(self):\n  self.assertEqual(unique_names([" B ","A","B","","Room  Two","Room Two"]),["B","A","Room  Two","Room Two"])\n def test_empty(self): self.assertEqual(unique_names([]),[])\n'},
 'tree':None,'tasks':['Fix unique_names to preserve first occurrence order and internal spaces, stripping only surrounding whitespace and dropping empty and duplicate exact names. Input is a list of strings. Include tests and keep docs accurate.'],
 'gold':[],'expected':'approve','provenance':'new synthetic clean control','caveat':''}])
fixtures[-2]['tree']={**fixtures[-2]['base'],'limits.py':'''def parse_limit(value):
    if type(value) not in (int, str):
        raise ValueError("expected integer or string")
    try:
        number = int(value)
    except (ValueError, TypeError) as error:
        raise ValueError("invalid limit") from error
    if not 1 <= number <= 100:
        raise ValueError("limit outside1..100")
    return number
'''}
fixtures[-1]['tree']={**fixtures[-1]['base'],'names.py':'''def unique_names(values):
    result = []
    seen = set()
    for value in values:
        name = value.strip()
        if name and name not in seen:
            seen.add(name)
            result.append(name)
    return result
'''}
# Test files above are part of the candidate; record them as additions rather than
# pretending their failing-regression content existed in the original base.
for f in fixtures[-2:]:
 for name in list(f['base']):
  if name.startswith('test_'): del f['base'][name]
rows=[]
for f in fixtures:
 case='case-'+hashlib.sha256(f['private_label'].encode()).hexdigest()[:10]
 root=E/'cases'/case/'source';assert not root.exists();root.mkdir(parents=True)
 for name,text in f['tree'].items():
  p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(text.encode())
 key=os.urandom(32);keypath=root.parent/'receipt-key';keypath.write_bytes(key);keypath.chmod(0o600)
 runner=DockerExecution(root,ENGINE+'/part2/cases/'+case+'/source',IMAGE)
 receipt=runner.run(expected_digest=source_digest(f['tree']),key=key)
 (root.parent/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 try:
  execution=execution_summaries([receipt],key=key,required_suites=['project'],candidate_digest=source_digest(f['tree']),environment_id=IMAGE)
  blocked=False
 except ReviewBlocked:
  blocked=True;execution=[receipt['payload']]
 assert blocked==(f['expected']=='execution_block'),(f['private_label'],receipt['payload']['output_tail'])
 changes={name:f['tree'].get(name) for name in sorted(set(f['base'])|set(f['tree'])) if f['base'].get(name)!=f['tree'].get(name)}
 docs=[name for name in f['tree'] if name=='README.md' or name==f['module']+'/README.md']
 # Whole-repository README is unrelated in real cases; select module docs only.
 if f['provenance']!='new synthetic clean control':docs=[f['module']+'/README.md']
 tests=[name for name in f['tree'] if name=='tests/test_'+f['module']+'.py' or name.startswith('test_')]
 revision='84afaf401b29753b6810e4f92f253e0d28637dbf'
 if f['provenance']=='new synthetic clean control':
  original=root.parent/'base-git';original.mkdir()
  for name,text in f['base'].items():(original/name).write_bytes(text.encode())
  subprocess.run(['git','init','-q',str(original)],check=True)
  subprocess.run(['git','-C',str(original),'add','.'],check=True)
  subprocess.run(['git','-C',str(original),'-c','user.name=Local Review Fixture','-c','user.email=evaluation@example.invalid','commit','-qm','Synthetic review baseline'],check=True)
  revision=subprocess.check_output(['git','-C',str(original),'rev-parse','HEAD'],text=True).strip()
 packet=build_packet(tasks=f['tasks'],base_revision=revision,base=f['base'],changes=changes,
                     context_paths=tests,documentation_paths=docs,execution=execution,
                     publication={'operation':'diagnostic_only','message':'Proposed code, tests and documentation'})
 (root.parent/'packet.json').write_text(json.dumps(packet,ensure_ascii=False,separators=(',',':')))
 rows.append({'case_id':case,'expected':f['expected'],'expected_findings':f['gold'],'contract_caveat':f['caveat'],
              'provenance':f['provenance'],'candidate_source_digest':packet['candidate_source_digest'],
              'packet_sha256':hashlib.sha256((root.parent/'packet.json').read_bytes()).hexdigest(),
              'packet_id':packet['packet_id'],'execution_blocked':blocked,'project_returncode':receipt['payload']['returncode']})
order=[r['case_id'] for r in rows if not r['execution_blocked']];random.Random(20261122).shuffle(order)
result={'created_epoch':time.time(),'development_only':True,'fresh_workflows':0,'cases':rows,'scored_order':order,'model_requests_per_profile':len(order)+1,'warm_repeat_case':order[0],'test_image':IMAGE,'caller_seconds':240,'socket_seconds':600,'output_cap':1024,'seed':20261122,'structured_output':True,'source_context':'Actual candidate only; no gold, reference, private grader, future task or private profile appears in packets.'}
(E/'corpus-private.json').write_text(json.dumps(result,indent=2)+'\n')
(E/'corpus-freeze.json').write_text(json.dumps({'epoch':time.time(),'corpus_sha256':hashlib.sha256((E/'corpus-private.json').read_bytes()).hexdigest(),'packet_sha256':{r['case_id']:r['packet_sha256'] for r in rows},'model_inference_started':False,'source_module_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'hermes-profile/compact-review').glob('*.py')}},indent=2)+'\n')
print(json.dumps({'cases':len(rows),'semantic_cases':len(order),'execution_failure_control':sum(r['execution_blocked'] for r in rows),'all_actual_project_runs_completed':True,'frozen_before_inference':True}))
