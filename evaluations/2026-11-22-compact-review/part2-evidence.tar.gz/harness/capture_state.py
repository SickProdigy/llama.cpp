from pathlib import Path
import json,subprocess,hashlib,urllib.request,sys,time
D=Path(__file__).resolve().parent
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
def capture():
 containers={}
 for name in ['hermes','llama-cpp','hermes-codex']:
  c=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
  signature=hashlib.sha256(json.dumps({k:c[k] for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()).hexdigest()
  containers[name]={'id':c['Id'],'image':c['Image'],'configuration_signature':signature,'running':c['State']['Running'],'started':c['State']['StartedAt'],'restarts':c['RestartCount'],'health':c['State'].get('Health',{}).get('Status')}
 code="from pathlib import Path;import json,hashlib;p=Path('/opt/data');print(json.dumps({n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['config.yaml','.env','auth.json','SOUL.md']}))"
 base=['docker','run','--rm','--pull','never','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL']
 profile=json.loads(subprocess.check_output([*base,'--volumes-from','hermes:ro','--entrypoint','python',IMAGE,'-c',code]))
 code="from pathlib import Path;import os,json;p=Path('/models');s=os.statvfs(p);print(json.dumps({'free_bytes':s.f_bavail*s.f_frsize,'files':[{'name':str(x.relative_to(p)),'bytes':x.stat().st_size,'mtime_ns':x.stat().st_mtime_ns} for x in sorted(p.rglob('*.gguf'))]}))"
 models=json.loads(subprocess.check_output([*base,'--volumes-from','llama-cpp:ro','--entrypoint','python',IMAGE,'-c',code]))
 props=json.load(urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=10))
 return {'epoch':time.time(),'containers':containers,'profile_hashes':profile,'models':models,'backend':{'alias':props['model_alias'],'context':props['default_generation_settings']['n_ctx']}}
if __name__=='__main__':
 name=sys.argv[1];assert name in ['part1-before','part1-after','part2-before','part2-after','part3-before','part3-after']
 x=capture();(D/(name+'.json')).write_text(json.dumps(x,indent=2)+'\n')
 print(json.dumps({'snapshot':name,'alias':x['backend']['alias'],'context':x['backend']['context'],'retained_models':len(x['models']['files']),'free_GiB':round(x['models']['free_bytes']/1024**3,2),'all_running':all(v['running'] for v in x['containers'].values())}))
