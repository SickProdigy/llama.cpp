"""New isolated compact-review calibration; diagnostic only, never publishes."""
import sys, os, json, time, hashlib, subprocess, urllib.request, signal, threading, traceback
from pathlib import Path
sys.path.insert(0, '/code')
from review_packet import encoded, sha, source_digest, execution_summaries, admission, ReviewBlocked
from review_transport import request_body, TimedReview, publication_review
from docker_execution import DockerExecution
D=Path('/state'); E=D/'part2'; A=E/'attempt2'; A.mkdir(exist_ok=False); OUT=A/'runs'; OUT.mkdir(exist_ok=True)
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp'
BACKEND='sha256:0eee1b477a28c1bd8806885d50447caa302eef5c977846f1177330def5fcd185'
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
MAIN='llama-compact-main'; HELPER='llama-compact-helper'
corpus=json.loads((E/'corpus-private.json').read_text()); freeze=json.loads((E/'corpus-freeze.json').read_text())
profiles={
 '27b':dict(file='Qwen3.8-27B-hermes-IQ3_XXS.gguf',alias='qwen3.8-27b-hermes-adapted-iq3xxs',ctx=98304,ngl=999,memory='40g',threads=8),
 '4b':dict(file='Qwopus3.5-4B-Coder-Fable5-v1-Q5_K_M.gguf',alias='qwopus35-4b-fable5-q5km-review',ctx=16384,ngl=999,memory='12g',threads=8),
 '4b-co':dict(file='Qwopus3.5-4B-Coder-Fable5-v1-Q5_K_M.gguf',alias='qwopus35-4b-fable5-q5km-review-partial',ctx=16384,ngl=12,memory='12g',threads=4)}
lock=threading.Lock(); sampling=True; owned={}; baseline={}; stopped=False

def save(path,x): Path(path).write_text(json.dumps(x,indent=2)+'\n')
def event(kind,**kw):
 x={'epoch':time.time(),'kind':kind,**kw}
 with lock:
  with (A/'events.jsonl').open('a') as f: f.write(json.dumps(x)+'\n')
 print(json.dumps(x),flush=True)
def cmd(*args,timeout=180,check=True):
 r=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and r.returncode: raise RuntimeError('Docker '+args[0]+': '+r.stderr[-2000:])
 return r.stdout

def inspect(name): return json.loads(cmd('inspect',name))[0]
def state(name):
 c=inspect(name)
 return {'id':c['Id'],'image':c['Image'],'signature':sha(encoded({k:c[k] for k in ['Image','Config','HostConfig','Mounts']})),
 'running':c['State']['Running'],'started':c['State']['StartedAt'],'restarts':c['RestartCount'],'health':c['State'].get('Health',{}).get('Status')}
def http(endpoint,path,body=None,timeout=30):
 data=None if body is None else encoded(body)
 req=urllib.request.Request(endpoint+path,data=data,headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=timeout))
def ready(endpoint,alias,ctx,seconds=300,name=None):
 t=time.monotonic()
 while time.monotonic()-t<seconds:
  if name and not inspect(name)['State']['Running']: raise RuntimeError('Server exited during startup: '+name)
  try:
   health=http(endpoint,'/health',timeout=3); p=http(endpoint,'/props',timeout=3)
   if health.get('status')=='ok' and p['model_alias']==alias and p['default_generation_settings']['n_ctx']==ctx:return p
  except (OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Readiness budget expired: '+alias)
def gpu():
 raw=''
 for name in [MAIN,HELPER,'llama-cpp']:
  r=subprocess.run(['docker','exec',name,'nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=15)
  if r.returncode==0:raw=r.stdout.strip();break
 try:
  used,free,util=[int(v.strip()) for v in raw.split(',')];return {'used_mib':used,'free_mib':free,'gpu_util_percent':util}
 except ValueError:return {'unknown':True}
def sampler():
 while sampling:
  try:
   x={'epoch':time.time(),**gpu()}
   with (A/'gpu.jsonl').open('a') as f:f.write(json.dumps(x)+'\n')
  except Exception as error:event('sample_error',error=str(error))
  time.sleep(5)
def remove(name):
 if name not in owned:return
 assert inspect(name)['Id']==owned[name], 'Refuse cleanup of replaced test container'
 c=subprocess.run(['docker','inspect',name],capture_output=True)
 if c.returncode==0:
  cmd('logs',name,check=False) # Save logs separately, never source/profile contents.
  (A/(name+'-'+str(time.time_ns())+'.log')).write_text(cmd('logs',name,check=False))
  # Docker logs uses stderr for llama; capture both streams explicitly.
  r=subprocess.run(['docker','logs',name],capture_output=True,text=True)
  (A/(name+'-last.log')).write_text(r.stdout+r.stderr)
  cmd('rm','-f',name);owned.pop(name,None)
def launch(label,name):
 p=profiles[label]; t=time.monotonic()
 args=['run','-d','--pull','never','--name',name,'--network','hermes-compact-review-net','--gpus','all','--memory',p['memory'],
 '--cpus',str(p['threads']),'--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=256m','--no-healthcheck',
 BACKEND,'-m','/models/'+p['file'],'--alias',p['alias'],'--jinja','--host','0.0.0.0','--port','11430',
 '--ctx-size',str(p['ctx']),'--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0',
 '--n-predict','1024','-ngl',str(p['ngl']),'--threads',str(p['threads']),'-b','512','-ub','128',
 '--temp','0.8','--top-k','0','--top-p','1','--min-p','0','--repeat-penalty','1','--presence-penalty','0']
 cid=cmd(*args).strip();owned[name]=cid;endpoint='http://'+name+':11430'
 props=ready(endpoint,p['alias'],p['ctx'],name=name)
 save(A/('launch-'+label+'.json'),{'label':label,'id':cid,'argv':['docker',*args], 'seconds':time.monotonic()-t,'gpu':gpu(),'props':props,'disk_cache':'warm OS file cache after full SHA reads; not cold disk'})
 event('ready',label=label,seconds=time.monotonic()-t,gpu=gpu());return endpoint

def preflight(endpoint,label):
 body={'model':profiles[label]['alias'],'messages':[{'role':'user','content':'Return the JSON object with ok true.'}],
 'max_tokens':32,'temperature':0,'chat_template_kwargs':{'enable_thinking':False},
 'response_format':{'type':'json_schema','json_schema':{'name':'preflight','strict':True,'schema':{
 'type':'object','properties':{'ok':{'type':'boolean','enum':[True]}},'required':['ok'],'additionalProperties':False}}}}
 result=http(endpoint,'/v1/chat/completions',body,timeout=180)
 save(A/('schema-preflight-'+label+'.json'),{'request':body,'response':result})
 assert json.loads(result['choices'][0]['message']['content'])=={'ok':True}
 assert result['choices'][0]['finish_reason']=='stop'
 event('schema_preflight_pass',label=label)

def one(endpoint,label,case_id,suffix=''):
 c=next(x for x in corpus['cases'] if x['case_id']==case_id); root=E/'cases'/case_id
 packet=json.loads((root/'packet.json').read_text());assert sha((root/'packet.json').read_bytes())==c['packet_sha256']
 executor=DockerExecution(root/'source',ENGINE+'/.git/hermes-compact-review-20261122/part2/cases/'+case_id+'/source',IMAGE)
 digest=source_digest(executor.inventory());assert digest==c['candidate_source_digest']
 receipt=json.loads((root/'receipt.json').read_text());key=(root/'receipt-key').read_bytes()
 execution_summaries([receipt],key=key,required_suites=['project'],candidate_digest=digest,environment_id=IMAGE)
 body=request_body(packet,profiles[label]['alias'])
 rendered=http(endpoint,'/apply-template',{'messages':body['messages'],'chat_template_kwargs':body['chat_template_kwargs']})
 tokens=http(endpoint,'/tokenize',{'content':rendered['prompt'],'add_special':False,'parse_special':True})['tokens']
 assert len(tokens)<=10000 and len(tokens)+1024<profiles[label]['ctx']
 path=OUT/label/(case_id+suffix);path.mkdir(parents=True,exist_ok=False)
 save(path/'input-metrics.json',{'packet_bytes':len(encoded(packet)),'rendered_tokens':len(tokens),'rendered_sha256':sha(rendered['prompt'].encode()),'gpu_before':gpu()})
 event('review_start',label=label,case_id=case_id,suffix=suffix,rendered_tokens=len(tokens))
 timed=TimedReview(endpoint+'/v1/chat/completions',body,path/'http').start();caller=timed.caller_result()
 event('caller_result',label=label,case_id=case_id,suffix=suffix,completed=caller['caller_completed'],seconds=caller['caller_seconds'])
 capture=timed.join_capture(620)
 admitted=False;reason=None
 try:
  review=publication_review(caller)
  admitted=admission(packet,review,receipts=[receipt],key=key,required_suites=['project'],current_digest=source_digest(executor.inventory()),environment_id=IMAGE)
 except ReviewBlocked as error:reason=str(error)
 save(path/'result.json',{'case_id':case_id,'profile':label,'warm_repeat':bool(suffix),'caller_completed':caller['caller_completed'],
 'caller_seconds':caller['caller_seconds'],'capture_seconds':capture['backend_http_seconds'],'admission_prerequisites_pass':admitted,
 'admission_reason':reason,'gpu_after':gpu(),'published':False})
 event('review_done',label=label,case_id=case_id,suffix=suffix,seconds=capture['backend_http_seconds'],finish=capture.get('finish_reason'),decision=(capture.get('parsed_review')or{}).get('decision'),admitted=admitted)

def cohort(endpoint,label):
 preflight(endpoint,label)
 for n,case_id in enumerate(corpus['scored_order']):
  one(endpoint,label,case_id)
  if n==0:one(endpoint,label,case_id,'-warm-repeat')

def cache_probe(endpoint,phase):
 # Synthetic non-agent cache-cost measurement, deliberately no tasks/grader/profile.
 prefix=('This is public synthetic cache-measurement text. Keep the coding context available.\n'*1200)
 body={'model':profiles['27b']['alias'],'messages':[{'role':'user','content':prefix+'\nReply with OK.'}],
 'max_tokens':1,'temperature':0,'stream':False,'cache_prompt':True,'chat_template_kwargs':{'enable_thinking':False}}
 result=http(endpoint,'/v1/chat/completions',body,timeout=600)
 save(A/('cache-probe-'+phase+'.json'),{'request_sha256':sha(encoded(body)),'response':result,'gpu':gpu()})
 event('cache_probe',phase=phase,usage=result.get('usage'),timings=result.get('timings'))

def stop_signal(signum,frame): raise TimeoutError('Stage guard/signal '+str(signum))
for sig in [signal.SIGALRM,signal.SIGTERM,signal.SIGINT]:signal.signal(sig,stop_signal)
signal.alarm(5400)
try:
 assert not (A/'inference-started.json').exists(),'Never rerun this controller/queue'
 assert sha((E/'corpus-private.json').read_bytes())==freeze['corpus_sha256']
 for name,digest in freeze['source_module_sha256'].items():assert sha((Path('/code')/name).read_bytes())==digest
 baseline={name:state(name) for name in ['hermes','llama-cpp','hermes-codex']};save(A/'controller-baseline.json',baseline)
 assert all(x['running'] for x in baseline.values())
 assert len(json.loads((D/'part2-before.json').read_text())['models']['files'])==29
 for name in [MAIN,HELPER]:
  assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0,'Test name already exists'
 for case in corpus['cases']:
  if case['execution_blocked']:
   root=E/'cases'/case['case_id'];receipt=json.loads((root/'receipt.json').read_text())
   try:execution_summaries([receipt],key=(root/'receipt-key').read_bytes(),required_suites=['project'],candidate_digest=case['candidate_source_digest'],environment_id=IMAGE)
   except ReviewBlocked as error:save(A/'execution-negative-control.json',{'blocked':True,'reason':str(error),'critic_called':False,'actual_returncode':receipt['payload']['returncode']})
   else:raise AssertionError('Failed suite allowed')
 save(A/'inference-started.json',{'epoch':time.time(),'protocol_sha256':sha((E/'protocol.json').read_bytes()),'controller_sha256':sha(Path(__file__).read_bytes())})
 stopped=True
 cmd('stop','-t','60','hermes');cmd('stop','-t','60','llama-cpp');event('originals_stopped_codex_untouched')
 threading.Thread(target=sampler,daemon=True).start()
 main=launch('27b',MAIN);cohort(main,'27b')
 cache_probe(main,'actor-cold');cache_probe(main,'actor-warm')
 one(main,'27b',corpus['scored_order'][-1],'-cache-interference')
 cache_probe(main,'actor-after-self-review')
 remove(MAIN)
 helper=launch('4b',HELPER);cohort(helper,'4b');remove(HELPER)
 main=launch('27b',MAIN);cache_probe(main,'actor-before-co-resident')
 helper=None
 try:
  helper=launch('4b-co',HELPER)
  headroom=gpu();save(A/'co-resident-headroom.json',headroom)
  if headroom.get('free_mib',0)<1024:raise RuntimeError('Predeclared 1024MiB GPU headroom not met')
  cohort(helper,'4b-co');cache_probe(main,'actor-after-co-resident')
 except Exception as error:
  event('co_resident_failure',error=type(error).__name__+': '+str(error));save(A/'co-resident-failure.json',{'error':str(error),'traceback':traceback.format_exc()})
 finally:remove(HELPER)
 event('measurement_complete')
except BaseException as error:
 save(A/'controller-error.json',{'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()});event('controller_error',error=str(error))
finally:
 sampling=False;signal.alarm(0)
 restore_errors=[]
 for name in [HELPER,MAIN]:
  try:remove(name)
  except Exception as error:restore_errors.append(str(error))
 try:
  if not stopped:raise RuntimeError('Preflight failed before runtime mutation; inspect originals without reload')
  cmd('start','llama-cpp');ready('http://llama-cpp:11430','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304,seconds=300,name='llama-cpp')
  cmd('start','hermes')
  after={name:state(name) for name in ['hermes','llama-cpp','hermes-codex']}
  for name,b in baseline.items():
   assert after[name]['id']==b['id'] and after[name]['image']==b['image'] and after[name]['signature']==b['signature'] and after[name]['running']
  assert after['hermes-codex']==baseline['hermes-codex']
  save(A/'controller-restoration.json',{'restored':True,'after':after,'cleanup_errors':restore_errors});event('original_runtime_restored')
 except BaseException as error:
  save(A/'RESTORATION-ERROR.json',{'error':str(error),'traceback':traceback.format_exc(),'cleanup_errors':restore_errors});event('restoration_error',error=str(error))
