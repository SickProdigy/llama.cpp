import http.server
import importlib.util
import io
import json
import sys
import threading
import types
import unittest
from pathlib import Path
from unittest.mock import patch


PLUGIN_PATH = Path(__file__).parents[1] / "arrrequests" / "__init__.py"


class FakeEvents:
    def __init__(self):
        self.invocations = []

    def invoke_main_thread(self, callback, *args):
        self.invocations.append((callback, args))
        callback(*args)


class FakeBasePlugin:
    core = types.SimpleNamespace(users=types.SimpleNamespace(login_username="owner"))

    def log(self, *_args):
        pass


def load_plugin_module():
    fake_events = FakeEvents()
    pynicotine = types.ModuleType("pynicotine")
    events_module = types.ModuleType("pynicotine.events")
    events_module.events = fake_events
    pluginsystem_module = types.ModuleType("pynicotine.pluginsystem")
    pluginsystem_module.BasePlugin = FakeBasePlugin
    module_name = "arrrequests_test_plugin"
    spec = importlib.util.spec_from_file_location(module_name, PLUGIN_PATH)
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {
        "pynicotine": pynicotine,
        "pynicotine.events": events_module,
        "pynicotine.pluginsystem": pluginsystem_module,
        module_name: module,
    }):
        spec.loader.exec_module(module)
    return module, fake_events


class FakeResponse:
    def __init__(self, payload):
        self._body = io.BytesIO(json.dumps(payload).encode("utf-8"))

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self, size=-1):
        return self._body.read(size)


class ArrRequestsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module, cls.events = load_plugin_module()

    def setUp(self):
        self.plugin = self.module.Plugin()
        self.plugin.settings = dict(self.module.Plugin.settings)
        self.plugin.core = types.SimpleNamespace(users=types.SimpleNamespace(login_username="owner"))
        self.plugin.sent = []
        self.plugin.echoes = []
        self.plugin.echo_message = self.plugin.echoes.append
        self.plugin.output = self.plugin.echoes.append
        self.plugin.send_public = lambda room, message: self.plugin.sent.append((room, message))
        self.plugin.send_private = lambda user, message, **_kwargs: self.plugin.sent.append((user, message))

    def test_service_routes_and_api_key_header(self):
        cases = {
            "tv": ("v3/series/lookup", [{"title": "Example Show", "year": 2020, "tvdbId": 12}]),
            "movie": ("v3/movie/lookup", [{"title": "Example Movie", "year": 2021, "tmdbId": 34}]),
            "music": ("v1/artist/lookup", [{"artistName": "Example Artist", "foreignArtistId": "mbid"}]),
        }
        for media_type, (route, payload) in cases.items():
            captured = {}

            def fake_urlopen(request, timeout, **kwargs):
                captured["request"] = request
                captured["timeout"] = timeout
                return FakeResponse(payload)

            client = self.module.ArrClient(media_type, "http://arr.local/", "secret")
            with patch.object(self.module, "_open_request", fake_urlopen):
                results = client.lookup("example title", 3, 9)
            self.assertIn(route, captured["request"].full_url)
            self.assertIn("term=example+title", captured["request"].full_url)
            self.assertEqual(captured["request"].headers["X-api-key"], "secret")
            self.assertEqual(captured["request"].get_method(), "GET")
            self.assertEqual(captured["timeout"], 9)
            self.assertEqual(len(results), 1)

    def test_status_uses_service_api_version(self):
        captured = []

        def fake_urlopen(request, timeout):
            captured.append(request.full_url)
            return FakeResponse({"appName": "Sonarr", "version": "4.0"})

        client = self.module.ArrClient("tv", "http://sonarr:8989", "key")
        with patch.object(self.module, "_open_request", fake_urlopen):
            self.assertEqual(client.status(10), "Sonarr 4.0")
        self.assertEqual(captured, ["http://sonarr:8989/api/v3/system/status"])

    def test_parse_request_accepts_only_supported_types(self):
        self.assertEqual(self.module._parse_request("movie Dune"), ("movie", "Dune"))
        self.assertEqual(self.module._parse_request("TV The Expanse"), ("tv", "The Expanse"))
        self.assertIsNone(self.module._parse_request("book Dune"))
        self.assertIsNone(self.module._parse_request("movie"))

    def test_remote_requests_require_enable_and_approval(self):
        self.assertIsNone(self.plugin._remote_request("friend", "!request movie Dune"))
        self.plugin.settings["allow_remote_requests"] = True
        self.plugin.settings["approved_users"] = "Friend, Trusted"
        self.assertIsNone(self.plugin._remote_request("stranger", "!request movie Dune"))
        with patch.object(self.module.time, "monotonic", return_value=100):
            self.assertEqual(
                self.plugin._remote_request("friend", "!REQUEST movie Dune"),
                ("movie", "Dune"),
            )

    def test_lookup_worker_is_read_only_and_returns_main_thread(self):
        class FakeClient:
            def lookup(self, query, limit, timeout):
                return [self_result]

        self_result = self.module.LookupResult("Dune", 2021, "tmdb:438631")
        self.plugin._client = lambda _media_type: FakeClient()
        self.plugin._active_requests = 1
        delivered = []
        invocation_count = len(self.events.invocations)
        self.plugin._lookup_worker("movie", "Dune", delivered.append)
        self.assertEqual(self.plugin._active_requests, 0)
        self.assertEqual(len(self.events.invocations), invocation_count + 1)
        self.assertEqual(delivered, [
            "movie: Dune (2021, tmdb:438631)",
            "Lookup only—nothing was added or downloaded.",
        ])

    def test_status_skips_unconfigured_services(self):
        self.plugin._active_requests = 1
        delivered = []
        self.plugin._status_worker(delivered.append)
        self.assertEqual(self.plugin._active_requests, 0)
        self.assertEqual(delivered, [
            "sonarr: not configured",
            "radarr: not configured",
            "lidarr: not configured",
        ])

    def test_invalid_url_and_missing_key_are_rejected(self):
        with self.assertRaises(self.module.ArrError):
            self.module.ArrClient("movie", "file:///tmp/radarr", "key")
        with self.assertRaises(self.module.ArrError):
            self.module.ArrClient("movie", "http://radarr:7878", "")


class RedirectBoundaryTests(unittest.TestCase):
    """Regression tests: API key must not be forwarded to a different origin via redirect."""

    @classmethod
    def setUpClass(cls):
        cls.module, cls.events = load_plugin_module()

    def _server(self, handler):
        """Start a threaded HTTP server on 127.0.0.1 and return its port."""
        server = http.server.HTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.shutdown)
        return server.server_address[1]

    def test_same_origin_redirect_is_followed_and_key_stays_in_origin(self):
        """A same-origin redirect must be followed and the key must remain within the origin."""
        seen_headers = []

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == "/api/v3/series/lookup":
                    seen_headers.append(dict(self.headers))
                    body = json.dumps([{"title": "Same Origin", "year": 2024, "tvdbId": 1}]).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(body)
                    return
                # Any other path: redirect to the lookup path (same origin)
                self.send_response(302)
                self.send_header("Location", "/api/v3/series/lookup")
                self.end_headers()

            def log_message(self, *_args):
                pass

        port = self._server(Handler)
        client = self.module.ArrClient("tv", f"http://127.0.0.1:{port}", "test-key-same-origin")
        results = client.lookup("test", 3, 5)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "Same Origin")
        # The key must have been sent to the same origin.
        received_key = seen_headers[-1].get("X-api-key") or seen_headers[-1].get("X-Api-Key")
        self.assertEqual(received_key, "test-key-same-origin")

    def test_cross_origin_redirect_is_blocked_and_key_not_leaked(self):
        """A redirect to a different origin must raise ArrError and must NOT forward the API key."""
        leaked = []

        class AttackerHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                leaked.append(dict(self.headers))
                body = b"{}"
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_args):
                pass

        class RedirectorHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(302)
                self.send_header("Location", f"http://127.0.0.1:{self.attacker_port}/steal")
                self.end_headers()

            def log_message(self, *_args):
                pass

        # Start attacker server first so we know its port.
        attacker_server = http.server.HTTPServer(("127.0.0.1", 0), AttackerHandler)
        attacker_thread = threading.Thread(target=attacker_server.serve_forever, daemon=True)
        attacker_thread.start()
        self.addCleanup(attacker_server.shutdown)
        attacker_port = attacker_server.server_address[1]

        # Patch the handler class to know the attacker port.
        RedirectorHandler.attacker_port = attacker_port

        redirector_server = http.server.HTTPServer(("127.0.0.1", 0), RedirectorHandler)
        redirector_thread = threading.Thread(target=redirector_server.serve_forever, daemon=True)
        redirector_thread.start()
        self.addCleanup(redirector_server.shutdown)
        redirector_port = redirector_server.server_address[1]

        client = self.module.ArrClient("tv", f"http://127.0.0.1:{redirector_port}", "test-key-should-not-leak")
        with self.assertRaises(self.module.ArrError) as ctx:
            client.lookup("test", 3, 5)
        self.assertIn("origin", str(ctx.exception).lower())
        # The attacker server must NOT have received the API key.
        for headers in leaked:
            self.assertNotEqual(headers.get("X-api-key"), "test-key-should-not-leak")
            self.assertNotIn("test-key-should-not-leak", str(headers))


class AllowRedirectsTests(unittest.TestCase):
    """Tests for the allow_redirects plugin setting."""

    @classmethod
    def setUpClass(cls):
        cls.module, cls.events = load_plugin_module()

    def _server(self, handler):
        """Start a threaded HTTP server on 127.0.0.1 and return its port."""
        server = http.server.HTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.shutdown)
        return server.server_address[1]

    def test_redirects_disabled_rejects_same_origin_redirect(self):
        """When allow_redirects is False, even a same-origin redirect must raise ArrError."""
        class RedirectHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(302)
                self.send_header("Location", "/api/v3/series/lookup")
                self.end_headers()

            def log_message(self, *_args):
                pass

        port = self._server(RedirectHandler)
        client = self.module.ArrClient(
            "tv", f"http://127.0.0.1:{port}", "test-key", allow_redirects=False
        )
        with self.assertRaises(self.module.ArrError) as ctx:
            client.lookup("test", 3, 5)
        self.assertIn("redirect", str(ctx.exception).lower())
        self.assertIn("disabled", str(ctx.exception).lower())

    def test_redirects_disabled_still_works_for_plain_get(self):
        """When allow_redirects is False, a non-redirected GET still succeeds."""
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                body = json.dumps([{"title": "Direct", "year": 2023, "tvdbId": 42}]).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_args):
                pass

        port = self._server(Handler)
        client = self.module.ArrClient(
            "tv", f"http://127.0.0.1:{port}", "test-key", allow_redirects=False
        )
        results = client.lookup("test", 3, 5)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "Direct")

    def test_redirects_enabled_follows_same_origin_by_default(self):
        """Default behavior (allow_redirects=True) follows same-origin redirects."""
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == "/api/v3/series/lookup":
                    body = json.dumps([{"title": "Redirected", "year": 2022, "tvdbId": 7}]).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(body)
                    return
                self.send_response(302)
                self.send_header("Location", "/api/v3/series/lookup")
                self.end_headers()

            def log_message(self, *_args):
                pass

        port = self._server(Handler)
        # No explicit allow_redirects — defaults to True.
        client = self.module.ArrClient("tv", f"http://127.0.0.1:{port}", "test-key")
        results = client.lookup("test", 3, 5)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "Redirected")

    def test_plugin_settings_include_allow_redirects(self):
        """The plugin settings dict must contain allow_redirects defaulting to True."""
        plugin = self.module.Plugin()
        self.assertIn("allow_redirects", plugin.settings)
        self.assertIs(plugin.settings["allow_redirects"], True)
        self.assertIn("allow_redirects", self.module.Plugin.metasettings)


if __name__ == "__main__":
    unittest.main()
