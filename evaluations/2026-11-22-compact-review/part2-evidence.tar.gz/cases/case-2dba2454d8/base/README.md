parse_limit accepts an integer or decimal string, strips surrounding whitespace, rejects booleans and values outside1..100.
