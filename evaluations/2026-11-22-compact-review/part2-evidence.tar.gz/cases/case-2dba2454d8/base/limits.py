def parse_limit(value):
    return int(value)
