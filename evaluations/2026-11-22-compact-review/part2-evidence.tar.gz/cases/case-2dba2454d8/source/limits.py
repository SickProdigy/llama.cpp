def parse_limit(value):
    if type(value) not in (int, str):
        raise ValueError("expected integer or string")
    try:
        number = int(value)
    except (ValueError, TypeError) as error:
        raise ValueError("invalid limit") from error
    if not 1 <= number <= 100:
        raise ValueError("limit outside1..100")
    return number
