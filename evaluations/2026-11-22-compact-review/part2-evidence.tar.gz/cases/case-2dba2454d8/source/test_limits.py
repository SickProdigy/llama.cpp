import unittest
from limits import parse_limit
class TestLimits(unittest.TestCase):
 def test_inputs(self):
  self.assertEqual(parse_limit(" 12 "),12)
  self.assertEqual(parse_limit(100),100)
  for value in [True,False,0,101,"bad",1.5,None]:
   with self.subTest(value=value), self.assertRaises(ValueError): parse_limit(value)
