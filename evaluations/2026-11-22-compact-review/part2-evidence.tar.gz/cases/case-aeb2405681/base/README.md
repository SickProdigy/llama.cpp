unique_names strips surrounding spaces, removes empty values and duplicate exact names while preserving first occurrence order and internal spaces. Input is a list of strings.
