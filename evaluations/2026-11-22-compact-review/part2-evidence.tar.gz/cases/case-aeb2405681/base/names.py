def unique_names(values):
    return sorted(set(values))
