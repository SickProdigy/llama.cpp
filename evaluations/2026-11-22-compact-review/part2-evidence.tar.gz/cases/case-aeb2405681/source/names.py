def unique_names(values):
    result = []
    seen = set()
    for value in values:
        name = value.strip()
        if name and name not in seen:
            seen.add(name)
            result.append(name)
    return result
