import unittest
from names import unique_names
class TestNames(unittest.TestCase):
 def test_order_and_spaces(self):
  self.assertEqual(unique_names([" B ","A","B","","Room  Two","Room Two"]),["B","A","Room  Two","Room Two"])
 def test_empty(self): self.assertEqual(unique_names([]),[])
