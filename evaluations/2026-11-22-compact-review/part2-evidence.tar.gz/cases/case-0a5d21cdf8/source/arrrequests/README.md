# Arr Requests

Arr Requests is a staged Nicotine+ request gateway for approved users. Version
0.1.0 is intentionally **lookup only**: it can verify connections and search
Sonarr, Radarr, and Lidarr catalogs, but it cannot add, monitor, search for, or
download any title.

## Current commands

- `/arrstatus` checks configured Arr connections without exposing API keys.
- `/arrlookup tv <query>` searches Sonarr.
- `/arrlookup movie <query>` searches Radarr.
- `/arrlookup music <query>` searches Lidarr artists.
- Approved users can type `!request tv|movie|music <query>` after remote requests
  are enabled. Results are returned privately, even if requested in a room.

Unapproved users receive no response. Approved-user matching is
case-insensitive, and each approved user has a configurable cooldown.

## API support

- Sonarr: `GET /api/v3/system/status` and `GET /api/v3/series/lookup`
- Radarr: `GET /api/v3/system/status` and `GET /api/v3/movie/lookup`
- Lidarr: `GET /api/v1/system/status` and `GET /api/v1/artist/lookup`

Authentication uses the standard `X-Api-Key` header. Keys are plugin settings
and are never included in chat messages, URLs, or logs. Nicotine+ stores plugin
settings in its configuration, so protect that file appropriately.

## Configuration

Set each application's base URL and API key. If Nicotine+ is containerized,
`127.0.0.1` refers to the Nicotine+ container. Prefer a shared internal Compose
network and service URLs such as `http://sonarr:8989`, `http://radarr:7878`, and
`http://lidarr:8686`. Avoid publishing Arr APIs directly to the internet.

Leave **Allow remote requests** disabled while testing `/arrstatus` and owner
lookups. Then populate **Approved users** with exact comma-separated Nicotine+
usernames before enabling remote lookups.

## Why adding requests is not implemented yet

A safe create-and-search workflow needs explicit decisions for every service:

- root folder;
- quality or metadata profile;
- language profile where applicable;
- tags identifying Nicotine+ requests;
- monitoring mode and season handling;
- minimum availability;
- whether to launch an automatic search immediately;
- duplicate/exclusion handling;
- request audit history and cancellation;
- per-user quotas and optional owner approval.

Hard-coding any of these can put titles in the wrong library, use an unwanted
profile, or launch downloads unexpectedly. The next stage should discover and
validate profiles/root folders, save a pending request record, notify the owner,
and require `/requestapprove <id>` before any Arr POST request. Automatic
approval can be considered later for selected users.

## Redirects and API-key safety

Every request carries the configured API key in the `X-Api-Key` header. To
prevent a malicious or misconfigured server from forwarding that key to an
unrelated host, the client uses a custom redirect handler
(`CredentialBoundaryRedirectHandler`) that only follows HTTP redirects when the
target URL has the **same scheme and network location** (host and port) as the
request that produced the redirect.

- **Same-origin redirects** (e.g. `http://sonarr:8989/api/v3/...` →
  `http://sonarr:8989/api/other`) are followed normally; the API key is sent
  on the redirected request as well.
- **Cross-origin redirects** (different scheme, host, or port) are **refused**.
  The lookup or status check fails with an `ArrError` whose message says the
  server was redirected to a different server and the request was not followed
  to protect the API key. The key is never sent to the cross-origin target.
- **Scheme changes** (e.g. `http://sonarr:8989` → `https://sonarr:8989`) count
  as cross-origin and are refused, even when host and port are identical.
- Redirect codes 301, 302, 303, 307, and 308 are all handled identically.
- A `3xx` response without a `Location` header is also refused.

### Limitations

- The boundary is per-request: the handler compares the redirect target to the
  URL in the `Request` object that received the redirect. It does not maintain
  a session-wide allow-list.
- The API key is sent on the initial request to the configured base URL. The
  redirect handler prevents the key from following to a different origin, but
  it does not prevent the configured Arr server itself from logging or
  exfiltrating the key through its own responses.
- The handler does not strip the `X-Api-Key` header from same-origin redirect
  targets. This is intentional: same-origin redirects are trusted to be part
  of the same service.
- Redirect chains are followed as long as each hop stays within the same
  origin. There is no explicit hop limit beyond what `urllib` enforces
  internally (50 hops by default).
- The API key is never included in URLs, chat messages, or log output. It
  appears only in HTTP request headers sent to the configured base URL (and,
  if followed, same-origin redirect targets).

## Ebooks

No ebook adapter is enabled. Readarr was the familiar Arr-style book manager,
but its official repository is archived. A later adapter should target whichever
maintained book service you choose and be reviewed against that service's actual
API rather than assuming Readarr remains suitable.

## Install for local review

Copy the complete `arrrequests` directory into the Nicotine+ user plugins
directory, restart Nicotine+, enable **Arr Requests**, add one service URL/key,
and run `/arrstatus`. No third-party Python packages are required.
