from pathlib import Path
import json,hashlib,shutil,tarfile
R=Path.cwd();D=R/'.git/hermes-compact-review-20261122';P=D/'part3';C=P/'context-diagnostic';S=C/'run';E=R/'evaluations/2026-11-22-compact-review';X=D/'part4-export'
assert json.loads((S/'runtime-restoration.json').read_text())['restored']
assert json.loads((S/'diagnostic-finished.json').read_text())['requested_variants']==4
assert not X.exists();X.mkdir()
def copy(src,rel):
 dst=X/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def write(rel,obj):
 dst=X/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(json.dumps(obj,indent=2)+'\n')
def tree(root,rel):
 for f in sorted(root.rglob('*')):
  if f.is_file()and not f.is_symlink()and not any(n in {'.git','__pycache__','.pytest_cache','AGENTS.md'}for n in f.relative_to(root).parts):copy(f,Path(rel)/f.relative_to(root))
for n in ['protocol.json','offline-sizing.json','manual-audit.json','preservation.json','cleanup.json','receipt-audit.json','independent-probes.json']:copy(C/n,Path('controls')/n)
for n in ['events.jsonl','runtime-before.json','runtime-restoration.json','backend-launch.json','diagnostic-finished.json']:copy(S/n,Path('runtime')/n)
tree(P/'baseline','baseline');copy(P/'owner-preservation-context-after.json','controls/owner-preservation.json')
copy(D/'context_diagnostic_controller.py','harness/controller.py');copy(D/'capture_state.py','harness/capture_state.py');copy(C/'audit_receipts.py','harness/audit_receipts.py');copy(D/'export_part4.py','harness/export.py')
for n,h in json.loads((P/'native-protocol.json').read_text())['library_sha256'].items():
 f=R/'hermes-profile/compact-review'/n;assert hashlib.sha256(f.read_bytes()).hexdigest()==h;copy(f,Path('harness/frozen-library')/n)
for case in sorted((S/'cases').iterdir()):
 tree(case/'source',Path('cases')/case.name/'source')
 for suite in ['project','preservation']:
  copy(case/(suite+'.log'),Path('cases')/case.name/(suite+'.log'));write(Path('cases')/case.name/(suite+'-receipt-payload.json'),json.loads((case/(suite+'-receipt.json')).read_text())['payload'])
 for variant in ['minimal','whole_changed_production_modules']:copy(case/(variant+'-packet.json'),Path('cases')/case.name/(variant+'-packet.json'))
rows=[]
for run in sorted((S/'runs').iterdir()):
 tree(run,Path('runs')/run.name)
 r=json.loads((run/'result.json').read_text());cap=json.loads((run/'http/capture.json').read_text());m=json.loads((run/'input-metrics.json').read_text());r.update(seconds=cap['backend_http_seconds'],packet_bytes=m['packet_bytes'],input_tokens=cap['usage']['prompt_tokens'],output_tokens=cap['usage']['completion_tokens'],review=cap['parsed_review']);rows.append(r)
write('results.json',rows)
for n in ['check_public_delivery.py','check_exact_fit_preservation.py']:copy(P/n,Path('checks')/n)
# The checks load immutable original fixture by its relative location.
tree(P/'immutable-fixtures','checks/immutable-fixtures')
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()}
write('manifest.json',{'sha256':manifest,'scope':'Four posthoc context requests, not fresh qualification. No native actor/profile prompts, credentials, issuer keys or historical MACs.'})
archive=E/'part4-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/'part4-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'requests':len(rows)}))
