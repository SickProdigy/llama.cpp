"""Four bounded posthoc context calls. No actors, private grader input or publication."""
from pathlib import Path
import os,sys,json,time,hashlib,subprocess,signal,traceback,urllib.request
D=Path('/state');P=D/'part3';C=P/'context-diagnostic';S=C/'run';S.mkdir(exist_ok=False)
sys.path.insert(0,'/compact-code')
from review_packet import encoded,source_digest,build_packet,packet_id,admission,ReviewBlocked
from docker_execution import DockerExecution
from publication_gate import measure_input
from review_transport import request_body,TimedReview,publication_review
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';BACKEND='sha256:0eee1b477a28c1bd8806885d50447caa302eef5c977846f1177330def5fcd185';ALIAS='qwen3.8-27b-hermes-adapted-iq3xxs'
ENGINE='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp';EP=ENGINE+'/.git/hermes-compact-review-20261122/part3';NET='hermes-compact-context-diagnostic';MAIN='compact-context-diagnostic-main';owned=None;network_id=None;stopped=False;before={}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def event(k,**kw):
 x={'epoch':time.time(),'kind':k,**kw}
 with(S/'events.jsonl').open('a')as f:f.write(json.dumps(x)+'\n')
 print(json.dumps(x),flush=True)
def docker(*a,check=True,timeout=180):
 r=subprocess.run(['docker',*a],capture_output=True,text=True,timeout=timeout)
 if check and r.returncode:raise RuntimeError('Docker '+a[0]+' failed: '+r.stderr[-1000:])
 return r.stdout

def inspect(n):return json.loads(docker('inspect',n))[0]
def state(n):
 c=inspect(n);return {'id':c['Id'],'image':c['Image'],'signature':hashlib.sha256(encoded({k:c[k]for k in ['Image','Config','HostConfig','Mounts']})).hexdigest(),'running':c['State']['Running'],'started':c['State']['StartedAt'],'restarts':c['RestartCount'],'health':c['State'].get('Health',{}).get('Status')}
def ready(n,alias):
 end=time.monotonic()+300
 while time.monotonic()<end:
  if not inspect(n)['State']['Running']:raise RuntimeError('Backend exited')
  try:
   with urllib.request.urlopen('http://'+n+':11430/props',timeout=10)as r:x=json.load(r)
   with urllib.request.urlopen('http://'+n+':11430/health',timeout=10)as r:h=json.load(r)
   if x['model_alias']==alias and x['default_generation_settings']['n_ctx']==98304 and h['status']=='ok':return x
  except(OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Readiness expired')
def inventory(root):return {str(f.relative_to(root)):f.read_bytes().decode()for f in root.rglob('*')if f.is_file()and not any(n in {'.git','__pycache__','.pytest_cache','AGENTS.md'}for n in f.relative_to(root).parts)}
def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in[signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(3600)
try:
 protocol=json.loads((C/'protocol.json').read_text());assert protocol['maximum_requests']==4
 assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==protocol['controller_sha256']
 freeze=json.loads((P/'native-protocol.json').read_text())
 for n,h in freeze['library_sha256'].items():assert hashlib.sha256((Path('/compact-code')/n).read_bytes()).hexdigest()==h,n
 for family in ['bounded_replies','wolfram_errors']:
  assert json.loads((P/'stages'/family/'workflows-finished.json').read_text())['turns']==6
  assert json.loads((P/'stages'/family/'runtime-restoration.json').read_text())['restored']is True
 before={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};assert all(x['running']for x in before.values());save(S/'runtime-before.json',before)
 base=inventory(P/'baseline');key=os.urandom(32);fd=os.open(S/'receipt-key',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb')as f:f.write(key)
 packets={};cases={x['id']:x for x in protocol['cases']}
 for cid,c in cases.items():
  record=P/c['source_record'];raw=(record/'packet.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==c['packet_sha256'];old=json.loads(raw);files=inventory(record/'source');digest=source_digest(files);assert digest==c['candidate_source_digest'];root=S/'cases'/cid;source=root/'source';source.mkdir(parents=True)
  for n,t in files.items():q=source/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(t.encode())
  env=IMAGE+'+original-tests:'+old['execution'][0]['environment_id'].split('+original-tests:',1)[1];receipts=[]
  for suite in ['project','preservation']:
   run=DockerExecution(source,EP+'/'+str(source.relative_to(P)),IMAGE,suite_id=suite,environment_id=env,preservation_tests=EP+'/baseline/tests'if suite=='preservation'else None,output_log=root/(suite+'.log'));r=run.run(expected_digest=digest,key=key);save(root/(suite+'-receipt.json'),r);assert r['payload']['returncode']==0 and not r['payload']['timed_out'];receipts.append(r)
  from review_packet import execution_summaries
  evidence=execution_summaries(receipts,key=key,required_suites=['project','preservation'],candidate_digest=digest,environment_id=env)
  changes={n:files.get(n)for n in set(base)|set(files)if base.get(n)!=files.get(n)}
  minimal=build_packet(tasks=old['tasks'],base_revision=old['base_revision'],base=base,changes=changes,context_paths=old['context'].keys(),documentation_paths=old['documentation_paths'],execution=evidence,publication=old['publication'],class_declarations=True)
  strip=lambda x:{k:v for k,v in x.items()if k not in ['execution','packet_id']}
  assert strip(minimal)==strip(old),'Minimal context differs beyond fresh receipts'
  full=json.loads(encoded(minimal));paths=[x['path']for x in full['patches']if x['path'].endswith('.py')and not any(y=='tests'or y.startswith('test_')for y in Path(x['path']).parts)]
  assert paths
  for n in paths:full['context'][n]={'sha256':hashlib.sha256(files[n].encode()).hexdigest(),'content':files[n]}
  full['related_code_context']=[x for x in full['related_code_context']if x['path']not in paths];full['context_policy']='Requested actual-tree files, generic local context, and complete actual changed production Python modules; not complete whole-program context';full['packet_id']=packet_id(full)
  for variant,packet in [('minimal',minimal),('whole_changed_production_modules',full)]:
   save(root/(variant+'-packet.json'),packet);packets[(cid,variant)]={'packet':packet,'receipts':receipts,'digest':digest,'environment':env,'bytes':len(encoded(packet)),'whole_module_paths':paths if variant!='minimal'else[]}
  event('source_execution_ready',case=cid)
 # No original runtime interruption until source/receipt/packet preflight succeeds.
 network_id=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME']);stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 launch=['--network',NET,'--gpus','all','--memory','40g','--cpus','8','--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=256m','--no-healthcheck',BACKEND,'-m','/models/Qwen3.8-27B-hermes-IQ3_XXS.gguf','--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size','98304','--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--n-predict','1024','-ngl','999','--threads','8','-b','512','-ub','128','--temp','0.8','--top-k','0','--top-p','1','--min-p','0','--repeat-penalty','1','--presence-penalty','0']
 assert subprocess.run(['docker','inspect',MAIN],capture_output=True).returncode!=0
 start=time.monotonic();owned=docker('run','-d','--pull','never','--name',MAIN,*launch).strip();props=ready(MAIN,ALIAS);save(S/'backend-launch.json',{'argv':launch,'seconds':time.monotonic()-start,'alias':props['model_alias'],'context':98304});event('backend_ready')
 endpoint='http://'+MAIN+':11430/v1/chat/completions'
 for index,item in enumerate(protocol['variant_order']):
  cid,variant=item.split('/');entry=packets[(cid,variant)];packet=entry['packet'];out=S/'runs'/str(index);out.mkdir(parents=True);save(out/'packet.json',packet)
  if entry['bytes']>32768:save(out/'result.json',{'case':cid,'variant':variant,'not_called':'Complete packet exceeds byte bound','packet_bytes':entry['bytes']});continue
  body=request_body(packet,ALIAS);metrics=measure_input(endpoint,body);metrics.update(packet_bytes=entry['bytes'],output_reserve=body['max_tokens']);save(out/'input-metrics.json',metrics)
  if metrics['rendered_tokens']>10000:save(out/'result.json',{'case':cid,'variant':variant,'not_called':'Rendered input exceeds bound'});continue
  event('review_start',case=cid,variant=variant);timed=TimedReview(endpoint,body,out/'http',caller_seconds=240).start();caller=timed.caller_result()
  if not timed.done.wait(650):raise TimeoutError('Existing capture did not finish; no replay')
  admitted=False;reason=None
  try:
   review=publication_review(caller);observed=(caller['capture'].get('usage')or{}).get('prompt_tokens')
   if not isinstance(observed,int)or observed>10000 or observed+body['max_tokens']>=98304:raise ReviewBlocked('Actual reviewer input usage exceeds/unverifies bound')
   admission(packet,review,receipts=entry['receipts'],key=key,required_suites=['project','preservation'],current_digest=entry['digest'],environment_id=entry['environment']);admitted=True
  except ReviewBlocked as e:reason=str(e)
  save(out/'result.json',{'case':cid,'variant':variant,'caller_completed':caller['caller_completed'],'would_admit':admitted,'reason':reason,'actual_publication':False,'not_a_fresh_qualification_score':True});event('review_end',case=cid,variant=variant,would_admit=admitted)
 save(S/'diagnostic-finished.json',{'maximum_requests':4,'requested_variants':4,'not_fresh_model_qualification':True,'actual_publication':False})
except BaseException as e:save(S/'controller-error.json',{'error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc()});event('controller_error',error=str(e))
finally:
 signal.alarm(0);errors=[]
 try:
  if owned:
   assert inspect(MAIN)['Id']==owned;logs=subprocess.run(['docker','logs',MAIN],capture_output=True);(S/'backend.log').write_bytes(logs.stdout+logs.stderr);docker('rm','-f',owned)
 except Exception as e:errors.append(str(e))
 try:
  if stopped:docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m');docker('start','hermes')
  after={n:state(n)for n in before}
  for n,b in before.items():assert all(after[n][k]==b[k]for k in ['id','image','signature','running'])
  if before:assert after['hermes-codex']==before['hermes-codex']
  if network_id:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network_id and not net['Containers'];docker('network','rm',network_id)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors});event('original_runtime_restored')
 except BaseException as e:save(S/'RESTORATION-ERROR.json',{'error':str(e),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(e))
