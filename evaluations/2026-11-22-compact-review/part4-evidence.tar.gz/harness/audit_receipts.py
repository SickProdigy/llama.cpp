from pathlib import Path
import json,sys,hashlib
sys.path.insert(0,'/compact-code')
from review_packet import execution_summaries,source_digest
c=Path('/state/part3/context-diagnostic');s=c/'run';key=(s/'receipt-key').read_bytes();checks=[]
for case in sorted((s/'cases').iterdir()):
 files={str(f.relative_to(case/'source')):f.read_bytes().decode()for f in(case/'source').rglob('*')if f.is_file()};digest=source_digest(files)
 receipts=[json.loads((case/(n+'-receipt.json')).read_text())for n in ['project','preservation']]
 execution_summaries(receipts,key=key,required_suites=['project','preservation'],candidate_digest=digest,environment_id=receipts[0]['payload']['environment_id'])
 for receipt in receipts:
  x=receipt['payload'];assert hashlib.sha256((case/(x['suite_id']+'.log')).read_bytes()).hexdigest()==x['output_sha256'];assert x['returncode']==0
 checks.append({'case':case.name,'source_digest':digest,'two_signatures_verified':True,'source_and_log_hashes_match':True})
r={'passed':True,'cases':checks,'private_key_and_MACs_not_exported':True};(c/'receipt-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
