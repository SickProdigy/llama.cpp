from pathlib import Path
import json,hashlib,shutil,tarfile
R=Path.cwd();D=R/'.git/hermes-wide-memory-20261123';S=D/'resource-v2-baseline';E=R/'evaluations/2026-11-23-wide-memory';X=D/'resource-baseline-v2-export'
assert json.loads((S/'runtime-restoration.json').read_text())['restored'];assert json.loads((S/'finished.json').read_text())['results'][0]['resource_probes_completed'];assert not X.exists();X.mkdir()
def copy(src,rel):
 f=X/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,f)
def write(rel,value):
 f=X/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(value,indent=2)+'\n')
for n in ['resource-protocol-v2.json','resource-controller-v2-registration.json','resource-v2-baseline-summary.json','resource-baseline-v2-preservation.json','resource-baseline-v2-cleanup.json']:copy(D/n,Path('controls')/n)
for n in ['resource_controller_v2.py','summarize_resource_v2.py','export_resource_baseline_v2.py']:copy(D/n,Path('source')/n)
for n in ['events.jsonl','runtime-before.json','model-identity.json','host-before.json','finished.json','runtime-restoration.json']:copy(S/n,Path('runtime')/n)
for n in ['launch.json','samples.jsonl','exit-state.json','backend.log','result.json','tool-check.json']:copy(S/'layout0'/n,Path('layout')/n)
r=json.loads((S/'layout0/ready.json').read_text());write('layout/ready.json',{'seconds':r['seconds'],'props':{k:r['props'][k]for k in ['model_alias','model_path','model_ftype','build_info','chat_template_caps','default_generation_settings']if k in r['props']}})
for probe in ['tool','prompt16000','prompt60000']:
 for f in sorted((S/'layout0'/probe).iterdir()):
  if f.is_file():copy(f,Path('probes')/probe/f.name)
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Completed matched IQ3 nonmapped resource-only pilot. Synthetic requests/measurements, no native actor profile, task/grader/reference or credential/key.'})
archive=E/'resource-baseline-v2-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/'resource-baseline-v2-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n');print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
