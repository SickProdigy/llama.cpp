from pathlib import Path
import json,hashlib,shutil,tarfile,re
R=Path.cwd();D=R/'.git/hermes-wide-memory-20261123';E=R/'evaluations/2026-11-23-wide-memory';X=D/'checkpoint-comparison-export';X.mkdir(exist_ok=False)
def cp(src,dst):
 p=X/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
def write(dst,x):
 p=X/dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
for name in ['cache_capacity_controller.py','summarize_cache_capacity.py','export_checkpoint_comparison.py','kernel_oom_diagnostic.py','recovery_admission_preflight.py']:
 cp(D/name,Path('source')/name)
for name in ['cache-capacity-protocol.json','cache-controller-registration.json','cache-input-identity.json','native-q4-kernel-oom.json','native-q4-interrupted-preservation.json','native-q4-interrupted-owner-preservation.json','recovery-admission-control.json']:
 cp(D/name,Path('controls')/name)
for arm in ['32','2']:
 S=D/('cache-capacity-'+arm);assert json.loads((S/'runtime-restoration.json').read_text())['restored'];summary=json.loads((D/('cache'+arm+'-summary.json')).read_text());write(arm+'/summary.json',summary)
 rawlog=(S/'layout0/backend.log').read_bytes();fragments=[]
 for line in rawlog.decode().splitlines():
  m=re.search(r'created context checkpoint \d+ of \d+ \(pos_min = -?\d+, pos_max = -?\d+, n_tokens = \d+, size = [0-9.]+ MiB\)',line)
  if m:fragments.append({'fragment':m.group(0),'original_line_sha256':hashlib.sha256(line.encode()).hexdigest()})
 assert len(fragments)==len(summary['checkpoint_events'])
 write(arm+'/checkpoint-trace.json',{'private_original_log_sha256':hashlib.sha256(rawlog).hexdigest(),'safe_numeric_fragments':fragments,'raw_log_excluded':True})
 for name in ['events.jsonl','model-identity.json','runtime-before.json','host-before.json','finished.json','runtime-restoration.json']:cp(S/name,Path(arm)/'runtime'/name)
 for name in ['launch.json','samples.jsonl','exit-state.json','result.json']:cp(S/'layout0'/name,Path(arm)/'layout'/name)
 ready=json.loads((S/'layout0/ready.json').read_text());write(arm+'/layout/ready.json',{'seconds':ready['seconds'],'props':{k:ready['props'][k]for k in ['model_alias','model_path','build_info','default_generation_settings']if k in ready['props']}})
 for row in summary['captures']:
  p=S/'layout0'/row['probe']
  for name in ['capture.json','input.json','response.bin']:cp(p/name,Path(arm)/'captures'/row['probe']/name)
 for name in ['preservation','owner-preservation','cleanup']:cp(D/('cache'+arm+'-'+name+'.json'),Path(arm)/'controls'/(name+'.json'))
write('privacy-boundary.json',{'excluded':['Raw private normal-policy request bodies','Raw verbose model logs','Native profiles/state databases','Owner ignored project instructions','Future tasks/private graders/reference fixes','Credentials and receipt keys'],'included':'Raw memory observations and complete one-token responses; input fingerprints/token counts and numeric checkpoint events. Original raw captures stay local. Offline verification does not recreate private input bodies or certify coding correctness.'})
manifest={str(p.relative_to(X)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(X.rglob('*'))if p.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Resource-only checkpoint comparison; no actor/MCP actions or model-quality result.'});archive=E/'checkpoint-comparison-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for p in sorted(X.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(X)),recursive=False)
(E/'checkpoint-comparison-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n');print({'files':len(manifest)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()})
