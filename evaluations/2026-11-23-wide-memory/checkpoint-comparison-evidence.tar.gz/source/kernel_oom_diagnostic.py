"""Read only kernel OOM entries in the interrupted model's bounded time window."""
from pathlib import Path
import ctypes as c,ctypes.util,json
lib=c.CDLL(ctypes.util.find_library('systemd'));ptr=c.c_void_p
spec={'sd_journal_open_directory':([c.POINTER(ptr),c.c_char_p,c.c_int],c.c_int),'sd_journal_add_match':([ptr,c.c_char_p,c.c_size_t],c.c_int),'sd_journal_seek_realtime_usec':([ptr,c.c_uint64],c.c_int),'sd_journal_next':([ptr],c.c_int),'sd_journal_get_realtime_usec':([ptr,c.POINTER(c.c_uint64)],c.c_int),'sd_journal_get_data':([ptr,c.c_char_p,c.POINTER(ptr),c.POINTER(c.c_size_t)],c.c_int),'sd_journal_close':([ptr],None)}
for n,(args,result)in spec.items():getattr(lib,n).argtypes=args;getattr(lib,n).restype=result
root=Path('/host-log/journal');rows=[];errors=[];begin=1795459790;end=1795460010
for directory in [root,*[p for p in root.iterdir()if p.is_dir()]]:
 if not list(directory.glob('*.journal')):continue
 journal=ptr();ret=lib.sd_journal_open_directory(c.byref(journal),str(directory).encode(),0)
 if ret<0:errors.append({'operation':'open','code':ret});continue
 try:
  match=b'_TRANSPORT=kernel';assert lib.sd_journal_add_match(journal,match,len(match))>=0;assert lib.sd_journal_seek_realtime_usec(journal,begin*1000000)>=0
  count=0
  while lib.sd_journal_next(journal)>0:
   count+=1;assert count<20000;when=c.c_uint64();assert lib.sd_journal_get_realtime_usec(journal,c.byref(when))>=0
   if when.value>end*1000000:break
   value=ptr();size=c.c_size_t();ret=lib.sd_journal_get_data(journal,b'MESSAGE',c.byref(value),c.byref(size))
   if ret<0:continue
   msg=c.string_at(value,size.value).decode(errors='replace').removeprefix('MESSAGE=')
   if any(w in msg.lower()for w in ['oom-kill','killed process','out of memory']) and ('llama' in msg.lower()or'docker' in msg.lower()):rows.append({'epoch':when.value/1000000,'kernel_message':msg})
 finally:lib.sd_journal_close(journal)
print(json.dumps({'window_epoch':[begin,end],'read_only':True,'kernel_oom_entries':rows,'errors':errors},indent=2))
