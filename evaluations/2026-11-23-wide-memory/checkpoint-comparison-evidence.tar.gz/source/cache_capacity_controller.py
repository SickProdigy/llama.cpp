"""Bounded isolated memory pilots; no actor, forge credentials or grading inputs."""
from pathlib import Path
import sys,os,json,time,hashlib,subprocess,urllib.request,threading,signal,traceback,re
D=Path('/state');KEY=sys.argv[1];assert KEY in ['32','2'];P=json.loads((D/'cache-capacity-protocol.json').read_text());S=D/('cache-capacity-'+KEY);S.mkdir(exist_ok=False)
MODEL=P['adapted_27B_Q4'];ALIAS='wide-checkpoint-capacity';NET='hermes-wide-cache';MAIN='hermes-wide-cache-model';BACKEND=P['backend_image'];owned=None;network=None;stopped=False;before={};monitor_stop=threading.Event();abort=threading.Event();thread=None

def save(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def event(kind,**kw):
 row={'epoch':time.time(),'kind':kind,**kw}
 with(S/'events.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
def docker(*args,check=True,timeout=180):
 z=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and z.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+z.stderr[-1200:])
 return z.stdout

def inspect(name):return json.loads(docker('inspect',name))[0]
def state(name):
 x=inspect(name);return {'id':x['Id'],'image':x['Image'],'config_sha256':hashlib.sha256(json.dumps({k:x[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()).hexdigest(),'running':x['State']['Running'],'started':x['State']['StartedAt'],'restarts':x['RestartCount']}
def http(host,path,body=None,timeout=60):
 req=urllib.request.Request('http://'+host+':11430'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=timeout)as response:raw=response.read()
 return json.loads(raw),raw

def ready(name,alias,ctx,timeout):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  if abort.is_set():raise RuntimeError('Pilot memory guard')
  if not inspect(name)['State']['Running']:raise RuntimeError('Backend exited before ready')
  try:
   props,_=http(name,'/props',timeout=10);health,_=http(name,'/health',timeout=10)
   if props['model_alias']==alias and props['default_generation_settings']['n_ctx']==ctx and health['status']=='ok':return props
  except(OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Backend readiness expired')

def host_memory():
 mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());return {'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
def monitor(out):
 paths=['/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.peak','/sys/fs/cgroup/memory.swap.current','/sys/fs/cgroup/memory.events','/sys/fs/cgroup/memory.stat','/proc/1/status','/proc/1/smaps_rollup']
 command='for p in "$@"; do printf "FILE %s\\n" "$p"; cat "$p"; done'
 while not monitor_stop.is_set():
  row={'epoch':time.time(),'host':host_memory()}
  try:
   row['backend_memory_raw']=docker('exec',MAIN,'/bin/sh','-c',command,'_',*paths,check=False,timeout=20)
   row['gpu_csv']=docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.total,memory.used,memory.free,utilization.gpu,utilization.memory','--format=csv,noheader,nounits',check=False,timeout=20).strip()
   match=re.search(r'^Pss:\s*(\d+) kB',row['backend_memory_raw'],re.M)
   pss=int(match.group(1))*1024 if match else None
   row['process_pss_bytes']=pss
   extra=docker('exec',os.environ['HOSTNAME'],'/bin/sh','-c',command,'_',*paths,check=False,timeout=20);row['supervisor_memory_raw']=extra
   cg=lambda raw: int(re.search(r'FILE /sys/fs/cgroup/memory.current\n(\d+)',raw).group(1))
   row['aggregate_cgroup_current_bytes']=cg(row['backend_memory_raw'])+cg(extra)
   other=re.search(r'^Pss:\s*(\d+) kB',extra,re.M);row['aggregate_process_pss_bytes']=(pss or 0)+(int(other.group(1))*1024 if other else 0)
   row['model_disk_free_bytes']=__import__('shutil').disk_usage('/models').free
   if row['aggregate_cgroup_current_bytes']>8*1024**3 or row['aggregate_process_pss_bytes']>8*1024**3 or row['model_disk_free_bytes']<100*1024**3 or row['host']['MemAvailable']<P['host_low_available_abort_bytes']:
    abort.set();row['host_memory_guard_triggered']=row['host']['MemAvailable']<P['host_low_available_abort_bytes'];row['resident_budget_guard_triggered']=row['aggregate_process_pss_bytes']>8*1024**3;row['disk_guard_triggered']=row['model_disk_free_bytes']<100*1024**3;row['cgroup_guard_triggered']=row['aggregate_cgroup_current_bytes']>8*1024**3
    if owned and inspect(MAIN)['Id']==owned:docker('stop','-t','10',owned,check=False)
  except Exception as e:row['measurement_error']=type(e).__name__+': '+str(e)
  with out.open('a')as f:f.write(json.dumps(row)+'\n')
  monitor_stop.wait(5)

def measure(body):
 prompt,_=http(MAIN,'/apply-template',{'messages':body['messages'],'tools':body.get('tools',[]),'chat_template_kwargs':body['chat_template_kwargs']});tokens,_=http(MAIN,'/tokenize',{'content':prompt['prompt'],'add_special':False,'parse_special':True});return len(tokens['tokens'])
def request(messages):return {'model':ALIAS,'messages':messages,'temperature':0.8,'top_p':1,'top_k':0,'min_p':0,'repeat_penalty':1,'presence_penalty':0,'seed':20261123,'chat_template_kwargs':{'enable_thinking':False},'max_tokens':512,'stream':False}
def call(out,body,kind):
 out.mkdir();save(out/'request.json',body);count=measure(body);save(out/'input.json',{'rendered_tokens':count,'context':layout['context'],'kind':kind});assert count+body['max_tokens']<layout['context'];event('probe_start',probe=kind,input_tokens=count)
 start=time.monotonic();result,raw=http(MAIN,'/v1/chat/completions',body,P['per_probe_deadline_seconds']);elapsed=time.monotonic()-start;(out/'response.bin').write_bytes(raw);usage=result.get('usage',{});assert isinstance(usage.get('prompt_tokens'),int);assert usage['prompt_tokens']==count,(count,usage);assert result.get('choices')
 save(out/'capture.json',{'body_complete':True,'seconds':elapsed,'usage':usage,'finish_reason':result['choices'][0].get('finish_reason'),'response_sha256':hashlib.sha256(raw).hexdigest(),'timings':result.get('timings')});event('probe_end',probe=kind,seconds=elapsed);return result

def stop_model():
 global owned,thread
 monitor_stop.set()
 if thread:thread.join(45);assert not thread.is_alive();thread=None
 if owned:
  assert inspect(MAIN)['Id']==owned;x=inspect(MAIN);save(current/'exit-state.json',{'container_id':x['Id'],'state':x['State'],'running':x['State']['Running'],'exit_code':x['State']['ExitCode'],'oom_killed':x['State']['OOMKilled'],'memory_limit':x['HostConfig']['Memory'],'memory_swap_limit':x['HostConfig']['MemorySwap']});z=subprocess.run(['docker','logs',owned],capture_output=True);(current/'backend.log').write_bytes(z.stdout+z.stderr);docker('rm','-f','-v',owned);owned=None

def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(P['per_model_stage_guard_seconds'])
try:
 registration=json.loads((D/'cache-controller-registration.json').read_text());assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==registration['controller_sha256'];assert hashlib.sha256((D/'cache-capacity-protocol.json').read_bytes()).hexdigest()==registration['protocol_sha256']
 before={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};assert all(x['running']for x in before.values());save(S/'runtime-before.json',before);save(S/'host-before.json',host_memory());model=Path('/models')/MODEL['file'];assert model.is_file()
 h=hashlib.sha256()
 with model.open('rb')as f:
  for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
 assert h.hexdigest()==MODEL['sha256'];save(S/'model-identity.json',{'file':model.name,'bytes':model.stat().st_size,'sha256':h.hexdigest(),'after_hash_specific_file_DONTNEED_advice':True})
 with model.open('rb')as f:os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 assert __import__('shutil').disk_usage('/models').free>=100*1024**3
 assert subprocess.run(['docker','inspect',MAIN],capture_output=True).returncode!=0
 network=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME']);stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 results=[]
 for index,layout in enumerate(MODEL['layouts']):
  current=S/('layout'+str(index));current.mkdir();abort.clear();monitor_stop.clear();passed=False
  try:
   launch=['--network',NET,'--gpus','all','--memory','6656m','--memory-swap','6656m','--cpus','8','--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=128m','--no-healthcheck',BACKEND,'-m','/models/'+MODEL['file'],'--load-mode',P['load_mode'],'--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(layout['context']),'--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--cache-ram','512','--ctx-checkpoints',KEY,'--log-verbosity','5','--fit','off','-ngl',str(layout['gpu_layers']),'--threads','8','--threads-batch','8','--poll','0','--poll-batch','0','-b','512','-ub','128','--n-predict','512'];start=time.monotonic();owned=docker('run','-d','--pull','never','--name',MAIN,'--label','hermes.wide.study=20261123',*launch).strip();save(current/'launch.json',{'argv':launch,'layout':layout,'container_id':owned});thread=threading.Thread(target=monitor,args=(current/'samples.jsonl',),daemon=True);thread.start();props=ready(MAIN,ALIAS,layout['context'],P['load_deadline_seconds']);save(current/'ready.json',{'seconds':time.monotonic()-start,'props':props});event('backend_ready',layout=layout)
   captures=[]
   for number,entry in enumerate(P['source_requests'],1):
    raw=(D/entry['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['sha256'];body=json.loads(raw);body['model']=ALIAS;body['max_tokens']=1;body.pop('max_completion_tokens',None);body['stream']=False;body.pop('stream_options',None);body['seed']=20261123
    out=current/('replay'+str(number).zfill(2));result=call(out,body,'captured_native_prefix_'+str(number));captures.append({'index':number,'usage':result.get('usage'),'not_task_completion_score':True})
    # Measurements remain live across all requests, including end-of-request checkpoints.
    time.sleep(1)
   passed=True;results.append({'layout':layout,'context_checkpoints':int(KEY),'resource_prefix_replays_completed':len(captures),'captures':captures,'no_actor_or_forge_actions':True,'no_quality_score':True});save(current/'result.json',results[-1])
  except Exception as e:
   result={'layout':layout,'resource_probes_completed':False,'error':type(e).__name__+': '+str(e),'no_model_quality_score':True};results.append(result);save(current/'result.json',result);event('layout_error',error=str(e))
  finally:stop_model()
  if passed:break
 save(S/'finished.json',{'results':results,'model':KEY,'not_agent_qualification':True})
except BaseException as e:save(S/'controller-error.json',{'error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc()});event('controller_error',error=str(e))
finally:
 signal.alarm(0);errors=[]
 try:
  if owned:stop_model()
 except BaseException as e:errors.append(str(e))
 try:
  if stopped:abort.clear();docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304,600);docker('start','hermes')
  after={n:state(n)for n in before}
  for n,b in before.items():assert all(after[n][k]==b[k]for k in ['id','image','config_sha256','running'])
  if before:assert after['hermes-codex']==before['hermes-codex']
  if network:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network and not net['Containers'];docker('network','rm',network)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors,'host_after':host_memory()});event('original_runtime_restored')
 except BaseException as e:save(S/'RESTORATION-ERROR.json',{'error':str(e),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(e))
