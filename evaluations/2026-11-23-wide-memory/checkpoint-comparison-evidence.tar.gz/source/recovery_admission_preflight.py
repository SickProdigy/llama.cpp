"""No-inference native admission test on a scratch copy of interrupted history."""
from pathlib import Path
import os,sys,shutil,sqlite3,hashlib,subprocess,json,stat,socket
home=Path('/tmp/recovery-admission-home');sockets=[]
def ignore_special(directory,names):
 excluded=[]
 for name in names:
  p=Path(directory)/name;mode=p.lstat().st_mode
  if stat.S_ISSOCK(mode):excluded.append(name);sockets.append((p.relative_to('/input-profile'),stat.S_IMODE(mode)))
  elif not(stat.S_ISREG(mode)or stat.S_ISDIR(mode)or stat.S_ISLNK(mode)):raise RuntimeError('Unexpected special file in profile copy')
 return excluded
shutil.copytree('/input-profile',home,ignore=ignore_special)
for relative,mode in sockets:
 p=home/relative;p.parent.mkdir(parents=True,exist_ok=True);sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.bind(str(p));sock.close();p.chmod(mode)
os.environ['HERMES_HOME']=str(home);os.environ['HOME']=str(home)
def inspect_history():
 db=sqlite3.connect(home/'state.db')
 try:
  rows=db.execute('select * from messages order by id').fetchall();users=db.execute("select session_id,content from messages where role='user'").fetchall();return hashlib.sha256(repr(rows).encode()).hexdigest(),users,len(rows)
 finally:db.close()
before,users,count=inspect_history();matches={sid for sid,text in users if hashlib.sha256(text.encode()).hexdigest()==os.environ['PILOT_QUERY_SHA256']};assert len(matches)==1;sid=next(iter(matches));z=subprocess.run(['/opt/hermes/bin/hermes','sessions','discard',sid,'--yes'],capture_output=True,text=True,timeout=90);assert z.returncode==0,z.stderr[-700:];after,_,after_count=inspect_history();assert before==after and count==after_count
print(json.dumps({'passed':True,'model_calls':0,'actual_native_command':'hermes sessions discard SID --yes','original_coding_session_found':True,'conversation_unchanged':True,'message_count':count,'message_rows_sha256_before':before,'message_rows_sha256_after':after,'session_id_sha256':hashlib.sha256(sid.encode()).hexdigest(),'force_unlock':False,'task_replayed':False,'original_profile_modified':False,'stale_socket_files_recreated_in_scratch':len(sockets),'scope':'Only a scratch copy was changed. No model inference or forge action.'}))
