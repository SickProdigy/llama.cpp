"""Posthoc captured feature source: reply preservation and owned room-map cleanup."""
from pathlib import Path
import importlib.util,json,pytest,hashlib
spec=importlib.util.spec_from_file_location('immutable_announcer','/fixtures/test_announcer.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);f.PLUGIN_PATH=Path('/workspace/announcer/__init__.py');results={}
def state(p):return {'pending':len(p._scheduled),'reply_entries':len(p._job_replies),'room_entries':len(p._scheduled_rooms),'finished_replies':sum(v[1]=='Announcement job finished.'for v in p.local_public)}
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');assert p.announce_command('Selective',room='Lobby');before=state(p);assert p.announce_cancel_command(' bOoKs ');after_cancel=state(p)
 for ident,delay,callback,args,repeat in m._fake_events.scheduled:
  if ident not in m._fake_events.cancelled:callback(*args)
 assert [r for r,_ in p.public_sent]==['Linux'];results['scoped_cancel_surviving_callback']={'before':before,'after_cancel':after_cancel,'after_survivor':state(p),'sent':p.public_sent}
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');assert p.announce_command('Normal',room='Lobby')
 for event in m._fake_events.scheduled:event[2](*event[3])
 results['normal_complete']=state(p);p.shutdown_notification();results['after_shutdown_of_completed_job']=state(p)
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');assert p.announce_command('Cancel all',room='Lobby');assert p.announce_cancel_command('');results['empty_argument_cancel_all']=state(p);p.shutdown_notification();results['shutdown_after_cancel_all']=state(p)
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');assert p.announce_command('Toggle',room='Lobby');first,second=m._fake_events.scheduled;p.settings['sending_enabled']=False;first[2](*first[3]);p.settings['sending_enabled']=True;second[2](*second[3]);assert [r for r,_ in p.public_sent]==['Books'];results['off_then_on_between_callbacks']={'state':state(p),'sent':p.public_sent}
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books')
 for i in range(4):
  start=len(m._fake_events.scheduled);assert p.announce_command('Unique job '+str(i),room='Lobby')
  for event in m._fake_events.scheduled[start:]:event[2](*event[3])
 results['four_completed_jobs']={**state(p),'jobs_executed_once_each':4,'rooms_sent':len(p.public_sent)}
print(json.dumps({'not_actor_feedback':True,'captured_phase':2,'source_sha256':hashlib.sha256(f.PLUGIN_PATH.read_bytes()).hexdigest(),'immutable_fixture_sha256':hashlib.sha256(Path('/fixtures/test_announcer.py').read_bytes()).hexdigest(),'results':results,'scope':'Immutable fake peers; selected scheduled callbacks executed once. Plugin-owned room mapping audited separately from fake event fixture storage. No GUI/network integration claim.'}))
