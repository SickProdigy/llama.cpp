from pathlib import Path
import json,hashlib,time
D=Path(__file__).resolve().parent;S=D/'native-glm-fresh-cp2/queued_announcements';L=S/'llm-records';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tasks=json.loads((D/'tasks.json').read_text())['families']['queued_announcements']
rows=[]
for phase,(first,last) in enumerate([(6,52),(53,63),(64,121)]):
 complete=[];observed=[]
 for n in range(first,last+1):
  f=L/f'{n:05}.metrics.json';m=json.loads(f.read_text());q=json.loads((L/f'{n:05}.request.json').read_text())
  if len(q.get('tools',[]))!=33:continue
  observed.append(n)
  raw=(L/f'{n:05}.response.txt').read_bytes();body=raw.rstrip().endswith(b'data: [DONE]')
  if not body and raw.lstrip().startswith(b'{'):
   try:body=bool(json.loads(raw).get('choices'))
   except ValueError:pass
  if body and not m.get('transport_error')and not m.get('response_parse_failed')and m.get('usage'):complete.append(n)
 n=complete[-1];f=L/f'{n:05}.request.json';q=json.loads(f.read_text());m=json.loads((L/f'{n:05}.metrics.json').read_text());containers=[]
 for task in tasks[:phase+1]:
  containers.append([{'index':i,'role':msg['role']}for i,msg in enumerate(q['messages'])if task in str(msg.get('content',''))])
 rows.append({'phase':phase,'completed_phase':True,'last_complete_HTTP_id':n,'prompt_tokens':m['usage']['prompt_tokens'],'saved_request_JSON_sha256':sha(f),'wire_request_sha256_from_proxy_metrics':m['request_sha256'],'expected_task_text_presence':[bool(v)for v in containers],'all_expected_task_texts_present':all(containers),'original_issue_fork_PR_task_still_present':bool(containers[0]),'task_role_containers':containers,'user_message_count':sum(x['role']=='user'for x in q['messages']),'primary_tool_count':33,'last_observed_primary_HTTP_id':observed[-1],'last_observed_primary_incomplete':observed[-1]not in complete})
a={'observed_epoch':time.time(),'not_actor_feedback':True,'classification':'Completed primary request retention inspection, not attention or quality proof','final_feature_phase_still_pending':False,'phases':rows,'compression':{'auxiliary_HTTP_ids':[94,96],'both_incomplete_without_usage_or_finish':True,'native_no_output_guard_seconds':300,'native_total_ceiling_seconds':600,'deterministic_fallback_committed':True,'successful_model_generated_summary':False,'pre_fallback_completed_primary_HTTP_id':95,'pre_fallback_prompt_tokens':84237,'post_fallback_first_primary_HTTP_id':97,'README_task_in_assistant_checkpoint_not_original_user_role':True},'limits':['Text presence does not prove attention or reasoning.','No private grade feedback or corrective prompt supplied.','Saved JSON and wire-body hashes are distinct fingerprints.','Last observed primary requests were interrupted by repetition detector; complete request selection excludes them.','Compression guard aborted auxiliary requests while backend prefill progressed; operator had extended main/provider timeout but overlooked separate compression guard settings.','Earlier initial/README defects and repetition preceded compression; do not attribute every failure to that runtime confound.']}
assert [r['last_complete_HTTP_id']for r in rows]==[51,62,120]and all(r['all_expected_task_texts_present']for r in rows)
(D/'glm-queue-context-instruction-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
