"""Posthoc captured initial source only, no actor feedback."""
from pathlib import Path
import importlib.util,json,pytest,hashlib
spec=importlib.util.spec_from_file_location('immutable_announcer','/fixtures/test_announcer.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);f.PLUGIN_PATH=Path('/workspace/announcer/__init__.py')
results={}
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');assert p.announce_command('Queued',room='Lobby');first,second=m._fake_events.scheduled
 p.settings['sending_enabled']=False;first[2](*first[3]);after_first={'sent':list(p.public_sent),'pending':len(p._scheduled),'reply_entries':len(p._job_replies),'local_public':[v[1]for v in p.local_public]}
 p.settings['sending_enabled']=True;second[2](*second[3]);results['off_then_on_between_callbacks']={'after_first':after_first,'sent':list(p.public_sent),'pending':len(p._scheduled),'reply_entries':len(p._job_replies),'local_public':[v[1]for v in p.local_public],'finished_reply_count':sum(v[1]=='Announcement job finished.'for v in p.local_public)}
 assert [r for r,_ in p.public_sent]==['Books'];assert not p._scheduled and not p._job_replies
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');assert p.announce_command('Queued',room='Lobby')
 for event in list(m._fake_events.scheduled):event[2](*event[3])
 results['normal_all_enabled']={'sent':list(p.public_sent),'pending':len(p._scheduled),'reply_entries':len(p._job_replies),'finished_reply_count':sum(v[1]=='Announcement job finished.'for v in p.local_public)}
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux');assert p.announce_command('Old disabled',room='Lobby');first=m._fake_events.scheduled[0];p.settings['sending_enabled']=False;first[2](*first[3]);assert not p.public_sent and not p._scheduled
 retained_events=len(m._fake_events.scheduled);p.settings['sending_enabled']=True;assert p.announce_command('Fresh enabled',room='Lobby');second=m._fake_events.scheduled[-1];second[2](*second[3]);assert p.public_sent==[('Linux','[Open Source] Fresh enabled')]
 results['fresh_job_after_disabled_callback_without_replay']={'sent':list(p.public_sent),'old_fake_event_retained_by_fixture':retained_events,'pending':len(p._scheduled),'local_private_count':len(p.local_private),'local_public':[v[1]for v in p.local_public],'fixture_helper_replays_all_retained_callbacks_if_called_again':True}
print(json.dumps({'not_actor_feedback':True,'captured_phase':0,'source_sha256':hashlib.sha256(f.PLUGIN_PATH.read_bytes()).hexdigest(),'immutable_fixture_sha256':hashlib.sha256(Path('/fixtures/test_announcer.py').read_bytes()).hexdigest(),'results':results,'scope':'Immutable fake peers, each selected callback executed once; no full GUI/network claim. Re-enable callback/state and visible completion audited separately.'}))
