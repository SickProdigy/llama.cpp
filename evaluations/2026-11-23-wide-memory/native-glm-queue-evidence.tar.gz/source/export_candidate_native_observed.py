"""Export observed completed native outcomes, including absent remote publication."""
from pathlib import Path
import json,hashlib,shutil,tarfile,statistics,sys
R=Path.cwd();D=R/'.git/hermes-wide-memory-20261123';E=R/'evaluations/2026-11-23-wide-memory';KEY,FAMILY=sys.argv[1:];assert KEY in ['q3','devstral','glm']and FAMILY in ['spam_enforcement','queued_announcements'];SHORT='spam'if FAMILY=='spam_enforcement'else'queue';LABEL='native-'+KEY+'-'+SHORT;S=D/('native-'+KEY+'-fresh-cp2')/FAMILY;RESTORE_LABEL=('native-'+KEY+'-fresh-cp2/'+FAMILY).replace('/','-');AUDIT_LABEL=KEY+'-'+SHORT
# Deliberately cannot publish a half-finished GPU stage as a completed result.
assert json.loads((S/'runtime-restoration.json').read_text())['restored']
assert json.loads((S/KEY/'case-finished.json').read_text())['turns']==3
final=json.loads((D/(AUDIT_LABEL+'-final-audit.json')).read_text());assert final['audit_complete']and final['not_actor_feedback']
assert json.loads((D/(RESTORE_LABEL+'-preservation.json')).read_text())['original_ids_images_configuration_running_preserved']
assert json.loads((D/(RESTORE_LABEL+'-owner-preservation.json')).read_text())['passed']
X=D/(LABEL+'-export');X.mkdir(exist_ok=False)
def cp(src,dst):
 f=X/dst;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,f)
def write(dst,value):
 f=X/dst;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(value,indent=2)+'\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['candidate_native_controller.py','audit_candidate_test_adequacy.py','audit_candidate_completed_stage.py','export_candidate_native_observed.py','audit_candidate_local_test_adequacy.py','verify_candidate_native_observed.py','check_observed_verifier_format.py']:
 cp(D/name,Path('source')/name)
for suffix in ['initial-manual-audit.json','README-manual-audit.json','feature-manual-audit.json','final-audit.json']:
 cp(D/(AUDIT_LABEL+'-'+suffix),Path('audits')/(AUDIT_LABEL+'-'+suffix))
for suffix in ['preservation.json','owner-preservation.json']:
 cp(D/(RESTORE_LABEL+'-'+suffix),Path('audits')/(RESTORE_LABEL+'-'+suffix))
cp(D/(LABEL+'-cleanup.json'),Path('audits')/(LABEL+'-cleanup.json'))
cp(D/(RESTORE_LABEL+'-supervisor-exit-state.json'),Path('audits')/'supervisor-exit-state.json')
for optional in [AUDIT_LABEL+'-read-control-audit.json',AUDIT_LABEL+'-runtime-limitation.json',AUDIT_LABEL+'-web-environment-limitation.json',AUDIT_LABEL+'-fork-independent-readback.json',AUDIT_LABEL+'-publication-independent-readback.json',AUDIT_LABEL+'-allowlist-independent-audit.json',AUDIT_LABEL+'-branch-scope-observation.json',AUDIT_LABEL+'-routing-observation.json']:
 if(D/optional).exists():cp(D/optional,Path('audits')/optional)
context_audit=D/(AUDIT_LABEL+'-context-instruction-audit.json')
if context_audit.exists()and KEY=='glm':
 context=json.loads(context_audit.read_text());assert not context['final_feature_phase_still_pending']and len(context['phases'])==3 and all(r['completed_phase']for r in context['phases'])
 cp(context_audit,Path('audits')/context_audit.name)
for name in ['events.jsonl','memory-samples.jsonl','model-identity.json','runtime-before.json','runtime-restoration.json']:
 cp(S/name,Path('runtime')/name)
launch=json.loads((S/'backend-launch.json').read_text());write('runtime/backend-launch.json',{'argv':launch['argv'],'seconds':launch['seconds'],'props':{k:launch['props'][k]for k in ['model_alias','model_path','build_info','default_generation_settings']if k in launch['props']}})
protocol=json.loads((D/('native-'+KEY+'-fresh-cp2-'+FAMILY+'-protocol.json')).read_text());safe_protocol={k:v for k,v in protocol.items()if k not in ['profile_sha256','code_sha256']};safe_protocol.update(private_original_protocol_sha256=sha((D/('native-'+KEY+'-fresh-cp2-'+FAMILY+'-protocol.json')).read_bytes()),profile_manifest_not_exported=True,private_code_fingerprints={k:v for k,v in protocol.get('code_sha256',{}).items()if not k.startswith(('profiles/','baseline/'))});write('controls/protocol.json',safe_protocol)
if (D/'observed-outcome-verifier-format-controls/result.json').exists():cp(D/'observed-outcome-verifier-format-controls/result.json',Path('controls')/'posthoc-verifier-format-result.json')
metrics=[]
for f in sorted((S/'llm-records').glob('*.metrics.json')):
 original=json.loads(f.read_text());row={k:original[k]for k in ['id','purpose','received_epoch','request_sha256','backend_start_epoch','end_epoch','usage','finish_reasons']if k in original};row['purpose']='native-main-or-auxiliary'if original.get('purpose')=='native-main-or-auxiliary'else'unrecognized-purpose'
 row['client_transport_error_present']=bool(original.get('transport_error'));row['transport_error_class']=original.get('transport_error','').split(':',1)[0]or None;row['response_parse_failed']=bool(original.get('response_parse_failed'))
 usage=original.get('usage')or{};row['usage']={k:usage[k]for k in ['prompt_tokens','completion_tokens','total_tokens']if isinstance(usage.get(k),int)}
 if isinstance(usage.get('prompt_tokens_details'),dict)and isinstance(usage['prompt_tokens_details'].get('cached_tokens'),int):row['usage']['prompt_tokens_details']={'cached_tokens':usage['prompt_tokens_details']['cached_tokens']}
 row['finish_reasons']=[v if v in ['stop','tool_calls','length','content_filter']else'other'for v in original.get('finish_reasons',[])]
 row['private_original_metrics_sha256']=sha(f.read_bytes());response=f.with_name(f.name.replace('.metrics.json','.response.txt'));request=f.with_name(f.name.replace('.metrics.json','.request.json'))
 if response.exists():row.update(private_response_sha256=sha(response.read_bytes()),private_response_bytes=response.stat().st_size)
 if request.exists():row.update(private_saved_request_file_sha256=sha(request.read_bytes()),private_saved_request_bytes=request.stat().st_size)
 raw=response.read_bytes()if response.exists()else b''
 body_complete=raw.rstrip().endswith(b'data: [DONE]')
 if not body_complete and raw.lstrip().startswith(b'{'):
  try:body_complete=bool(json.loads(raw).get('choices'))
  except (ValueError,TypeError):pass
 row['backend_body_complete']=bool(body_complete and not row['response_parse_failed'])
 row['capture_complete_without_transport_error']=row['backend_body_complete']and not row['client_transport_error_present']
 row['raw_capture_excluded']=True;metrics.append(row);write('requests/'+f.name,row)
phases=[]
for phase in range(3):
 src=S/KEY/('turn'+str(phase));run=json.loads((src/'run.json').read_text());safe={k:run[k]for k in ['family','arm','phase','elapsed_seconds','exit_code','external_timeout','query_sha256']};safe['native_session_fingerprints']={k:sha(run[k].encode())if run.get(k)else None for k in ['logical_root','incoming_sid','effective_sid']};safe['private_original_run_sha256']=sha((src/'run.json').read_bytes());write('phases/'+str(phase)+'/run.json',safe)
 grades={}
 for kind in ['local-grade','remote-grade']:
  if not(src/kind/'grade.json').exists():
   assert kind=='remote-grade' and not(json.loads((src/'forge-snapshot.json').read_text()).get('clone')), 'Missing grade for captured remote publication'
   continue
  grade=json.loads((src/kind/'grade.json').read_text());grades[kind]=grade;write('phases/'+str(phase)+'/'+kind+'/grade.json',grade)
  files={}
  for f in sorted((src/kind/'source').rglob('*')):
   assert not f.is_symlink()
   if f.is_file():files[str(f.relative_to(src/kind/'source'))]=sha(f.read_bytes())
  write('phases/'+str(phase)+'/'+kind+'/source-sha256.json',files)
  # These are project/original tests available to the actor, not hidden grader logs.
  for name in ['project.log','preservation.log']:cp(src/kind/name,Path('phases')/str(phase)/kind/name)
 forge=json.loads((src/'forge-snapshot.json').read_text());snapshot={'scope_state':forge['scope_state'],'phase':phase}
 for label in ['issue','pr']:
  if label in forge:
   obj=forge[label];snapshot[label]={k:obj[k]for k in ['number','state','merged','title','created_at','updated_at','closed_at']if k in obj}
   if label=='pr':snapshot[label].update(head={'sha':obj['head']['sha'],'ref':obj['head']['ref'],'repo':obj['head']['repo']['full_name']},base={'sha':obj['base']['sha'],'ref':obj['base']['ref'],'repo':obj['base']['repo']['full_name']})
 if 'clone'in forge:snapshot['clone']={k:forge['clone'][k]for k in ['name','head','tree']}
 write('phases/'+str(phase)+'/forge-readback.json',snapshot);phases.append({**safe,'local_grade':grades['local-grade'],'remote_grade':grades.get('remote-grade'),'remote_grade_absent':('remote-grade' not in grades),'forge':snapshot})
for phase in [0,2]:
 source_kind='remote-grade' if (S/KEY/('turn'+str(phase))/'remote-grade/grade.json').exists() else 'local-grade'
 control=KEY+'-'+FAMILY+'-phase'+str(phase)+('-test-adequacy' if source_kind=='remote-grade' else '-local-test-adequacy')
 write('controls/test-adequacy-phase'+str(phase)+'-source-kind.json',{'source_kind':source_kind,'control_directory':control,'no_remote_grade_fabricated':True})
 cp(D/control/'result.json',Path('controls')/control/'result.json')
 for f in sorted((D/control).rglob('*.log')):
  cp(f,Path('controls')/control/f.relative_to(D/control))
if KEY=='q3'and FAMILY=='spam_enforcement':
 cp(D/'q3-initial-hook-behavior/result.json',Path('controls')/'posthoc-hook-behavior-result.json')
if FAMILY=='queued_announcements'and(D/(KEY+'-queue-documentation-semantics')/'result.json').exists():
 cp(D/(KEY+'-queue-documentation-semantics')/'result.json',Path('controls')/'posthoc-documentation-semantics-result.json')
if FAMILY=='queued_announcements'and(D/(KEY+'-queue-dispatch-cleanup')/'result.json').exists():
 cp(D/(KEY+'-queue-dispatch-cleanup')/'result.json',Path('controls')/'posthoc-dispatch-cleanup-result.json')
 cp(D/'nicotine-dispatch-primary-source/pins.json',Path('controls')/'upstream-dispatch-pins.json')
 cp(D/'announcer_dispatch_cleanup_control.py',Path('source')/'announcer_dispatch_cleanup_control.py')
if KEY=='glm'and FAMILY=='spam_enforcement'and(D/'glm-spam-initial-supplementary-control/result.json').exists():
 cp(D/'glm_spam_initial_supplementary_control.py',Path('source')/'glm_spam_initial_supplementary_control.py')
 for n in ['result.json','run.json','authored-explicit-pytest.log']:
  cp(D/'glm-spam-initial-supplementary-control'/n,Path('controls/glm-spam-initial-supplementary')/n)
if KEY=='glm'and FAMILY=='spam_enforcement'and(D/'glm-spam-feature-supplementary-control/result.json').exists():
 cp(D/'glm_spam_feature_supplementary_control.py',Path('source')/'glm_spam_feature_supplementary_control.py')
 cp(D/'finalize_glm_spam_audit.py',Path('source')/'finalize_glm_spam_audit.py')
 for n in ['result.json','run.json','authored-explicit-pytest.log']:
  cp(D/'glm-spam-feature-supplementary-control'/n,Path('controls/glm-spam-feature-supplementary')/n)
if KEY=='glm'and FAMILY=='queued_announcements':
 cp(D/'glm_queue_initial_supplementary_control.py',Path('source')/'glm_queue_initial_supplementary_control.py')
 cp(D/'announcer-initial-completion-control-comparison.json',Path('controls')/'announcer-initial-completion-control-comparison.json')
 for other in ['q3','q4','devstral','glm']:
  root=D/(other+'-queue-initial-supplementary-control')
  for n in ['result.json','run.json','control.log']:
   cp(root/n,Path('controls/announcer-initial-completion')/other/n)
if KEY=='glm'and FAMILY=='queued_announcements':
 cp(D/'glm_queue_feature_supplementary_control.py',Path('source')/'glm_queue_feature_supplementary_control.py')
 for name in ['finalize_glm_queue_context.py','finalize_glm_queue_audit.py']:
  cp(D/name,Path('source')/name)
 for n in ['result.json','run.json','control.log']:
  cp(D/'glm-queue-feature-supplementary-control'/n,Path('controls/glm-queue-feature-supplementary')/n)
 cp(D/'native-compression-guard-source/pins.json',Path('controls')/'native-compression-guard-source-pins.json')
samples=[json.loads(line)for line in(S/'memory-samples.jsonl').read_text().splitlines()];good=[r for r in samples if all(k in r for k in ['total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes','host'])];assert good
complete=[r for r in metrics if r['capture_complete_without_transport_error']];assert complete
latency=[r['end_epoch']-r['backend_start_epoch']for r in complete if all(k in r for k in ['end_epoch','backend_start_epoch'])];summary={'classification':final['classification'],'model':json.loads((S/'model-identity.json').read_text()),'candidate_key':KEY,'family':FAMILY,'phases':phases,'independent_final_audit':final,'measurements':{'sample_count':len(samples),'complete_aggregate_sample_count':len(good),'measurement_error_sample_count':sum('measurement_error'in r for r in samples),'peak_observed_cgroup_bytes':max(r['total_cgroup_bytes']for r in good),'peak_observed_all_process_PSS_bytes':max(r['total_process_pss_bytes']for r in good),'peak_observed_experiment_swap_bytes':max(r['total_cgroup_swap_bytes']for r in good),'resource_guard_samples':sum(bool(r.get('budget_guard_triggered'))for r in samples),'global_pswpin_delta_pages':good[-1]['host']['pswpin_pages']-good[0]['host']['pswpin_pages'],'global_pswpout_delta_pages':good[-1]['host']['pswpout_pages']-good[0]['host']['pswpout_pages'],'global_swap_not_attributed_to_model':True,'HTTP_records':len(metrics),'completed_HTTP_records_without_transport_error':len(complete),'transport_error_record_count':sum(r['client_transport_error_present']for r in metrics),'incomplete_backend_body_record_count':sum(not r['backend_body_complete']for r in metrics),'maximum_completed_prompt_tokens':max(r.get('usage',{}).get('prompt_tokens',0)for r in complete),'HTTP_latency_seconds':{'min':min(latency),'median':statistics.median(latency),'max':max(latency),'sum':sum(latency)},'not_isolated_decode_throughput':True,'sampling_not_continuous_peak_or_entire_host_attribution':True},'comparison_limits':['Fresh primary starts independently of the read-only control; all three coding turns share one native lineage.','Same predefined followups, no private grade feedback; final model sampling is not seed-pinned.','Focused scoped Gitea tools and publication execution gate are part of this configuration.','Private source snapshots, raw wire captures, profiles, tasks, graders and receipt keys remain local. Public evidence verification does not recreate the whole private workflow or prove all behavior correct.']}
write('summary.json',summary)
write('privacy-boundary.json',{'excluded':['Private normal-policy request bodies and generated raw responses','Native consoles and verbose model logs','Profiles, session databases and ignored owner instructions','Future task text, private graders and reference implementations','Credentials and receipt keys','Full source snapshots of selected private project'],'included':'Raw numeric memory observations, selected timing/usage/fingerprints, source hashes, project/original-suite logs and independently audited publication/claims summaries. Reproduction of the complete private quality workflow requires the retained local inputs; this bundle alone verifies recorded evidence consistency.'})
manifest={str(f.relative_to(X)):sha(f.read_bytes())for f in sorted(X.rglob('*'))if f.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Completed native candidate evidence; quality may fail; independence and correctness still require the scoped audits and stated limits.'});archive=E/(LABEL+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/(LABEL+'-evidence.sha256')).write_text(sha(archive.read_bytes())+'  '+archive.name+'\n');(E/(LABEL+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}))
