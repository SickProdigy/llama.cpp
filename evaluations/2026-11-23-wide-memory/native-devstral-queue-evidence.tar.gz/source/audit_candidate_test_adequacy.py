"""Post-turn controls: retained model-authored tests against published/prior sources.
No findings are actor feedback; failures alone are not meaningful-regression proof.
"""
from pathlib import Path
import json,subprocess,hashlib,ast,time,sys
D=Path(__file__).resolve().parent;key,family,phase=sys.argv[1:];phase=int(phase);assert key in ['q3','devstral','glm']and family in ['spam_enforcement','queued_announcements']and phase in [0,2]
S=D/('native-'+key+'-fresh-cp2')/family;out=D/(key+'-'+family+'-phase'+str(phase)+'-test-adequacy');out.mkdir(exist_ok=False);engine='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-wide-memory-20261123';image='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';module='autospamignore'if family=='spam_enforcement'else'announcer';test='tests/test_'+module+'.py'
def inventory(root):
 files={}
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():files[str(p.relative_to(root))]=p.read_bytes()
 return files
candidate=inventory(S/key/('turn'+str(phase))/'remote-grade/source');prior=inventory(D/'baseline'if phase==0 else S/key/'turn1/remote-grade/source');old=ast.parse(prior[test]);new=ast.parse(candidate[test]);added=[]
def strip_added(old_node,new_node,prefix=''):
 original={(type(n).__name__,n.name):n for n in old_node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))};kept=[]
 for n in new_node.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
   key=(type(n).__name__,n.name)
   if key not in original:
    if isinstance(n,ast.ClassDef):added.extend(prefix+n.name+'.'+m.name for m in n.body if isinstance(m,(ast.FunctionDef,ast.AsyncFunctionDef))and m.name.startswith('test'))
    else:added.append(prefix+n.name)
    continue
   if isinstance(n,ast.ClassDef):strip_added(original[key],n,prefix+n.name+'.')
  kept.append(n)
 new_node.body=kept
strip_added(old,new);preserved=ast.dump(new)==ast.dump(old)

def snapshot(name,files):
 root=out/name/'source';root.mkdir(parents=True)
 for path,raw in files.items():p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 (root.parent/'source-sha256.json').write_text(json.dumps({n:hashlib.sha256(v).hexdigest()for n,v in sorted(files.items())},indent=2)+'\n');return root
def run(name,files):
 root=snapshot(name,files);mount='type=bind,source='+engine+'/'+str(root.relative_to(D))+',target=/workspace,readonly';args=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','384m','--memory-swap','384m','--cpus','1','--tmpfs','/tmp:rw,size=64m','--mount',mount,'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','-w','/workspace','--entrypoint','python',image,'-m','pytest','-q','-p','no:cacheprovider','tests'];start=time.monotonic();r=subprocess.run(args,capture_output=True,text=True,timeout=90);log=r.stdout+r.stderr;(root.parent/'project.log').write_text(log);record={'argv':args,'returncode':r.returncode,'seconds':time.monotonic()-start,'last_line':log.splitlines()[-1]if log.splitlines()else None};(root.parent/'run.json').write_text(json.dumps(record,indent=2)+'\n');return record
published=run('published',candidate);merged=dict(prior);merged[test]=candidate[test];control=run('prior_with_authored_tests',merged);record={'not_actor_feedback':True,'key':key,'family':family,'phase':phase,'existing_test_AST_unchanged_except_added_functions':preserved,'added_test_functions':added,'published':published,'prior_with_authored_tests':control,'requires_manual_failure_and_source_classification':True,'not_quality_pass_from_green_tests':True};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items()if k not in ['published','prior_with_authored_tests']},indent=2));print('published:',published['last_line']);print('prior:',control['last_line'])
