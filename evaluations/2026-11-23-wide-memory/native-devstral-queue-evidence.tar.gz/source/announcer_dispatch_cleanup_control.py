"""Posthoc control using pinned upstream dispatcher AST and immutable peer fixture.
No actor feedback; no alteration of captured candidate source or frozen graders.
"""
from pathlib import Path
import ast,hashlib,importlib.util,json,types,pytest
spec=importlib.util.spec_from_file_location('immutable_announcer','/fixtures/test_announcer.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);f.PLUGIN_PATH=Path('/workspace/announcer/__init__.py')
pins=json.loads(Path('/primary/pins.json').read_text());results=[]
for pin in pins:
 if pin.get('requested_ref')not in ['3.3.11','master']:continue
 raw=(Path('/primary')/pin['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==pin['sha256'];tree=ast.parse(raw.decode());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='PluginHandler');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='_trigger_command');ns={'CommandInterface':types.SimpleNamespace(CHATROOM='chatroom',PRIVATE_CHAT='private_chat',CLI='cli'),'_':lambda s:s,'log':types.SimpleNamespace(add_debug=lambda *a,**k:None)};exec(compile(ast.Module(body=[method],type_ignores=[]),pin['file'],'exec'),ns);trigger=ns['_trigger_command']
 class Handler:
  def __init__(self,p):self.loaded_plugins={'captured_candidate':p};self.enabled_plugins=self.loaded_plugins;self.command_source=None;self.errors=[]
  def show_plugin_error(self,*a):self.errors.append([str(x)for x in a])
 def setup(m,rooms):
  p=f.make_plugin(m);p.__publiccommands__=[];p.__privatecommands__=[];p.settings.update(sending_enabled=True,default_rooms=rooms);assert p.announce_command('Posthoc cancellation control',room='Lobby')is True;return p,Handler(p)
 with pytest.MonkeyPatch.context()as mp:
  m=f.module.__wrapped__(mp);p,h=setup(m,'Linux, Books');metadata=bool(p.commands['announcecancel'].get('parameters'));ok=trigger(h,'announcecancel',' bOoKs ',room='Lobby');assert ok and not h.errors;cancelled=list(m._fake_events.cancelled)
  for ident,delay,callback,args,repeat in list(m._fake_events.scheduled):
   if ident not in cancelled:callback(*args)
  selective={'declared_parameters':metadata,'actual_upstream_dispatch_accepted_room_argument':bool(ok),'cancelled_event_ids':cancelled,'rooms_sent':[r for r,_ in p.public_sent],'pending_entries_after_callbacks':len(p._scheduled),'reply_entries_after_callbacks':len(p._job_replies),'completion_reported':any(item[1]=='Announcement job finished.'for item in p.local_public)}
 with pytest.MonkeyPatch.context()as mp:
  m=f.module.__wrapped__(mp);p,h=setup(m,'Books');before=len(p.local_public);ok=trigger(h,'announcecancel',' bOoKs ',room='Lobby');assert ok and not h.errors;last={'actual_upstream_dispatch_accepted_room_argument':bool(ok),'cancelled_event_ids':list(m._fake_events.cancelled),'pending_entries_after_cancelling_only_target':len(p._scheduled),'reply_entries_after_cancelling_only_target':len(p._job_replies),'completion_reported_after_cancellation':any(item[1]=='Announcement job finished.'for item in p.local_public[before:]),'job_cleanup_complete':not p._scheduled and not p._job_replies}
 results.append({'requested_ref':pin['requested_ref'],'commit':pin['commit'],'upstream_source_sha256':pin['sha256'],'upstream_url':pin['url'],'method_AST_sha256':hashlib.sha256(ast.dump(method).encode()).hexdigest(),'selective_with_surviving_target':selective,'cancelling_last_target_of_job':last})
print(json.dumps({'not_actor_feedback':True,'source_sha256':hashlib.sha256(f.PLUGIN_PATH.read_bytes()).hexdigest(),'pinned_upstream_dispatcher_method_executed_without_body_changes':True,'scope':'Exact dispatcher method with immutable fake peers; not full GUI/network integration. Missing parameters may affect help but are not an argument rejection in these pins. Job cleanup reported separately.','results':results}))
