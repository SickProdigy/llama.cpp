"""Export complete restored resource stages; no native coding quality claim."""
from pathlib import Path
import json,sys,hashlib,shutil,tarfile
R=Path.cwd();D=R/'.git/hermes-wide-memory-20261123';E=R/'evaluations/2026-11-23-wide-memory';key=sys.argv[1];assert key in ['q3','devstral','glm'];S=D/('remaining-resource-'+key);label='resource-'+key;X=D/(label+'-export');assert not X.exists()
assert json.loads((S/'runtime-restoration.json').read_text())['restored'];assert json.loads((D/('remaining-resource-'+key+'-preservation.json')).read_text())['all_29_original_model_metadata_unchanged'];assert json.loads((D/('remaining-resource-'+key+'-owner-preservation.json')).read_text())['passed'];X.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def copy(p,name):
 out=X/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
def write(name,x):
 out=X/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(x,indent=2)+'\n')
for n in ['candidate_resource_controller.py','export_candidate_resource.py','verify_candidate_resource.py']:copy(D/n,Path('source')/n)
for n in ['remaining-resource-protocol.json','remaining-resource-controller-registration.json','remaining-resource-'+key+'-preservation.json','remaining-resource-'+key+'-owner-preservation.json']:copy(D/n,Path('controls')/n)
for n in ['runtime-before.json','model-identity.json','host-before.json','events.jsonl','finished.json','runtime-restoration.json']:copy(S/n,Path('runtime')/n)
summary={'candidate':key,'classification':'Resource/template/history controls; not native coding/Gitea task quality','layouts':[],'sampling_limit':'Observed cgroup/file-cache and all-process PSS, not continuous entire-host attribution; no global cache flush. Global swap counter changes are not model swap proof.'}
for layout in sorted(S.glob('layout*')):
 rows=[]
 for f in sorted(layout.iterdir()):
  if f.is_file()and f.name!='ready.json':copy(f,Path(layout.name)/f.name)
 if(layout/'ready.json').exists():
  ready=json.loads((layout/'ready.json').read_text());write(layout.name+'/ready.json',{'seconds':ready['seconds'],'props':{k:v for k,v in ready['props'].items()if k in ['model_alias','model_path','model_ftype','build_info','chat_template_caps','default_generation_settings']}})
 for probe in ['tool','tool-followup','prompt16000','prompt60000']:
  if(layout/probe).is_dir():
   for f in sorted((layout/probe).iterdir()):
    if f.is_file():copy(f,Path(layout.name)/probe/f.name)
 if(layout/'samples.jsonl').exists():rows=[json.loads(s)for s in(layout/'samples.jsonl').read_text().splitlines()]
 good=[r for r in rows if all(k in r for k in ['total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes'])];result=json.loads((layout/'result.json').read_text());item={'layout':layout.name,'result':result,'samples':len(rows),'complete_samples':len(good),'measurement_error_samples':sum('measurement_error'in r for r in rows),'guard_samples':sum(bool(r.get('budget_guard_triggered'))for r in rows),'probes':{}}
 if good:item['peaks']={k:max(r[k]for r in good)for k in ['total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes']}
 for probe in ['tool','tool-followup','prompt16000','prompt60000']:
  if(layout/probe/'capture.json').exists():item['probes'][probe]={'capture':json.loads((layout/probe/'capture.json').read_text()),'input':json.loads((layout/probe/'input.json').read_text())}
 summary['layouts'].append(item)
write('summary.json',summary);(E/(label+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');manifest={str(f.relative_to(X)):sha(f.read_bytes())for f in sorted(X.rglob('*'))if f.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Restored resource-only stage; no native actor profiles, private tasks or graders.'});archive=E/(label+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/(label+'-evidence.sha256')).write_text(sha(archive.read_bytes())+'  '+archive.name+'\n');print(json.dumps({'files':len(manifest)+1,'archive_sha256':sha(archive.read_bytes()),'candidate':key}))
