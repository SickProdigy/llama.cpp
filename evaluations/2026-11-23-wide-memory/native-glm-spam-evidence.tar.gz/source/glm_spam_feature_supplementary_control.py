from pathlib import Path
import importlib.util,json,hashlib,subprocess,time,ast
from unittest.mock import patch
ROOT=Path('/candidate')
OUT=Path('/out')
fixture=ROOT/'tests/test_autospamignore.py'
spec=importlib.util.spec_from_file_location('fixture_feature',fixture)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
def make(cooldown=60):
    t=m.AutoSpamIgnoreTests()
    t.setUpClass()
    t.setUp()
    t.plugin.settings.update(blocked_phrases='blocked',rule_alert_cooldown_seconds=cooldown)
    return t
def event(t,now,user='spammer',line='blocked',room='Books'):
    with patch.object(t.module.time,'monotonic',return_value=now):
        t.plugin.incoming_public_chat_notification(room,user,line)
def error_call(fn):
    try:
        fn()
        return None
    except Exception as e:
        return type(e).__name__+': '+str(e)
low=make()
event(low,1)
normal=make()
event(normal,10000)
first=len(normal.plugin.logs)
event(normal,10061)
reset=make()
event(reset,10000)
reset.plugin.spam_reset_command(' sPaMmEr ')
reset_type=type(reset.plugin._rule_alert_timestamps).__name__
reset_error=error_call(lambda:event(reset,10001))
cleanup=make(3600)
event(cleanup,10000,line='ordinary')
event(cleanup,10001)
before_cleanup=len(cleanup.plugin.logs)
event(cleanup,10120,user='other',line='ordinary',room='Linux')
cleanup_type=type(cleanup.plugin._rule_alert_timestamps).__name__
cleanup_error=error_call(lambda:event(cleanup,10121))
enforce=make()
event(enforce,10000)
enforce.plugin.settings['enforce_ignores']=True
event(enforce,10001)
cmd=['python','-m','pytest','-q','-p','no:cacheprovider','autospamignore/tests.py']
start=time.monotonic()
run=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=90)
raw=run.stdout+run.stderr
(OUT/'authored-explicit-pytest.log').write_text(raw)
tree=ast.parse((ROOT/'autospamignore/tests.py').read_text())
counts={n.name:len([f for f in n.body if isinstance(f,ast.FunctionDef)and f.name.startswith('test_')])for n in tree.body if isinstance(n,ast.ClassDef)}
result={'not_actor_feedback':True,'source_kind':'captured_unpublished_feature_draft','first_alert_at_low_clock_logs':len(low.plugin.logs),'high_clock_first_alert_logs':first,'high_clock_after_elapsed_cooldown_logs':len(normal.plugin.logs),'selected_reset_timestamp_type':reset_type,'selected_reset_next_event_error':reset_error,'long_cooldown_seconds':3600,'ordinary_cleanup_before_unexpired_cooldown':{'first_alert_logs':before_cleanup,'timestamp_type_after_cleanup':cleanup_type,'next_event_error':cleanup_error,'elapsed_since_first_alert_seconds':120},'enforcement_bypass_ignored_users':enforce.network_filter.ignored,'authored_method_counts':counts,'authored_explicit_pytest':{'argv':cmd,'exit_code':run.returncode,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(raw.encode()).hexdigest()},'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()for n in ['autospamignore/__init__.py','autospamignore/tests.py','tests/test_autospamignore.py']},'control_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual incoming message callbacks using unchanged original fixture. High clock avoids relying solely on startup/clock-origin artifact; cleanup occurs before a configured long cooldown expires. No actor source/test repairs.'}
assert first==1 and len(normal.plugin.logs)==1
assert reset_type=='set'and reset_error.startswith('AttributeError:')
assert cleanup_type=='set'and cleanup_error.startswith('AttributeError:')
assert enforce.network_filter.ignored==['spammer']
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

