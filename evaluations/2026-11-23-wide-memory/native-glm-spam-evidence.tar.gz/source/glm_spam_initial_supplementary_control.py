from pathlib import Path
import importlib.util,json,hashlib,subprocess,time
from unittest.mock import patch
OUT=Path('/out')
def behavior(root,label):
 root=Path(root);fixture=root/'tests/test_autospamignore.py';spec=importlib.util.spec_from_file_location('fixture_'+label,fixture);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);case=m.AutoSpamIgnoreTests();case.setUpClass();case.setUp()
 case.send(room='Books',user='spammer',timestamp=1)
 case.plugin.settings['blocked_phrases']='blocked'
 with patch.object(case.module.time,'monotonic',return_value=2):case.plugin.incoming_public_chat_notification('Books','spammer','blocked')
 before=len(case.plugin.logs);alerts_before=len(case.plugin._rule_alerts)
 case.send(room='Linux',user='other',timestamp=120)
 alerts_after=len(case.plugin._rule_alerts)
 with patch.object(case.module.time,'monotonic',return_value=121):case.plugin.incoming_public_chat_notification('Books','spammer','blocked')
 return {'source':label,'logs_after_first_rule_message':before,'rule_alerts_before_ordinary_expiry_cleanup':alerts_before,'rule_alerts_after_ordinary_expiry_cleanup':alerts_after,'logs_after_repeated_rule_message':len(case.plugin.logs),'plugin_sha256':hashlib.sha256((root/'autospamignore/__init__.py').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest()}
prior=behavior('/baseline','baseline');candidate=behavior('/candidate','initial_local_draft');assert prior['logs_after_repeated_rule_message']==1 and candidate['logs_after_repeated_rule_message']==2
cmd=['python','-m','pytest','-q','-p','no:cacheprovider','autospamignore/tests.py'];start=time.monotonic();r=subprocess.run(cmd,cwd='/candidate',capture_output=True,text=True,timeout=90);(OUT/'authored-explicit-pytest.log').write_text(r.stdout+r.stderr)
result={'not_actor_feedback':True,'source_kind':'captured_unpublished_initial_draft','baseline':prior,'candidate':candidate,'independent_behavior_regression_reproduced':True,'authored_explicit_pytest':{'argv':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256((r.stdout+r.stderr).encode()).hexdigest()},'control_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual incoming chat events exercise stale ordinary counter cleanup and repeated phrase alert; unchanged baseline test fixture, no candidate source repairs or actor feedback.'};(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
