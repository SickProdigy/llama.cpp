from pathlib import Path
import json,hashlib,re
D=Path(__file__).resolve().parent
S=D/'native-glm-fresh-cp2/spam_enforcement'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['glm-spam-'+x+'-manual-audit.json'for x in ['initial','README','feature']]
manual=[json.loads((D/n).read_text())for n in names]
assert all(x['audit_complete_for_this_turn']and x['not_actor_feedback']for x in manual)
assert json.loads((S/'runtime-restoration.json').read_text())['restored']
assert json.loads((D/'native-glm-spam-cleanup.json').read_text())['passed']
pres=json.loads((D/'native-glm-fresh-cp2-spam_enforcement-preservation.json').read_text())
assert pres['codex_entire_snapshot_unchanged']and pres['all_29_original_model_metadata_unchanged']and pres['original_ids_images_configuration_running_preserved']
assert json.loads((D/'native-glm-fresh-cp2-spam_enforcement-owner-preservation.json').read_text())['passed']
pub=json.loads((D/'glm-spam-publication-independent-readback.json').read_text())
assert pub['upstream_issue_state']=='closed'and pub['upstream_PR_count']==0
assert pub['fork_branches']==[{'name':'main','head':'e703b9e32748cbd930c47b523fa4225dbf70691b'}]
context=json.loads((D/'glm-spam-context-instruction-audit.json').read_text())
assert not context['final_feature_phase_still_pending']and all(x['completed_phase']for x in context['phases'])
states=list(S.glob('wide-glm-fresh2-spam-main-*-state.json'))
assert len(states)==1
model_state=json.loads(states[0].read_text())
assert not model_state['state']['OOMKilled']
rows=[json.loads(x)for x in(S/'memory-samples.jsonl').read_text().splitlines()]
good=[x for x in rows if all(k in x for k in ['total_cgroup_bytes','total_process_pss_bytes','total_cgroup_swap_bytes','host'])]
gpu=[]
for x in good:
    try:gpu.append(int(x['gpu_csv'].split(',')[0]))
    except(ValueError,KeyError):pass
a={'audit_complete':True,'not_actor_feedback':True,'fresh_primary':True,
'classification':'Fresh Spam fails original notification preservation and requested cooldown behavior; correct Gitea issue/fork but no published commit/PR; authored tests and claims fail audit',
'requested_initial_next_message_repair_local_passed':True,
'requested_cooldown_feature_local_passed':False,
'source_and_behavior_preservation_passed':False,
'original_tests_each_phase':83,
'original_suite_passed_by_phase':[x['immutable_original_suite']['passed']for x in manual],
'original_suite_failed_by_phase':[x['immutable_original_suite']['failed']for x in manual],
'project_tests_by_phase':[x['project_suite']['passed']for x in manual],
'independent_exit_by_phase':[],
'original_test_AST_preserved':True,
'new_initial_authored_methods':8,'new_feature_authored_methods':11,'actual_total_authored_methods':19,
'claimed_new_feature_methods':18,'claimed_total_authored_methods':26,
'authored_file_not_collected_by_normal_project_suite':True,
'explicit_authored_collection_failed_in_prepared_image':True,
'new_authored_regression_test_adequacy_not_demonstrated':True,
'initial_ordinary_cleanup_rule_alert_regression_reproduced':True,
'feature_high_clock_expired_cooldown_still_suppressed_reproduced':True,
'feature_selected_reset_and_ordinary_cleanup_timestamp_type_exceptions_reproduced':True,
'feature_cleanup_control_before_long_unexpired_cooldown':True,
'feature_enforcement_bypass_supported':True,
'feature_correct_bounded_setting_source_present':True,
'required_Gitea_upstream_issue_personal_fork_branch_and_PR_completed':False,
'correct_upstream_issue_created':1,'personal_fork_id':34331,'fork_parent_independently_verified':True,
'successful_actual_forge_mutations':2,'successful_forge_mutation_kinds':['upstream_issue','personal_fork'],
'branch_attempts_rejected_by_local_scope_not_server_outage':2,
'branch_prefix_visible_in_original_and_later_requests':True,
'final_published_commit':None,'upstream_main_unchanged':pub['upstream_main'],
'model_final_answers_delegate_push_and_PR_to_user':True,
'model_final_comprehensive_test_and_compatibility_claims_contradicted':True,
'read_control_Gitea_verified_claim_unsupported':True,
'original_and_followup_tasks_present_in_actual_final_requests':all(x['all_expected_task_texts_present']for x in context['phases']),
'text_presence_not_attention_proof':True,
'publication_independently_audited':True,'test_issue_cleanup_independently_verified':True,
'test_issues_opened':1,'test_issues_remaining_open':0,'test_PRs_opened':0,
'runtime_restoration_settings_models_owner_and_Codex_independently_verified':True,
'owned_stage_cleanup_independently_verified':True,
'phase_actor_seconds':[],'observed_grades_by_phase':[],'test_log_sha256_by_phase':[],
'source_changes_from_previous_phase':[],'native_exit_by_phase':[],'publication_scope_by_phase':[],
'read_control_seconds_separate':json.loads((D/'glm-spam-read-control-audit.json').read_text())['elapsed_seconds'],
'manual_audit_sha256':{n:sha(D/n)for n in names},
'posthoc_control_sha256':{n:sha(D/n)for n in ['glm-spam-initial-supplementary-control/result.json','glm-spam-feature-supplementary-control/result.json','glm-spam-context-instruction-audit.json','glm-spam-publication-independent-readback.json']},
'peak_gpu_MiB':max(gpu),'GPU_sample_count':len(gpu),
'limits':['One fresh family with dependent followups is not an autonomous-reliability sample.',
'Scoped initial checks pass but original-suite notification preservation fails; requested feature checks also fail.',
'Low-clock first-alert failure is separately qualified by high-clock no-realert and type-exception controls.',
'Initial cleanup suppression finding applies before the intentional cooldown requirement; feature control uses a long unexpired interval.',
'Private tests, raw actor requests and full source snapshots remain local; artifact verification alone is not behavior reexecution.',
'Focused scoped Gitea wrappers, branch lease and execution publication gate are part of this setup.',
'No actual code publication occurred, so no remote behavior quality is claimed.',
'Read-only and coding conversations are separate; first coding request uses a warm backend prefix cache.',
'Samples are not continuous entire-host memory attribution; global swap changes cannot be attributed to the model.',
'Announcer is a separate required fresh family still underway, followed by the registered fresh Q4 Spam comparison.']}
previous=None
for phase in range(3):
    p=S/'glm'/('turn'+str(phase))
    run=json.loads((p/'run.json').read_text())
    g=json.loads((p/'local-grade/grade.json').read_text())
    assert not(p/'remote-grade').exists()
    assert (g['project_exit'],g['preservation_exit'],g['independent_exit'])==[(1,1,0),(1,1,0),(1,1,1)][phase]
    a['phase_actor_seconds'].append(run['elapsed_seconds'])
    a['observed_grades_by_phase'].append({'local-grade':g})
    a['independent_exit_by_phase'].append(g['independent_exit'])
    a['test_log_sha256_by_phase'].append({'local-grade':{n:sha(p/'local-grade'/n)for n in ['project.log','preservation.log']}})
    source=p/'local-grade/source'
    current={str(x.relative_to(source)):sha(x)for x in source.rglob('*')if x.is_file()}
    a['source_changes_from_previous_phase'].append(None if previous is None else sorted(n for n in set(previous)|set(current)if previous.get(n)!=current.get(n)))
    previous=current
    a['native_exit_by_phase'].append({k:run[k]for k in ['exit_code','external_timeout']})
    scope=json.loads((p/'forge-snapshot.json').read_text())['scope_state']
    assert scope=={'issue':1,'pr':None,'branch':None,'commits':0}
    a['publication_scope_by_phase'].append(scope)
p=D/'glm-spam-final-audit.json'
assert not p.exists()
p.write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'audit_complete':True,'classification':a['classification'],'total_coding_minutes':sum(a['phase_actor_seconds'])/60,'GPU_peak_MiB':a['peak_gpu_MiB']}))

