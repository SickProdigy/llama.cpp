"""Bounded isolated memory pilots; no actor, forge credentials or grading inputs."""
from pathlib import Path
import sys,os,json,time,hashlib,subprocess,urllib.request,threading,signal,traceback,re,shutil
D=Path('/state');KEY=sys.argv[1];assert KEY in ['q3','devstral','glm'];P=json.loads((D/'remaining-resource-protocol.json').read_text());S=D/('remaining-resource-'+KEY);S.mkdir(exist_ok=False)
MODEL=P[KEY];ALIAS='wide-'+KEY.lower();NET='hermes-wide-resource-'+KEY;MAIN='hermes-wide-resource-'+KEY+'-model';BACKEND=P['backend_image'];owned=None;network=None;stopped=False;before={};monitor_stop=threading.Event();abort=threading.Event();thread=None

def save(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def event(kind,**kw):
 row={'epoch':time.time(),'kind':kind,**kw}
 with(S/'events.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
def docker(*args,check=True,timeout=180):
 z=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and z.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+z.stderr[-1200:])
 return z.stdout

def inspect(name):return json.loads(docker('inspect',name))[0]
def state(name):
 x=inspect(name);return {'id':x['Id'],'image':x['Image'],'config_sha256':hashlib.sha256(json.dumps({k:x[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()).hexdigest(),'running':x['State']['Running'],'started':x['State']['StartedAt'],'restarts':x['RestartCount']}
def http(host,path,body=None,timeout=60):
 req=urllib.request.Request('http://'+host+':11430'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=timeout)as response:raw=response.read()
 return json.loads(raw),raw

def ready(name,alias,ctx,timeout):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  if abort.is_set():raise RuntimeError('Pilot memory guard')
  if not inspect(name)['State']['Running']:raise RuntimeError('Backend exited before ready')
  try:
   props,_=http(name,'/props',timeout=10);health,_=http(name,'/health',timeout=10)
   if props['model_alias']==alias and props['default_generation_settings']['n_ctx']==ctx and health['status']=='ok':return props
  except(OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Backend readiness expired')

def host_memory():
 mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());return {'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
def monitor(out):
 command='for f in /sys/fs/cgroup/memory.current /sys/fs/cgroup/memory.peak /sys/fs/cgroup/memory.swap.current /sys/fs/cgroup/memory.events /sys/fs/cgroup/memory.stat /proc/[0-9]*/smaps_rollup; do printf "FILE %s\\n" "$f"; cat "$f" 2>/dev/null; done'
 while not monitor_stop.is_set():
  row={'epoch':time.time(),'containers':{},'model_disk_free_bytes':shutil.disk_usage('/models').free}
  try:
   mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());row['host']={'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
   cg_total=0;pss_total=0;swap_total=0
   targets={MAIN:owned,'supervisor':inspect(os.environ['HOSTNAME'])['Id']}
   for ident in docker('ps','-q','--filter','label=hermes.wide.study=20261123',timeout=20).split():
    item=inspect(ident);targets[item['Name'].lstrip('/')]=item['Id']
   unique={ident:name for name,ident in targets.items()}
   for ident,name in unique.items():
    raw=docker('exec',ident,'/bin/sh','-c',command,check=False,timeout=25)
    match=re.search(r'FILE /sys/fs/cgroup/memory.current\n(\d+)',raw);current=int(match.group(1))if match else 0
    match=re.search(r'FILE /sys/fs/cgroup/memory.swap.current\n(\d+)',raw);swap=int(match.group(1))if match else 0
    pss=sum(int(n)*1024 for n in re.findall(r'^Pss:\s*(\d+) kB',raw,re.M))
    row['containers'][name]={'raw':raw,'pss_all_processes_bytes':pss,'cgroup_current_bytes':current,'cgroup_swap_bytes':swap};cg_total+=current;pss_total+=pss;swap_total+=swap
   row.update(total_cgroup_bytes=cg_total,total_process_pss_bytes=pss_total,total_cgroup_swap_bytes=swap_total)
   row['gpu_csv']=docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits',check=False,timeout=20).strip()
   if cg_total>8*1024**3 or pss_total>8*1024**3 or swap_total or mem['MemAvailable']<4*1024**3 or row['model_disk_free_bytes']<100*1024**3:
    row['budget_guard_triggered']=True;row['disk_reserve_guard_triggered']=row['model_disk_free_bytes']<100*1024**3;abort.set()
    if owned and inspect(MAIN)['Id']==owned:docker('stop','-t','10',owned,check=False)
  except Exception as error:row['measurement_error']=type(error).__name__+': '+str(error)
  with out.open('a')as f:f.write(json.dumps(row)+'\n')
  monitor_stop.wait(5)

def measure(body):
 prompt,_=http(MAIN,'/apply-template',{'messages':body['messages'],'tools':body.get('tools',[]),'chat_template_kwargs':body.get('chat_template_kwargs',{})});tokens,_=http(MAIN,'/tokenize',{'content':prompt['prompt'],'add_special':True,'parse_special':True});return len(tokens['tokens'])
def request(messages):
 body={'model':ALIAS,'messages':messages,'seed':20261123,'max_tokens':MODEL['probe_output_cap'],'stream':False}
 body.update(MODEL['sampler']);return body

def call(out,body,kind):
 assert not abort.is_set(),'Resource guard latched before request'
 out.mkdir();save(out/'request.json',body);count=measure(body);save(out/'input.json',{'rendered_tokens':count,'context':layout['context'],'kind':kind});assert count+body['max_tokens']<layout['context'];event('probe_start',probe=kind,input_tokens=count)
 start=time.monotonic();result,raw=http(MAIN,'/v1/chat/completions',body,P['per_probe_deadline_seconds']);elapsed=time.monotonic()-start;(out/'response.bin').write_bytes(raw);usage=result.get('usage',{});assert isinstance(usage.get('prompt_tokens'),int);assert usage['prompt_tokens']==count,(count,usage);assert result.get('choices')
 save(out/'capture.json',{'body_complete':True,'seconds':elapsed,'usage':usage,'finish_reason':result['choices'][0].get('finish_reason'),'response_sha256':hashlib.sha256(raw).hexdigest(),'timings':result.get('timings')});event('probe_end',probe=kind,seconds=elapsed);return result

def stop_model():
 global owned,thread
 monitor_stop.set()
 if thread:thread.join(150);assert not thread.is_alive();thread=None
 if owned:
  assert inspect(MAIN)['Id']==owned;x=inspect(MAIN);save(current/'exit-state.json',{'running':x['State']['Running'],'exit_code':x['State']['ExitCode'],'oom_killed':x['State']['OOMKilled'],'memory_limit':x['HostConfig']['Memory'],'memory_swap_limit':x['HostConfig']['MemorySwap']});z=subprocess.run(['docker','logs',owned],capture_output=True);(current/'backend.log').write_bytes(z.stdout+z.stderr);docker('rm','-f','-v',owned);owned=None

def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(P['per_model_stage_guard_seconds'])
try:
 registration=json.loads((D/'remaining-resource-controller-registration.json').read_text());assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==registration['controller_sha256'];assert hashlib.sha256((D/'remaining-resource-protocol.json').read_bytes()).hexdigest()==registration['protocol_sha256']
 assert shutil.disk_usage('/models').free>=100*1024**3,'Disk reserve before resource stage'
 for ident in docker('ps','-q','--filter','label=hermes.wide.study=20261123').split():
  assert ident==os.environ['HOSTNAME'] or inspect(ident)['Id']==inspect(os.environ['HOSTNAME'])['Id'],'Other study job still active; no overlapping GPU stage'
 before={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};assert all(x['running']for x in before.values());save(S/'runtime-before.json',before);save(S/'host-before.json',host_memory());model=Path('/models')/MODEL['file'];assert model.is_file()
 h=hashlib.sha256()
 with model.open('rb')as f:
  for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
 assert h.hexdigest()==MODEL['sha256'] and model.stat().st_size==MODEL['expected_bytes']
 with model.open('rb')as f:os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 save(S/'model-identity.json',{'file':model.name,'bytes':model.stat().st_size,'sha256':h.hexdigest(),'specific_study_file_advised_DONTNEED_after_hash':True,'not_global_cache_flush_or_cold_cache_proof':True})
 assert subprocess.run(['docker','inspect',MAIN],capture_output=True).returncode!=0
 network=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME']);stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 results=[]
 for index,layout in enumerate(MODEL['layouts']):
  current=S/('layout'+str(index));current.mkdir();abort.clear();monitor_stop.clear();passed=False
  try:
   launch=['--network',NET,'--gpus','all','--memory','6656m','--memory-swap','6656m','--cpus','8','--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=128m','--no-healthcheck',BACKEND,'-m','/models/'+MODEL['file'],'--load-mode',P['load_mode'],'--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(layout['context']),'--parallel','1','--cache-type-k',layout.get('cache_k','q4_0'),'--cache-type-v',layout.get('cache_v','q4_0'),'--cache-ram','512','--ctx-checkpoints','2','--fit','off','-ngl',str(layout['gpu_layers']),'--threads','8','--threads-batch','8','--poll','0','--poll-batch','0','-b','512','-ub','128','--n-predict',str(MODEL['probe_output_cap'])]
   if 'cpu_moe_layers'in layout:launch+=['--n-cpu-moe',str(layout['cpu_moe_layers'])]
   start=time.monotonic();owned=docker('run','-d','--pull','never','--name',MAIN,'--label','hermes.wide.study=20261123',*launch).strip();save(current/'launch.json',{'argv':launch,'layout':layout,'container_id':owned});thread=threading.Thread(target=monitor,args=(current/'samples.jsonl',),daemon=True);thread.start();props=ready(MAIN,ALIAS,layout['context'],P['load_deadline_seconds']);save(current/'ready.json',{'seconds':time.monotonic()-start,'props':props});event('backend_ready',layout=layout)
   body=request([{'role':'user','content':'Use lookup_record to retrieve the record named memory-probe. Make the tool call now.'}]);body['tools']=[{'type':'function','function':{'name':'lookup_record','description':'Retrieve one named local test record.','parameters':{'type':'object','properties':{'name':{'type':'string'}},'required':['name'],'additionalProperties':False}}}];result=call(current/'tool',body,'one_tool_call');calls=result['choices'][0]['message'].get('tool_calls')or[];tool_ok=False
   for c in calls:
    try:tool_ok=tool_ok or (c.get('function',{}).get('name')=='lookup_record'and json.loads(c['function']['arguments'])=={'name':'memory-probe'})
    except(ValueError,TypeError,KeyError):pass
   save(current/'tool-check.json',{'valid_tool_call':tool_ok,'not_actual_MCP_routing':True})
   if tool_ok:
    assistant=result['choices'][0]['message'];assert isinstance(assistant.get('tool_calls'),list)
    # The model's actual assistant record is retained, including reasoning.
    follow=request(body['messages']+[assistant,*[{'role':'tool','tool_call_id':c['id'],'content':json.dumps({'name':'memory-probe','code':'tool-history-capacity-ok'})}for c in assistant['tool_calls']]])
    follow['tools']=body['tools']
    follow['messages'].append({'role':'user','content':'What code did that lookup return? Reply with only the code.'})
    rendered,_=http(MAIN,'/apply-template',{'messages':follow['messages'],'tools':follow['tools'],'chat_template_kwargs':follow.get('chat_template_kwargs',{})})
    reasoning=assistant.get('reasoning_content')or''
    save(current/'tool-history-template.json',{'actual_reasoning_nonempty':bool(reasoning),'actual_reasoning_retained_in_rendered_template':reasoning in rendered['prompt']if reasoning else None,'not_replaced_with_operator_reasoning':True})
    follow_result=call(current/'tool-followup',follow,'dependent_tool_history')
    save(current/'tool-followup-check.json',{'expected':'tool-history-capacity-ok','content':follow_result['choices'][0]['message'].get('content'),'not_actual_MCP_or_coding_quality':True})
   for target in P['synthetic_prompt_targets']:
    lines=1000
    for attempt in range(5):
     content='Resource capacity probe. Read the records, then reply with ONLY the value of FINAL_MARKER.\n'+'\n'.join('Record '+str(i)+': amber cedar lake stone north south.'for i in range(lines))+'\nFINAL_MARKER=capacity-check-'+str(target)
     body=request([{'role':'user','content':content}]);actual=measure(body)
     if abs(actual-target)<=target*.05:break
     lines=max(1,round(lines*target/actual))
    else:raise RuntimeError('Synthetic prompt sizing failed')
    result=call(current/('prompt'+str(target)),body,'synthetic_'+str(target));save(current/('prompt'+str(target))/'retrieval-check.json',{'expected':'capacity-check-'+str(target),'content':result['choices'][0]['message'].get('content'),'not_agent_quality':True})
   passed=True;results.append({'layout':layout,'resource_probes_completed':True,'tool_call_correct':tool_ok,'no_agent_quality_claim':True});save(current/'result.json',results[-1])
  except Exception as e:
   backend_state=inspect(MAIN)['State']if owned else{}
   log_result=subprocess.run(['docker','logs',owned],capture_output=True,text=True,timeout=60)if owned else None
   backend_log=(log_result.stdout+log_result.stderr)if log_result else''
   gpu_oom=any(text in backend_log.lower()for text in ['cuda error: out of memory','cuda out of memory','cudamalloc failed','cuda_error_out_of_memory'])
   retry_gpu_layout=gpu_oom and not backend_state.get('OOMKilled',False)and not abort.is_set()
   result={'layout':layout,'resource_probes_completed':False,'error':type(e).__name__+': '+str(e),'no_model_quality_score':True,'backend_state':backend_state,'GPU_OOM_log_marker':gpu_oom,'retry_next_GPU_layout':retry_gpu_layout};results.append(result);save(current/'result.json',result);event('layout_error',error=str(e))
  finally:stop_model()
  if passed or not results[-1].get('retry_next_GPU_layout',False):break
 save(S/'finished.json',{'results':results,'model':KEY,'not_agent_qualification':True})
except BaseException as e:save(S/'controller-error.json',{'error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc()});event('controller_error',error=str(e))
finally:
 signal.alarm(0);errors=[]
 try:
  if owned:stop_model()
 except BaseException as e:errors.append(str(e))
 try:
  if stopped:abort.clear();docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304,600);docker('start','hermes')
  after={n:state(n)for n in before}
  for n,b in before.items():assert all(after[n][k]==b[k]for k in ['id','image','config_sha256','running'])
  if before:assert after['hermes-codex']==before['hermes-codex']
  if network:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network and not net['Containers'];docker('network','rm',network)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors,'host_after':host_memory()});event('original_runtime_restored')
 except BaseException as e:save(S/'RESTORATION-ERROR.json',{'error':str(e),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(e))
