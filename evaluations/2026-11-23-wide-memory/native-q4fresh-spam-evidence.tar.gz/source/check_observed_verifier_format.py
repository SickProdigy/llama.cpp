"""Isolated public-format controls, never candidate quality evidence or actor feedback."""
from pathlib import Path
import json,hashlib,tarfile,io,subprocess,sys,copy
D=Path(__file__).resolve().parent;R=D.parent.parent;E=R/'evaluations/2026-11-23-wide-memory';C=D/'observed-outcome-verifier-format-controls';C.mkdir(exist_ok=False);label='native-q3-queue';sha=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(E/(label+'-evidence.tar.gz'))as t:
 assert all(m.isfile()for m in t.getmembers());base={m.name:t.extractfile(m).read()for m in t.getmembers()}
def load(f,n):return json.loads(f[n])
def put(f,n,x):f[n]=(json.dumps(x,indent=2)+'\n').encode()
a=load(base,'summary.json');audit=a['independent_final_audit'];audit['observed_grades_by_phase']=[];audit['test_log_sha256_by_phase']=[];audit['source_changes_from_previous_phase']=[];audit['native_exit_by_phase']=[];audit['publication_scope_by_phase']=[];prev=None
for phase in range(3):
 p='phases/'+str(phase);row=a['phases'][phase];row['remote_grade_absent']=False;kinds=['local-grade','remote-grade'];audit['observed_grades_by_phase'].append({k:load(base,p+'/'+k+'/grade.json')for k in kinds});audit['test_log_sha256_by_phase'].append({k:{n:sha(base[p+'/'+k+'/'+n])for n in ['project.log','preservation.log']}for k in kinds});cur=load(base,p+'/local-grade/source-sha256.json');audit['source_changes_from_previous_phase'].append(None if prev is None else sorted(n for n in set(prev)|set(cur)if prev.get(n)!=cur.get(n)));prev=cur;run=load(base,p+'/run.json');audit['native_exit_by_phase'].append({k:run[k]for k in ['exit_code','external_timeout']});audit['publication_scope_by_phase'].append(load(base,p+'/forge-readback.json')['scope_state'])
audit['publication_independently_audited']=True;audit['test_issue_cleanup_independently_verified']=True;put(base,'summary.json',a);put(base,'audits/q3-queue-final-audit.json',audit)
def execute(name,files,should_pass):
 out=C/name;out.mkdir();put(files,'manifest.json',{'sha256':{n:sha(raw)for n,raw in sorted(files.items())if n!='manifest.json'},'scope':'Synthetic verifier-format control derived from an existing sanitized Q3 archive; not new candidate evidence.'});arc=out/(label+'-evidence.tar.gz')
 with tarfile.open(arc,'w:gz')as t:
  for n,raw in sorted(files.items()):
   info=tarfile.TarInfo(n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
 (out/(label+'-evidence.sha256')).write_text(sha(arc.read_bytes())+'  '+arc.name+'\n');(out/(label+'-summary.json')).write_bytes(files['summary.json']);ver=out/'verify_candidate_native_observed.py';ver.write_bytes((D/ver.name).read_bytes());p=subprocess.run([sys.executable,str(ver),'q3','queued_announcements'],capture_output=True,text=True);(out/'verifier.stdout').write_text(p.stdout);(out/'verifier.stderr').write_text(p.stderr);assert(p.returncode==0)==should_pass,(name,p.stderr[-1200:]);return{'case':name,'expected_pass':should_pass,'observed_exit':p.returncode,'matched_expectation':True}
results=[execute('consistent_existing_observations',dict(base),True)];changed=dict(base);g=load(changed,'phases/0/local-grade/grade.json');g['preservation_exit']=1;put(changed,'phases/0/local-grade/grade.json',g);results.append(execute('unreported_preservation_failure',changed,False));changed={n:v for n,v in base.items()if not n.startswith('phases/0/remote-grade/')};results.append(execute('unreported_missing_remote_grade',changed,False));result={'passed':True,'not_actor_feedback':True,'not_model_inference_or_quality_evidence':True,'verifier_sha256':sha((D/'verify_candidate_native_observed.py').read_bytes()),'cases':results};(C/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
