"""Post-run public-callback observations with immutable original fake peers."""
from pathlib import Path
import importlib.util,json,hashlib
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('immutable_spam_fixture','/fixtures/test_autospamignore.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);f.PLUGIN_PATH=Path('/workspace/autospamignore/__init__.py');f.AutoSpamIgnoreTests.setUpClass()
def make(cooldown=60):
 c=f.AutoSpamIgnoreTests();c.setUp();c.plugin.settings.update(blocked_countries='RU',blocked_phrases='blocked phrase',notify_local_room=True,notify_desktop=True,rule_alert_cooldown_seconds=cooldown);return c
def send(c,t,user='shared',room='Books',line='hello'):
 with patch.object(c.module.time,'monotonic',return_value=t):c.plugin.incoming_public_chat_notification(room,user,line)
def state(c):return{'logs':len(c.plugin.logs),'local':len(c.plugin.local_room_messages),'desktop':len(c.plugin.core.notifications.shown),'ignored':list(c.network_filter.ignored)}
def notices(c,n):
 s=state(c);return s['logs']==s['local']==s['desktop']==n
def zero_and_boundary():
 c=make();c.plugin.core.users.countries['shared']='RU';send(c,0);a=state(c);send(c,59);b=state(c);send(c,60);d=state(c);return{'first':a,'inside':b,'at_boundary':d,'passed':a['logs']==a['local']==a['desktop']==1 and a==b and notices(c,2)}
def isolation_and_priority():
 c=make();c.plugin.core.users.countries.update(shared='RU',other='RU');send(c,10000,line='blocked phrase');first=state(c);country_first='country code RU'in c.plugin.logs[0][0];c.plugin.core.users.countries['shared']='US';send(c,10001,line='blocked phrase');different_rule=state(c);send(c,10002,line='blocked phrase');repeat=state(c);c.plugin.core.users.countries['shared']='RU';send(c,10003);old_country=state(c);send(c,10004,room='Linux');different_room=state(c);send(c,10005,user='other');different_user=state(c);return{'both_match_first_only_country':country_first,'first':first,'same_user_room_different_rule':different_rule,'same_rule_repeat':repeat,'original_country_still_suppressed':old_country,'different_room':different_room,'different_user':different_user,'passed':country_first and first['logs']==1 and different_rule['logs']==2 and repeat==different_rule==old_country and different_room['logs']==3 and notices(c,4)}
def reset_isolation():
 c=make(600);c.plugin.core.users.countries.update(alice='RU',bob='RU');send(c,10000,user='alice');send(c,10001,user='bob');c.plugin.spam_reset_command('ALICE');send(c,10002,user='bob');other=state(c);send(c,10003,user='alice');selected=state(c);c.plugin.spam_reset_command('');send(c,10004,user='bob');send(c,10005,user='alice');global_reset=state(c);return{'other_user_after_selected_reset':other,'selected_user_after_reset':selected,'after_global_reset':global_reset,'passed':other['logs']==2 and selected['logs']==3 and notices(c,5)and global_reset['ignored']==[]}
def ordinary_cleanup_keeps_unexpired_rule():
 c=make(1800);c.plugin.core.users.countries['shared']='RU';send(c,10000);send(c,10090,user='normal');send(c,10091);unexpired=state(c);send(c,11800);expired=state(c);return{'after_ordinary_rate_callback_cleanup_and_unexpired_rule':unexpired,'at_rule_expiry':expired,'passed':unexpired['logs']==1 and notices(c,2)}
def enforcement_bypass():
 c=make(3600);c.plugin.core.users.countries['shared']='RU';send(c,10000);c.plugin.settings['enforce_ignores']=True;send(c,10001);enforced=state(c);send(c,10002);repeated=state(c);return{'enforced_inside_cooldown':enforced,'already_ignored_callback':repeated,'passed':enforced['ignored']==['shared']and enforced==repeated and notices(c,2)}
def bounds():
 rows=[]
 for raw,seconds in [(0,1),(99999,3600),('not-an-integer',60)]:
  c=make(raw);c.plugin.core.users.countries['shared']='RU';send(c,10000);send(c,10000+seconds-0.25);inside=state(c);send(c,10000+seconds);at=state(c);rows.append({'setting':raw,'expected_effective_seconds':seconds,'inside':inside,'at_boundary':at,'passed':inside['logs']==1 and notices(c,2)})
 return{'cases':rows,'passed':all(x['passed']for x in rows)}
results={}
for name,fn in [('zero_clock_and_exact_expiry',zero_and_boundary),('rule_room_user_isolation_and_original_priority',isolation_and_priority),('selected_and_global_reset',reset_isolation),('normal_cleanup_preserves_unexpired_long_cooldown',ordinary_cleanup_keeps_unexpired_rule),('enforcement_bypasses_cooldown',enforcement_bypass),('bounded_settings',bounds)]:
 try:results[name]=fn()
 except Exception as e:results[name]={'passed':False,'error_class':type(e).__name__,'error_message':str(e)}
print(json.dumps({'not_actor_feedback':True,'captured_phase':2,'source_sha256':hashlib.sha256(f.PLUGIN_PATH.read_bytes()).hexdigest(),'immutable_fixture_sha256':hashlib.sha256(Path('/fixtures/test_autospamignore.py').read_bytes()).hexdigest(),'results':results,'all_observed_cases_passed':all(r['passed']for r in results.values()),'scope':'Immutable fake-peer public callbacks and reset command; zero/high monotonic clocks, actual notice channels, original country-before-phrase priority and normal cleanup trigger. Not full GUI/network integration or autonomous reliability.'}))
