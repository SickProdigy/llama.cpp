"""Exact scoped actor-authenticated readonly fork audit; credentials stdin only."""
from pathlib import Path
import subprocess,json,time,hashlib
D=Path(__file__).resolve().parent
container=json.loads(subprocess.check_output(['docker','inspect','mcp-gitea-hermes'],text=True))[0];env=dict(v.split('=',1)for v in container['Config']['Env']);credentials={'host':env['GITEA_HOST'].rstrip('/'),'token':env['GITEA_ACCESS_TOKEN']}
code='''import json,sys,urllib.request,time
c=json.load(sys.stdin)
def get(path):
 req=urllib.request.Request(c['host']+'/api/v1/'+path,headers={'Authorization':'token '+c['token']})
 with urllib.request.urlopen(req,timeout=15)as r:return json.load(r)
u=get('user');assert u['login']=='hermes-agent'
r=get('repos/hermes-agent/hermes-wide-q4fresh-20261124');assert r['id']==34333 and r['fork']and r['parent']['id']==34332 and r['parent']['full_name']=='chatgpt-codex/hermes-wide-q4fresh-20261124'
b=get('repos/hermes-agent/hermes-wide-q4fresh-20261124/branches?limit=50')
print(json.dumps({'epoch':time.time(),'actor_identity':u['login'],'personal_fork':r['full_name'],'fork_id':r['id'],'parent':r['parent']['full_name'],'parent_id':r['parent']['id'],'fork_branches':[{'name':v['name'],'head':v['commit']['id']}for v in b],'credentials_via_stdin_not_persisted':True,'read_only_not_actor_feedback':True,'interim_not_final_phase_audit':False,'final_after_native_stage':True,'read_only_API_fallback':'Connector cannot see actor private fork; exact actor-authenticated GET user, private fork metadata and branches only.'}))
'''
a=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','homelab','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','128m','--memory-swap','128m','--cpus','1','-i','-e','NVIDIA_VISIBLE_DEVICES=void','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint','python','sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae','-c',code]
r=subprocess.run(a,input=json.dumps(credentials),capture_output=True,text=True,timeout=60);assert r.returncode==0,'Read-only helper failed; credentials not printed';result=json.loads(r.stdout);result['helper_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();out=D/'q4fresh-spam-fork-independent-readback.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
