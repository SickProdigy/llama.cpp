"""Read-only callback controls against captured README-stage source and original fakes."""
from pathlib import Path
import importlib.util,json,hashlib
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('immutable_spam_fixture','/fixtures/test_autospamignore.py');fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture);fixture.PLUGIN_PATH=Path('/workspace/autospamignore/__init__.py');fixture.AutoSpamIgnoreTests.setUpClass()
results={}
for rule in ['rate','country','phrase']:
 c=fixture.AutoSpamIgnoreTests();c.setUp();c.plugin.settings['notify_local_room']=True;c.plugin.settings['notify_desktop']=True
 if rule=='country':c.plugin.settings['blocked_countries']='RU';c.plugin.core.users.countries['spammer']='RU'
 if rule=='phrase':c.plugin.settings['blocked_phrases']='blocked phrase'
 def send(t):
  with patch.object(c.module.time,'monotonic',return_value=t):c.plugin.incoming_public_chat_notification('Books','spammer','blocked phrase'if rule=='phrase'else'message')
 for t in ([1,2,3]if rule=='rate'else[1]):send(t)
 assert c.network_filter.ignored==[]and len(c.plugin.logs)==1 and'Would ignore'in c.plugin.logs[0][0]
 c.plugin.settings['enforce_ignores']=True;assert c.network_filter.ignored==[]
 send(4);assert c.network_filter.ignored==['spammer']and len(c.plugin.logs)==2 and'Ignored spammer'in c.plugin.logs[-1][0]
 send(5);assert c.network_filter.ignored==['spammer']and len(c.plugin.logs)==2
 c.plugin.settings['enforce_ignores']=False;send(6);assert c.network_filter.ignored==['spammer']and len(c.plugin.logs)==2
 results[rule]={'log_only_notice_count_before_toggle':1,'ignore_before_next_callback':False,'ignore_after_next_qualifying_callback':list(c.network_filter.ignored),'total_log_count_after_enforce_and_repeated_callbacks':len(c.plugin.logs),'local_notice_count':len(c.plugin.local_room_messages),'desktop_notice_count':len(c.plugin.core.notifications.shown),'switching_off_did_not_unignore':True,'plugin_ignored_user_guard_prevents_further_notices':True}
print(json.dumps({'not_actor_feedback':True,'captured_phase':1,'source_sha256':hashlib.sha256(fixture.PLUGIN_PATH.read_bytes()).hexdigest(),'README_sha256':hashlib.sha256(Path('/workspace/autospamignore/README.md').read_bytes()).hexdigest(),'immutable_fixture_sha256':hashlib.sha256(Path('/fixtures/test_autospamignore.py').read_bytes()).hexdigest(),'results':results,'scope':'Actual captured plugin public callback with immutable fake peers; verifies plugin guard and actions, not Soulseek packet delivery or full GUI/network integration.'}))
