"""Post-run primary context retention audit; raw tasks/requests stay private."""
from pathlib import Path
import json,hashlib,time
D=Path(__file__).resolve().parent;S=D/'native-q4-matched-fresh-cp2/spam_enforcement';L=S/'llm-records';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();tasks=read(D/'tasks.json')['families']['spam_enforcement'];events=[json.loads(x)for x in(S/'events.jsonl').read_text().splitlines()];phases=[]
def text(m):
 v=m.get('content','')
 return v if isinstance(v,str)else'\n'.join(x.get('text','')for x in(v or[])if isinstance(x,dict))
for phase in range(3):
 run=read(S/'q4fresh'/f'turn{phase}/run.json');start=next(x['epoch']for x in events if x['kind']=='turn_start'and x.get('phase')==phase);end=next(x['epoch']for x in events if x['kind']=='turn_end'and x.get('phase')==phase);observed=[];complete=[]
 for p in sorted(L.glob('*.metrics.json')):
  m=read(p)
  if not(start<=m['received_epoch']<=end):continue
  qpath=p.with_name(p.name.replace('.metrics.json','.request.json'));q=read(qpath)
  if len(q.get('tools',[]))!=33:continue
  observed.append((m,qpath,q));raw=p.with_name(p.name.replace('.metrics.json','.response.txt')).read_bytes();body=raw.rstrip().endswith(b'data: [DONE]')
  if not body and raw.lstrip().startswith(b'{'):
   try:body=bool(json.loads(raw).get('choices'))
   except ValueError:pass
  if body and not m.get('transport_error')and not m.get('response_parse_failed')and m.get('usage'):complete.append((m,qpath,q))
 assert observed and complete
 m,qpath,q=complete[-1];containers=[[{'index':i,'role':v['role']}for i,v in enumerate(q['messages'])if task in text(v)]for task in tasks[:phase+1]]
 phases.append({'phase':phase,'completed_phase':True,'last_complete_HTTP_id':m['id'],'prompt_tokens':m['usage']['prompt_tokens'],'saved_request_JSON_sha256':sha(qpath),'wire_request_sha256_from_proxy_metrics':m['request_sha256'],'expected_task_text_presence':[bool(x)for x in containers],'all_expected_task_texts_present':all(containers),'original_issue_fork_PR_task_still_present':bool(containers[0]),'task_role_containers':containers,'user_message_count':sum(x['role']=='user'for x in q['messages']),'primary_tool_count':len(q['tools']),'last_observed_primary_HTTP_id':observed[-1][0]['id'],'last_observed_primary_incomplete':observed[-1][0]['id']!=m['id'],'native_exit_code':run['exit_code']})
a={'observed_epoch':time.time(),'not_actor_feedback':True,'classification':'Final completed primary request retention inspection, not attention or quality proof','final_feature_phase_still_pending':False,'phases':phases,'first_coding_request_actual_cached_tokens':read(D/'q4fresh-spam-read-control-audit.json')['first_coding_actual_cached_tokens'],'native_compression_lineage_lengths_by_phase':[len(read(S/'q4fresh'/f'turn{p}/run.json').get('lineage',[]))for p in range(3)],'limits':['Exact task presence is inspected in real saved primary requests; it does not prove attention or reasoning.','Saved pretty JSON hashes and wire-body hashes are distinct fingerprints.','Incomplete last observations are recorded separately from the last complete primary response.','Auxiliary requests without the33primarytools are excluded from primary phase selection.','Any missing task text remains an observed limitation, not repaired with corrective prompts.','No grader feedback, neutral continuation or task restatement was supplied.','One three-turn lineage is not autonomous reliability.']}
out=D/'q4fresh-spam-context-instruction-audit.json';assert not out.exists();out.write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({'completed_context_audit':True,'last_complete_primary_ids':[x['last_complete_HTTP_id']for x in phases],'task_presence_by_phase':[x['expected_task_text_presence']for x in phases]}))
