"""Independent operator control on pinned published bytes, never actor feedback."""
from pathlib import Path
import ast,json,subprocess,hashlib,shutil,time
D=Path(__file__).resolve().parent;O=D/'q4-first-published-test-adequacy';O.mkdir(exist_ok=False)
EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-wide-memory-20261123'
IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
root=D/'worktrees/q4-spam-published-first-head';head=subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'rev-parse','HEAD'],text=True).strip();assert head=='fad4f886b6cec54a4f9fc3679409e019f1c81e54'
def inventory(root):
 files={}
 for f in root.rglob('*'):
  rel=f.relative_to(root)
  if any(x in {'.git','__pycache__','.pytest_cache'}for x in rel.parts)or f.name=='AGENTS.md':continue
  assert not f.is_symlink()
  if f.is_file():files[str(rel)]=f.read_bytes()
 return files
base=inventory(D/'baseline');candidate=inventory(root);changed=[n for n in sorted(set(base)|set(candidate))if base.get(n)!=candidate.get(n)];assert changed==['autospamignore/README.md','autospamignore/__init__.py','tests/test_autospamignore.py']
path='tests/test_autospamignore.py';old=ast.parse(base[path]);new=ast.parse(candidate[path]);oldclass=next(n for n in old.body if isinstance(n,ast.ClassDef)and n.name=='AutoSpamIgnoreTests');newclass=next(n for n in new.body if isinstance(n,ast.ClassDef)and n.name==oldclass.name);oldnames={n.name for n in oldclass.body if isinstance(n,ast.FunctionDef)};added=[n.name for n in newclass.body if isinstance(n,ast.FunctionDef)and n.name not in oldnames];newclass.body=[n for n in newclass.body if not(isinstance(n,ast.FunctionDef)and n.name in added)];assert ast.dump(old)==ast.dump(new),'Existing test code changed';assert len(added)==3
results=[]
for kind,files in [('published',candidate),('original_with_published_tests',dict(base,**{path:candidate[path]}))]:
 out=O/kind;out.mkdir();source=out/'source';source.mkdir()
 for name,data in files.items():
  f=source/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 source_identity={n:hashlib.sha256(data).hexdigest()for n,data in sorted(files.items())};(out/'source-sha256.json').write_text(json.dumps(source_identity,indent=2)+'\n')
 args=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','384m','--memory-swap','384m','--cpus','1','--tmpfs','/tmp:rw,size=64m','--mount','type=bind,source='+EP+'/'+str(source.relative_to(D))+',target=/workspace,readonly','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','-w','/workspace','--entrypoint','python',IMAGE,'-m','pytest','-q','-p','no:cacheprovider','tests']
 start=time.monotonic();r=subprocess.run(args,capture_output=True,text=True,timeout=90);(out/'pytest.log').write_text(r.stdout+r.stderr);row={'kind':kind,'returncode':r.returncode,'seconds':time.monotonic()-start,'argv':args};results.append(row)
 assert r.returncode==(0 if kind=='published'else 1),(kind,r.stdout[-1500:],r.stderr[-500:])
 if kind=='published':assert '86 passed'in r.stdout
 else:
  assert '1 failed, 85 passed'in r.stdout
  assert 'FAILED tests/test_autospamignore.py::AutoSpamIgnoreTests::test_switching_enforcement_on_actually_ignores_next_qualifying_message'in r.stdout
summary={'passed':True,'head':head,'changed_paths':changed,'existing_test_AST_preserved':True,'new_test_methods':added,'published_full_suite':'86 passed','original_with_published_tests':'1 failed, 85 passed','meaningful_bug_catching_new_tests':1,'not_all_three_new_tests_detect_original_bug':True,'private_behavioral_grades_separate':True,'not_actor_feedback':True,'not_whole_task_or_reliability_verdict':True,'results':results};(O/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='results'},indent=2))
