"""Fresh read-only restoration and owner-worktree audit after a completed GPU stage."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,urllib.request
R=Path.cwd();D=R/'.git/hermes-wide-memory-20261123';key=sys.argv[1];assert key in ['native-q4-recovery','native-q4-fresh'];S=D/({'native-q4-recovery':'native-q4-recovery-cp2/spam_enforcement','native-q4-fresh':'native-q4-fresh-cp2/queued_announcements'}[key]);assert json.loads((S/'runtime-restoration.json').read_text())['restored'];B=json.loads((D/'resource-q4-after.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def docker(*args):return subprocess.check_output(['docker',*args],text=True)
c={}
for name in ['hermes','llama-cpp','hermes-codex']:
 x=json.loads(docker('inspect',name))[0];c[name]={'id':x['Id'],'image':x['Image'],'configuration_signature':sha(json.dumps({k:x[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()),'running':x['State']['Running'],'started':x['State']['StartedAt'],'restarts':x['RestartCount'],'health':x['State'].get('Health',{}).get('Status')}
for name in c:
 for field in ['id','image','configuration_signature','running']:assert c[name][field]==B['containers'][name][field]
assert c['hermes-codex']==B['containers']['hermes-codex']
source="from pathlib import Path;import json,hashlib,shutil;p=Path('/models');print(json.dumps({'profile_hashes':{n:hashlib.sha256((Path('/opt/data')/n).read_bytes()).hexdigest()for n in ['config.yaml','.env','auth.json','SOUL.md']},'models':{'free_bytes':shutil.disk_usage(p).free,'files':[{'name':f.name,'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}for f in sorted(p.glob('*.gguf'))]}}))"
a=['run','--rm','--label','hermes.wide.study=20261123','--memory','256m','--memory-swap','256m','--runtime','runc','--network','none','--read-only','--cap-drop','ALL','--cap-add','DAC_OVERRIDE','--volumes-from','llama-cpp:ro','--volumes-from','hermes:ro','-e','NVIDIA_VISIBLE_DEVICES=void','--entrypoint','python','sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae','-c',source];x=json.loads(docker(*a));assert x['profile_hashes']==B['profile_hashes'];assert x['models']['files']==B['models']['files'];assert x['models']['free_bytes']>=100*1024**3
with urllib.request.urlopen('http://192.168.86.239:11430/props',timeout=15)as f:props=json.load(f)
assert props['model_alias']=='qwen3.6-14b-a3b-vibeforged-v2-q4_k_m'and props['default_generation_settings']['n_ctx']==98304
snapshot={'epoch':time.time(),'containers':c,**x,'props':{k:props[k]for k in ['model_alias','model_path','default_generation_settings']}};(D/(key+'-after.json')).write_text(json.dumps(snapshot,indent=2)+'\n')
preservation={'original_ids_images_configuration_running_preserved':True,'codex_entire_snapshot_unchanged':True,'four_profile_hashes_unchanged':True,'all_30_model_metadata_unchanged':True,'original_alias_context_restored':True,'at_least_100_GiB_free':True,'free_GiB':x['models']['free_bytes']/1024**3};(D/(key+'-preservation.json')).write_text(json.dumps(preservation,indent=2)+'\n')
O=Path('/media/prodigy/Coding-Programming/Repos/nicotineplus-plugins');before=json.loads((D/'owner-before.json').read_text());git=lambda *a:subprocess.check_output(['git','-C',str(O),*a]);assert git('rev-parse','HEAD').decode().strip()==before['head'];assert sha(git('status','--porcelain=v1','-z'))==before['status_sha256']
for n,h in before['tracked_file_sha256'].items():assert sha((O/n).read_bytes())==h,n
assert sha((O/'AGENTS.md').read_bytes())==before['ignored_owner_instructions_sha256']
(D/(key+'-owner-preservation.json')).write_text(json.dumps({'passed':True,'head_status_all_tracked_and_ignored_instructions_unchanged':True,'tracked_files_checked':len(before['tracked_file_sha256'])},indent=2)+'\n');print(json.dumps(preservation))
