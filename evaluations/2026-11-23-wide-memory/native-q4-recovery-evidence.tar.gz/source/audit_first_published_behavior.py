"""Independent published-byte preservation and frozen public-callback checks."""
from pathlib import Path
import json,subprocess,hashlib,time
D=Path(__file__).resolve().parent;O=D/'q4-first-published-behavior-audit';O.mkdir(exist_ok=False);EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-wide-memory-20261123';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';published=D/'q4-first-published-test-adequacy/published/source';assert json.loads((D/'q4-first-published-test-adequacy/result.json').read_text())['head']=='fad4f886b6cec54a4f9fc3679409e019f1c81e54'
source=O/'preservation/source';source.mkdir(parents=True)
files={str(f.relative_to(published)):f.read_bytes()for f in published.rglob('*')if f.is_file()}
for f in(D/'baseline/tests').rglob('*'):
 if f.is_file():files['tests/'+str(f.relative_to(D/'baseline/tests'))]=f.read_bytes()
for name,data in files.items():
 q=source/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
(O/'preservation/source-sha256.json').write_text(json.dumps({n:hashlib.sha256(data).hexdigest()for n,data in sorted(files.items())},indent=2)+'\n')
def mount(path,target):return['--mount','type=bind,source='+EP+'/'+str(path.relative_to(D))+',target='+target+',readonly']
def run(kind,src,args,extra=[]):
 out=O/kind;out.mkdir(exist_ok=True);a=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','384m','--memory-swap','384m','--cpus','1','--tmpfs','/tmp:rw,size=64m',*mount(src,'/workspace'),*extra,'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','-w','/workspace','--entrypoint','python',IMAGE,*args];t=time.monotonic();r=subprocess.run(a,capture_output=True,text=True,timeout=90);(out/'test.log').write_text(r.stdout+r.stderr);x={'returncode':r.returncode,'seconds':time.monotonic()-t,'argv':a};(out/'run.json').write_text(json.dumps(x,indent=2)+'\n');assert r.returncode==0,(kind,r.stdout[-2000:],r.stderr[-800:]);return r.stdout
text=run('preservation',source,['-m','pytest','-q','-p','no:cacheprovider','tests']);assert '83 passed'in text
run('independent',published,['/state/initial_checks.py','/workspace','spam_enforcement'],mount(D/'initial_checks.py','/state/initial_checks.py')+mount(D/'baseline/tests','/state/baseline/tests'))
x={'passed':True,'pinned_published_commit':'fad4f886b6cec54a4f9fc3679409e019f1c81e54','original_unchanged_suite':'83 passed','independent_checker_sha256':hashlib.sha256((D/'initial_checks.py').read_bytes()).hexdigest(),'independent_public_callback_checks_exit':0,'not_actor_feedback':True,'stage':'Initial fix only; README followup and feature followup remain separate','whole_workflow_quality_or_reliability_not_established':True};(O/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
