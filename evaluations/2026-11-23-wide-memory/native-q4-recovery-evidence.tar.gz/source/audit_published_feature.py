"""Independent pinned-commit tests and adequacy controls; no actor feedback."""
from pathlib import Path
import json,subprocess,hashlib,time,ast,re
D=Path(__file__).resolve().parent;O=D/'q4-published-feature-audit';O.mkdir(exist_ok=False);EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-wide-memory-20261123';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae';root=D/'worktrees/q4-spam-published-feature-head';head=subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'rev-parse','HEAD'],text=True).strip();assert head=='1c43b71c7b8461c7ad7caad0232388187ab8ae43'
def inventory(root):
 files={}
 for f in root.rglob('*'):
  rel=f.relative_to(root)
  if any(x in {'.git','__pycache__','.pytest_cache'}for x in rel.parts)or f.name=='AGENTS.md':continue
  assert not f.is_symlink()
  if f.is_file():files[str(rel)]=f.read_bytes()
 return files
candidate=inventory(root);old=inventory(D/'native-q4-recovery-cp2/spam_enforcement/q4/turn1/remote-grade/source');base=inventory(D/'baseline');changed=[n for n in sorted(set(old)|set(candidate))if old.get(n)!=candidate.get(n)];assert changed==['autospamignore/README.md','autospamignore/__init__.py','tests/test_autospamignore.py']
path='tests/test_autospamignore.py';a=next(n for n in ast.parse(old[path]).body if isinstance(n,ast.ClassDef)and n.name=='AutoSpamIgnoreTests');b=next(n for n in ast.parse(candidate[path]).body if isinstance(n,ast.ClassDef)and n.name==a.name);am={n.name:n for n in a.body if isinstance(n,ast.FunctionDef)};bm={n.name:n for n in b.body if isinstance(n,ast.FunctionDef)};added=sorted(set(bm)-set(am));assert len(added)==6;assert all(ast.dump(bm[n])==ast.dump(am[n])for n in am if n!='send');assert [v.arg for v in bm['send'].args.args][:len(am['send'].args.args)]==[v.arg for v in am['send'].args.args];assert ast.dump(bm['send'].args.defaults[-1])==ast.dump(ast.Constant(value='message'))
def snapshot(kind,files):
 out=O/kind;out.mkdir();src=out/'source';src.mkdir()
 for name,data in files.items():
  f=src/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 (out/'source-sha256.json').write_text(json.dumps({n:hashlib.sha256(data).hexdigest()for n,data in sorted(files.items())},indent=2)+'\n');return src
def mount(path,target):return['--mount','type=bind,source='+EP+'/'+str(path.relative_to(D))+',target='+target+',readonly']
def run(kind,src,args,extra=[]):
 out=O/kind;out.mkdir(exist_ok=True);a=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','384m','--memory-swap','384m','--cpus','1','--tmpfs','/tmp:rw,size=64m',*mount(src,'/workspace'),*extra,'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','-w','/workspace','--entrypoint','python',IMAGE,*args];t=time.monotonic();r=subprocess.run(a,capture_output=True,text=True,timeout=90);(out/'test.log').write_text(r.stdout+r.stderr);(out/'run.json').write_text(json.dumps({'returncode':r.returncode,'seconds':time.monotonic()-t,'argv':a},indent=2)+'\n');return r
pytest=['-m','pytest','-q','-p','no:cacheprovider','tests']
fixed=snapshot('published',candidate);r=run('published',fixed,pytest);assert r.returncode==0 and '92 passed'in r.stdout,r.stdout[-2000:]
merged=dict(candidate);merged.update({n:data for n,data in base.items()if n.startswith('tests/')});r=run('preservation',snapshot('preservation',merged),pytest);assert r.returncode==0 and '83 passed'in r.stdout,r.stdout[-2000:]
merged=dict(old);merged[path]=candidate[path];r=run('prefeature_with_new_tests',snapshot('prefeature_with_new_tests',merged),pytest);assert r.returncode==1 and 'ERROR collecting'not in r.stdout and 'AttributeError'not in r.stdout,(r.returncode,r.stdout[-3000:]);failed=re.findall(r'^FAILED ([^\n]+)',r.stdout,re.M);assert any('test_rule_alert_cooldown_suppresses_repeats_in_log_only'in s for s in failed)and any('test_rule_alert_cooldown_is_configurable'in s for s in failed)
common=mount(D/'initial_checks.py','/state/initial_checks.py')+mount(D/'baseline/tests','/state/baseline/tests')
for kind,checker in [('independent-initial','initial_checks.py'),('independent-feature','feature_checks.py')]:
 extra=common+(mount(D/checker,'/state/'+checker)if checker!='initial_checks.py'else[]);r=run(kind,fixed,['/state/'+checker,'/workspace','spam_enforcement'],extra);assert r.returncode==0,(kind,r.stdout[-2500:],r.stderr[-1200:])
x={'passed':True,'published_commit':head,'prefeature_commit':'c17f6603e36c4b8d712ad78bbf20dd7c218bb852','changed_paths':changed,'published_suite':'92 passed','original_unchanged_suite':'83 passed','old_test_methods_unchanged_except_compatible_send_fixture_extension':True,'new_test_methods':added,'prefeature_genuine_assertion_failures':failed,'private_initial_and_feature_checks_exit':0,'not_actor_feedback':True,'limitations':['Independent fake-peer callbacks and original suite, not actual Nicotine+ GUI/network.','New independence test varies user/room/rule together rather than isolating each axis; phrase repetition, bounds and all-user reset need separate source/behavior audits.','A green authored suite alone does not establish correctness.']};(O/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
