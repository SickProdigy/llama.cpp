"""Independent initial regression and documentation-semantic controls."""
from pathlib import Path
import json,subprocess,hashlib,ast,time
D=Path(__file__).resolve().parent;S=D/'native-q4-fresh-cp2/queued_announcements';O=D/'q4-fresh-announcer-feature-audit';O.mkdir(exist_ok=False);EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-wide-memory-20261123';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
def inv(root):
 out={}
 for f in root.rglob('*'):
  assert not f.is_symlink()
  if f.is_file():out[str(f.relative_to(root))]=f.read_bytes()
 return out

base=inv(S/'q4/turn1/remote-grade/source');candidate=inv(S/'q4/turn2/remote-grade/source');path='tests/test_announcer.py';old=ast.parse(base[path]);new=ast.parse(candidate[path]);names={n.name for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};added=[n.name for n in new.body if isinstance(n,ast.FunctionDef)and n.name not in names];new.body=[n for n in new.body if not(isinstance(n,ast.FunctionDef)and n.name in added)];assert len(added)==5 and ast.dump(old)==ast.dump(new)
def snapshot(kind,files):
 out=O/kind;out.mkdir();root=out/'source';root.mkdir()
 for name,b in files.items():
  q=root/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 (out/'source-sha256.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(files.items())},indent=2)+'\n');return root
def mount(path,target):return['--mount','type=bind,source='+EP+'/'+str(path.relative_to(D))+',target='+target+',readonly']
def run(kind,src,args,extra=[]):
 out=O/kind;out.mkdir(exist_ok=True);a=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','384m','--memory-swap','384m','--cpus','1','--tmpfs','/tmp:rw,size=64m',*mount(src,'/workspace'),*extra,'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','-w','/workspace','--entrypoint','python',IMAGE,*args];t=time.monotonic();r=subprocess.run(a,capture_output=True,text=True,timeout=90);(out/'test.log').write_text(r.stdout+r.stderr);(out/'run.json').write_text(json.dumps({'argv':a,'returncode':r.returncode,'seconds':time.monotonic()-t},indent=2)+'\n');return r

pytest=['-m','pytest','-q','-p','no:cacheprovider','tests'];r=run('published',snapshot('published',candidate),pytest);assert r.returncode==0 and '91 passed'in r.stdout,r.stdout[-3000:];merged=dict(base);merged[path]=candidate[path];r=run('prefeature_with_new_tests',snapshot('prefeature_with_new_tests',merged),pytest);assert r.returncode==1,r.stdout[-3000:]
x={'passed':True,'commit':'ec238323fed7acee5ad356007483473f1a34a858','existing_test_AST_preserved':True,'new_tests':added,'published_test_summary':(O/'published/test.log').read_text().splitlines()[-1],'prefeature_test_summary':r.stdout.splitlines()[-1],'not_actor_feedback':True};(O/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
