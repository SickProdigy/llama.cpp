"""Independent initial regression and documentation-semantic controls."""
from pathlib import Path
import json,subprocess,hashlib,ast,time
D=Path(__file__).resolve().parent;S=D/'native-q4-fresh-cp2/queued_announcements';O=D/'q4-fresh-announcer-initial-audit';O.mkdir(exist_ok=False);EP='/srv/samba/media/Documents/prodigy/Coding-Programming/docker-containers2/llama.cpp/.git/hermes-wide-memory-20261123';IMAGE='sha256:97b08c5ce375113809299fc8c5dd86ae60600f618158d15fe4ad5fc9d7f4b7ae'
def inv(root):
 out={}
 for f in root.rglob('*'):
  assert not f.is_symlink()
  if f.is_file():out[str(f.relative_to(root))]=f.read_bytes()
 return out
base=inv(D/'baseline');candidate=inv(S/'q4/turn0/remote-grade/source');doc=inv(S/'q4/turn1/remote-grade/source');assert sorted(n for n in set(candidate)|set(doc)if candidate.get(n)!=doc.get(n))==['announcer/README.md'];path='tests/test_announcer.py';old=ast.parse(base[path]);new=ast.parse(candidate[path]);names={n.name for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};added=[n.name for n in new.body if isinstance(n,ast.FunctionDef)and n.name not in names];new.body=[n for n in new.body if not(isinstance(n,ast.FunctionDef)and n.name in added)];assert len(added)==3 and ast.dump(old)==ast.dump(new)
def snapshot(kind,files):
 out=O/kind;out.mkdir();root=out/'source';root.mkdir()
 for name,b in files.items():
  q=root/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 (out/'source-sha256.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(files.items())},indent=2)+'\n');return root
def mount(path,target):return['--mount','type=bind,source='+EP+'/'+str(path.relative_to(D))+',target='+target+',readonly']
def run(kind,src,args,extra=[]):
 out=O/kind;out.mkdir(exist_ok=True);a=['docker','run','--rm','--pull','never','--runtime','runc','--user','1000:1000','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--label','hermes.wide.study=20261123','--memory','384m','--memory-swap','384m','--cpus','1','--tmpfs','/tmp:rw,size=64m',*mount(src,'/workspace'),*extra,'-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/workspace','-w','/workspace','--entrypoint','python',IMAGE,*args];t=time.monotonic();r=subprocess.run(a,capture_output=True,text=True,timeout=90);(out/'test.log').write_text(r.stdout+r.stderr);(out/'run.json').write_text(json.dumps({'argv':a,'returncode':r.returncode,'seconds':time.monotonic()-t},indent=2)+'\n');return r
pytest=['-m','pytest','-q','-p','no:cacheprovider','tests'];fixed=snapshot('published',candidate);r=run('published',fixed,pytest);assert r.returncode==0 and '86 passed'in r.stdout,r.stdout[-2000:];merged=dict(base);merged[path]=candidate[path];r=run('original_with_new_tests',snapshot('original_with_new_tests',merged),pytest);assert r.returncode==1 and '3 failed, 83 passed'in r.stdout and 'AttributeError'not in r.stdout,r.stdout[-3000:]
control=O/'reenable_before_pending_callback.py';control.write_text('''from pathlib import Path
import importlib.util,json,pytest
spec=importlib.util.spec_from_file_location('immutable_announcer','/fixtures/test_announcer.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);f.PLUGIN_PATH=Path('/workspace/announcer/__init__.py')
with pytest.MonkeyPatch.context()as mp:
 m=f.module.__wrapped__(mp);p=f.make_plugin(m);p.settings.update(sending_enabled=True,default_rooms='Linux, Books');p.announce_command('Queued',room='Lobby');first,second=m._fake_events.scheduled;p.settings['sending_enabled']=False;first[2](*first[3]);assert p.public_sent==[];p.settings['sending_enabled']=True;second[2](*second[3]);assert [room for room,_ in p.public_sent]==['Books'];assert not p._scheduled and not p._job_replies
 print(json.dumps({'rooms_posted':['Books'],'skipped_Linux_not_retried':True,'reenabling_before_Books_callback_allows_that_send':True,'pending_job_completes':True}))
''');r=run('documentation_semantics',snapshot('documentation_semantics',doc),['/control.py'],mount(control,'/control.py')+mount(D/'baseline/tests/test_announcer.py','/fixtures/test_announcer.py'));assert r.returncode==0,r.stdout+r.stderr
x={'passed':True,'initial_published_commit':'709176ad955c3a4f12d010ad1fd1d7f5efcce079','README_published_commit':'6cdaddcdd242d2600caa65ace04b540b1f75e291','existing_test_AST_preserved':True,'new_tests':added,'all_three_reject_original_bug':'3 failed,83 passed on original implementation;86 pass on published implementation','README_only_incremental_change':True,'documentation_qualification':'Per-callback check is correct, but disabling is not permanent cancellation of all remaining rooms: re-enabling before a later pending callback allows that send. README wording about stopping the remainder needs this qualification. No corrective feedback sent.','not_actor_feedback':True,'initial_source_behavior_pass_independent_of_documentation_qualification':True};(O/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
