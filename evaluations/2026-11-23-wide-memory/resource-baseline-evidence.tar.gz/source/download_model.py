"""One public pinned file; no overwrite, reserve checked throughout, atomic verified finish."""
from pathlib import Path
import json,os,time,hashlib,urllib.request,traceback
D=Path('/state');meta=json.loads((D/'public-model-metadata.json').read_text());repo='netprojects/Qwen3.8-27B-hermes-adapted-GGUF';m=meta[repo];f=next(x for x in m['files']if x['rfilename']=='Qwen3.8-27B-hermes-Q4_K_M.gguf');root=Path('/models');target=root/f['rfilename'];partial=root/('.wide-20261123-'+f['rfilename']+'.part');minimum=100*1024**3
url='https://huggingface.co/'+repo+'/resolve/'+m['revision']+'/'+f['rfilename'];result={'repo':repo,'revision':m['revision'],'file':f['rfilename'],'expected_bytes':f['size'],'expected_sha256':f['lfs']['sha256'],'started_epoch':time.time()}
def free():s=os.statvfs(root);return s.f_bavail*s.f_frsize
def save(): (D/'download-status.json').write_text(json.dumps(result,indent=2)+'\n')
try:
 assert not target.exists()and not partial.exists(),'Refusing to overwrite any existing or partial model'
 assert free()-f['size']>=minimum+2*1024**3,'Insufficient reserve for this download'
 save();h=hashlib.sha256();count=0;last=time.monotonic()
 with urllib.request.urlopen(url,timeout=90)as response,partial.open('xb')as out:
  while True:
   block=response.read(1024*1024)
   if not block:break
   assert free()-len(block)>=minimum,'Disk reserve guard'
   count+=len(block);assert count<=f['size'],'Unexpected file size';out.write(block);h.update(block)
   if time.monotonic()-last>=15:result.update(received_bytes=count,free_bytes=free(),updated_epoch=time.time());save();last=time.monotonic()
  out.flush();os.fsync(out.fileno())
 assert count==f['size']and h.hexdigest()==f['lfs']['sha256'],'Downloaded bytes/hash mismatch'
 assert not target.exists();partial.rename(target);result.update(complete=True,received_bytes=count,actual_sha256=h.hexdigest(),finished_epoch=time.time(),free_bytes=free());save();print(json.dumps(result),flush=True)
except BaseException as e:result.update(complete=False,error=type(e).__name__+': '+str(e),finished_epoch=time.time());save();raise
