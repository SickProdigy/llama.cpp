"""Derive memory/token/transport observations after a pilot restores runtime."""
from pathlib import Path
import json,re,sys,hashlib
D=Path(__file__).resolve().parent;key=sys.argv[1];s=D/('resource-'+key);rest=json.loads((s/'runtime-restoration.json').read_text());assert rest['restored'];finished=json.loads((s/'finished.json').read_text());out=[]
for layout in sorted(s.glob('layout*')):
 rows=[json.loads(line)for line in(layout/'samples.jsonl').read_text().splitlines()];values=[]
 for row in rows:
  x={'epoch':row['epoch'],'host':row['host']};segments={}
  for chunk in row.get('backend_memory_raw','').split('FILE ')[1:]:
   path,_,content=chunk.partition('\n');segments[path.strip()]=content
  for n in ['memory.current','memory.peak','memory.swap.current']:
   content=segments.get('/sys/fs/cgroup/'+n,'').strip();x[n]=int(content.splitlines()[0])if content and content.splitlines()[0].isdigit()else None
  stats=dict(line.split()for line in segments.get('/sys/fs/cgroup/memory.stat','').splitlines()if len(line.split())==2)
  for n in ['anon','file','kernel']:x['cgroup_'+n]=int(stats[n])if n in stats else None
  for n in ['Pss','Pss_Anon','Pss_File','Rss','Swap']:
   m=re.search(r'^'+n+r':\s*(\d+) kB',segments.get('/proc/1/smaps_rollup',''),re.M);x[n]=int(m.group(1))*1024 if m else None
  try:gpu=[int(v.strip())for v in row['gpu_csv'].split(',')];x.update(gpu_used_MiB=gpu[1],gpu_free_MiB=gpu[2],gpu_util_percent=gpu[3])
  except(ValueError,KeyError,IndexError):pass
  values.append(x)
 peak=lambda n:max((x[n]for x in values if x.get(n)is not None),default=None)
 minimum=lambda n:min((x[n]for x in values if x.get(n)is not None),default=None)
 probes=[]
 for name in ['tool','prompt16000','prompt60000']:
  p=layout/name
  if not(p/'capture.json').exists():continue
  cap=json.loads((p/'capture.json').read_text());raw=(p/'response.bin').read_bytes();assert hashlib.sha256(raw).hexdigest()==cap['response_sha256'];input=json.loads((p/'input.json').read_text());assert cap['usage']['prompt_tokens']==input['rendered_tokens'];probes.append({'name':name,'seconds':cap['seconds'],'actual_input_tokens':input['rendered_tokens'],'output_tokens':cap['usage']['completion_tokens'],'finish_reason':cap['finish_reason'],'body_complete':cap['body_complete']})
 result=json.loads((layout/'result.json').read_text());out.append({'result':result,'samples':len(values),'probes':probes,'memory_peak_bytes':{n:peak(n)for n in ['memory.current','memory.peak','memory.swap.current','cgroup_anon','cgroup_file','cgroup_kernel','Pss','Pss_Anon','Pss_File','Swap']},'gpu_peak_used_MiB':peak('gpu_used_MiB'),'gpu_minimum_free_MiB':minimum('gpu_free_MiB'),'host_min_available_bytes':min(x['host']['MemAvailable']for x in values),'load_seconds':json.loads((layout/'ready.json').read_text())['seconds']if(layout/'ready.json').exists()else None,'build':json.loads((layout/'ready.json').read_text())['props']['build_info']if(layout/'ready.json').exists()else None})
before=json.loads((s/'host-before.json').read_text());after=rest['host_after'];summary={'model':key,'layouts':out,'runtime_restored':True,'host_global_swap_activity_delta_pages':{k:after[k]-before[k]for k in ['pswpin_pages','pswpout_pages']},'swap_scope':'Global host deltas include unrelated services; process/cgroup swap tracked separately. No attribution to model from global counters alone.','memory_scope':'Charged cgroup memory includes reclaimable file cache. Process PSS and anon/file recorded separately. Tiny observed cgroup limit overshoots are reported, not hidden. Driver/shared accounting is not proven solely by the cap.','load_scope':'Full model SHA read warms file cache; concurrent model download and ambient host workload are uncontrolled. Not a cold-load benchmark or a quantization-only speed comparison.','not_fresh_agent_quality':True};(D/('resource-'+key+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
