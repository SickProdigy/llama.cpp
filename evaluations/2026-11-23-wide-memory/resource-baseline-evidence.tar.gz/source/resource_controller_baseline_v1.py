"""Bounded isolated memory pilots; no actor, forge credentials or grading inputs."""
from pathlib import Path
import sys,os,json,time,hashlib,subprocess,urllib.request,threading,signal,traceback
D=Path('/state');KEY=sys.argv[1];assert KEY in ['baseline','adapted_27B_Q4'];P=json.loads((D/'resource-protocol.json').read_text());S=D/('resource-'+KEY);S.mkdir(exist_ok=False)
MODEL=P[KEY];ALIAS='wide-'+KEY.lower();NET='hermes-wide-resource';MAIN='hermes-wide-resource-model';BACKEND=P['backend_image'];owned=None;network=None;stopped=False;before={};monitor_stop=threading.Event();abort=threading.Event();thread=None

def save(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,indent=2)+'\n')
def event(kind,**kw):
 row={'epoch':time.time(),'kind':kind,**kw}
 with(S/'events.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
def docker(*args,check=True,timeout=180):
 z=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout)
 if check and z.returncode:raise RuntimeError('Docker '+args[0]+' failed: '+z.stderr[-1200:])
 return z.stdout

def inspect(name):return json.loads(docker('inspect',name))[0]
def state(name):
 x=inspect(name);return {'id':x['Id'],'image':x['Image'],'config_sha256':hashlib.sha256(json.dumps({k:x[k]for k in ['Image','Config','HostConfig','Mounts']},sort_keys=True).encode()).hexdigest(),'running':x['State']['Running'],'started':x['State']['StartedAt'],'restarts':x['RestartCount']}
def http(host,path,body=None,timeout=60):
 req=urllib.request.Request('http://'+host+':11430'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=timeout)as response:raw=response.read()
 return json.loads(raw),raw

def ready(name,alias,ctx,timeout):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  if abort.is_set():raise RuntimeError('Host memory guard')
  if not inspect(name)['State']['Running']:raise RuntimeError('Backend exited before ready')
  try:
   props,_=http(name,'/props',timeout=10);health,_=http(name,'/health',timeout=10)
   if props['model_alias']==alias and props['default_generation_settings']['n_ctx']==ctx and health['status']=='ok':return props
  except(OSError,ValueError,KeyError):pass
  time.sleep(2)
 raise TimeoutError('Backend readiness expired')

def host_memory():
 mem={k:int(v.split()[0])*1024 for k,v in(line.split(':',1)for line in Path('/proc/meminfo').read_text().splitlines())};vm=dict(line.split()for line in Path('/proc/vmstat').read_text().splitlines());return {'MemAvailable':mem['MemAvailable'],'SwapFree':mem['SwapFree'],'pswpin_pages':int(vm['pswpin']),'pswpout_pages':int(vm['pswpout'])}
def monitor(out):
 paths=['/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.peak','/sys/fs/cgroup/memory.swap.current','/sys/fs/cgroup/memory.events','/sys/fs/cgroup/memory.stat','/proc/1/status','/proc/1/smaps_rollup']
 command='for p in "$@"; do printf "FILE %s\\n" "$p"; cat "$p"; done'
 while not monitor_stop.is_set():
  row={'epoch':time.time(),'host':host_memory()}
  try:
   row['backend_memory_raw']=docker('exec',MAIN,'/bin/sh','-c',command,'_',*paths,check=False,timeout=20)
   row['gpu_csv']=docker('exec',MAIN,'nvidia-smi','--query-gpu=memory.total,memory.used,memory.free,utilization.gpu,utilization.memory','--format=csv,noheader,nounits',check=False,timeout=20).strip()
   if row['host']['MemAvailable']<P['host_low_available_abort_bytes']:
    abort.set();row['host_memory_guard_triggered']=True
    if owned and inspect(MAIN)['Id']==owned:docker('stop','-t','10',owned,check=False)
  except Exception as e:row['measurement_error']=type(e).__name__+': '+str(e)
  with out.open('a')as f:f.write(json.dumps(row)+'\n')
  monitor_stop.wait(5)

def measure(body):
 prompt,_=http(MAIN,'/apply-template',{'messages':body['messages'],'tools':body.get('tools',[]),'chat_template_kwargs':body['chat_template_kwargs']});tokens,_=http(MAIN,'/tokenize',{'content':prompt['prompt'],'add_special':False,'parse_special':True});return len(tokens['tokens'])
def request(messages):return {'model':ALIAS,'messages':messages,'temperature':0.8,'top_p':1,'top_k':0,'min_p':0,'repeat_penalty':1,'presence_penalty':0,'seed':20261123,'chat_template_kwargs':{'enable_thinking':False},'max_tokens':512,'stream':False}
def call(out,body,kind):
 out.mkdir();save(out/'request.json',body);count=measure(body);save(out/'input.json',{'rendered_tokens':count,'context':layout['context'],'kind':kind});assert count+body['max_tokens']<layout['context'];event('probe_start',probe=kind,input_tokens=count)
 start=time.monotonic();result,raw=http(MAIN,'/v1/chat/completions',body,P['per_probe_deadline_seconds']);elapsed=time.monotonic()-start;(out/'response.bin').write_bytes(raw);usage=result.get('usage',{});assert isinstance(usage.get('prompt_tokens'),int);assert usage['prompt_tokens']==count,(count,usage);assert result.get('choices')
 save(out/'capture.json',{'body_complete':True,'seconds':elapsed,'usage':usage,'finish_reason':result['choices'][0].get('finish_reason'),'response_sha256':hashlib.sha256(raw).hexdigest(),'timings':result.get('timings')});event('probe_end',probe=kind,seconds=elapsed);return result

def stop_model():
 global owned,thread
 monitor_stop.set()
 if thread:thread.join(45);assert not thread.is_alive();thread=None
 if owned:
  assert inspect(MAIN)['Id']==owned;x=inspect(MAIN);save(current/'exit-state.json',{'running':x['State']['Running'],'exit_code':x['State']['ExitCode'],'oom_killed':x['State']['OOMKilled'],'memory_limit':x['HostConfig']['Memory'],'memory_swap_limit':x['HostConfig']['MemorySwap']});z=subprocess.run(['docker','logs',owned],capture_output=True);(current/'backend.log').write_bytes(z.stdout+z.stderr);docker('rm','-f','-v',owned);owned=None

def guard(sig,frame):raise TimeoutError('Stage signal/guard '+str(sig))
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,guard)
signal.alarm(P['per_model_stage_guard_seconds'])
try:
 registration=json.loads((D/'resource-controller-registration.json').read_text());assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==registration['controller_sha256'];assert hashlib.sha256((D/'resource-protocol.json').read_bytes()).hexdigest()==registration['protocol_sha256']
 before={n:state(n)for n in ['hermes','llama-cpp','hermes-codex']};assert all(x['running']for x in before.values());save(S/'runtime-before.json',before);save(S/'host-before.json',host_memory());model=Path('/models')/MODEL['file'];assert model.is_file()
 h=hashlib.sha256()
 with model.open('rb')as f:
  for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
 assert h.hexdigest()==MODEL['sha256'];save(S/'model-identity.json',{'file':model.name,'bytes':model.stat().st_size,'sha256':h.hexdigest(),'OS_file_cache_warmed_by_hash_read':True})
 assert subprocess.run(['docker','inspect',MAIN],capture_output=True).returncode!=0
 network=docker('network','create','--internal',NET).strip();docker('network','connect',NET,os.environ['HOSTNAME']);stopped=True;docker('stop','-t','60','hermes');docker('stop','-t','60','llama-cpp')
 results=[]
 for index,layout in enumerate(MODEL['layouts']):
  current=S/('layout'+str(index));current.mkdir();abort.clear();monitor_stop.clear();passed=False
  try:
   launch=['--network',NET,'--gpus','all','--memory','8g','--memory-swap','8g','--cpus','8','--volumes-from','llama-cpp:ro','--read-only','--tmpfs','/tmp:rw,size=128m','--no-healthcheck',BACKEND,'-m','/models/'+MODEL['file'],'--alias',ALIAS,'--jinja','--host','0.0.0.0','--port','11430','--ctx-size',str(layout['context']),'--parallel','1','--cache-type-k','q4_0','--cache-type-v','q4_0','--cache-ram','512','--fit','off','-ngl',str(layout['gpu_layers']),'--threads','8','--threads-batch','8','--poll','0','--poll-batch','0','-b','512','-ub','128','--n-predict','512'];start=time.monotonic();owned=docker('run','-d','--pull','never','--name',MAIN,*launch).strip();save(current/'launch.json',{'argv':launch,'layout':layout,'container_id':owned});thread=threading.Thread(target=monitor,args=(current/'samples.jsonl',),daemon=True);thread.start();props=ready(MAIN,ALIAS,layout['context'],P['load_deadline_seconds']);save(current/'ready.json',{'seconds':time.monotonic()-start,'props':props});event('backend_ready',layout=layout)
   body=request([{'role':'user','content':'Use lookup_record to retrieve the record named memory-probe. Make the tool call now.'}]);body['tools']=[{'type':'function','function':{'name':'lookup_record','description':'Retrieve one named local test record.','parameters':{'type':'object','properties':{'name':{'type':'string'}},'required':['name'],'additionalProperties':False}}}];result=call(current/'tool',body,'one_tool_call');calls=result['choices'][0]['message'].get('tool_calls')or[];tool_ok=False
   for c in calls:
    try:tool_ok=tool_ok or (c.get('function',{}).get('name')=='lookup_record'and json.loads(c['function']['arguments'])=={'name':'memory-probe'})
    except(ValueError,TypeError,KeyError):pass;save(current/'tool-check.json',{'valid_tool_call':tool_ok,'not_actual_MCP_routing':True})
   for target in P['synthetic_prompt_targets']:
    lines=1000
    for attempt in range(5):
     content='Resource capacity probe. Read the records, then reply with ONLY the value of FINAL_MARKER.\n'+'\n'.join('Record '+str(i)+': amber cedar lake stone north south.'for i in range(lines))+'\nFINAL_MARKER=capacity-check-'+str(target)
     body=request([{'role':'user','content':content}]);actual=measure(body)
     if abs(actual-target)<=target*.05:break
     lines=max(1,round(lines*target/actual))
    else:raise RuntimeError('Synthetic prompt sizing failed')
    result=call(current/('prompt'+str(target)),body,'synthetic_'+str(target));save(current/('prompt'+str(target))/'retrieval-check.json',{'expected':'capacity-check-'+str(target),'content':result['choices'][0]['message'].get('content'),'not_agent_quality':True})
   passed=True;results.append({'layout':layout,'resource_probes_completed':True,'tool_call_correct':tool_ok,'no_agent_quality_claim':True});save(current/'result.json',results[-1])
  except Exception as e:
   result={'layout':layout,'resource_probes_completed':False,'error':type(e).__name__+': '+str(e),'no_model_quality_score':True};results.append(result);save(current/'result.json',result);event('layout_error',error=str(e))
  finally:stop_model()
  if passed:break
 save(S/'finished.json',{'results':results,'model':KEY,'not_agent_qualification':True})
except BaseException as e:save(S/'controller-error.json',{'error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc()});event('controller_error',error=str(e))
finally:
 signal.alarm(0);errors=[]
 try:
  if owned:stop_model()
 except BaseException as e:errors.append(str(e))
 try:
  if stopped:abort.clear();docker('start','llama-cpp');ready('llama-cpp','qwen3.6-14b-a3b-vibeforged-v2-q4_k_m',98304,600);docker('start','hermes')
  after={n:state(n)for n in before}
  for n,b in before.items():assert all(after[n][k]==b[k]for k in ['id','image','config_sha256','running'])
  if before:assert after['hermes-codex']==before['hermes-codex']
  if network:
   docker('network','disconnect',NET,os.environ['HOSTNAME']);net=json.loads(docker('network','inspect',NET))[0];assert net['Id']==network and not net['Containers'];docker('network','rm',network)
  save(S/'runtime-restoration.json',{'restored':True,'after':after,'cleanup_errors':errors,'host_after':host_memory()});event('original_runtime_restored')
 except BaseException as e:save(S/'RESTORATION-ERROR.json',{'error':str(e),'traceback':traceback.format_exc(),'cleanup_errors':errors});event('restoration_error',error=str(e))
