from pathlib import Path
import json,hashlib,shutil,tarfile
R=Path.cwd();D=R/'.git/hermes-wide-memory-20261123';S=D/'resource-baseline';E=R/'evaluations/2026-11-23-wide-memory';X=D/'resource-baseline-export'
assert json.loads((S/'runtime-restoration.json').read_text())['restored'];assert json.loads((S/'finished.json').read_text())['results'][0]['resource_probes_completed'];assert not X.exists();X.mkdir()
def copy(src,rel):
 f=X/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,f)
def write(rel,value):
 f=X/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(value,indent=2)+'\n')
for n in ['resource-protocol.json','resource-baseline-controller-registration.json','resource-baseline-summary.json','resource-baseline-preservation.json','resource-baseline-owner-preservation.json','resource-baseline-cleanup.json','resource-baseline-tool-audit.json','download-status.json','download-cleanup.json']:
 copy(D/n,Path('controls')/n)
for n in ['resource_controller_baseline_v1.py','summarize_resource.py','download_model.py','export_resource_baseline.py']:copy(D/n,Path('source')/n)
for n in ['events.jsonl','runtime-before.json','model-identity.json','host-before.json','finished.json','runtime-restoration.json']:copy(S/n,Path('runtime')/n)
for n in ['launch.json','samples.jsonl','exit-state.json','backend.log','result.json']:copy(S/'layout0'/n,Path('layout')/n)
r=json.loads((S/'layout0/ready.json').read_text());write('layout/ready.json',{'seconds':r['seconds'],'props':{k:r['props'][k]for k in ['model_alias','model_path','build_info','chat_template_caps','default_generation_settings']if k in r['props']}})
for probe in ['tool','prompt16000','prompt60000']:
 for f in sorted((S/'layout0'/probe).iterdir()):
  if f.is_file():copy(f,Path('probes')/probe/f.name)
manifest={str(f.relative_to(X)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(X.rglob('*'))if f.is_file()};write('manifest.json',{'sha256':manifest,'scope':'Completed resource-only baseline, synthetic requests and scalar/proc measurements; no native profile, credentials, private coding tasks/checks/references or signing keys.'})
archive=E/'resource-baseline-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for f in sorted(X.rglob('*')):
  if f.is_file():t.add(f,arcname=str(f.relative_to(X)),recursive=False)
(E/'resource-baseline-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n');print(json.dumps({'files':len(manifest)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
